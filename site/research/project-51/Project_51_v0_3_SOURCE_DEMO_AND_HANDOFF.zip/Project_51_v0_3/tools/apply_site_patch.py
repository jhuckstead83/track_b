#!/usr/bin/env python3
"""Hash-gated additive patch for the supplied Cerebral Graphix v2.1.0 site.

Default is a dry run. Every target is preflighted before writing. Only the
manifest's fourteen paths are eligible; no Finance or wallet paths are allowed.
"""
from pathlib import Path
import argparse, hashlib, json, os, shutil, tempfile
ROOT=Path(__file__).resolve().parents[1]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--site',type=Path,required=True,help='Unpacked website root, not the area-51 subfolder')
    parser.add_argument('--apply',action='store_true',help='Write after all preflight checks pass')
    parser.add_argument('--backup-dir',type=Path,help='Required for writes; must be outside the site root')
    args=parser.parse_args();site=args.site.resolve()
    if not (site/'area-51/index.html').is_file():parser.error('Expected a full website root containing area-51/index.html')
    manifest=json.loads((ROOT/'audit/DEPLOY_MANIFEST.json').read_text())
    plans=[];failures=[]
    for row in manifest:
        rel=Path(row['path']);parts=rel.parts
        allowed=(rel.as_posix() in {'area-51/index.html',*[f'area-51/{g}/index.html' for g in ['invariant','blackjack-51','telescope-51','memory-51']], 'area-51/assets/project51-mobile-v03.css','area-51/assets/project51-mobile-v03.js','research/project-51/Project_51_v0_3.pdf'} or (len(parts)==3 and parts[:2]==('area-51','rotor-51')))
        if rel.is_absolute() or '..' in parts or not allowed:raise RuntimeError('Disallowed manifest path: '+str(rel))
        target=site/rel;source=ROOT/'website'/rel
        if not target.resolve().is_relative_to(site) or any(p.is_symlink() for p in [target,*list(target.parents)[:len(parts)-1]]):raise RuntimeError('Refusing symlink target: '+str(rel))
        if not source.is_file() or digest(source)!=row['after_sha256']:raise RuntimeError('Package hash mismatch: '+str(rel))
        current=digest(target) if target.is_file() else None
        if current==row['after_sha256']:action='unchanged'
        elif current==row.get('before_sha256'):action='replace' if current else 'add'
        else:failures.append(str(rel));continue
        plans.append((row,source,target,action))
    if failures:raise RuntimeError('Preflight refused; no files written. Reconcile these paths against your newer site: '+', '.join(failures))
    summary={a:sum(x[3]==a for x in plans) for a in ['add','replace','unchanged']}
    if not args.apply:print(json.dumps({'mode':'DRY RUN','plan':summary,'files':[{'path':x[0]['path'],'action':x[3]} for x in plans]},indent=2));return
    if args.backup_dir is None:parser.error('--backup-dir is required with --apply')
    backup=args.backup_dir.resolve()
    if backup==site or backup.is_relative_to(site):parser.error('Backup directory must be outside the website')
    for row,source,target,action in plans:
        if action=='unchanged':continue
        if target.exists():
            old=backup/row['path']
            if old.exists() and digest(old)!=digest(target):raise RuntimeError('Existing backup conflicts: '+str(old))
    for row,source,target,action in plans:
        if action=='unchanged':continue
        if target.exists():
            old=backup/row['path'];old.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,old)
        target.parent.mkdir(parents=True,exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=target.parent,delete=False) as f:f.write(source.read_bytes());temp=Path(f.name)
        os.chmod(temp,0o644);os.replace(temp,target)
        if digest(target)!=row['after_sha256']:raise RuntimeError('Post-write mismatch: '+str(target))
    backup.mkdir(parents=True,exist_ok=True)
    (backup/'PROJECT51_PATCH_RECEIPT.json').write_text(json.dumps({'changes':summary,'manifest':manifest},indent=2)+'\n')
    print(json.dumps({'mode':'APPLIED','changes':summary,'backup':str(backup)},indent=2))
if __name__=='__main__':main()
