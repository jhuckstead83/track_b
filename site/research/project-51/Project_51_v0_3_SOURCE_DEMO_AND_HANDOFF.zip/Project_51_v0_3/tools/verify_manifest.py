#!/usr/bin/env python3
"""Verify all delivered files against SHA256SUMS.txt. Does not modify the package."""
from pathlib import Path
import hashlib,sys
root=Path(__file__).resolve().parents[1];bad=[];count=0
for line in (root/'SHA256SUMS.txt').read_text().splitlines():
    if not line.strip():continue
    expected,rel=line.split('  ',1);p=root/rel
    if not p.resolve().is_relative_to(root):raise RuntimeError('Unsafe manifest path')
    actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
    if actual!=expected:bad.append(rel)
    count+=1
if bad:print('FAIL: '+', '.join(bad),file=sys.stderr);sys.exit(1)
print(f'PASS: {count} delivered files match SHA256SUMS.txt')
