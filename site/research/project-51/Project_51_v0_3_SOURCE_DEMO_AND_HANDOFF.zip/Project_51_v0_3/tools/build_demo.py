#!/usr/bin/env python3
"""Build the dependency-free single HTML demo from the modular website source."""
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'website/area-51/rotor-51'
text = (SRC / 'index.html').read_text()
text = text.replace('<link rel="stylesheet" href="style.css">', '<style>\n'+(SRC/'style.css').read_text()+'\n</style>')
# Place scripts at the end so they run after the document has been parsed.
scripts=[]
for name in ('data.js','engine.js','tokens.js','app.js'):
    text = text.replace(f'<script defer src="{name}"></script>', '')
    code=(SRC/name).read_text()
    if '</script' in code.lower():raise ValueError('Unsafe script delimiter in '+name)
    scripts.append('<script>\n'+code+'\n</script>')
text=text.replace('</body>', '\n'+'\n'.join(scripts)+'\n</body>')
text=text.replace('href="/area-51/"','href="https://cerebralgraphix.com/area-51/"')
text=text.replace('href="/research/project-51/Project_51_v0_3.pdf"','href="../paper/Project_51_v0_3.pdf"')
out=ROOT/'demo/Rotor_51_v0_3_DEMO.html';out.parent.mkdir(exist_ok=True);out.write_text(text)
print(out)
