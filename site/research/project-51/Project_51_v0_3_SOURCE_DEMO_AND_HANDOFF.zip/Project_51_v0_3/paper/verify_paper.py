#!/usr/bin/env python3
"""Exact finite checks for Project 51. Python standard library only.

The proofs in the paper establish the general statements. This runner checks
the declared 51-token instance, the inherited Telescope witness, and all
1,566 stored integer records. It does not run a predictive experiment.
"""
from pathlib import Path
from collections import Counter, defaultdict
from fractions import Fraction
from decimal import Decimal
from itertools import permutations
import datetime
import csv
import hashlib
import json
import math
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'fixtures'))
from derive51 import derive
from T51_replay import REFERENCE, published_cards, pair


def check(name, condition):
    if not condition:
        raise AssertionError(name)
    CHECKS.append(name)


def address(m):
    n = 1
    while n * (n + 1) // 2 < m:
        n += 1
    return n, m - n * (n - 1) // 2


def unrank(integer):
    pool, deck = list(range(1, 52)), []
    for width in range(51, 0, -1):
        digit, integer = divmod(integer, math.factorial(width - 1))
        deck.append(pool.pop(digit))
    assert integer == 0
    return deck


def rank(deck):
    pool, integer = list(range(1, 52)), 0
    for token in deck:
        digit = pool.index(token)
        integer += digit * math.factorial(len(pool) - 1)
        pool.pop(digit)
    return integer


def multiply(A, B):
    return [[sum(a * b for a, b in zip(row, column))
             for column in zip(*B)] for row in A]


def main():
    result = derive()
    sizes = result['class_sizes']
    check('Inherited 51-component class sizes', sizes == [2, 1, 9, 1, 9, 11, 18])
    check('Published alphabet has 51 identities and outside 2C',
          len(REFERENCE) == 51 and '2C' not in REFERENCE)
    with (ROOT/'fixtures/card_alphabet.csv').open() as handle:
        table = list(csv.DictReader(handle))
    check('Published card table agrees with the exact derived identity order',
          [row['card'] for row in table] == REFERENCE and
          [row['component'] for row in table] == [row['component'] for row in result['rows']])
    check('Exact ordering agrees with the published rounded ordering convention',
          result['rows'] == sorted(result['rows'],
              key=lambda r: (-round(r['weight'], 12), ord(r['component']))))
    check('The terminal class is precisely T10 through T27',
          result['lowest'] == [f'T{j}' for j in range(10, 28)])
    classes = [j for j, size in enumerate(sizes, 1) for _ in range(size)]
    token_rows = []
    for m, (card, cls) in enumerate(zip(REFERENCE, classes), 1):
        n, k = address(m)
        color = 1 if card[-1] in 'HD' else -1
        natural = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'].index(card[:-1]) + 1
        token_rows.append(dict(m=m, card=card, cls=cls, n=n, k=k,
                               point=Fraction(k, n), gcd=math.gcd(n, k),
                               color=color, natural=natural, value=min(natural, 10)))
    rules = {
        'weight': lambda r: r['cls'],
        'polar': lambda r: r['point'],
        'joint': lambda r: (r['cls'], r['point']),
        'joint_color': lambda r: (r['cls'], r['point'], r['color']),
        'joint_value': lambda r: (r['cls'], r['point'], r['value']),
        'joint_color_value': lambda r: (r['cls'], r['point'], r['color'], r['value']),
        'joint_natural': lambda r: (r['cls'], r['point'], r['natural']),
        'polar_gcd': lambda r: (r['point'], r['gcd']),
        'polar_color': lambda r: (r['point'], r['color'])}
    labels = {name: {r['m']: rule(r) for r in token_rows} for name, rule in rules.items()}
    groups = {}
    for name, mapping in labels.items():
        groups[name] = defaultdict(list)
        for token, label in mapping.items():
            groups[name][label].append(token)
    summary = {name: {
        'distinct_labels': len(group),
        'arrangements_per_profile': str(math.prod(math.factorial(len(members)) for members in group.values())),
        'ambiguous_groups': [members for members in group.values() if len(members) > 1]}
        for name, group in groups.items()}
    check('Full weight fiber', summary['weight']['arrangements_per_profile'] == '67305847895575919030981099520000000')
    check('Polar labels and fiber', summary['polar']['distinct_labels'] == 30 and summary['polar']['arrangements_per_profile'] == '50164531200')
    check('Joint labels and three ambiguous pairs', summary['joint']['distinct_labels'] == 48 and summary['joint']['ambiguous_groups'] == [[6, 10], [15, 21], [36, 45]])
    check('Joint color leaves pair 6/10', summary['joint_color']['ambiguous_groups'] == [[6, 10]])
    check('Joint blackjack value leaves pair 36/45', summary['joint_value']['ambiguous_groups'] == [[36, 45]])
    check('Joint color and value recover all identities', summary['joint_color_value']['distinct_labels'] == 51)
    check('Joint natural rank recovers all identities', summary['joint_natural']['distinct_labels'] == 51)
    check('Polar plus gcd recovers all identities', summary['polar_gcd']['distinct_labels'] == 51)

    # A small independent permutation enumeration checks the product-of-cells rule.
    p_labels = [0, 0, 0, 1, 1, 1]
    q_labels = [0, 0, 1, 1, 2, 2]
    coarse, joint = Counter(), Counter()
    for perm in permutations(range(6)):
        coarse[tuple(p_labels[i] for i in perm)] += 1
        joint[tuple((p_labels[i], q_labels[i]) for i in perm)] += 1
    check('Six-token enumeration: marginal fibers', set(coarse.values()) == {36})
    check('Six-token enumeration: intersection fibers', set(joint.values()) == {4})

    tail = list(range(34, 52))
    tail_points = defaultdict(list)
    for m in tail:
        tail_points[labels['polar'][m]].append(m)
    check('Exactly one polar pair throughout the 18-token sector',
          [x for x in tail_points.values() if len(x) > 1] == [[36, 45]])
    check('Polar-color labels injective on all 18 terminal identities',
          len({labels['polar_color'][m] for m in tail}) == 18)
    sector_inverse = {labels['polar_color'][m]: m for m in tail}

    paths = [ROOT/'fixtures'/name for name in
             ['zeros_1438.txt', 'zeros_1439_1502.txt', 'zeros_1503_1566.txt']]
    vals = []
    for path in paths:
        for line in path.read_text().splitlines():
            if line.strip():
                scaled = Decimal(line) * 10**12
                assert scaled == int(scaled)
                vals.append(int(scaled))
    check('Exactly 1566 increasing fixed-precision records',
          len(vals) == 1566 and all(a < b for a, b in zip(vals, vals[1:])))
    check('All stored integers are in the 18-factorial sector', 0 <= min(vals) <= max(vals) < math.factorial(18))
    record_views = ['weight', 'polar', 'joint', 'polar_gcd', 'polar_color']
    profiles = {name: set() for name in record_views}
    unchanged = Counter()
    swaps = {pair: Counter() for pair in [(34, 35), (36, 45)]}
    residual = Counter()
    joint_collisions = []
    roundtrips = 0
    sector_roundtrips = 0
    relabel_roundtrips = 0
    symbols = {m: row['component'] for m, row in enumerate(result['rows'], 1)}
    inverse_symbols = {symbol: m for m, symbol in symbols.items()}
    transported = {name: {symbols[m]: label for m, label in mapping.items()}
                   for name, mapping in labels.items()}
    def profile(deck, view):
        return tuple(labels[view][m] for m in deck)
    ambiguous = summary['joint']['ambiguous_groups']
    for index, integer in enumerate(vals, 1):
        deck = unrank(integer)
        next_deck = unrank(integer + 1)
        assert deck[:33] == list(range(1, 34))
        bits = tuple(int(deck.index(a) > deck.index(b)) for a, b in ambiguous)
        residual[''.join(map(str, bits))] += 1
        ordered = {label: members.copy() for label, members in groups['joint'].items()}
        for (a, b), bit in zip(ambiguous, bits):
            if bit:
                ordered[labels['joint'][a]].reverse()
        seen = Counter()
        recovered = []
        for label in profile(deck, 'joint'):
            recovered.append(ordered[label][seen[label]])
            seen[label] += 1
        roundtrips += recovered == deck and rank(recovered) == integer
        recovered_sector = list(range(1, 34)) + [sector_inverse[x] for x in profile(deck, 'polar_color')[33:]]
        sector_roundtrips += recovered_sector == deck and rank(recovered_sector) == integer
        renamed = [symbols[m] for m in deck]
        relabel_roundtrips += (
            rank([inverse_symbols[c] for c in renamed]) == integer and
            all(tuple(transported[name][c] for c in renamed) == profile(deck, name)
                for name in rules))
        for name in record_views:
            p = profile(deck, name)
            profiles[name].add(p)
            unchanged[name] += p == profile(next_deck, name)
        if profile(deck, 'joint') == profile(next_deck, 'joint'):
            joint_collisions.append({'record': index, 'R': str(integer), 'R_plus_1': str(integer+1)})
        for a, b in swaps:
            changed = [b if m == a else a if m == b else m for m in deck]
            for name in record_views:
                swaps[a, b][name] += profile(deck, name) == profile(changed, name)
    check('All joint-profile plus residual round trips', roundtrips == 1566)
    check('All polar-color sector round trips without residual bits', sector_roundtrips == 1566)
    check('Nonnumeric relabeling retains all source ranks and all nine profiles',
          relabel_roundtrips == 1566)
    check('Archive profile counts', {k: len(v) for k, v in profiles.items()} == {
        'weight': 1, 'polar': 1566, 'joint': 1566, 'polar_gcd': 1566, 'polar_color': 1566})
    check('Synthetic adjacent-integer collisions', dict(unchanged) == {
        'weight': 1566, 'polar': 1, 'joint': 1, 'polar_gcd': 0, 'polar_color': 0})
    check('Unique joint neighbor collision at record 168', joint_collisions == [
        {'record': 168, 'R': '347272677584420', 'R_plus_1': '347272677584421'}])
    check('Observed residual frequencies', dict(residual) == {'001': 641, '000': 925})
    check('Equal-weight swap exposed by polar point', swaps[34, 35]['weight'] == 1566 and swaps[34, 35]['polar'] == 0)
    check('Remaining polar swap exposed by color and gcd', swaps[36, 45]['joint'] == 1566 and swaps[36, 45]['polar_color'] == swaps[36, 45]['polar_gcd'] == 0)

    A, B = pair()
    published = published_cards()
    worked = [REFERENCE[m-1] for m in unrank(vals[0])]
    check('Printed worked example is exactly the first stored integer deck',
          worked == published and vals[0] == 14134725141735 and
          Decimal(vals[0]) / 10**12 == Decimal('14.134725141735'))
    a_ids = [REFERENCE.index(card) + 1 for card in published]
    b_ids = a_ids[:-2] + a_ids[-2:][::-1]
    check('Published one-unit swap retains every positional weight',
          profile(a_ids, 'weight') == profile(b_ids, 'weight') and
          rank(a_ids) - rank(b_ids) == 1 and
          math.factorial(15) <= rank(a_ids) < math.factorial(16))
    check('Published Telescope rank pair', [A['integer'], B['integer']] == [14134725141735, 14134725141734])
    check('Published Telescope resolution word and unequal winners',
          A['depth_word'] == B['depth_word'] == 'SCCVSSCVSSCVSCRRR' and
          A['winner_history'] == '33332333233331312' and B['winner_history'] == '33332333233331313')
    paths3 = [A['signed_prefixes'][-3:], B['signed_prefixes'][-3:]]
    readings = [v[0] - 2*v[1] + v[2] for v in paths3]
    check('Published path pair and signed Pascal difference', paths3 == [[1, 0, 1], [1, 2, 1]] and readings == [2, -2])
    check('Both paths have the same parity', [[v % 2 for v in p] for p in paths3] == [[1, 0, 1], [1, 0, 1]])
    check('Full published prefix parity is forced by position',
          all(value % 2 == j % 2 for branch in (A, B)
              for j, value in enumerate(branch['signed_prefixes'])))
    # Compare the decision rule on component marks with the card replay.
    fields = [(letter, {symbols[r['m']]: r[key] for r in token_rows})
              for letter, key in [('V', 'value'), ('R', 'natural'), ('C', 'color')]]
    fields.append(('S', {symbols[m]: 'SHDC'.index(REFERENCE[m-1][-1]) for m in symbols}))
    symbol_results = []
    for ids in (a_ids, b_ids):
        renamed = [symbols[m] for m in ids]
        word, winners, ledger = [], [], []
        for start in range(0, 51, 3):
            triple = renamed[start:start+3]
            live, counts, first = list(range(3)), [3], None
            for letter, field in fields:
                top = max(field[triple[i]] for i in live)
                live = [i for i in live if field[triple[i]] == top]
                counts.append(len(live))
                if len(live) == 1 and first is None:
                    first = letter
            word.append(first)
            winners.append(str(live[0] + 1))
            ledger.append(counts)
        symbol_results.append((''.join(word), ''.join(winners), ledger))
    check('Telescope decisions survive nonnumeric relabeling',
          symbol_results == [(b['depth_word'], b['winner_history'], b['candidate_sizes'])
                             for b in (A, B)])
    for N in range(13):
        U = [[(-1)**j * math.comb(r, j) if j <= r else 0 for r in range(N+1)] for j in range(N+1)]
        M = [[math.comb(r+s, r) for s in range(N+1)] for r in range(N+1)]
        I = [[int(i == j) for j in range(N+1)] for i in range(N+1)]
        check(f'Signed Pascal involution degree {N}', multiply(U, U) == I)
        check(f'Signed Pascal Gram identity degree {N}', multiply(list(map(list, zip(*U))), U) == M)

    tfG = []
    for n in [20, 51]:
        count = Counter(n // math.gcd(n, k) for k in range(1, n+1))
        for s, size in count.items():
            assert size == sum(math.gcd(t, s) == 1 for t in range(1, s+1))
        for k in range(1, n+1):
            g = math.gcd(n, k)
            s, t = n//g, k//g
            assert (n//s)*t == k
        tfG.append({'n': n, 'divisors': sorted(count), 'class_sizes': [count[s] for s in sorted(count)]})
    check('TFG chamber 20 partition', tfG[0]['class_sizes'] == [1, 1, 2, 4, 4, 8])
    check('TFG chamber 51 partition', tfG[1]['class_sizes'] == [1, 2, 16, 32])
    # A history can refine a static observation when the transition does not descend.
    K, F = [0, 0, 1], [0, 2, 2]
    check('Finite history example', K[0] == K[1] and K[F[0]] != K[F[1]] and
          len({(K[x], K[F[x]]) for x in range(3)}) == 3)

    output = {
        'run_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope': 'Exact representation and retention checks; no predictive experiment.',
        'checks_passed': len(CHECKS), 'checks': CHECKS,
        'global_views': summary,
        'sector': {'size': str(math.factorial(18)), 'polar_fiber_size': 2, 'polar_color_fiber_size': 1,
                   'fixed_prefix_length': 33, 'remaining_polar_pair': [36, 45]},
        'archive': {'records': len(vals), 'views': {k: {'distinct_profiles': len(profiles[k]),
                     'unchanged_under_R_plus_1': unchanged[k]} for k in record_views},
                    'joint_residual_frequencies': dict(residual), 'joint_roundtrips': roundtrips,
                    'polar_color_sector_roundtrips': sector_roundtrips,
                    'nonnumeric_relabel_roundtrips': relabel_roundtrips,
                    'joint_R_plus_1_collisions': joint_collisions,
                    'swap_unchanged': {str(k): dict(v) for k, v in swaps.items()}},
        'telescope': {'last_three_prefixes': paths3, 'signed_pascal_readings': readings,
                      'parity': [1, 0, 1], 'depth_word': A['depth_word'],
                      'winner_histories': [A['winner_history'], B['winner_history']]},
        'tfg_chambers': tfG,
        'input_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'fixtures').glob('*')) if p.is_file()},
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results/PAPER_CHECKS.json').write_text(json.dumps(output, indent=2)+'\n')
    (ROOT/'results/TOKEN_DICTIONARY.json').write_text(json.dumps(token_rows, indent=2, default=str)+'\n')
    print(json.dumps({'checks_passed': len(CHECKS), 'global_views': {k: {p:v for p,v in row.items() if p!='ambiguous_groups'} for k,row in summary.items()},
                      'sector': output['sector'], 'archive': output['archive'], 'telescope': output['telescope']}, indent=2))


CHECKS = []
if __name__ == '__main__':
    main()
