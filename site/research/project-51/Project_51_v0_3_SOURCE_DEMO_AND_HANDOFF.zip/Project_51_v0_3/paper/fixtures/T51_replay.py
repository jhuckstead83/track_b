#!/usr/bin/env python3
"""Replay the published pair from the paper's exact card string, standard library only.

This reconstructs the finite Telescope observations. It neither certifies zero
ordinates nor reruns the frozen War sample.
"""
from pathlib import Path
import json
import math

ROOT = Path(__file__).resolve().parent
RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
SUITS = 'SHDC'
REFERENCE = [r+s for r in RANKS for s in SUITS if r+s != '2C']

def published_cards():
    # Extracted verbatim from the Line Game and matched to Telescope's active record.
    cards = (ROOT/'PUBLISHED_CARD_RECORD.txt').read_text().split()
    assert cards[-1] == '2C' and len(cards) == 52
    assert set(cards[:-1]) == set(REFERENCE)
    return cards[:-1]

def rank(deck):
    unused = REFERENCE.copy()
    total = 0
    for i, card in enumerate(deck):
        digit = unused.index(card)
        total += digit * math.factorial(50-i)
        unused.pop(digit)
    return total

def natural(card):
    return RANKS.index(card[:-1]) + 1

def color(card):
    return 1 if card[-1] in 'HD' else -1

def replay(deck):
    stages = [('V', lambda c: min(10, natural(c))), ('R', natural),
              ('C', color), ('S', lambda c: SUITS.index(c[-1]))]
    word, winners, ledger = [], [], []
    for start in range(0, 51, 3):
        triple = deck[start:start+3]
        leaders = list(range(3))
        counts = [3]
        first = None
        for label, value in stages:
            maximum = max(value(triple[p]) for p in leaders)
            leaders = [p for p in leaders if value(triple[p]) == maximum]
            counts.append(len(leaders))
            if first is None and len(leaders) == 1:
                first = label
        assert len(leaders) == 1
        word.append(first)
        winners.append(str(leaders[0] + 1))
        ledger.append(counts)
    prefixes = [0]
    for card in deck:
        prefixes.append(prefixes[-1] + color(card))
    integer = rank(deck)
    quotient, remainder = divmod(integer, 10**12)
    return {'integer': integer, 'decimal': f'{quotient}.{remainder:012d}',
            'depth_word': ''.join(word), 'winner_history': ''.join(winners),
            'candidate_sizes': ledger, 'signed_prefixes': prefixes}

def pair():
    a = published_cards()
    b = a.copy()
    b[-2], b[-1] = b[-1], b[-2]
    return replay(a), replay(b)

def main():
    a, b = pair()
    assert [a['integer'], b['integer']] == [14134725141735, 14134725141734]
    assert a['depth_word'] == b['depth_word'] == 'SCCVSSCVSSCVSCRRR'
    assert a['winner_history'] == '33332333233331312'
    assert b['winner_history'] == '33332333233331313'
    assert a['candidate_sizes'] == b['candidate_sizes']
    assert a['candidate_sizes'][-1] == [3, 3, 1, 1, 1]
    assert a['signed_prefixes'][-3:] == [1, 0, 1]
    assert b['signed_prefixes'][-3:] == [1, 2, 1]
    print(json.dumps({'status': 'PASS', 'A': a, 'B': b}, indent=2))

if __name__ == '__main__':
    main()
