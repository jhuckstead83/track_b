#!/usr/bin/env python3
"""Verify and build Project 51 v0.3. Python stdlib + a pdfLaTeX installation.

PDF bytes are reproducible under the same TeX environment. Verification
receipts record each run's actual time. Build a working copy if preserving
the delivered manifest. Visual inspection remains a separate release check.
"""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / 'build'
NAME = 'Project_51_v0_3'
BUILD.mkdir(exist_ok=True)
env = os.environ.copy()
env.update(SOURCE_DATE_EPOCH='1790294400', FORCE_SOURCE_DATE='1', TZ='UTC')
subprocess.run([sys.executable, str(ROOT / 'verify_paper.py')],
               cwd=ROOT, check=True, capture_output=True, text=True)
checks = json.loads((ROOT / 'results/PAPER_CHECKS.json').read_text())['checks_passed']
for _ in range(2):
    result = subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                             '-output-directory', str(BUILD), NAME + '.tex'],
                            cwd=ROOT, env=env, capture_output=True, text=True)
    if result.returncode:
        print(result.stdout[-12000:], file=sys.stderr)
        raise SystemExit(result.returncode)
log = (BUILD / (NAME + '.log')).read_text(errors='replace')
for message in ['Overfull \\hbox', 'Overfull \\vbox',
                'There were undefined references', 'There were multiply-defined labels',
                'Rerun to get cross-references right']:
    if message in log:
        raise RuntimeError('Build review required: ' + message)
page_match = re.search(r'Output written on .*?\((\d+)\s+pages?', log, re.S)
if not page_match or not 1 <= int(page_match[1]) <= 13:
    raise RuntimeError('Missing page count or thirteen-page ceiling exceeded')
pdf = (BUILD / (NAME + '.pdf')).read_bytes()
(ROOT / (NAME + '.pdf')).write_bytes(pdf)
review = {'checks_passed': checks, 'pages': int(page_match[1]),
          'source_date_epoch': env['SOURCE_DATE_EPOCH'],
          'pdf_sha256': hashlib.sha256(pdf).hexdigest(),
          'build_gate': 'PASS', 'visual_inspection': 'Separate release gate'}
(BUILD / 'BUILD_CHECKS.json').write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps(review, indent=2))
