# Independent reading before Forge Weights

Written before opening or extracting `Forge_Weights_Review_2026-09-24.zip`.

The user clarified that each historical paper's fences predate Area 51. I treat those as statements about the paper's original objects and tested maps, not as instructions that prohibit constructing a new Area 51 object. Transfer requires specifying what is retained, changed, and tested.

## Initial findings

1. **The newest TN source sharpens the Pascal connection.** The v5.1 Reading Volume §§R12A, R17F–G and Dossier equations (163A.6)–(163A.9) supply the signed Pascal involution U²=I, the Pascal Gram factor UᵀU=M, and an exact source-energy identity. My previous parity/chaos-game comparison retains the pattern but discards signs and coefficient magnitudes. Both remain available in a richer Area 51 record. Exact checks through degree 12 passed; these checks do not evaluate the full TN source.

2. **TFG can supply a new, explicit alphabet rule.** In a declared chamber n, let the state be k∈{1,…,n} and the observed class be s=n/gcd(n,k). Its size is φ(s), and under uniform k its probability is φ(s)/n. Keeping n, s, and the rank of the reduced numerator among units modulo s recovers k. For permutations of all n distinct states, a fixed divisor-class word has ∏_(s|n)φ(s)! lifts. This is the same finite partition mechanism underlying the Area 51 factorial ledger, with a new partition. At n=51 the class sizes are (1,2,16,32); at n=20 they are (1,1,2,4,4,8). These sizes come from the TFG observation, not from the zeta records. Classes with equal φ(s) must still retain s if their identity matters. Checks for chambers 1–64 passed.

3. **The shared C-geometry and flux chart is explicit.** Both contain C(c)=(1−c)/(1+c). C is involutive. Flux adds a conjugated scale action C∘S∘C⁻¹. This offers an exact chart dictionary for a new observer/game. The wave-energy half weights and boundary flux provide a useful accounting example; this does not assign physical energy to card credits automatically.

4. **R142 has distinct coordinates that can be confused by display rounding.** In the cached R142G3 arrival table, grid 3.140 has 168/42=4; the separate exact-π rail has 172/38≈4.5263157895. The requested active constant 2.747718405030618 maps to grid 2.750 in one mode (1895/611≈3.101473), while its named exact rail has 1903/561≈3.392157. These are distinct observation channels. The copied notebook output is evidence of the recorded run; I have not rerun the 103.8-billion-gap stream.

5. **Arrival history is already a documented missing coordinate.** R142G3 explicitly rejects old R142G2 checkpoints because terminal counts cannot reconstruct chronology. Its per-file increments and selected exact event ledgers are precisely the kind of state history Area 51 can retain. One representative predecessor is selected when reconstructing a relation, so even this ledger has a declared tie rule and event scope. The attached material provides code and cached summaries; the external route shards are not included among the three supplied output archives.

6. **R143F/G are weighted positive-series tails.** Their q_k are the reduced denominators in ζ(2k)=p_kπ^(2k)/q_k; they are not the folded-zero q=ρ(1−ρ). The crossing equation is q_kζ(2k,N+1)=q_(k+1)ζ(2k+2,N+1). Independently recomputing the five major roots agrees with the saved decimals. With s=2k and N₀²=(s−1)q_(k+1)/[(s+1)q_k], centered Euler–Maclaurin gives the explicit next approximation N≈N₀−1/2−(2s+1)/(24N₀). It improves the plain half-step errors in all five cases, by factors about 619–3582. The notebook already contains higher-order EM root estimates; this is an explicit formula for part of that mechanism, not a claim to a new unexplained pattern.

## The unresolved question that triggers the last read

The scalar word “weight” currently spans at least four different quantities: class multiplicity, source mass, a ratio of two event counts, and an inverse-variance proxy for a log ratio. The files before Forge Weights do not select a canonical Area 51 state/observation rule that combines them. In particular, terminal ratios alone cannot determine the arrival stream or the probability measure for a new game.

I am at that gap now: which richer record should travel into Area 51, and what did the separate weight review notice about information lost at the earlier aggregations? The next step is to open Forge Weights and compare its proposals with this frozen assessment, keeping additions and corrections explicit.

## Scope of the reading

This is a focused review of definitions, theorem interfaces, relevant experiments, and source code, not a claim to have re-proved every theorem in the 382-page TN release or executed every notebook cell. Consulted: the supplied TFG, C-geometry, polar-shell, and flux PDFs; TN v5.1 README, relevant Reading Volume sections and Dossier source; the three saved Forge output archives; the 104-cell notebook index, relevant R143F/G code, later calibration outputs, and R142G3 arrival code/output. Forge Weights remained unopened throughout this stage.
