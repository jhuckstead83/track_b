"""Independent algebra and saved-table checks, written before Forge Weights was opened."""
from pathlib import Path
from fractions import Fraction
from math import factorial, gcd, comb, log2, sqrt
from collections import Counter
import csv, json, hashlib, datetime
import sympy as sp
import mpmath as mp

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results'
CHECKS=[]
def check(name,ok):
    if not ok: raise AssertionError(name)
    CHECKS.append(name)
def phi(n):return sum(gcd(k,n)==1 for k in range(1,n+1))

# A new finite Area 51 observer built from TFG: keep the class and within-class rank.
rows=[]
for n in range(1,65):
    classes={s:[k for k in range(1,n+1) if n//gcd(n,k)==s] for s in range(1,n+1) if n%s==0}
    check(f'TFG class sizes n={n}',all(len(ks)==phi(s) for s,ks in classes.items()))
    recovered=[]
    for k in range(1,n+1):
        g=gcd(n,k);s=n//g;u=k//g
        units=[v for v in range(1,s+1) if gcd(v,s)==1]
        rank=units.index(u)
        recovered.append((n//s)*units[rank]==k and Fraction(k,n)==Fraction(units[rank],s))
    check(f'TFG record recovery n={n}',all(recovered))
    sizes=list(map(len,classes.values()))
    H=-sum((m/n)*log2(m/n) for m in sizes)
    conditional=sum((m/n)*log2(m) for m in sizes)
    check(f'TFG information ledger n={n}',abs(H+conditional-log2(n))<1e-12)
    fiber=1
    for m in sizes:fiber*=factorial(m)
    if n in [12,20,50,51,52,60,64]:
        rows.append({'n':n,'divisors':list(classes),'class_sizes':sizes,
                     'class_entropy_bits':H,'conditional_identity_bits':conditional,
                     'profile_fiber_permutation_count':str(fiber),
                     'distinct_class_words':str(factorial(n)//fiber)})

# Signed Pascal versus parity and energy, checked in exact arithmetic.
pascal=[]
for N in range(1,13):
    U=sp.Matrix(N+1,N+1,lambda j,r:(-1)**j*comb(r,j) if j<=r else 0)
    M=sp.Matrix(N+1,N+1,lambda r,s:comb(r+s,r))
    check(f'Signed Pascal involution N={N}',U*U==sp.eye(N+1))
    check(f'Pascal Gram factor N={N}',U.T*U==M)
    check(f'Pascal determinant N={N}',M.det()==1)
    d=sp.Matrix([(-1)**r*(r+1) for r in range(N+1)])
    B=U*d
    check(f'Energy identity N={N}',(d.T*M*d)[0]==(B.T*B)[0])
    signed=[(-1)**j*comb(N,j) for j in range(N+1)]
    unsigned=[comb(N,j) for j in range(N+1)]
    check(f'Parity forgets sign N={N}',[x%2 for x in signed]==[x%2 for x in unsigned])
    pascal.append({'N':N,'signed_row_sum':sum(signed),'unsigned_row_sum':sum(unsigned),'same_parity':True})

# The two projective charts have an exact algebraic transfer without importing a physical model.
c,R,beta=sp.symbols('c R beta')
C=lambda x:(1-x)/(1+x)
check('C-geometry Cayley chart is involutive',sp.simplify(C(C(c))-c)==0)
check('Flux chart is conjugated scaling',sp.simplify(C(C(R)*(1+beta)/(1-beta))-(R-beta)/(1-beta*R))==0)

# Recompute the R143G roots from its integer coefficients, independent of its root finder.
mp.mp.dps=70
source=next((ROOT/'input').glob('*half_step_crossings*.csv'))
crossings=[]
for row in csv.DictReader(source.open()):
    if row['class']!='major_shock':continue
    k=int(row['k']);s=2*k
    q=mp.mpf(row['q_k']);qn=mp.mpf(row['q_next'])
    N0=mp.sqrt((s-1)*qn/((s+1)*q))
    f=lambda N:mp.log(qn/q)+mp.log(mp.zeta(s+2,N+1))-mp.log(mp.zeta(s,N+1))
    root=mp.findroot(f,(N0-1,N0))
    first=N0-mp.mpf('0.5')
    second=first-mp.mpf(2*s+1)/(24*N0)
    check(f"Saved crossing {row['pair']}",abs(root-mp.mpf(row['N_exact']))<mp.mpf('1e-11'))
    check(f"Centered correction improves {row['pair']}",abs(root-second)<abs(root-first))
    crossings.append({'pair':row['pair'],'N_exact':str(root),'N_leading':str(N0),
                      'half_step_error':float(abs(root-first)),'centered_correction_error':float(abs(root-second)),
                      'improvement_factor':float(abs(root-first)/abs(root-second)),
                      'N_centered_correction':str(second)})

# Exact count arithmetic. Counts are read from the notebook's cached R142G3 table,
# not regenerated from the unavailable 103.8-billion-zero source stream.
routes=[{'label':'grid 3.140','active':168,'reference':42},
        {'label':'exact pi','active':172,'reference':38},
        {'label':'grid 2.750','active':1895,'reference':611},
        {'label':'exact active 2.747718405030618','active':1903,'reference':561}]
for row in routes:
    a,b=row['active'],row['reference'];row['ratio']=float(Fraction(a,b))
    row['smoothed_ratio']=float(Fraction(2*a+1,2*b+1))
    row['weight_log']=1/(1/(a+.5)+1/(b+.5))

result={'run_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'tfG_area51_candidate':rows,'pascal':pascal,'tail_correction':crossings,
        'cached_route_count_arithmetic':routes,'checks_passed':len(CHECKS),'checks':CHECKS,
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(OUT/'PRE_WEIGHTS_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k in ['tfG_area51_candidate','tail_correction','cached_route_count_arithmetic','checks_passed']},indent=2))
