# Applying the reviewed joint observer to the existing source block

Fixed after reading Forge Weights and before computing this comparison. This is a deterministic information-retention audit on previously used data, not a statistical discovery test.

Use the unchanged 1,566 fixed-precision integer records from Rounds 01–03. Encode each integer by the original lexicographic permutation rank on the same 51 active identities. Attach the weights review's triangular address once to canonical importance rank, never to a shuffled position.

Compare four observations: weight class; reduced polar point (represented exactly by its reduced fraction); joint weight class and reduced polar point; reduced polar point plus the gcd multiplier. Count distinct complete positional profiles over the source records, and count unchanged profiles under R→R+1. These are archive-specific retention counts, not estimates of a new alphabet or predictions.

For every source deck, also make two fixed interventions: exchange canonical identities 34 and 35 (equal weight, different polar point), and exchange identities 36 and 45 (equal weight and equal polar point, different gcd multiplier). Check exactly which observations distinguish the swaps. The swaps act on identity wherever it appears, not on fixed positions.

Implement a decoder from the complete joint profile plus three fixed-order binary choices for the pairs (6,10), (15,21), and (36,45). Require exact recovery of every original deck and integer. Record the three-bit words but do not call them a complete encoding of the records: the profile and shared dictionary carry the other information.

Also exhibit two distinct signed input vectors that have the same parity observation and different outputs under a signed Pascal row. This identifies a property that the parity viewer cannot decide, without treating that viewer as an invalid tool.
