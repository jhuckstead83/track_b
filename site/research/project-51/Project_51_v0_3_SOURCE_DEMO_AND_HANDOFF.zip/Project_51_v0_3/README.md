# Project 51 v0.3
## Reading the Record Across Rules / Rotor 51

**Author:** Jeffery Lyn Huckstead, Cerebral Graphix  
**Release:** 25 September 2026, working research and website-team handoff  
**Status:** manuscript + playable isolated demo + optional, hash-gated website patch. Nothing has been deployed.

The new game reads the same object twice. Poker reads an unordered five-card hand; the archive lock reads an exact five-card order. A permutation can preserve the poker award and lose the ordered target. Card and component faces are two presentations of the same retained identity, not two different games.

## Start here

Open `paper/Project_51_v0_3.pdf` for the 13-page manuscript. Its compact card tiles now function as inline notation, including the frozen record and worked examples. Section 8 adds the separately declared Rotor 51 model and proof of the rotor sampling law. The prior recovery results and verifier remain intact.

Open `demo/Rotor_51_v0_3_DEMO.html` in a browser for the self-contained game. It needs no asset server or network connection. A browser with unavailable Web Crypto cannot deal; examples still work. Storage restrictions trigger explicit memory-only play rather than a failed bank load.

Send `docs/WEBSITE_HANDOFF.md` and this entire package to the website team. The `website/` directory is a **partial overlay, not a replacement full site**. Do not upload it blindly over a newer version. The patch tool first checks the expected hashes.

## What changed

- **Notation:** small square rank/suit tokens replace exposition-sized card illustrations. The web component flips to the exact paper component on click or keyboard activation. Holding a card is a separate action.
- **Game:** five distinct cards, one hold decision, one optional redraw, an exact conditional-odds counter, two rotor wirings, a 3-by-17 identity lab, and a noncoprime-gear demonstration.
- **Awards:** one-point entry, declared gross poker awards, and a local archive meter. All points are isolated from shared jbits and Finance holdings.
- **Mobile:** optional scoped presentation changes for Invariant, Blackjack, Telescope, and Memory, plus a fifth hub card. Existing game engines and wallet code are not changed.

## Package map

| Path | Purpose |
|---|---|
| `paper/` | PDF, LaTeX source, original verifier, original research fixtures and source attribution |
| `demo/` | One-file playable HTML |
| `website/` | Six new game files, two mobile assets, five updated HTML pages, additive paper PDF |
| `docs/WEBSITE_HANDOFF.md` | Implementation order, exclusions, mobile evidence, acceptance gate |
| `docs/RULES_AND_PROBABILITY.md` | Frozen rules, probability domains, exact census, jackpot contract |
| `docs/NOTATION_AND_SOURCE_LEDGER.md` | Identity discipline and inherited/new/unproved ledger |
| `audit/` | Machine-readable results, source/deployment hashes, screenshots |
| `tests/` | Executable paper-adjacent, game, browser, mobile and patch checks |
| `tools/` | Demo bundler, safe patch applicator, manifest verifier |

## Rebuild and replay

Use a working copy: audit receipts change when rerun, so their hashes will no longer match the delivered manifest.

```sh
python paper/build_paper.py
node tests/engine_checks.cjs
python tests/independent_census.py
python tools/build_demo.py
python tests/browser_checks.py
python tests/site_patch_checks.py --site /path/to/unpacked/full-site
python tests/mobile_checks.py --site /path/to/unpacked/full-site
```

The first command needs pdfLaTeX; the browser commands need Python Playwright and Chromium, and the existing-site fixture renderer also needs Beautiful Soup. Set `CHROMIUM` to an installed browser executable when it is not `/usr/bin/chromium`. Paper/game combinatorial checks do not need a browser or internet access.

## Boundary of this release

The browser UI was exercised in real Chromium using inlined local assets. This authoring environment blocks URL navigation, so it is not a live deployment, actual file-origin persistence, Safari, physical-phone, shared-wallet, or random-source certification. Existing-game tests use fixture storage. The opening census is exact; optimal-play return and a production shared jackpot are not claimed. No new RH result or participant learning result is asserted.
