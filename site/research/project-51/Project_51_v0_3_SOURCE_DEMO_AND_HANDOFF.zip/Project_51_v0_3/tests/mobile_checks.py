#!/usr/bin/env python3
"""Render old and patched local assets in real Chromium using a fixture loader.

Requires the unpacked supplied website as --site. URL navigation is not used.
Actual scripts are inlined; ESM is wrapped by the test helper, and storage is
isolated. This is not live wallet testing or physical-phone certification.
"""
import argparse,json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
from playwright.sync_api import sync_playwright
import inline_site_fixture as fixture
ROOT=Path(__file__).resolve().parents[1]
GAMES=['invariant','blackjack-51','telescope-51','memory-51']
SELECTORS={'invariant':'#step','blackjack-51':'#deal','telescope-51':'.choose-player','memory-51':'#answers button'}
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--site',type=Path,required=True);args=parser.parse_args()
    checks=[];metrics=[];before=[];errors=[];prev=ROOT/'audit/previews';prev.mkdir(exist_ok=True)
    def check(name,condition):
        if not condition:raise AssertionError(name)
        checks.append(name)
    with tempfile.TemporaryDirectory(prefix='project51-mobile-') as tmp, sync_playwright() as p:
        tmp=Path(tmp);site=tmp/'site';shutil.copytree(args.site,site)
        subprocess.run([sys.executable,str(ROOT/'tools/apply_site_patch.py'),'--site',str(site),'--apply','--backup-dir',str(tmp/'backup')],check=True,capture_output=True)
        browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
        for stage,root in [('before',args.site.resolve()),('after',site)]:
            fixture.ROOT=root
            for width in ([390] if stage=='before' else [320,360,390,600,768,1280]):
                for game in GAMES:
                    page=browser.new_page(viewport={'width':width,'height':844},reduced_motion='reduce');page.on('pageerror',lambda e:errors.append(str(e)))
                    page.set_content(fixture.bundle('area-51/'+game+'/index.html'));page.wait_for_function('window.__fixtureLoaded || window.__fixtureError');page.wait_for_timeout(200)
                    loaded=page.evaluate('!!window.__fixtureLoaded && !window.__fixtureError')
                    box=page.locator(SELECTORS[game]).first.bounding_box()
                    record={'game':game,'width':width,'loaded':loaded,'scrollWidth':page.evaluate('document.documentElement.scrollWidth'),'primaryActionY':round(box['y']) if box else None}
                    if stage=='before':before.append(record)
                    else:
                        metrics.append(record);check(f'{game} at {width}px loads original scripts',loaded)
                        check(f'{game} at {width}px has no document overflow',record['scrollWidth']<=width)
                        if width==390:
                            page.screenshot(path=str(prev/(game+'_mobile_after.png')),full_page=True)
                            if game=='invariant':
                                page.locator('#step').click();page.wait_for_timeout(100)
                                check('Invariant free turn still advances',int(page.locator('#turn').inner_text())>=1)
                                page.locator('.p51-setup-panel summary').click();page.locator('#show-hands').click()
                                check('Invariant optional hand view remains accessible',page.locator('#show-hands').get_attribute('aria-pressed')=='true')
                            elif game=='blackjack-51':
                                page.locator('#deal').click();page.wait_for_timeout(250)
                                check('Blackjack still deals from fixture bank',page.locator('#player-hands .card:not(.ghost)').count()>=2)
                            elif game=='telescope-51':
                                page.locator('#depthGrid button').first.click();page.locator('.choose-player').first.click()
                                check('Telescope winner selection is still operable','Winner selected' in page.locator('#playerTable').inner_text())
                            else:
                                page.locator('#answers button').first.click();page.wait_for_timeout(100)
                                check('Memory still records a completed answer',int(page.locator('#completed').inner_text())==1)
                            check(f'{game} remains within phone width after interaction',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
                    page.close()
        browser.close()
    for game in GAMES:
        old=next(r for r in before if r['game']==game);new=next(r for r in metrics if r['game']==game and r['width']==390)
        check(game+' primary action moves closer to the top',new['primaryActionY']<old['primaryActionY'])
    check('No uncaught exceptions in old or patched fixture pages',not errors)
    out={'checksPassed':len(checks),'checks':checks,'before390px':before,'after':metrics,'errors':errors,'method':'Real Chromium / set_content; local CSS inlined, ESM wrapped for fixtures, in-memory bank storage; not production source rewriting','limits':'No URL navigation, deployed assets, real accounts, live jbit wallet, physical devices, or Safari were tested.'}
    (ROOT/'audit/MOBILE_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'checksPassed':len(checks),'errors':errors,'before':before,'after390px':[r for r in metrics if r['width']==390]},indent=2))
if __name__=='__main__':main()
