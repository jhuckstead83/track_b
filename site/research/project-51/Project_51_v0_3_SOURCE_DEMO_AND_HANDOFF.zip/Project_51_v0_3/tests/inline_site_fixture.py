"""Test-only local asset inliner; never ship as production game code.
Uses explicit fixture storage and a restricted ESM wrapper for these source files.
"""
from pathlib import Path
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
import json,re,posixpath
ROOT=Path('.')  # Set by mobile_checks.py to an unpacked site copy.
def resolve(ref,parent):
 return posixpath.normpath(ref.lstrip('/') if ref.startswith('/') else posixpath.join(posixpath.dirname(parent),ref))
def bundle(pagepath,extra_css='',tag=''):
 soup=BeautifulSoup((ROOT/pagepath).read_text(),'html.parser')
 for el in soup.find_all('link',rel='stylesheet'):
  ref=resolve(el['href'],pagepath)
  if (ROOT/ref).exists():
   t=soup.new_tag('style');t.string=(ROOT/ref).read_text();el.replace_with(t)
 if tag:soup.body['data-p51-mobile']=tag
 if extra_css:
  t=soup.new_tag('style');t.string=extra_css;soup.head.append(t)
 modules={}
 def load(ref):
  if ref in modules:return ref
  modules[ref]=''
  src=(ROOT/ref).read_text();exports=[]
  def im(m):
   names,path=m.groups();dest=resolve(path,ref);load(dest)
   names=re.sub(r'\s+as\s+',':',names)
   return 'const {'+names+'}=await R('+json.dumps(dest)+');'
  src=re.sub(r'import\s*\{(.*?)\}\s*from\s*[\'"](.*?)[\'"]\s*;',im,src,flags=re.S)
  def dyn(m):
   dest=resolve(m.group(1),ref);load(dest);return 'R('+json.dumps(dest)+')'
  src=re.sub(r'import\([\'"](.*?)[\'"]\)',dyn,src)
  def exp(m):exports.append(m.group(2));return m.group(1)+m.group(2)
  src=re.sub(r'export\s+((?:async\s+)?function\s+|const\s+|let\s+|class\s+)(\w+)',exp,src)
  def exnames(m):exports.extend(x.strip() for x in m.group(1).split(','));return ''
  src=re.sub(r'export\s*\{(.*?)\};?',exnames,src,flags=re.S)
  # fetch() gets fixture bytes resolved relative to its own source module.
  src=re.sub(r'fetch\(([\'"])(.*?)\1\)',lambda m:'F('+json.dumps(resolve(m.group(2),ref))+')',src)
  modules[ref]=src+'\nreturn {'+','.join(exports)+'};'
  return ref
 runs=[]
 for el in soup.find_all('script'):
  typ=el.get('type','')
  if typ in ['application/json','application/ld+json']:continue
  if typ=='module':
   ref=resolve(el['src'],pagepath);load(ref);runs.append('await R('+json.dumps(ref)+');')
  else:
   src=(ROOT/resolve(el['src'],pagepath)).read_text() if el.get('src') else el.get_text()
   def dyn(m):dest=resolve(m.group(1),resolve(el.get('src','index.html'),pagepath));load(dest);return '__p51R('+json.dumps(dest)+')'
   src=re.sub(r'import\([\'"](.*?)[\'"]\)',dyn,src)
   runs.append('(0,eval)('+json.dumps(src)+');')
  el.decompose()
 fixtures={}
 for ref in re.findall(r'F\("([^"]+)"\)','\n'.join(modules.values())):
  if (ROOT/ref).exists():fixtures[ref]=(ROOT/ref).read_text()
 shim=r'''function storage(){let m=new Map();return {getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i]??null,get length(){return m.size}}}
 Object.defineProperty(window,'localStorage',{value:storage(),configurable:true});Object.defineProperty(window,'sessionStorage',{value:storage(),configurable:true});
 if(!crypto.randomUUID)crypto.randomUUID=()=>Array.from(crypto.getRandomValues(new Uint8Array(16)),x=>x.toString(16).padStart(2,'0')).join('');
 '''
 registry='const M={'+','.join(json.dumps(k)+':async function(R,F){\n'+v+'\n}' for k,v in modules.items())+'};\n'
 script=shim+'(async()=>{const fixtures='+json.dumps(fixtures)+';const F=async p=>new Response(fixtures[p]||"{}",{headers:{"Content-Type":"application/json"}});'+registry+'const cache=new Map();function R(id){if(!cache.has(id))cache.set(id,M[id](R,F));return cache.get(id)};window.__p51R=R;'+''.join(runs)+';window.__fixtureLoaded=true;})().catch(e=>{console.error(e);window.__fixtureError=e.stack;});'
 t=soup.new_tag('script');t.string=script;soup.body.append(t)
 return str(soup)
