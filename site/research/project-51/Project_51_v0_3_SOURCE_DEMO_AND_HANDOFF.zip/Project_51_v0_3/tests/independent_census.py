#!/usr/bin/env python3
"""Independent exact census by rank multisets, not the JavaScript hand evaluator."""
from collections import Counter
from itertools import combinations_with_replacement
from math import comb, prod
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
counts=[0]*10
rank_cases=0
for ranks in combinations_with_replacement(range(2,15),5):
    multiplicities=Counter(ranks)
    capacity=lambda r: 3 if r==2 else 4
    if any(c>capacity(r) for r,c in multiplicities.items()):continue
    rank_cases+=1
    ways=prod(comb(capacity(r),c) for r,c in multiplicities.items())
    pattern=sorted(multiplicities.values(),reverse=True)
    if pattern==[1]*5:
        straight=(ranks[-1]-ranks[0]==4 or ranks==(2,3,4,5,14))
        same_suit=3 if 2 in ranks else 4
        if straight:
            counts[9 if ranks==(10,11,12,13,14) else 8]+=same_suit
            counts[4]+=ways-same_suit
        else:
            counts[5]+=same_suit
            counts[0]+=ways-same_suit
    else:
        category={(4,1):7,(3,2):6,(3,1,1):3,(2,2,1):2}.get(tuple(pattern),0)
        if pattern==[2,1,1,1] and next(r for r,c in multiplicities.items() if c==2)>=11:category=1
        counts[category]+=ways
js=json.loads((ROOT/'audit/ENGINE_CHECKS.json').read_text())['exhaustiveOpeningCensus']
assert sum(counts)==comb(51,5)==js['total']
assert counts==[x['count'] for x in js['categories']]
assert prod(range(47,52))==281887200
# Four royal hearts and an off-suit discard: one of all 46 legal replacements.
pack={(r,s) for r in range(2,15) for s in 'SHDC'}-{(2,'C')}
initial={(r,'H') for r in (10,11,12,13)}|{(2,'S')}
remaining=pack-initial
assert len(remaining)==46 and sum(c==(14,'H') for c in remaining)==1
out={'method':'Rank-multiset enumeration with exact suit multiplicities; no use of JS evaluator',
     'rank_multisets':rank_cases,'counts':counts,'total':sum(counts),'all_categories_match_javascript':True,
     'checks_passed':4,'scope':'Independent combinatorial cross-check of the opening census, not optimal draw return.'}
(ROOT/'audit/INDEPENDENT_CENSUS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
