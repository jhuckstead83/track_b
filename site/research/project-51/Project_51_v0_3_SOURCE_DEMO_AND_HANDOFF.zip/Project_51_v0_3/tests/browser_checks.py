#!/usr/bin/env python3
"""Real Chromium execution with inlined local assets (not a deployment test).

The authoring environment blocks URL navigation. set_content executes the shipped
standalone HTML. A labelled storage fixture tests round restoration. No network,
real user account, live wallet, or Safari certification is implied.
"""
from pathlib import Path
import json, os
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'demo/Rotor_51_v0_3_DEMO.html').read_text()
KEY='project51.rotor51.v0.3.tab-demo'
OUT=ROOT/'audit';PREV=OUT/'previews';PREV.mkdir(exist_ok=True)
checks=[];errors=[];requests=[]
def check(name,condition):
    if not condition:raise AssertionError(name)
    checks.append(name)
def fixture(saved=None,unavailable_rng=False,storage=True):
    setup='window.__sharedStorageReads=0;Object.defineProperty(window,"localStorage",{configurable:true,get(){window.__sharedStorageReads++;throw Error("Shared storage forbidden in this test")}});'
    if storage:
        initial={} if saved is None else {KEY:saved}
        setup+='window.__demoStore='+json.dumps(initial)+';Object.defineProperty(window,"sessionStorage",{configurable:true,value:{getItem:k=>window.__demoStore[k]??null,setItem:(k,v)=>window.__demoStore[k]=String(v),removeItem:k=>delete window.__demoStore[k]}});'
    if unavailable_rng:setup+='Object.defineProperty(window,"crypto",{configurable:true,value:{}});'
    return HTML.replace('<head>','<head><script>'+setup+'</script>',1)
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
    def page(width=390,saved=None,unavailable_rng=False,storage=True):
        q=browser.new_page(viewport={'width':width,'height':844},reduced_motion='reduce')
        q.on('pageerror',lambda e:errors.append(str(e)));q.on('request',lambda r:requests.append(r.url))
        q.set_content(fixture(saved,unavailable_rng,storage));q.wait_for_function('window.P51Engine && document.querySelectorAll("#rotors p51-token").length===5')
        return q
    def state(q):return q.evaluate('JSON.parse(window.__demoStore['+json.dumps(KEY)+'])')
    for width in [320,360,390,600,768,1280,1440]:
        q=page(width)
        check(f'{width}px initial document has no horizontal overflow',q.evaluate('document.documentElement.scrollWidth<=innerWidth'))
        q.locator('#deal').click();q.wait_for_timeout(40)
        check(f'{width}px dealt hand has five distinct cards',len(set(state(q)['round']['hand']))==5)
        check(f'{width}px hold targets are at least 44 by 44',q.locator('#hold-0').evaluate('(e)=>{let r=e.getBoundingClientRect();return r.width>=44&&r.height>=44}'))
        check(f'{width}px active hand has no horizontal overflow',q.evaluate('document.documentElement.scrollWidth<=innerWidth'))
        if width in [390,1440]:q.screenshot(path=str(PREV/f'rotor_{width}px.png'),full_page=True)
        q.close()
    q=page();q.locator('#settings-panel summary').click();q.select_option('#wiring','straight');q.locator('#knob').evaluate('(e)=>{e.value=17;e.dispatchEvent(new Event("input",{bubbles:true}))}');q.locator('#deal').click();q.wait_for_timeout(40)
    initial=state(q)
    check('Entry is exactly one point and local meter adds 0.01',initial['balanceCents']==9900 and initial['meterCents']==5101)
    check('Rotor controls lock during a live hand',q.locator('#wiring').is_disabled() and q.locator('#knob').is_disabled())
    check('Deal control cannot overwrite live hand',not q.locator('#deal').is_visible())
    q.locator('#hold-0').click();held=state(q)
    before=q.evaluate('JSON.stringify(window.__demoStore)')
    q.locator('#token-0 button').focus();q.keyboard.press('Enter')
    check('Card flips preserve game and bank state',q.evaluate('JSON.stringify(window.__demoStore)')==before)
    check('Keyboard focus survives an individual face flip',q.locator('#token-0').evaluate('(e)=>e.shadowRoot.activeElement?.tagName==="BUTTON"'))
    check('Component face is an outlined glyph',q.locator('#token-0 svg').count()==1)
    q.locator('#show-symbols').click()
    check('Global symbol mode shows five component paths',q.locator('#rotors svg path').count()==5)
    check('Symbol mode leaves hold mask unchanged',state(q)['round']['holds']==held['round']['holds'])
    q.screenshot(path=str(PREV/'rotor_symbols_390px.png'),full_page=True)
    q.locator('[data-example="royal"]').click()
    check('Examples neither settle nor alter an in-progress game',q.evaluate('JSON.stringify(window.__demoStore)')==before)
    check('Illustration banner is shown and deal is hidden',q.locator('#example-banner').is_visible() and not q.locator('#deal').is_visible())
    q.locator('#exit-example').click()
    check('Leaving illustration restores the held card',q.locator('#hold-0').get_attribute('aria-pressed')=='true')
    saved=q.evaluate('window.__demoStore['+json.dumps(KEY)+']')
    restored=page(saved=saved)
    check('Restored tab fixture preserves charged bank and active hold',restored.locator('#bank').inner_text()=='99.00' and restored.locator('#hold-0').get_attribute('aria-pressed')=='true')
    check('Restored rotor controls display the actual saved settings',restored.locator('#wiring').input_value()=='straight' and restored.locator('#knob').input_value()=='17')
    restored.locator('#draw').click();restored.wait_for_timeout(40);finished=state(restored)
    check('Draw settles once and keeps the held identity',finished['phase']=='settled' and finished['round']['hand'][0]==held['round']['hand'][0])
    check('Replacements exclude all five original identities',all(c not in initial['round']['initial'] for c in finished['round']['hand'][1:]))
    check('Settlement is additive gross award with one entry',finished['balanceCents']==9900+finished['round']['result']['totalCents'])
    check('Draw button disappears after settlement',not restored.locator('#draw').is_visible())
    restored.on('dialog',lambda d:d.accept());restored.locator('#reset').click()
    check('Explicit reset restores only isolated demo bank',state(restored)['balanceCents']==10000 and state(restored)['phase']=='ready')
    check('No shared localStorage access was attempted',q.evaluate('window.__sharedStorageReads')==0 and restored.evaluate('window.__sharedStorageReads')==0)
    restored.close();q.close()
    # Actual UI count of C(46,1) plus independent browser-side royal witness.
    q=page();q.locator('#deal').click();q.wait_for_timeout(30)
    for i in range(4):q.locator(f'#hold-{i}').click()
    q.locator('#odds-panel summary').click();q.locator('#odds').click();q.wait_for_function('document.querySelector("#odds-result").textContent.includes("46 equally likely completions")')
    check('Conditional UI reports 46 completions for four holds','46 equally likely completions' in q.locator('#odds-result').inner_text())
    royal=q.evaluate('''()=>{const e=P51Engine,j=e.drawOdds(['10H','JH','QH','KH','2S'],[true,true,true,true,false]);let n=0,r=0;for(const c of j.iterator){n++;if(e.scoreFast(j.kept.concat(c))===9)r++;}return [n,r]}''')
    check('Four royal hearts have exactly one winning completion in 46',royal==[46,1])
    q.locator('#hold-4').click();q.locator('#odds').click();q.wait_for_function('document.querySelector("#odds-result").textContent.startsWith("1 equally likely")')
    check('All held has one completion, not a fresh opening sample',q.locator('#odds-result').inner_text().startswith('1 equally likely'))
    q.locator('#mechanism summary').click();q.select_option('#lab-step','17')
    check('Noncoprime modulus demonstration has exactly three reachable dots',q.locator('#lab-dots .on').count()==3)
    q.select_option('#lab-step','2');check('Coprime demonstration reaches all 51 dots',q.locator('#lab-dots .on').count()==51)
    q.close()
    for corrupted in ['not json','{}']:
        q=page(saved=corrupted)
        check('Malformed save is blocked without silent replacement: '+corrupted,q.locator('#error').is_visible() and q.locator('#deal').is_disabled() and q.evaluate('window.__demoStore['+json.dumps(KEY)+']')==corrupted);q.close()
    q=page(unavailable_rng=True);q.locator('#deal').click()
    check('Missing RNG cannot charge an entry',q.locator('#bank').inner_text()=='100.00' and q.locator('#error').is_visible())
    q.locator('[data-example="key"]').click();check('Examples remain available without RNG',q.locator('#example-banner').is_visible());q.close()
    q=page(storage=False);q.locator('#deal').click();q.wait_for_timeout(40)
    check('Storage-denied environment supports explicit memory-only play',q.locator('#bank').inner_text()=='99.00' and 'Memory only' in q.locator('#save-status').inner_text());q.close()
    check('No uncaught browser exceptions in all fixtures',not errors)
    check('Standalone demo performs no network requests',not requests)
    browser.close()
report={'checksPassed':len(checks),'checks':checks,'errors':errors,'requests':requests,'engine':'Chromium via Playwright','method':'set_content of shipped standalone HTML; explicit in-memory storage fixture for restoration; actual Web Crypto for random deals except missing-RNG test','limits':'URL navigation is administrator-blocked here. Not a live deployment, real file:// persistence, physical phone, Safari, wallet, or cryptographic certification.'}
(OUT/'BROWSER_CHECKS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'checksPassed':len(checks),'errors':errors,'requests':requests},indent=2))
