#!/usr/bin/env python3
"""Exercise the patch against an unpacked, unmodified supplied site. Stdlib only."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parents[1]
def hashes(p):return {f.relative_to(p).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file()}
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--site',type=Path,required=True);a=parser.parse_args()
    source=a.site.resolve();initial=hashes(source);checks=[]
    def check(name,ok):
        if not ok:raise AssertionError(name)
        checks.append(name)
    with tempfile.TemporaryDirectory(prefix='project51-patch-') as t:
        t=Path(t);site=t/'site';backup=t/'backup';shutil.copytree(source,site)
        cmd=[sys.executable,str(ROOT/'tools/apply_site_patch.py'),'--site',str(site)]
        dry=subprocess.run(cmd,capture_output=True,text=True,check=True);plan=json.loads(dry.stdout)
        check('Dry run proposes nine additions and five HTML replacements',plan['plan']=={'add':9,'replace':5,'unchanged':0})
        check('Dry run changes no source bytes',hashes(site)==initial)
        subprocess.run(cmd+['--apply','--backup-dir',str(backup)],check=True,capture_output=True,text=True)
        after=hashes(site);changed={k for k in initial if after.get(k)!=initial[k]}
        expected={r['path'] for r in json.loads((ROOT/'audit/SITE_PATCH_TARGETS.json').read_text())}
        check('Only the five authorized HTML files are changed',changed==expected)
        check('All original files still exist',set(initial)<=set(after))
        check('Every original non-HTML-target file is byte-for-byte unchanged',all(after[k]==h for k,h in initial.items() if k not in expected))
        protected=[k for k in initial if k.startswith('finance/') or 'wallet' in k.lower() or '/credits' in k.lower()]
        check('Finance, wallet, and credit implementation bytes are unchanged',bool(protected) and all(after[k]==initial[k] for k in protected))
        check('Original HTML backups are exact',all(hashlib.sha256((backup/k).read_bytes()).hexdigest()==initial[k] for k in expected))
        reapply=subprocess.run(cmd+['--apply','--backup-dir',str(backup)],check=True,capture_output=True,text=True)
        check('Reapplication is idempotent',json.loads(reapply.stdout)['changes']=={'add':0,'replace':0,'unchanged':14} and hashes(site)==after)
        # Conflict test must abort preflight, not silently overwrite a newer website.
        drift=site/'area-51/invariant/index.html';drift.write_text(drift.read_text()+'\n<!-- later team edit -->\n');before=hashes(site)
        bad=subprocess.run(cmd+['--apply','--backup-dir',str(backup)],capture_output=True,text=True)
        check('A later team edit causes a no-write refusal',bad.returncode!=0 and hashes(site)==before)
    out={'checksPassed':len(checks),'checks':checks,'baselineFileCount':len(initial),'protectedFileCount':len(protected),'protectedPaths':protected,'modifiedPaths':sorted(changed),'newPaths':sorted(set(after)-set(initial)),'scope':'Local copy of supplied site only. No deployed files, external accounts, or live wallet were modified.'}
    (ROOT/'audit/SITE_PATCH_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'checksPassed':len(checks),'baselineFileCount':len(initial),'protectedFileCount':len(protected)},indent=2))
if __name__=='__main__':main()
