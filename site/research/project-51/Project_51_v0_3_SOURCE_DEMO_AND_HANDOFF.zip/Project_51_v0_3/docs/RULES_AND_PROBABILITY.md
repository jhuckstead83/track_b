# Rotor 51 / Rule card R51-0.3

## Fixed object and permitted actions

The active pack is the supplied 51-identity dictionary: ordinary rank/suit identities except 2C. The outside marker is not a wild card, selectable reel identity, or substitute for a missing rank. There are 26 red and 25 black active identities. The card/component bijection is unchanged.

Deal five distinct identities into ordered slots. The initial five leave the inventory. Hold zero through five slots; draw once to replace all unheld slots, or bank the original hand immediately. All five original identities, including discards, remain excluded from replacement. A draw settles immediately. Display flips do not hold, draw, consume an entry, or alter identity.

Royal, nonroyal straight flush, four of a kind, full house, flush, straight, three of a kind, two pair, and jacks-or-better receive the gross point awards below. Every other hand receives zero. Aces are high or low in A-2-3-4-5 only. Straights do not wrap around the ace. Exact suit identities define a flush, not red/black color. There is no suit tiebreak payout.

## Uniform depletion rotors

Begin from the canonical identity list `a_1,...,a_51` in `data.js`, not the published record's shuffled order. For rotor slot `j=1,...,5`, the initial remaining size is `m=52-j`. Draw an independent uniform integer `d` from `0,...,m-1`, form `e=(a*d+b) mod m`, and remove the identity at zero-based index `e` in the current remaining list.

Unit wiring uses `a=1`. Geared wiring begins with `(2*j+1) mod m` and increments cyclically to the first residue coprime to `m`. Let `k` be the ring setting in `0,...,50`. The offset is `b=(k+j*(j+1)/2+carry) mod m`. The initial deal starts its carry at the round number. After each selection, `carry += e+1`. A redraw starts a new carry at `round number + 51`, uses original slot indices for `j`, and selects unheld slots from left to right.

Settings are frozen throughout a hand. They may change the mapping of fresh random digits, but they cannot depend on the current unseen digit. Multiplication by a unit and translation are bijections. Conditional on every preceding selection, each remaining identity therefore has probability `1/m`. The product is uniform on all

```
51 * 50 * 49 * 48 * 47 = 281,887,200
```

ordered initial hands. This is a mathematical implication of the uniform-input assumption, not an empirical certification of a browser's random source. The implementation obtains words from Web Crypto and rejects words outside the largest multiple of `m` below `2^32` before taking a remainder. It has no `Math.random` fallback.

For a general step `a`, if `g=gcd(a,m)`, exactly `m/g` output positions are reachable, each with `g` preimages. The mechanism lab demonstrates this at modulus 51. Noncoprime gearing is **not** offered as a live-play setting with the same paytable.

Two mixed-radix address dials `u in 0..2` and `v in 0..16` give `i=17*u+v`. Together they name all 51 canonical identities once. This is an addressing view, not a new two-card poker mode. Five independent modulus-51 reels would instead allow repeats, with `51^5` ordered outputs; that is a different model. Three- or seven-card variants likewise require newly declared scoring and new counts.

## Exact opening census

There are `C(51,5)=2,349,060` unordered initial hands. Counts are mutually exclusive, with royal flushes removed from the straight-flush row and all straight flushes removed from the straight/flush rows.

| Category | Count | Gross points |
|---|---:|---:|
| Royal flush | 4 | 250 |
| Nonroyal straight flush | 34 | 50 |
| Four of a kind | 564 | 25 |
| Full house | 3,384 | 9 |
| Flush | 4,615 | 6 |
| Straight | 9,690 | 4 |
| Three of a kind | 49,632 | 3 |
| Two pair | 111,672 | 2 |
| Jacks or better, exactly one pair | 316,800 | 1 |
| No award, including low pairs | 1,852,665 | 0 |
| **Total** | **2,349,060** | |

`tests/engine_checks.cjs` exhaustively scores every initial subset. `tests/independent_census.py` independently enumerates 6,163 valid rank multisets and counts their suit assignments, using rank-2 capacity three rather than four. It agrees in every category without using the JavaScript evaluator for its count.

The opening base gross expectation **when banking the deal without a draw** is `802746/2349060 = 0.341730734847...` points. Net expectation subtracts the one-point entry. This excludes the separately reserved archive bonus. It is not the return of a draw strategy or an optimal-play RTP. The UI offers exact conditional calculations instead of reusing opening probabilities after a player intervention.

## Conditional draw domain

For a fixed initial hand and a chosen hold with `r` replacements, the pool has 46 eligible identities and there are `C(46,r)` equally likely replacement subsets. Ordered draws are uniform too; poker scoring forgets the `r!` orders within each such subset. Denominators for `r=0,...,5` are

```
1, 46, 1,035, 15,180, 163,185, 1,370,754.
```

The conditional-odds panel exhaustively evaluates this domain for the current hold and reports award chance, royal count, and expected base gross points. The entry is already paid. The archive bonus is fixed by the first deal and therefore cannot be improved by changing holds.

For example, holding 10H-JH-QH-KH from an initial hand whose fifth card is 2S gives exactly one royal completion, AH, among the remaining 46. Neither `4/C(51,5)` nor `1/47` is the probability for that decision. Changing a valid gear does not change this conditional distribution; changing the held subset generally does.

## Ordered archive target

The key is `[10S, JD, JH, KS, 10D]`, the published record's last five identities. It is tested on the initial ordered slots only. Every distinct five-card subset has `5!=120` ordered realizations, but only one realization of this particular subset matches the key. The key probability is `1/281887200` per initial deal under the declared uniform model.

The key's ordinary poker score is two pair. Swapping its first two cards preserves that score but loses the ordered prize. This is a concrete failure of recovering an ordered target from an unordered view, not evidence that the published source predicts random deals.

The demo meter begins at 51.00 points and adds 0.01 per paid entry. A hit reserves the incremented amount, resets the meter to 51.00, and adds the reserved amount once to the eventual poker award. The meter is a local illustration. Resettable, client-owned demo points do not constitute a funded global progressive.

## Future shared-prize service: required contract, not implemented

A shared service must own the round ID, rules/data hash, entry debit, randomness, initial eligibility, hold commitment, replacement draw, settlement and meter transition. A retry of the same round/phase must return the same committed result, not redraw or repay. Meter increment, jackpot reservation and reset must be atomic across concurrent players. The client cannot submit its own winning hand as authority.

Define disconnect/recovery, aborted-round, refund, version migration and maximum-credit policies before exposing shared stakes. Replay the frozen rule engine against the authoritative receipt. Publish a separately computed strategy/economic model before claiming a return figure. No such service or certification is included in v0.3.
