# Notation, provenance and claim ledger

## Symbol before illustration

The retained card is an identity, not a picture that needs a paragraph of introduction each time it appears. The PDF's small square tile is a typographic replacement for a card abbreviation. It preserves rank, suit shape and red/black color at body-text scale. The frozen 51-card record is now three compact rows of seventeen tiles rather than oversized explanatory artwork. Machine-readable fixtures retain their exact ASCII card identifiers.

The web equivalent is:

```html
<p51-token card="8S"></p51-token>
<p51-token card="8S" face="symbol"></p51-token>
```

A tile flips its face without changing identity. Use `static` for a noninteractive token; `size="reel"` opts into a larger active-table face. Styling is encapsulated in a shadow root. Labels name the card and exact component role/code point. Both suit shape and rank remain available; color is not the sole identifier. Hold controls are separate full-size buttons. Do not attach an implicit wager or hold to a face flip.

The component paths in `data.js` are outlined from Noto Sans CJK KR for consistent rendering. They represent the original Unicode characters; they are not a replacement cipher alphabet. No font binaries are distributed. The local source-font license notice is in `docs/THIRD_PARTY_NOTICES.txt`.

## What the indices mean

`m=1,...,51` is the dense canonical identity address. `cardSlot` retains source CSV `q`, the zero-based address in the 52-slot rank/suit convention with the 2C gap. These are not interchangeable. The mixed-radix lab uses `i=m-1`, **not** `q`.

For the triangular address, `m=n(n-1)/2+k`, with `1<=k<=n`. The reduced point and gcd are separate retained fields. The alphabet has 3 L components, 21 V components and 27 T components. The source weight classes retain sizes 2, 1, 9, 1, 9, 11 and 18. None of those class sizes is silently substituted for the live reel probability distribution.

## Source authority

The nonvisual Project 51 v0.2 archive supplies the prior mathematical baseline. The supplied card-visual version provides the immediate manuscript and visual direction; its exact fixtures and verifier are preserved. The v2.1.0 full website is the patch baseline. The older v2.0.2 mobile/audit archive is not allowed to overwrite its newer Finance changes.

The two numbered publication archives and TN Postmaster v5.1 remain companion context; this package neither republishes nor independently recertifies their complete analytic contents. No source theorem is upgraded merely because the interface illustrates a related distinction. All seven supplied archive hashes are in `audit/INPUT_SHA256.json`.

The shared-chat URL did not expose readable conversation content in this environment. The supplied archives and the user's reproduced final prompt, rather than an invented reconstruction of that chat, control this handoff.

## Inherited, new, and not established

| Item | Status in v0.3 |
|---|---|
| Exact 51-identity dictionary and frozen published record | Retained; checked against paper and website fixtures |
| Prior recovery results, 48-label joint view and eight lifts | Retained from v0.2/source research with original attribution |
| Original 65-check verifier and 1,566-record audit | Replayed; not replaced by game tests |
| Compact card notation | New presentation of retained identities |
| Uniformity of coprime affine depletion rotors | Proved in new Proposition 5 under independent uniform input digits |
| Common-factor support/preimage count | Proved in the same proposition; exposed in the mechanism lab |
| Five-card opening census | Exhaustively counted and independently cross-checked |
| Exact conditional draw domains | Implemented per hold, with all initial cards excluded |
| Archive lock and point paytable | New declared game conventions, not recovered source laws |
| New zero law, RH implication, physical information cost, human learning effect | Not established or claimed |
| Optimal draw-policy return, certified RNG, shared/global jackpot | Not established or implemented |

The useful addition is not a claim that poker proves the source. It is a controlled comparison: invertible face changes preserve identity; unordered scoring loses order; player holds change the conditional experiment; a noninvertible gear removes possible outputs. Each has a different mathematical effect and a visible place in the interface.
