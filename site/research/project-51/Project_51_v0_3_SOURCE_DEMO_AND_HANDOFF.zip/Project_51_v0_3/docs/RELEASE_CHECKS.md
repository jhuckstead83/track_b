# Release evidence and limits

This package separates source verification, exact finite counting, UI exercise and deployment readiness. A count of passed checks is not a count of independent mathematical theorems.

| Gate | Delivered result | Evidence |
|---|---|---|
| Original Project 51 verifier | 65 checks passed; 1,566-record audit retained | `paper/results/PAPER_CHECKS.json` |
| Manuscript build | 13 pages; no overfull boxes or unresolved references; identical PDF hash on repeat build | `paper/build/BUILD_CHECKS.json` |
| Pure game engine | 33 named checks, including all 32 hold masks, slot preservation, discard exclusion, archive reservation, save validation and settlement-once | `audit/ENGINE_CHECKS.json` |
| Exact opening-hand census | All 2,349,060 subsets evaluated | Same engine receipt |
| Independent combinatorial census | 6,163 valid rank multisets; all ten category totals match | `audit/INDEPENDENT_CENSUS.json` |
| New demo in Chromium | 59 checks, seven viewport widths, no uncaught exceptions, no network requests | `audit/BROWSER_CHECKS.json` |
| Existing-game mobile pass | 62 checks; six viewport widths across four games; basic game actions preserved | `audit/MOBILE_CHECKS.json` |
| Safe website patch | 9 checks; 406 baseline files compared; 60 Finance/wallet/credit paths unchanged | `audit/SITE_PATCH_CHECKS.json` |

The manuscript was rendered and inspected as page images, including every page in a contact sheet and detailed views of the compact notation and new rotor section. Final UI screenshots are included. This is a manual visual review, not a proof of absence of every layout or accessibility defect.

Browser testing used actual Chromium via Playwright `set_content`. Navigation to public, local-server and file URLs is administrator-blocked in this authoring environment. The new game used its actual inlined scripts; restoration tests used explicit storage fixtures. Existing-site testing used a test-only local asset/module wrapper and in-memory wallet fixtures. The original production scripts were not replaced by that wrapper in the delivered website patch.

Not certified here: deployment, real account state, cross-browser persistence, physical phone rendering, Safari, assistive-technology behavior, cryptographic random-source quality, anti-cheat, optimal draw-policy return, funded shared jackpot, participant learning or a new RH result. These limits do not detract from the exact finite counts or the conditional uniformity proof; they define their scope.
