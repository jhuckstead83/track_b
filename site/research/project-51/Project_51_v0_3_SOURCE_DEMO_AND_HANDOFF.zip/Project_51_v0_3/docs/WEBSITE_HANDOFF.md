# Website-team handoff: Project 51 v0.3 / Rotor 51

**Deliverable:** one new playable game, compact identity notation, a 13-page paper, and an optional mobile presentation patch.  
**Controlling website:** the supplied `CerebralGraphix_FINANCE_WEATHER_v2_1_0_FULL_SITE(1).zip`.  
**Do not replace the whole site. Do not connect this prototype to the jbit wallet by changing its storage key.**

## 1. The design to preserve

Use the familiar card face first. A small square rank/suit tile should occupy the role of a symbol in a sentence, table, trace, or formula. The tile is already meaningful notation; do not put a large explanatory card diagram in front of every use. A click or keyboard activation reveals the exact corresponding component from the paper. The identity, hold, outcome and bank must not change when its face changes.

The new table is **Rotor 51**. Five depletion rotors deal five distinct identities from the existing 51-card alphabet. The player can hold any subset and draw the rest once, or bank the first hand. Poker supplies the unordered reading. The archive lock supplies the ordered reading. One swap can leave the first unchanged and destroy the second.

The component weights are retained source data, not reel probabilities. The rotor moduli are determined by the remaining inventory. The poker categories, payout amounts, triangular ring offsets, and particular archive key are explicitly declared design choices, not laws inferred from the source.

## 2. Drop-in files and routes

The new route is `/area-51/rotor-51/`. Its six files are `index.html`, `style.css`, `data.js`, `engine.js`, `tokens.js`, and `app.js`. They are dependency-free browser assets; serve over the site's normal HTTPS origin. There is no module loader, fetch call, external font requirement, analytics service, or shared-wallet import in this game.

The paper is additive at `/research/project-51/Project_51_v0_3.pdf`. Leave older publications and their identifiers in place. This draft does not introduce a new DOI.

`data.js` contains the exact identity dictionary and outlined component glyphs. `engine.js` is the pure rule layer. `tokens.js` owns display only. `app.js` owns the isolated demo state and UI. These layers can be reused without absorbing the rest of the site's economy.

`demo/Rotor_51_v0_3_DEMO.html` bundles the same CSS and scripts for portable review. The website should use the separate files, not add the single-file demo as another copy of the application.

## 3. Apply safely

From this package root, point the patch tool at an unpacked full-site copy:

```sh
python tools/apply_site_patch.py --site /path/to/full-site
python tools/apply_site_patch.py --site /path/to/full-site --apply --backup-dir /path/to/backup
```

The first command is a dry run. The second writes only after all target hashes match the expected baseline or the already-applied patch. It backs up replaced HTML and verifies written bytes. The expected plan is **nine additions and five HTML replacements**. It refuses an unrecognized edit instead of erasing newer work. Individual replacements are atomic; this is not a transactional deployment system. Retain the backup until staging acceptance.

The five replacements are the Area 51 hub and the `index.html` files for Invariant, Blackjack, Telescope and Memory. Original executable inline scripts are preserved. All other original files are unchanged, including the game engines, card dictionary, shared wallet/credit code and Finance assets. The local patch audit compared all 406 original files and explicitly checked 60 Finance/wallet/credit paths. It also checked refusal on a simulated later edit and idempotent reapplication.

On a newer site, use `docs/WEBSITE_PRESENTATION.diff` and `audit/SITE_PATCH_TARGETS.json` to reconcile the five pages manually. Do not bypass a hash conflict merely because these changes are described as cosmetic.

## 4. Mobile presentation patch

The new `project51-mobile-v03.css` is scoped to `data-p51-mobile` and applies its compact rules at 600 CSS pixels and below. A tiny companion script closes optional setup panels at initial phone load; desktop setup remains open. Every original game action, identifier and rule remains available.

Invariant moves the free play controls above the felt, keeps three hands side by side, and puts order/view settings in a disclosure. Blackjack moves its existing stake/action controls before the table in document order; no button is cloned. Telescope moves the optional branch/resolution-word panel below the player cards, compacts the rule-depth controls and retains the rule ledger. Memory presents four answers in a two-by-two grid and reduces the empty stage area. Phone navigation becomes a contained horizontal strip instead of consuming several rows.

The Invariant and Blackjack action moves also affect desktop document order. This is deliberate: keyboard order agrees with visual order. It is not a change to their game transitions.

Measured at 390 by 844 CSS pixels in the local browser fixture:

| First relevant action | Before: top coordinate | After: top coordinate |
|---|---:|---:|
| Invariant: Play one turn | 1,513 px | 409 px |
| Blackjack: Deal a hand | 979 px | 395 px |
| Telescope: Choose winner | 1,459 px | 785 px |
| Memory: first answer | 664 px | 508 px |

These are document positions at initial render, not guaranteed device-specific timings or fold positions. Memory can begin with a card or a component, so small height differences are expected. Invariant's 401-pixel and Blackjack's 407-pixel overflow at a 390-pixel viewport became 390 pixels. The patched four-game pages were checked at 320, 360, 390, 600, 768 and 1280 pixels, including a basic gameplay interaction at 390 pixels. Screenshots are in `audit/previews/`.

## 5. The demo economy is deliberately separate

A new demo starts at 100.00 points. A deal costs 1.00, a redraw is free, and awards are gross rather than profit. A tab-local meter starts at 51.00 and adds 0.01 per paid deal. An initial ordered-key hit reserves that incremented meter, resets the visible meter to 51.00, and adds the reserved amount once when the hand settles. It remains reserved if the player redraws.

The key is the supplied published record's last five cards: **10S, JD, JH, KS, 10D**, in that order. Only the initial deal can qualify. The example buttons illustrate a royal or this key without charging, paying, or replacing an unfinished game. The order prize is intentionally extremely rare under the declared sampler; examples are labelled illustrations, not manufactured wins.

The storage key is `project51.rotor51.v0.3.tab-demo` in `sessionStorage`, not `localStorage`. Normal same-tab refresh can retain a live hand when the browser permits session storage. The state is browser-controlled and has no monetary or shared-jbit value. A malformed save is preserved and play blocked until explicit reset. Denied storage switches to clearly labelled memory-only mode. Reset does not touch shared jbits or Finance holdings.

This is **not** a site-wide funded progressive, an anti-cheat system, or an economic-return certification. Before shared prizes are enabled, implement a server-authoritative round/settlement service, atomic meter accounting, explicit versioned rules, restart/refund policy, and an economic review of player strategies. The pure engine is suitable for replay tests, not proof that a client-reported win should be credited.

## 6. Acceptance before public release

First verify the package with `python tools/verify_manifest.py`. Apply on staging, check all fourteen manifest paths and the paper link, and confirm that existing Finance views and balances behave exactly as before. Open all five games on actual target phones, keyboard-only desktop, Safari and Chromium. Check existing games with both fresh and already-persisted banks, including Blackjack dealing and cross-game bank continuity. Confirm the new game never changes that bank.

For Rotor, test deal/hold/draw, bank without drawing, all-held, symbol flips, examples during a hand, conditional odds, interrupted-hand refresh, invalid saved state, denied storage, absent RNG and explicit reset. Verify that examples never pay and settlement cannot repeat. Review contrast and screen-reader announcements on actual assistive technology; this package provides accessible labels/focus handling, not an accessibility certification.

The delivered browser tests use real Chromium with inlined local assets because this environment blocks URL navigation. Existing-game scripts use a test-only module wrapper and storage fixtures. Do not mistake those checks for a public-URL, real-wallet or physical-device deployment test. Nothing in this handoff has been deployed.
