/* Collapse only optional setup at initial phone load. Game state is untouched. */
(function(){
 'use strict';
 function init(){
  if(window.matchMedia('(max-width:600px)').matches){
   document.querySelectorAll('[data-p51-mobile] .p51-setup-panel').forEach(el=>el.open=false);
  }
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
