(function(){'use strict';
 const E=globalThis.P51Engine,$=id=>document.getElementById(id),KEY='project51.rotor51.v0.3.tab-demo';
 let state=E.fresh(),preview=null,busy=false,display='card',oddsEpoch=0,saveAvailable=true,saveInvalid=false;
 const faces=new Map();
 const money=n=>(n/100).toFixed(2),fmt=n=>n.toLocaleString('en-US');
 function error(err){$('error').hidden=false;$('error').textContent=err.message||String(err);}
 function save(){try{sessionStorage.setItem(KEY,JSON.stringify(state));$('save-status').textContent='Saved in this tab only';}catch{saveAvailable=false;$('save-status').textContent='Memory only; browser storage unavailable';}}
 let savedRaw=null;
 try{savedRaw=sessionStorage.getItem(KEY);}catch{saveAvailable=false;$('save-status').textContent='Memory only; browser storage unavailable';}
 if(savedRaw){try{state=E.validate(JSON.parse(savedRaw));}catch(err){saveInvalid=true;error(new Error('The saved demo could not be read. It has not been replaced. Reset demo to start a new isolated bank.'));}}
 if(state.round){$('wiring').value=state.round.settings.wire;$('knob').value=state.round.settings.knob;$('knob-out').textContent=String(state.round.settings.knob);}
 function cancelOdds(){oddsEpoch++;$('odds-result').textContent=state.phase==='hold'?'Choose a hold and count its possible draws.':'Deal a hand to compare a decision.';}
 for(let i=0;i<5;i++){
  const div=document.createElement('div');div.className='rotor';div.id='rotor-'+i;
  div.innerHTML=`<p class="rotor-label">ROTOR ${String(i+1).padStart(2,'0')}</p><div class="drum"><p51-token size="reel" id="token-${i}" static></p51-token></div><p class="residue" id="residue-${i}">mod ${51-i}</p><button class="hold" id="hold-${i}" aria-pressed="false" aria-label="Hold rotor ${i+1}" disabled>HOLD</button>`;
  $('rotors').appendChild(div);$('hold-'+i).onclick=()=>act(()=>{state=E.hold(state,i);save();cancelOdds();render();});
 }
 for(const card of E.ARCHIVE_KEY){const t=document.createElement('p51-token');t.setAttribute('card',card);$('archive-key').appendChild(t);}
 for(let i=9;i>=1;i--){const tr=document.createElement('tr');tr.id='pay-'+i;tr.innerHTML=`<td>${E.CATEGORIES[i]}</td><td>${E.PAYS[i]}</td>`;$('paytable').appendChild(tr);}
 document.addEventListener('p51-inspect',e=>{faces.set(e.detail.card,e.detail.face);});
 function act(fn){if(busy||saveInvalid)return;try{$('error').hidden=true;fn();}catch(err){error(err);render();}}
 function settings(){return {wire:$('wiring').value,knob:Number($('knob').value)};}
 function animate(){busy=true;$('rotors').classList.add('spinning');render();const ms=matchMedia('(prefers-reduced-motion: reduce)').matches?0:330;setTimeout(()=>{busy=false;$('rotors').classList.remove('spinning');render();},ms);}
 function render(){
  const r=state.round,hand=preview?preview.hand:r?r.hand:[],active=state.phase==='hold'&&!preview,settled=state.phase==='settled'&&!preview;
  $('bank').textContent=money(state.balanceCents);$('meter').textContent=money(state.meterCents);$('example-banner').hidden=!preview;
  for(let i=0;i<5;i++){
   const t=$('token-'+i),c=hand[i];if(c){t.removeAttribute('static');if(t.getAttribute('card')!==c)t.setAttribute('card',c);t.setAttribute('face',faces.get(c)||display);}else{t.setAttribute('static','');t.removeAttribute('card');}
   const h=active&&r.holds[i];$('rotor-'+i).classList.toggle('held',!!h);$('hold-'+i).setAttribute('aria-pressed',String(!!h));$('hold-'+i).textContent=h?'HELD':'HOLD';$('hold-'+i).disabled=!active||busy||saveInvalid;
   const rows=!preview&&r?r.trace.filter(t=>t.slot===i):[],tr=rows[rows.length-1];$('residue-'+i).innerHTML=tr?`<span>mod ${tr.m}</span><span>${tr.d} &rarr; ${tr.e}</span>`:`<span>mod ${51-i}</span><span>&nbsp;</span>`;
  }
  $('deal').hidden=active||!!preview;$('deal').disabled=busy||saveInvalid||state.balanceCents<100;
  $('draw').hidden=!active;$('draw').disabled=!active||busy||saveInvalid;
  $('draw').textContent=active&&r.holds.every(Boolean)?'Keep all \u00b7 bank':'Draw unheld \u00b7 free';
  $('bank-hand').hidden=!active;$('bank-hand').disabled=busy||saveInvalid;$('exit-example').hidden=!preview;
  $('wiring').disabled=active||busy;$('knob').disabled=active||busy;$('odds').disabled=!active||busy||saveInvalid;
  $('show-cards').setAttribute('aria-pressed',String(display==='card'));$('show-symbols').setAttribute('aria-pressed',String(display==='symbol'));
  for(let i=1;i<=9;i++)$('pay-'+i).classList.remove('active');
  const s=hand.length?E.score(hand):null;if(s&&s.category)$('pay-'+s.category).classList.add('active');
  $('result').classList.toggle('win',!!(s&&s.category&&(settled||preview)));
  if(preview){$('result-title').textContent=preview.name;$('result-note').textContent=E.score(preview.hand).name+' \u00b7 illustration only; no points awarded.';}
  else if(active){$('result-title').textContent='What will you keep?';$('result-note').textContent=s.name+' now. '+(r.pendingBonusCents?'Archive lock matched; '+money(r.pendingBonusCents)+' bonus secured for settlement.':'Hold any cards, then draw once or bank this hand.');}
  else if(settled){$('result-title').textContent=r.result.name+(r.result.totalCents?' \u00b7 +'+money(r.result.totalCents):'');$('result-note').textContent='Gross '+money(r.result.totalCents)+'; net '+(r.result.netCents>=0?'+':'')+money(r.result.netCents)+' after the one-point entry.';}
  else{$('result-title').textContent='A new reading of the same cards.';$('result-note').textContent='Deal five, hold any, then draw once or bank the hand.';}
  $('trace').replaceChildren();if(!preview&&r)for(const row of r.trace){const tr=document.createElement('tr');for(const val of [row.slot+1,row.m,row.a,row.b,row.d,row.e,row.card]){const td=document.createElement('td');if(typeof val==='string'){const t=document.createElement('p51-token');t.setAttribute('card',val);td.appendChild(t);}else td.textContent=val;tr.appendChild(td);}$('trace').appendChild(tr);}
  $('history').replaceChildren();for(const h of state.history){const div=document.createElement('div');div.className='history-row';const left=document.createElement('span'),right=document.createElement('span');left.textContent='#'+h.id+' \u00b7 '+h.result.name;right.textContent=money(h.result.totalCents)+' gross';div.append(left,right);$('history').appendChild(div);}
 }
 $('deal').onclick=()=>act(()=>{preview=null;state=E.deal(state,settings());save();cancelOdds();animate();});
 $('draw').onclick=()=>act(()=>{state=E.finish(state,true);save();cancelOdds();animate();});
 $('bank-hand').onclick=()=>act(()=>{state=E.finish(state,false);save();cancelOdds();render();});
 $('exit-example').onclick=()=>{preview=null;cancelOdds();render();};
 for(const b of document.querySelectorAll('[data-example]'))b.onclick=()=>{if(busy)return;preview=b.dataset.example==='royal'?{name:'A royal, read two ways.',hand:['10H','JH','QH','KH','AH']}:{name:'The archive lock, exactly.',hand:E.ARCHIVE_KEY};cancelOdds();render();};
 for(const [id,mode]of[['show-cards','card'],['show-symbols','symbol']])$(id).onclick=()=>{display=mode;faces.clear();render();};
 $('knob').oninput=()=>$('knob-out').textContent=$('knob').value;
 $('reset').onclick=()=>{if(busy)return;if(!confirm('Reset only the Rotor 51 sandbox to 100 demo points and a 51-point local meter? Shared jbits and Finance are not touched.'))return;state=E.fresh();preview=null;saveInvalid=false;$('error').hidden=true;save();cancelOdds();render();};
 $('export-record').onclick=()=>{const payload={format:'Rotor51-public-demo-record-v0.3',createdAt:new Date().toISOString(),disclaimer:'Client-side example record. No server validation or random-source certification.',state};const url=URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='Rotor_51_demo_record.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);};
 $('odds').onclick=()=>act(async()=>{
  if(state.phase!=='hold'||preview)return;const epoch=++oddsEpoch,job=E.drawOdds(state.round.initial,state.round.holds);const counts=E.PAYS.map(()=>0);let done=0,gross=0;
  $('odds').disabled=true;
  function batch(){
   if(epoch!==oddsEpoch)return;let item;
   for(let n=0;n<3500;n++){
    item=job.iterator.next();if(item.done)break;const c=E.scoreFast(job.kept.concat(item.value));counts[c]++;gross+=E.PAYS[c];done++;
   }
   if(item&&item.done){const paid=done-counts[0];$('odds-result').textContent=`${fmt(done)} equally likely completions. Award chance ${(100*paid/done).toFixed(4)}%. Royal: ${counts[9]} / ${fmt(done)}. Expected base gross: ${(gross/done).toFixed(6)} points. The entry is already paid; the archive bonus is fixed by the initial deal.`;$('odds').disabled=false;}
   else{$('odds-result').textContent=`Counting ${fmt(done)} / ${fmt(job.total)} completions... Change a hold to cancel.`;setTimeout(batch,0);}
  }
  setTimeout(batch,0);
 });
 function lab(){const u=Number($('lab-u').value),v=Number($('lab-v').value),i=17*u+v,d=E.DATA[i];$('u-out').textContent=u;$('v-out').textContent=v;$('lab-token').setAttribute('card',d.card);$('lab-address').textContent=`i = ${i}; canonical identity a${i+1}; ${d.role}, ${d.codePoint}. Triangular address (${d.n}, ${d.k}).`;const a=Number($('lab-step').value),reach=new Set(Array.from({length:51},(_,j)=>(a*j)%51));$('lab-dots').replaceChildren();for(let j=0;j<51;j++){const s=document.createElement('span');s.className='dot'+(reach.has(j)?' on':'');$('lab-dots').appendChild(s);}$('lab-reach').textContent=`gcd(${a}, 51) = ${E.gcd(a,51)}. ${reach.size} of 51 positions reachable; ${E.gcd(a,51)} input digits per reachable output.`;}
 for(const id of ['lab-u','lab-v','lab-step'])$(id).oninput=lab;
 if(!globalThis.crypto?.getRandomValues)error(new Error('Secure browser randomness is unavailable. Random deals will not run; examples and the mechanism lab remain available.'));
 lab();render();
})();
