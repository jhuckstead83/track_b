---
title: "The Line Game | Surprise Is Not Meaning"
subtitle: "The answer key, the folded line, and a number in the reader's hands"
author: "Jeffery Lyn Huckstead"
date: "Preprint v7.2 | 19 September 2026"
lang: en-US
fontsize: 11pt
---

\begin{center}\small Cerebral Graphix\quad |\quad ORCID 0009-0007-0234-2177\quad |\quad CC BY 4.0\end{center}

## Abstract

A word can finish a sentence and reopen a page. Its surprise has a probability model; the work of its placement belongs to a composition. This paper follows that distinction through an answer-key game, a message recovered from fractions, a number carried by a pack of cards, and a positive distribution on folded zeta-zero states. The cards let a reader check what an arrangement and a shared convention supply. A finite card game then makes recurrence and a terminating rule explicit. The zero-state construction gives an exact boundary: a property is recoverable from an observation precisely when it is constant on that observation's fibers. On the ambient domain, a point on the critical line and one off it can have the same weight. RH remains open. The larger argument concerns what makes a measurement count, and how a small statement recruits work the reader already carries.

## 1. The word that arrives late

A word lands in a rhyme. It fits the sound, the timing, the sentence. Then it does something else: the listener hears the preceding lines differently. Nothing in those lines has moved. A relationship has become available.

The best next word for the last five words need not be the best next word for the last fifty. A word chosen for a later turn may look merely adequate where it first appears. When the turn arrives, the earlier placement acquires a second use. The rhyme closes; the composition stays open.

There is a primal distinction here. A word's local fit and its work across a whole passage are different questions. Change one consequential word and the grammar may survive while the preparation, echo, or delayed recognition fails. The unit of the edit was one word. The unit of the judgment was the work.

Shannon gave surprise an exact measure. For a specified distribution $P$, an outcome $x$ with $P(x)>0$ has

$$
I_P(x)=-\log_2 P(x),\qquad H_2(P)=\sum_xP(x)I_P(x).
\tag{1}
$$

Lower probability gives greater surprisal; entropy averages it over the source [1]. The model may include a long context. That does not turn the resulting scalar into a statement of what the placement accomplishes. To assess that accomplishment, we still need the relation being sought and the context in which it matters.

The title has already asked the reader to do this work. Four familiar words invite an interpretation before their claim has been examined. A reader may object, agree, or wait. The same sentence has arrived; it has entered different compositions.

\newpage

## 2. The answer key does the quiet work

In Wordle, the secret word exists before the first guess. The rules define what counts as finding it. An entropy-based guess is useful because its feedback is expected to narrow the remaining possibilities. The relevant probabilities concern feedback against candidate answers, rather than the rarity of the guess's letters [4].

The answer key and the rules are doing quiet work. They give the search a destination and make progress assessable. The score can guide a player because the game has already supplied a reason to prefer one reduction of uncertainty to another. One-step entropy maximization is a search strategy; the objective belongs to the game.

This is the sense in which the answer key is a **hidden semantic engine**: within the demonstration, it supplies the practical interpretation that makes the score look like importance. The phrase names a dependency. The player does not have to rediscover the game's purpose with every guess, and the entropy calculation does not have to produce that purpose.

Open prose need not offer a final word to uncover. It can give a reader a question, an argument, an invitation, or several uses at once. There may be a strong authorial intention without a unique answer that ends the reading. Removing the game's answer key leaves the measurement intact. What becomes visible is the work the key had been doing.

An early version of the author's text-weighting engine made this distinction conspicuous. On one sample of news prose, its provisional letter-value table favored rare-lettered names. The run had no independent reader-salience control. It motivates the present question; it does not establish how surprise and importance correlate. A calibrated model and a reader task could test that relation. Their specification would be part of the experiment.

### The debt comes first

Shannon explicitly separated semantic interpretation from his engineering problem of reproducing a selected message [1]. Landauer's treatment of logical irreversibility and Bennett's construction of reversible computation make a related discipline concrete: identify the operation before charging it a cost [2,3]. Their physical results retain their own assumptions. We borrow the care with which the question is set.

Sanderson's exposition of information theory through Wordle is a direct stimulus [4]. It belongs to the tradition of making an exact structure visible inside ordinary play. The present paper takes that invitation seriously enough to ask what changes when the game ends and the reading continues.

The distinction is inherited. The composition offered here puts its dependence on a key in view. **A score can complete its calculation before a reader has settled what counts.**

\newpage

## 3. The address was paid in advance

The triangular-fractional grid begins with a small act: divide each chamber into its own number of equal steps,

$$
a(n,k)=n-1+\frac{k}{n},\qquad 1\le k\le n.
\tag{2}
$$

The capstone *A Message Hidden as an Address* proves the inverse [8]. For a positive reduced fraction $r/d$, set $n=\lceil r/d\rceil$. It belongs to the grid exactly when $d\mid n$, and its step is

$$
k=\frac nd\bigl(r-d(n-1)\bigr).
\tag{3}
$$

One fraction makes the seam visible. For $16862/65$, the chamber is $260$, the bracketed remainder is $27$, and the step is $4\cdot27=108$. Under ASCII, $108$ is `l`. The factor four belongs to the arithmetic. The letter belongs to the convention.

The capstone lets eleven fractions recover `hello world`. A reader who knows ASCII can make the last transition almost at once. The ease is real: the message calls on a convention the receiver already carries. A later reader needs that convention too, even when the later reader is the person who made the record. The description on the page is only part of the account; the rule, the retained record, and the work of reading belong in it together.

An address is not a meaning. **An address can nevertheless be enough for someone who knows where it goes.** That is an affirmative use of the distinction. The theorem has done its work when it recovers the integer. The reader has further work available without demanding a longer theorem.

The same project carries this economy into its triangular coordinate. Write $T_z=z(z+1)/2$, extending the familiar polynomial beyond integer indices. Then

$$
T_z=T_{-z-1},\qquad
8T_z+1=(2z+1)^2.
\tag{4}
$$

The triangle is unchanged by reflection about $-1/2$. The signed coordinate $2z+1$ reverses. Put $z=s-1$ and the same algebra reads

$$
q=s(1-s)=-2T_{s-1}=\frac14-\left(s-\frac12\right)^2.
\tag{5}
$$

Now the center is $1/2$. The invariant has changed its address without changing its arithmetic. In *TN Postmaster*, this small identity opens into the completed zeta function [7, R1 and R9]. The folded-zero construction below uses that convention. The Reading Volume develops the picture; the Technical Dossier carries the longer proof obligations.

\newpage

## 4. A number in your hands

Take an ordinary pack of cards. Keep the two of clubs as a fixed marker, called $I$ here; this role is distinct from the surprisal $I_P$ in (1). Let A=1, J=11, Q=12, K=13. Give suits the order spades, hearts, diamonds, clubs, with residues $s=0,1,2,3$. A face of rank value $v$ has address $4(v-1)+s$. The suit is its residue modulo four. The remaining 51 cards can move while the marker holds the boundary.

Use S, H, D, C for those suits. Lay out this exact string, left to right and then downward. Row breaks are only for reading; the last card is $I$.

```text
AS AH AD AC 2S 2H 2D 3S 3H 3D 3C 4S 4H
4D 4C 5S 5H 5D 5C 6S 6H 6D 6C 7S 7H 7D
7C 8S 8H 8D 8C 9S 9H 9D 9C QD KH 10H KD
QH QS JS 10C JC QC KC 10S JD JH KS 10D 2C
```

The decoder needs a reference order: A,2,3,...,K, each in the declared suit order, with 2C omitted. At position $i$, let $d_i$ count still-unused reference cards preceding the displayed card. Its zero-based permutation rank is

$$R=\sum_{i=1}^{51}d_i(51-i)!=14\,134\,725\,141\,735.\tag{C}$$

Supply the scale $10^{12}$ and the recovered string is exactly `14.134725141735`, the first numerical ordinate in the supplied table. This decimal is a stored approximation to a zero's height. Swap cards 50 and 51, KS and 10D. The last binary choice changes and $R$ decreases by one. The same decoder now returns `14.134725141734`. Under the companion's uniform-symbol model, the final eighteen active reference cards have equal expected information contributions. The swap leaves the component weight at every position unchanged. The same complete weight profile therefore permits two different decoded records [13]. The arrangement has changed what can be read.

There are $51!$ possible active orders, giving $\log_2(51!)\approx219.88$ bits of capacity per pack. This particular integer has 44 binary digits, or six bytes when padded:

```text
11001101101011111111010001010110010011100111
0C DA FF 45 64 E7  (unsigned, big-endian)
```

These are descriptions of different objects. The smaller integer still needs its scale and decoding convention. The whole latest 1,566-record file takes 301 ordered deck arrangements under the supplied byte codec; one arrangement does not contain that entire table [13]. The faces need not carry numerals: any one-to-one relabeling, read through its matching inverse, recovers the same stored heights, their order, and their gaps.

The direct decoder uses 51 position lookups. Linear search needs at most $51+50+\cdots+1=1326$ card comparisons, plus factorial arithmetic; it does not enumerate $51!$ orders. This is an explicit algorithm, not a lower bound on computation. Computing the zero originally is separate work. The table, the code, and the reader now make its recorded value available in another medium.

**The reader can perform the check.** The game need not know that the recovered number names a zero ordinate. That relevance comes from the source and the question brought to the table. The shared convention transfers the record; its significance is supplied in use.

\newpage

## 5. What the fold keeps

Write $s=\beta+it$ for an arbitrary point with $0<\beta<1$. Equation (5) gives

$$
q=q_r+iq_i,\qquad q_r=t^2+\beta(1-\beta)>0,
\qquad q_i=t(1-2\beta).
\tag{6}
$$

For $t\ne0$, being on the critical line is exactly the condition that $q$ is real. The fold has kept that question. Indeed,

$$
q(s_1)-q(s_2)=(s_1-s_2)(1-s_1-s_2),
\tag{7}
$$

so it identifies precisely the reflection pair $s,1-s$. Passing to $1/q$ is also invertible. The additional act is to retain only a real part:

$$
W(\beta,t)=2\Re\frac1q=\frac{2q_r}{q_r^2+q_i^2}>0.
\tag{8}
$$

Here $W$ is a scalar weight, distinct from TN's Widder notation. It can be positive on either side of the question the fold preserved.

For actual nontrivial zeros $\rho$, follow TN exactly: one state is $[\rho]=\{\rho,1-\rho\}$, with the common multiplicity $m_\rho$ of its two zeros. An off-line quartet supplies two conjugate folded states. They remain two states when their weights agree. Multiplicity is absorbed into a state's mass. The classical first Li value is [5--7]

$$
\lambda_1=\sum_{[\rho]}\frac{m_\rho}{q_\rho}
=1+\frac{\gamma_{\rm E}}2-\log(2\sqrt\pi)
=0.0230957089661\ldots.
\tag{9}
$$

The folded sum converges absolutely. Taking real parts gives an unconditional probability distribution,

$$
\sum_{[\rho]}m_\rho W_\rho=2\lambda_1,
\qquad p_{[\rho]}=\frac{m_\rho W_\rho}{2\lambda_1}.
\tag{10}
$$

**Lemma 1.** Its Shannon entropy $H=-\sum p_{[\rho]}\log p_{[\rho]}$ is finite, without assuming RH. Natural logarithms give nats.

*Proof.* Split a state of multiplicity $m$ into $m$ equal atoms $r=W/(2\lambda_1)$. At large height, $r\le1/(\lambda_1t^2)$. The classical count $N(T)=O(T\log T)$ [9] puts $O(j2^j)$ atoms in the shell $2^j\le|t|<2^{j+1}$. Each contributes $O(j4^{-j})$ to entropy, so the shell sum is $O(j^2 2^{-j})$ and is summable. The finitely many low atoms cause no difficulty. Merging the $m$ equal atoms reduces entropy by $mr\log m\ge0$. $\square$

The distribution is real, positive, and finite in entropy. Its existence is an accomplished calculation. Which question it can answer is still a separate matter.

\newpage

## 6. The same weight, another side

The outline of a missing puzzle piece may be known exactly while its picture remains unknown. A different picture can occupy the same cut. For this analogy, the information retained is the outline alone. The next identity supplies a literal instance of the distinction:

$$
\boxed{
W\left(\frac14,1\right)=\frac{608}{425}
=W\left(\frac12,\sqrt{\frac{349}{304}}\right).
}
\tag{11}
$$

The first point is off the critical line; the second is on it. Substitution into (8) checks both sides. Every digit of their weights agrees because they are the same rational number.

**Lemma 2 (the fiber criterion).** Given maps $K:D\to Y$ and $A:D\to Z$, a function $g:K(D)\to Z$ satisfying $A=g\circ K$ exists exactly when $A$ is constant on every fiber of $K$.

*Proof.* Equal $K$-values must give equal $g(K)$-values. Conversely, constancy lets us define $g$ by the common value of $A$ on each fiber. $\square$

For the present map, take

$$
D=\{(\beta,t):0<\beta<1,\ t>0,\ 0<W(\beta,t)<8\},
\qquad A(\beta,t)=\mathbf1_{\{\beta=1/2\}}.
\tag{12}
$$

Every weight $w\in(0,8)$ has a positive-height critical-line preimage,

$$
t'=\sqrt{\frac2w-\frac14},\qquad W(1/2,t')=w.
\tag{13}
$$

Thus every off-line point in $D$ shares its weight with an on-line point in $D$. Equation (11) makes the collision explicit. By Lemma 2, $A$ is not a function of $W$ on $D$. A fixed list of such weights, with multiplicities fixed, also retains the same normalized probabilities and entropy after same-weight replacements.

**No increase in precision can separate what this observation identifies.** The obstruction is equality, not inadequate precision. It occurs before entropy is computed.

These comparison points are ambient points; (13) does not make them zeta zeros. Arithmetic restricts the actual zero set, and the lemma must be applied again on any restricted domain. This construction establishes the boundary of the stated map, not an RH criterion or its impossibility.

Additional information changes the result. Retain a known $t\ge1$. With $v=(\beta-1/2)^2$ and $Q=t^2+1/4$, differentiating (8) shows that $\partial W/\partial v$ has the sign of $(Q-v)^2-4t^2Q<0$. Hence $(t,W)$ determines $|\beta-1/2|$. The scalar lost a distinction that a richer observation restores.

\newpage

## 7. The number and the convention

The exact infinite entropy of (10) has been defined and its finiteness proved. To estimate its value, the supplied computation uses 1,438 tabulated numerical ordinates and a smooth model for the remaining tail. The three numbers below answer different questions; this 1,438-record entropy prefix is unchanged by the larger representation test in §4:

| Quantity | Definition | Nats |
|:--|:--|--:|
| Prefix contribution $J_n$ | $-\sum_{k\le n}p_k\log p_k$ | $3.9205765$ |
| Finite entropy $H_n$ | $J_n/a_n+\log a_n$ | $3.9932974$ |
| Infinite model $\widehat H_n$ | Normalized prefix plus tail surrogate | $4.25068$ |

Here $n=1438$ and $a_n=\sum_{k\le n}p_k$. The middle row renormalizes the prefix to total mass one. The last uses the critical-line reference mass and smooth count

$$
f(t)=\frac1{\lambda_1(t^2+1/4)},\qquad
N_{\rm sm}(t)=\frac{t}{2\pi}\log\frac{t}{2\pi e}+\frac78.
\tag{14}
$$

Choose $t_\star$ by $N_{\rm sm}(t_\star)=n$, the model's midpoint-count convention. Define

$$
\begin{aligned}
M_n&=a_n+\int_{t_\star}^{\infty} f(t)\,dN_{\rm sm}(t),\\
\widehat J_n&=J_n-\int_{t_\star}^{\infty}f(t)\log f(t)\,dN_{\rm sm}(t),\\
\widehat H_n&=\widehat J_n/M_n+\log M_n.
\end{aligned}
\tag{15}
$$

This is a quadrature surrogate for a discrete entropy sum, using one simple critical-line state per unit of smooth count. It gives $M_{1438}\approx1.00000000238$ and $\widehat H_{1438}\approx4.25068$ nats. The mass correction leaves the five displayed entropy decimals unchanged. Agreement in mass and stability across cutoffs are diagnostics, not certified error bounds for the actual infinite entropy. The uncomputed zeros need not obey the surrogate's simplicity and critical-line assumptions.

The weight also responds to a change in abscissa when height is fixed. Writing $\delta=\beta-1/2$, direct subtraction gives

$$
\frac{W(\beta,t)}{W(1/2,t)}-1
=-\frac{\delta^2(3t^2-1/4+\delta^2)}{q_r^2+q_i^2}.
\tag{16}
$$

For the finite table, replacing only its first weight by $W(0.9,t_1)$ and renormalizing changes $H_{1438}$ from $3.9932974006$ to $3.9946175423$ nats. This is a synthetic one-entry perturbation. Moving at fixed height changes a weight; moving along its fiber preserves it. Sensitivity and recoverability have different answers because they ask different questions.

Shanker's entropy of zero counts in Gram intervals uses another alphabet and another distribution [10]. The common word *entropy* does not make its number and this one measurements of the same object.

\newpage

## 8. The rule gives the continuation somewhere to go

The same triangle has reflected indices. The same weight has points on and off a line. The same pack has different readable numbers. Each sameness belongs to an operation. The reader can now change an arrangement and check which statement survives the move.

Deal the 51 active cards into three hands of 17. Each nonempty hand reveals its first card. Higher rank wins; suit order resolves ties. The winner returns its own card to the bottom first, then the other revealed cards clockwise. Captures reenter later contests. Players compete with one another; $I$ stays outside the contest. The full ordered hands, not just their sizes, are the state.

**Lemma 3 (a finite continuation).** For a deterministic transition $X_{n+1}=F(X_n)$, if $X_r=X_s$ with $r<s$, then $X_{r+k}=X_{s+k}$ for every $k\ge0$.

*Proof.* Apply the same function to equal states and repeat. $\square$

The companion test applies the same recorded shuffle to the two orders in §4. One finishes at turn 144; the swapped order repeats from turn 1015 to 1535, a period of 520. Across 64 paired shuffles, 15 runs finish and 113 reach an exact repeat [13]. The latter is a win condition for the analysis: under the fixed rule, the continuation is certified. Withholding intervention preserves that detected loop; some other deals finish normally.

Give $I$ an optional *forgiveness* rule. At an exact repeat, each live hand places one top card under $I$, permanently out of further contests. Start a fresh recurrence ledger. Cards in hands plus this escrow still total 51. Every intervention removes at least two circulating cards, so there are at most 25. Between interventions, a finite deterministic phase finishes or repeats. Thus the modified game eventually ends with a survivor or with all remaining cards in escrow. All 128 tested starts had a survivor, after 55--28,834 turns and 0--24 interventions [13]. The proof supplies termination; the sample supplies those durations.

Generous tit-for-tat is studied as a cooperative strategy in the repeated Prisoner's Dilemma [12]. The card rule here has its own proof: a conserved account and a strictly decreasing number of circulating cards. Calling an intervention forgiveness does not transfer another game's conclusion into this one.

The connection to the zero problem is now precise. A tail certificate needs a state adequate to the question and a proved continuation rule. Labeling card turns by known $y_n$ does not supply such a rule for unobserved zeros. The label never enters the card transition. Lemma 2 identifies what a retained observation must preserve before the desired answer can pass through it.

In ordinary War, the stack keeps an order the players may no longer know. Earlier reveals may still be carried in memory or written in a ledger. Another tie can be the surprise: one familiar label, another delay, a growing contest. To measure that surprise, we must say what the observer retains and how the remaining possibilities are weighted. The same reveal can carry different surprisal for players with different histories. What it means to them still depends on the sequence and what is now at stake.

The composition is still open. A later turn can expose what an earlier word was carrying; *primal* can acquire another contact after the arithmetic of primes. Euclid's "on that side" points into an arrangement already supplied [11]. The reader brings that arrangement, follows the relation, and can now test one of these dependencies on a table. The experiment's statistics describe card runs. The importance felt by a reader remains something the reader can judge.

**The count can be exact while what counts remains open.**

\newpage

## 9. Reading map and credits

TN section numbers below refer to v5.1 [7]. The supplement [13] makes the card results reproducible.

\begingroup\small

| Question | What carries the answer | Status and route |
|:--|:--|:--|
| What makes a guess useful? | Target, rules, feedback model | Task supplied; §2 and [4] |
| What turns an address into a letter? | Inverse law, then a character convention | Exact address; §3; capstone §§3--6 [8] |
| What can a pack recover? | Declared order, rank decoder, scale | Exact decimal record; §4; executable supplement [13] |
| What does folding preserve? | $q=s(1-s)=-2T_{s-1}$ and reflection pairs | Exact; TN R1, R9, R10C; Dossier §32 |
| What does the weight retain? | Its fibers on declared domain $D$ | Exact ambient obstruction; §6 |
| What does $4.25068$ report? | Prefix and specified smooth tail | Model estimate; §7; entropy finiteness in §5 |
| When is the card tail settled? | Full recurrence; optional decreasing-circulation rule | Exact finite model; §8 and [13]; RH remains open |

\endgroup

The information theory, reversible-computation results, Li coefficient, and zero-counting estimates are classical. The address and TN conventions come from the author's companion works. The card and fiber demonstrations make the retained relations checkable. Human authorship and final judgment are Jeffery Lyn Huckstead's; AI-assisted drafting, computation, and review contributed to this revision.

### References

\begingroup\footnotesize

1. C. E. Shannon, "A Mathematical Theory of Communication," *Bell System Technical Journal* **27** (1948), 379--423, 623--656. [Author text](https://web.mit.edu/6.441/www/reading/shannon1948.pdf).
2. R. Landauer, "Irreversibility and Heat Generation in the Computing Process," *IBM Journal of Research and Development* **5** (1961), 183--191. [doi:10.1147/rd.53.0183](https://doi.org/10.1147/rd.53.0183).
3. C. H. Bennett, "Logical Reversibility of Computation," *IBM Journal of Research and Development* **17** (1973), 525--532. [Author text](https://www.cs.princeton.edu/courses/archive/fall04/cos576/papers/bennett73.html).
4. G. Sanderson, "Solving Wordle Using Information Theory," 3Blue1Brown (2022). [Exposition](https://www.3blue1brown.com/lessons/wordle/).
5. X.-J. Li, "The Positivity of a Sequence of Numbers and the Riemann Hypothesis," *Journal of Number Theory* **65** (1997), 325--333. [doi:10.1006/jnth.1997.2137](https://doi.org/10.1006/jnth.1997.2137).
6. E. Bombieri and J. C. Lagarias, "Complements to Li's Criterion for the Riemann Hypothesis," *Journal of Number Theory* **77** (1999), 274--287. [doi:10.1006/jnth.1999.2392](https://doi.org/10.1006/jnth.1999.2392).
7. J. Huckstead, *Triangular-n Postmaster: From the Triangular Primitive to the Completed Source Frontier*, Volume I, v5.1 (September 2026). *Reading Volume*, R1, R9, R10C; *Technical Dossier*, §32. Supplied companion manuscripts; [series DOI](https://doi.org/10.5281/zenodo.21968915).
8. J. Huckstead, *A Message Hidden as an Address: Where a Theorem Recovers a Number, and Only You Recover the Letter*, v1.0 (June 2026), §§3--6. Supplied capstone manuscript.
9. E. C. Titchmarsh, revised by D. R. Heath-Brown, *The Theory of the Riemann Zeta-Function*, 2nd ed., Oxford University Press (1986). Zero-counting estimates.
10. O. Shanker, "Entropy of Riemann Zeta Zero Sequence," *Advanced Modeling and Optimization* **15** (2013), 449--456. [Author text](https://camo.ici.ro/journal/vol15/v15b18.pdf).
11. Euclid, *Elements*, Book I, Postulate 5, English text in D. E. Joyce's edition. [Postulate and commentary](https://mathcs.clarku.edu/~djoyce/java/elements/bookI/post5.html).

12. C. Wedekind and M. Milinski, "Human Cooperation in the Simultaneous and the Alternating Prisoner's Dilemma: Pavlov versus Generous Tit-for-Tat," *PNAS* **93** (1996), 2686--2689. [doi:10.1073/pnas.93.7.2686](https://doi.org/10.1073/pnas.93.7.2686).
13. J. Huckstead, *Invariant*, v7.2 computational supplement (2026): HTML game, exact strings, card guide, data, source, and verification. Supplied with this paper. [Canonical supplement](https://cerebralgraphix.com/research/line-game/).

\endgroup
