# The Line Game | Surprise Is Not Meaning — v7.2

Nine pages. Page 9 is the reading map, credits, and references. The earlier v7.1 remains unchanged.

The revised paper keeps the opening account of words, composition, and the answer key. Section 4 adds an exact 52-card string, its integer, binary representation, decoding rule, and an explicit algorithmic cost. Section 8 adds the measured card continuation, a full-state cycle certificate, and the finite-model termination argument for forgiveness. The last paragraph of section 4 separates a card arrangement's game role from the external convention identifying its decoded number as a zero ordinate.

The 1,438-record entropy computation is unchanged. The larger 1,566-record byte-transfer experiment is a separate representation test. Supplied numerical ordinates are not newly certified here. The ambient weight collision and the card demonstration do not prove RH or supply an error bound for the true zero tail.

## Rebuild

Install the pinned Python dependencies in `requirements.txt`, plus Pandoc and a LaTeX installation containing the packages named in preamble.tex. PDF inspection uses PyMuPDF (`fitz`). Run:

    python build.py

This generates the TeX and PDF, then runs verify_v7_2.py. The verifier checks the displayed algebra, numerical model, exact card string, quoted sample counts, and the nine-page layout. CARD_FACTS.json is the snapshot of the saved card experiments used by that check. Reproducing those experiments is described in the companion card_lab/ folder.

V7_2_VERIFICATION.json records 36 passing checks. The final PDF's nine pages were also rendered and visually reviewed.
