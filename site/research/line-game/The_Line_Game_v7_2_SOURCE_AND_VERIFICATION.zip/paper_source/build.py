#!/usr/bin/env python3
"""Build the reading PDF, then replay its focused verification."""
from pathlib import Path
import os
import shutil
import subprocess
import sys

root=Path(__file__).resolve().parent
stem='Surprise_Is_Not_Meaning_v7_2'
build_env=os.environ.copy()
build_env.setdefault('SOURCE_DATE_EPOCH','1789776000')
build_env['FORCE_SOURCE_DATE']='1'
(root/'build').mkdir(exist_ok=True)
subprocess.run(['pandoc',stem+'.md','--standalone',
    '--include-in-header=preamble.tex','--output='+stem+'.tex'],cwd=root,env=build_env,check=True)
for n in (1,2):
    with (root/'build'/f'build_pass_{n}.txt').open('w') as out:
        subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',
            '-output-directory=build',stem+'.tex'],cwd=root,stdout=out,
            stderr=subprocess.STDOUT,env=build_env,check=True)
shutil.copyfile(root/'build'/(stem+'.pdf'),root/(stem+'.pdf'))
subprocess.run([sys.executable,str(root/'verify_v7_2.py')],cwd=root,check=True)
