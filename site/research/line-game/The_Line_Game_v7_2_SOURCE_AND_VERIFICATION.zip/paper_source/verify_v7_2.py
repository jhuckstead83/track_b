#!/usr/bin/env python3
"""Replay the displayed algebra and numerical model in Surprise v7.2.

This checks the supplied decimal table and the specified surrogate. It does
not certify zeros, bound the true entropy tail, or test reader salience.
"""
from pathlib import Path
import hashlib
import json
import platform
import re
import math

import mpmath as mp
import sympy as sp

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'Surprise_Is_Not_Meaning_v7_2.md'
DATA = ROOT / 'zeros_1438.txt'
mp.mp.dps = 45
checks = []

def check(name, condition):
    checks.append({'name': name, 'pass': bool(condition)})
    if not condition:
        raise AssertionError(name)

def zero(name, expression):
    check(name, sp.cancel(sp.expand(expression)) == 0)

s, s1, s2, z = sp.symbols('s s1 s2 z')
T = lambda z: z*(z+1)/2
q = lambda s: s*(1-s)
zero('triangular reflection', T(z)-T(-z-1))
zero('triangular centered square', 8*T(z)+1-(2*z+1)**2)
zero('triangular fold', q(s)+2*T(s-1))
zero('centered fold', q(s)-(sp.Rational(1,4)-(s-sp.Rational(1,2))**2))
zero('exact reflection-pair factorization', q(s1)-q(s2)-(s1-s2)*(1-s1-s2))
r,d=16862,65
n=sp.ceiling(sp.Rational(r,d))
check('address example: chamber, remainder, step',
      n==260 and r-d*(n-1)==27 and n*(r-d*(n-1))/d==108)

u,v = sp.symbols('u v', real=True)
Q=u+sp.Rational(1,4)
a=Q-v
D=a*a+4*u*v
w=2*a/D
twin2=D/a-sp.Rational(1,4)
zero('same-weight critical-line preimage', 2/(twin2+sp.Rational(1,4))-w)
point={u:1,v:sp.Rational(1,16)}
check('exact rational collision weight', w.subs(point)==sp.Rational(608,425))
check('exact rational collision ordinate squared', twin2.subs(point)==sp.Rational(349,304))
check('collision lies in declared weight domain', 0<w.subs(point)<8 and twin2.subs(point)>0)
zero('known-height derivative', sp.diff(w,v)-2*(a*a-4*u*Q)/D**2)
zero('derivative sign reduction', (a*a-4*u*Q)-(Q*(sp.Rational(1,4)-3*u)-v*(2*Q-v)))
# For u>=1 and 0<=v<1/4, the first term is strictly negative and
# v*(2Q-v)>=0. Thus this derivative is strictly negative.
zero('exact fixed-height relative response', w/(2/Q)-1+v*(3*u-sp.Rational(1,4)+v)/D)
for beta in (sp.Rational(1,2),sp.Rational(3,4)):
    rho=beta+2*sp.I
    orbit=set((rho,1-rho,sp.conjugate(rho),1-sp.conjugate(rho)))
    upper=[x for x in orbit if sp.im(x)>0]
    total=sum(2*sp.re(1/q(x)) for x in upper)
    zero('reflection-pair mass bookkeeping beta='+str(beta), total-2*sum(1/x for x in orbit))

lam=1+mp.euler/2-mp.log(2*mp.sqrt(mp.pi))
zs=[mp.mpf(x) for x in DATA.read_text().splitlines() if x.strip()]
check('1438 positive increasing supplied ordinates',
      len(zs)==1438 and all(x>0 for x in zs) and all(a<b for a,b in zip(zs,zs[1:])))
ws=[2/(t*t+mp.mpf('.25')) for t in zs]
ps=[w/(2*lam) for w in ws]
aN=mp.fsum(ps)
JN=-mp.fsum(p*mp.log(p) for p in ps)
HN=JN/aN+mp.log(aN)
def entropy(weights):
    Z=mp.fsum(weights)
    return -mp.fsum((w/Z)*mp.log(w/Z) for w in weights)
check('finite normalization agrees by two computations', abs(HN-entropy(ws))<mp.mpf('1e-40'))
altered=list(ws)
beta=mp.mpf('.9'); t=zs[0]
qr=t*t+beta*(1-beta); qi=t*(1-2*beta)
altered[0]=2*qr/(qr*qr+qi*qi)
Halt=entropy(altered)
Nsm=lambda t:t/(2*mp.pi)*mp.log(t/(2*mp.pi*mp.e))+mp.mpf(7)/8
tstar=mp.findroot(lambda t:Nsm(t)-len(zs),zs[-1])
f=lambda t:1/(lam*(t*t+mp.mpf('.25')))
density=lambda t:mp.log(t/(2*mp.pi))/(2*mp.pi)
mt=mp.quad(lambda t:f(t)*density(t),[tstar,mp.inf])
et=mp.quad(lambda t:-f(t)*mp.log(f(t))*density(t),[tstar,mp.inf])
M=aN+mt
Hhat=(JN+et)/M+mp.log(M)
numbers={'lambda1':lam,'prefix_mass':aN,'prefix_contribution':JN,
         'finite_entropy':HN,'finite_entropy_perturbed':Halt,
         'model_mass':M,'model_entropy':Hhat,'tail_start':tstar}

# Bind displayed tokens to the named quantity, not to arbitrary digit
# substrings elsewhere in the document.
specs=[
 ('lambda1',r'=([0-9]+\.[0-9]+)\\ldots\.',13),
 ('prefix_contribution',r'\| Prefix contribution[^\n]*\| \$([0-9]+\.[0-9]+)\$ \|',7),
 ('finite_entropy',r'\| Finite entropy[^\n]*\| \$([0-9]+\.[0-9]+)\$ \|',7),
 ('model_entropy',r'\| Infinite model[^\n]*\| \$([0-9]+\.[0-9]+)\$ \|',5),
 ('model_mass',r'M_\{1438\}\\approx([0-9]+\.[0-9]+)',11),
 ('model_entropy',r'\\widehat H_\{1438\}\\approx([0-9]+\.[0-9]+)',5),
 ('finite_entropy',r'from \$([0-9]+\.[0-9]+)\$ to',10),
 ('finite_entropy_perturbed',r'to \$([0-9]+\.[0-9]+)\$ nats',10),
]
def errors(text):
    es=[]
    for key,pattern,places in specs:
        matches=re.findall(pattern,text)
        if not matches:
            es.append('missing: '+key)
        for token in matches:
            if abs(mp.mpf(token)-numbers[key])>mp.mpf('.5')*10**(-mp.mpf(places)):
                es.append(key+': '+token)
    return es
text=SOURCE.read_text()
check('all displayed decimal claims match computed values', not errors(text))
card_string=re.search(r'```text\n(AS[\s\S]*?)\n```',text).group(1)
cards=card_string.split()
ranks=['A','2','3','4','5','6','7','8','9','10','J','Q','K']
faces=[r+s for r in ranks for s in ['S','H','D','C']]
check('displayed string is one full deck with fixed null',len(cards)==52 and set(cards)==set(faces) and cards[-1]=='2C')
unused=[c for c in faces if c!='2C'];card_rank=0
for i,c in enumerate(cards[:-1]):
    j=unused.index(c);card_rank+=j*math.factorial(50-i);unused.pop(j)
check('displayed arrangement decodes to stated integer',card_rank==14134725141735)
check('displayed binary string matches exactly',bin(card_rank)[2:] in text and card_rank.bit_length()==44)
check('displayed six-byte string matches exactly',card_rank.to_bytes(6,'big').hex(' ').upper() in text)
check('comparison budget is correct',sum(range(1,52))==1326)
facts=json.loads((ROOT/'CARD_FACTS.json').read_text())
check('quoted ordinary sample matches saved experiments',facts['ordinary']['statuses']=={'cycle':113,'finished':15})
check('quoted forgiveness sample matches saved experiments',facts['forgiveness']['statuses']=={'finished':128} and facts['forgiveness']['observed_turn_range']==[55,28834] and facts['forgiveness']['observed_intervention_range']==[0,24])
check('recurrence period is tied to exact saved example',facts['ordinary']['example_after']['cycle_entry_turn']==1015 and facts['ordinary']['example_after']['turns_observed']==1535 and facts['ordinary']['example_after']['cycle_period']==520)
for good,bad in [('4.25068','4.35068'),('3.9205765','3.8205765'),
                 ('3.9946175423','3.8946175423'),('1.00000000238','1.10000000238')]:
    check('negative control rejects changed '+good, bool(errors(text.replace(good,bad))))

pdf=ROOT/'Surprise_Is_Not_Meaning_v7_2.pdf'
pages=None
if not pdf.exists():
    raise FileNotFoundError('Current paper PDF is required for verification: '+str(pdf))
import fitz
with fitz.open(pdf) as doc:
    pages=len(doc)
    check('paper is nine pages with closing reading map and citations', pages==9)
    check('hard 13-page ceiling', pages<=13)
    final=doc[-1].get_text()
    check('closing page has map, credits, and complete references',
          'Reading map and credits' in final and 'References' in final and 'Euclid' in final)
    check('all pages carry text',all(len(p.get_text().split())>200 for p in doc))
log=ROOT/'build/Surprise_Is_Not_Meaning_v7_2.log'
if not log.exists():
    raise FileNotFoundError('Current LaTeX build log is required for verification: '+str(log))
L=log.read_text(errors='replace')
check('no missing characters or unresolved references',
      'Missing character:' not in L and 'undefined references' not in L)
check('no overflowing text or display boxes',
      'Overfull \\hbox' not in L and 'Overfull \\vbox' not in L)

receipt={'status':'PASS','scope':__doc__.strip(),'precision_decimal_digits':mp.mp.dps,
         'python':platform.python_version(),'mpmath':mp.__version__,'sympy':sp.__version__,
         'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
         'table_sha256':hashlib.sha256(DATA.read_bytes()).hexdigest(),
         'pages':pages,'numbers':{k:mp.nstr(v,35) for k,v in numbers.items()},
         'checks':checks,'passed':len(checks)}
(ROOT/'V7_2_VERIFICATION.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
