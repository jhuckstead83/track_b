# The Line Game | Surprise Is Not Meaning — complete v7.2 package

The paper is nine pages. Its last page contains the reading map, credits, and citations. Earlier v7.1 and the two zero-text experiment packages are retained in prior_work/.

## Read and play

- Surprise_Is_Not_Meaning_v7_2.pdf: the paper, including the exact card string, decoding rule, measured continuation, and finite-model proofs.
- Invariant.html: open locally in a modern browser. The game and decoder work without a network connection. Keep the three PDFs beside it for its reading links.
- Playing_Cards_Field_Guide.pdf: eight pages of rules, exact deals, results, and the physical decoding exercise.
- Playing_Cards_Printable_Set.pdf: nine sheets of card fronts. Print at Actual Size and check the inch scale. An ordinary 52-card pack also works.
- Exact_Card_String.txt: the complete string, key, exact integer and binary representation, one-swap comparison, and cost qualification.

The canonical online edition is /research/line-game/. Before DOI assignment, the portable HTML edition and its six public downloads form the review set; final record links are filled only after the publication DOI is known.

## What the record says

The handheld arrangement decodes to 14.134725141735, the first stored ordinate. Swapping its last two active cards changes the decoded value by 0.000000000001. The interpretation comes from the convention and source. The game uses card order and rank, not the assertion that this number describes a zeta zero.

The entropy calculation uses a 1,438-record prefix ending at the stored value 1913.182489775883. Here 1,438 is a count, not that final height. The separate byte-transfer experiment uses 1,566 records, ending at 2052.407790192401. The bytes are recovered exactly; this work does not newly certify the supplied zeros or their rounding.

The paired ordinary game sample has 15 finishes and 113 certified cycles across 128 starts. Under the added forgiveness rule, the same 128 starts all finish; the finite-state/decreasing-circulation proof establishes eventual termination for that rule beyond this sample. Neither the card experiment nor its turn labels establish an RH-tail estimate. The smooth entropy-tail number in the paper remains a model result.

## Reproduce and inspect

- paper_source/: editable Markdown and TeX, build script, supplied prefix, card fact snapshot, and verification receipt. Run python build.py with the dependencies listed there.
- card_lab/: exact Unicode/card mapping, byte transports, Python code, the 128-start experiments, null comparison, square ledger, and complete illustrative move histories. Follow its README.md and FORGIVENESS.md.
- game_source/: self-contained browser source, saved initial-hand fixtures, and the Node comparison script. Run node verify_game.mjs there; 256 JavaScript games were matched against the saved Python outcomes.
- LAYOUT_REVIEW.json: scope of the visual document review.
- MANIFEST.sha256: SHA-256 hashes of every packaged file except the manifest itself.

Verification recorded 36 paper checks, 4,585 card audit checks, and 256 matching JavaScript/Python game outcomes. All nine paper pages, eight guide pages, and nine printable sheets were rendered and visually reviewed. Browser layout and optional WebMCP hooks could not be exercised in the available static-preview environment; this limitation is recorded in GAME_VERIFICATION.json.

The shared key is reusable work already supplied. A demonstration lets the reader verify a stated relationship; reader appreciation is not evidence for an additional mathematical claim. The useful result is that the record, interpretation, measurement, and continuation can each be inspected.


## Final release

DOI: 10.5281/zenodo.22851517. `Invariant.html` is the current shell; `Invariant_v7_2.html` preserves the original v7.2 presentation. Both use the distinct intervention marker `Ⅰ`.
