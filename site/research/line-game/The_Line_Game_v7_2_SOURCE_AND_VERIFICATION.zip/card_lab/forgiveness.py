"""Cycle-triggered escrow makes finite War phases terminate globally."""
from pathlib import Path
from collections import deque, Counter
import json
from cards import parse_records,unrank_deck
from war import Q,state_key,shuffled_hands

ROOT=Path(__file__).resolve().parent

def play_with_forgiveness(initial,cap=200000,keep_log=False):
    hands=[deque(h) for h in initial];bank=[];history=[];events=[];certificates=[]
    initial_cards=sorted(c for h in hands for c in h)
    assert len(initial_cards)==len(set(initial_cards))==51
    seen={state_key(hands):0};status='capped';winner=None
    for turn in range(1,cap+1):
        live=[p for p,h in enumerate(hands) if h]
        if len(live)<=1:
            status='finished' if live else 'draw';winner=live[0]+1 if live else None;turn-=1;break
        drawn={p:hands[p].popleft() for p in live};win=max(live,key=lambda p:Q[drawn[p]])
        pot=[drawn[(win+k)%3] for k in range(3) if (win+k)%3 in drawn]
        hands[win].extend(pot)
        if keep_log:events.append({'kind':'play','turn':turn,'drawn':{str(p+1):c for p,c in drawn.items()},'winner':win+1,'returned':pot})
        key=state_key(hands)
        live=[p for p,h in enumerate(hands) if h]
        if len(live)>1 and key in seen:
            before=sum(map(len,hands));withdrawn={p:hands[p].popleft() for p in live}
            bank.extend(withdrawn.values())
            cert={'turn':turn,'cycle_entry':seen[key],'cycle_period':turn-seen[key],
              'withdrawn':{str(p+1):c for p,c in withdrawn.items()},'circulating_before':before,
              'circulating_after':sum(map(len,hands)),'escrow_count':len(bank)}
            assert before-cert['circulating_after']>=2
            certificates.append(cert)
            if keep_log:events.append({'kind':'forgive',**cert})
            seen={state_key(hands):turn}
        else:seen[key]=turn
        assert sorted([c for h in hands for c in h]+bank)==initial_cards
        assert sum(map(len,hands))+len(bank)==51
        if keep_log:history.append({'turn':turn,'counts':[len(h) for h in hands],'escrow':len(bank)})
        live=[p for p,h in enumerate(hands) if h]
        if len(live)<=1:
            status='finished' if live else 'draw';winner=live[0]+1 if live else None;break
    else:turn=cap
    assert len(certificates)<=25
    return {'status':status,'winner':winner,'turns':turn,'interventions':len(certificates),
      'counts':[len(h) for h in hands],'escrow_count':len(bank),'certificates':certificates,
      'final_hands':[list(h) for h in hands],'escrow':bank,'events':events,'history':history}

def undo(run):
    hands=[deque(h) for h in run['final_hands']];bank=list(run['escrow'])
    for e in reversed(run['events']):
        if e['kind']=='forgive':
            for player,c in reversed(list(e['withdrawn'].items())):
                assert bank.pop()==c;hands[int(player)-1].appendleft(c)
        else:
            for c in reversed(e['returned']):assert hands[e['winner']-1].pop()==c
            for player,c in e['drawn'].items():hands[int(player)-1].appendleft(c)
    assert not bank
    return [list(h) for h in hands]

def compact(r):return {k:v for k,v in r.items() if k not in ['events','history','final_hands','escrow']}

def main():
    x=parse_records((ROOT/'inputs/zeros_1438.txt').read_bytes())[0]
    results=[]
    for seed in range(64):
        for variant,value in [('before',x),('after',x-1)]:
            hands,positions=shuffled_hands(unrank_deck(value),seed)
            run=play_with_forgiveness(hands,keep_log=seed==3)
            if seed==3:
                assert undo(run)==hands
                (ROOT/f'war/forgiveness_example_{variant}.json').write_text(json.dumps({'seed':seed,'initial_hands':hands,'shuffle_positions':positions,**run},indent=2)+'\n')
            results.append({'seed':seed,'variant':variant,**compact(run)})
    counts=Counter(r['status'] for r in results)
    summary={'rule':'At an exact within-phase recurrence, every live player puts its top card in permanent escrow under I. Resume with a fresh recurrence ledger.',
      'preserved_total':'cards in hands + escrow = 51; including marker = 52',
      'progress':'each intervention removes at least 2 cards from future contests',
      'intervention_bound':25,'termination_proved':True,
      'sample_runs':len(results),'turn_cap':200000,'statuses':dict(counts),
      'observed_turn_range':[min(r['turns'] for r in results),max(r['turns'] for r in results)],
      'observed_intervention_range':[min(r['interventions'] for r in results),max(r['interventions'] for r in results)],
      'example_before':next(r for r in results if r['seed']==3 and r['variant']=='before'),
      'example_after':next(r for r in results if r['seed']==3 and r['variant']=='after'),
      'illustrative_games_reverse_exactly':True,
      'qualification':'This is an added rule for this finite game. The finite-state and decreasing-circulation hypotheses do not establish a rule for the zeta-zero tail.'}
    (ROOT/'war/FORGIVENESS_RESULTS.json').write_text(json.dumps(summary,indent=2)+'\n')
    (ROOT/'war/forgiveness_runs.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
