"""A 51-card alphabet, a fixed null, and exact factorial deck transport."""
from pathlib import Path
from collections import Counter,defaultdict
import csv,hashlib,json,math,struct,unicodedata,zlib
from codec import RADIX,HANGUL_BASE,compress,decompress,pack_digits,unpack_digits,glyphs,read_glyphs,parse_records,serialize
from tiles import PATHS,TREE

ROOT=Path(__file__).resolve().parent
RANKS=['A','2','3','4','5','6','7','8','9','10','J','Q','K']
SUITS=['S','H','D','C']
FACES=[rank+suit for rank in RANKS for suit in SUITS]
NULL='2C'
ACTIVE=[face for face in FACES if face!=NULL]
FACT=[math.factorial(n) for n in range(52)]
CAPACITY=FACT[51]
SUIT_GLYPHS={'S':'♠','H':'♥','D':'♦','C':'♣'}

def face_display(face):return face[:-1]+SUIT_GLYPHS[face[-1]]
def role(cp):
    if 0x1100<=cp<=0x1112:return 'L'+str(cp-0x1100)
    if 0x1161<=cp<=0x1175:return 'V'+str(cp-0x1161)
    if 0x11A8<=cp<=0x11C2:return 'T'+str(cp-0x11A7)
    raise ValueError(cp)

def alphabet():
    contribution=defaultdict(float);occurrences=Counter();ending=0.
    for d,path in enumerate(PATHS):
        chars=unicodedata.normalize('NFD',chr(HANGUL_BASE+d))
        costs=[math.log2(TREE[v]/TREE[w]) for v,w in zip(path,path[1:])]
        assert len(chars) in (2,3)
        for i,c in enumerate(chars):
            contribution[c]+=costs[i]/RADIX;occurrences[c]+=1
        if len(chars)==2:ending+=costs[2]/RADIX
    ordered=sorted(contribution,key=lambda c:(-round(contribution[c],12),ord(c)))
    assert len(ordered)==51
    rows=[]
    for importance_rank,(c,face) in enumerate(zip(ordered,ACTIVE),1):
        q=FACES.index(face)
        rows.append({'q':q,'importance_rank':importance_rank,'card':face,'card_display':face_display(face),'rank_index':q//4,'rank_value':q//4+1,'suit_residue':q%4,
          'component':c,'code_point':f'U+{ord(c):04X}','role':role(ord(c)),
          'importance_bits_per_complete_symbol':contribution[c],'inventory_occurrences':occurrences[c]})
    assert abs(sum(contribution.values())+ending-math.log2(RADIX))<1e-11
    return rows,ending

def unrank_deck(number):
    assert 0<=number<CAPACITY
    remaining=list(ACTIVE);deal=[]
    for n in range(51,0,-1):
        index,number=divmod(number,FACT[n-1])
        deal.append(remaining.pop(index))
    assert number==0
    return deal+[NULL]

def rank_deck(deal):
    if len(deal)!=52 or deal[-1]!=NULL or set(deal)!=set(FACES):
        raise ValueError('A frame must contain each card once and end with the null 2C.')
    remaining=list(ACTIVE);number=0
    for card in deal[:-1]:
        index=remaining.index(card);number+=index*FACT[len(remaining)-1];remaining.pop(index)
    return number

def encode_packet(raw):
    packed=compress(raw,'delta32')
    packet=struct.pack('>4sIII',b'PC51',len(packed),len(raw),zlib.crc32(raw))+packed
    number=int.from_bytes(b'\x01'+packet,'big');ranks=[]
    while number:number,digit=divmod(number,CAPACITY);ranks.append(digit)
    return [unrank_deck(n) for n in ranks[::-1]],packed,packet

def decode_packet(deals):
    ranks=[rank_deck(d) for d in deals]
    assert ranks and ranks[0]>0
    number=0
    for digit in ranks:number=number*CAPACITY+digit
    b=number.to_bytes((number.bit_length()+7)//8,'big')
    assert b[0]==1
    packet=b[1:];magic,packed_len,source_len,checksum=struct.unpack('>4sIII',packet[:16])
    assert magic==b'PC51' and len(packet)==16+packed_len
    raw=decompress(packet[16:],'delta32')
    assert len(raw)==source_len and zlib.crc32(raw)==checksum
    return raw

def decode_components(cards,mapping):
    assert cards and len(cards)%3==0
    inverse={r['card']:r['component'] for r in mapping}
    parts=[]
    for i in range(0,len(cards),3):
        a,b,c=cards[i:i+3]
        assert a!=NULL and b!=NULL
        assert role(ord(inverse[a])).startswith('L') and role(ord(inverse[b])).startswith('V')
        assert c==NULL or role(ord(inverse[c])).startswith('T')
        parts.append(inverse[a]+inverse[b]+('' if c==NULL else inverse[c]))
    nfd=''.join(parts)
    complete=unicodedata.normalize('NFC',nfd)
    assert unicodedata.normalize('NFD',complete)==nfd
    return decompress(unpack_digits(read_glyphs(complete)),'delta32')

def main():
    mapping,ending=alphabet();lookup={r['component']:r['card'] for r in mapping}
    (ROOT/'card_alphabet.json').write_text(json.dumps({'null':NULL,'suit_order':SUITS,'cards':mapping,
      'ending_event_expected_bits':ending,'visible_component_expected_bits':sum(r['importance_bits_per_complete_symbol'] for r in mapping),
      'total_complete_symbol_bits':math.log2(RADIX)},indent=2,ensure_ascii=False)+'\n')
    with (ROOT/'card_alphabet.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(mapping[0]));w.writeheader();w.writerows(mapping)
    original=(ROOT/'inputs/zeros_1438.txt').read_bytes()
    latest=original+(ROOT/'inputs/zeros_1439_1502.txt').read_bytes()+(ROOT/'inputs/zeros_1503_1566.txt').read_bytes()
    results={'null_card':NULL,'null_position_in_frame':52,'active_cards':51,'cards_per_physical_frame':52,
      'suit_order':SUITS,'rank_values':dict(zip(RANKS,range(1,14))),'null_address':FACES.index(NULL),'card_address':'q=4(v-1)+s; A=1, J=11, Q=12, K=13; q mod 4=s',
      'active_suit_counts':dict(Counter(c[-1] for c in ACTIVE)),
      'deck_capacity_bits':math.log2(CAPACITY),'whole_deck_uniform_card_histogram_entropy_bits':math.log2(52),
      'active_card_uniform_histogram_entropy_bits':math.log2(51),'streams':{}}
    for name,raw in [('prefix_1438',original),('latest_1566',latest)]:
        packed=compress(raw,'delta32');text=glyphs(pack_digits(packed));nfd=unicodedata.normalize('NFD',text)
        hands=[]
        for c in text:
            parts=unicodedata.normalize('NFD',c)
            hand=[lookup[x] for x in parts]
            if len(hand)==2:hand.append(NULL)
            assert len(hand)==len(set(hand))==3
            hands.append(hand)
        transcript=[c for hand in hands for c in hand]
        assert decode_components(transcript,mapping)==raw
        (ROOT/f'transports/{name}_component_cards.txt').write_text(' '.join(transcript)+'\n')
        # Grouped complete symbols help a reader use the card alphabet by hand.
        with (ROOT/f'transports/{name}_symbol_groups.csv').open('w',newline='',encoding='utf8') as f:
            w=csv.writer(f);w.writerow(['symbol_index','radix_digit','card_group'])
            for i,(c,hand) in enumerate(zip(text,hands),1):w.writerow([i,ord(c)-HANGUL_BASE,' '.join(hand)])
        deals,packed2,packet=encode_packet(raw);assert packed2==packed and decode_packet(deals)==raw
        for d in deals:assert unrank_deck(rank_deck(d))==d
        (ROOT/f'transports/{name}_deck_frames.json').write_text(json.dumps({'null':NULL,'frame_order':'first to last',
          'card_order':'top to bottom','frames':deals},indent=2)+'\n')
        with (ROOT/f'transports/{name}_deck_frames.txt').open('w') as f:
            for i,deal in enumerate(deals,1):f.write(f'{i:04d}: '+' '.join(deal)+'\n')
        (ROOT/f'transports/{name}.delta32').write_bytes(packed)
        results['streams'][name]={'records':len(raw.splitlines()),'raw_bytes':len(raw),'delta32_bytes':len(packed),
          'complete_symbols':len(text),'component_card_uses':len(nfd),'null_slot_uses':transcript.count(NULL),
          'transcript_total_card_uses':len(transcript),'packet_header_bytes':16,'sentinel_bytes':1,
          'packet_bytes_without_sentinel':len(packet),'physical_deck_frames':len(deals),
          'physical_card_positions_across_frames':52*len(deals),'active_positions_across_frames':51*len(deals),
          'source_sha256':hashlib.sha256(raw).hexdigest(),'component_roundtrip_exact':True,'deck_roundtrip_exact':True,
          'first_symbol_cards':hands[:8],
          'first_deck_frame':deals[0]}
    x=parse_records(original)[0]
    first=unrank_deck(x);swapped=list(first);swapped[-3],swapped[-2]=swapped[-2],swapped[-3]
    y=rank_deck(swapped);assert y==x-1 and first[-1]==swapped[-1]==NULL
    broken=list(first);broken[-1],broken[0]=broken[0],broken[-1]
    try:rank_deck(broken)
    except ValueError:null_rejected=True
    else:raise AssertionError('Null displacement must reject the frame.')
    score={r['card']:r['importance_bits_per_complete_symbol'] for r in mapping};score[NULL]=ending
    assert Counter(first)==Counter(swapped)
    before_score=math.fsum(score[c] for c in first);after_score=math.fsum(score[c] for c in swapped)
    assert before_score==after_score
    assert abs(before_score-math.log2(RADIX))<1e-11
    trace=[];remaining=list(ACTIVE)
    for i,card in enumerate(first[:-1]):
        digit=remaining.index(card);place=FACT[len(remaining)-1]
        trace.append({'position':i+1,'card':card,'lehmer_digit':digit,'factorial_place':len(remaining)-1,'factorial':place,'contribution':digit*place})
        remaining.pop(digit)
    assert sum(t['contribution'] for t in trace)==x
    results['handheld_demo']={'source_record':1,'integer_scale':10**12,'rank_before':x,'rank_after':y,
      'height_before':serialize([x]).decode().strip(),'height_after':serialize([y]).decode().strip(),
      'cards_before':first,'cards_after':swapped,'changed_positions':[50,51],
      'null_stays_at_52':True,'displaced_null_rejected':null_rejected,
      'same_card_histogram':True,'same_total_assigned_score':True,'total_assigned_score':before_score,
      'rank_trace':trace}
    (ROOT/'HANDHELD_DEMO.json').write_text(json.dumps(results['handheld_demo'],indent=2)+'\n')
    results['paper_support']={'shared_convention_section_3':'Concrete reversible card code with explicit costs and decoder.',
      'fiber_lemma_section_5':'All deck orders have identical card inventory, histogram, and fixed-score sum; differing ranks cannot be recovered from those observations.',
      'metrics_section_6':'Card histogram entropy, order capacity, and zero-state weighted entropy are distinct quantities.',
      'composition_section_7':'The physical arrangement makes the retained relation inspectable.',
      'new_RH_or_infinite_tail_result':False,'paper_modified':False}
    (ROOT/'CARD_RESULTS.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'capacity_bits':results['deck_capacity_bits'],'streams':{k:{a:b for a,b in v.items() if a not in ['first_symbol_cards','first_deck_frame']} for k,v in results['streams'].items()},
      'demo':{k:v for k,v in results['handheld_demo'].items() if k not in ['cards_before','cards_after','rank_trace']},
      'mapping_first_five':mapping[:5],'expected_ending_bits':ending},indent=2,ensure_ascii=False))

if __name__=='__main__':main()
