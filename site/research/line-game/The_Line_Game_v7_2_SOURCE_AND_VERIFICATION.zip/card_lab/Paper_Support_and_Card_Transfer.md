# Playing cards, feedback, and invariant I

The cards strengthen the paper's explanation of shared conventions and recoverability. They also supply a finite model whose continuation can be certified exactly. The eight-page v7.1 paper remains unchanged. The new nine-page v7.2 incorporates the exact card string, decoding cost, recurrence, and forgiveness results. This note records the fuller experiment.

## What someone can hold

Set aside 2♣ as invariant marker I and deal three ordered hands of 17. A=1, J=11, Q=12, K=13. Suits ♠, ♥, ♦, ♣ have residues 0 through 3. Thus q=4(v-1)+s supplies the mod-4 address. The null has q=7; its full-deck transport position is 52.

Each nonempty hand reveals its top card. Higher rank wins; the declared suit order resolves a rank tie. Return the winning card to the bottom first, followed by other revealed cards clockwise. Captured cards reenter later contests. An empty player is out; two-player play continues by the same rule. These return and tie rules define the tested variant.

Accumulation now feeds back into future play. Starting distribution affects later counts, eliminations, and duration. Which cards are held, and their order, still matter. The 51 component-importance scores are separate from these face strengths.

## The paired experiment

A deck with I fixed can encode an integer by the permutation rank of the other 51 cards. Our small demonstration stores 14,134,725,141,735, read at supplied scale 10^12 as 14.134725141735. Swapping the last two active cards changes the integer to 14,134,725,141,734. Inventory, frequencies, total assigned score, and null position stay fixed. This changes a stored decimal record, not an exact zeta zero.

The same recorded position shuffle is applied to both arrangements. For seeds 0 through 63, the resulting 128 games gave 15 finishes and 113 exact cycles. None reached the 32,768-turn cap. Finishes took 55 to 151 turns; cycle periods ranged from 312 to 4,004. In 63 pairs the observed stopping time differed. In 7, a finish changed to a cycle or vice versa. These are sample results for the specified rule.

| Observation, seed 3 | Original order | One-swap order |
| --- | --- | --- |
| Stored decimal | 14.134725141735 | 14.134725141734 |
| First count difference | Turn 15 | Turn 15 |
| First player eliminated | P1 at turn 86 | P3 at turn 83 |
| Continuation | P2 wins at turn 144 | Repeats under the frozen rule |
| Full-state certificate | Absorption | State 1015 equals state 1535 |
| Cycle period | Not applicable | 520 turns |

Reversing both complete move logs and undoing the recorded shuffle recovers both input deck ranks. The ledger enables this recovery; final counts alone do not.

K♣ is the highest active card and cannot lose under this rule. Its initial holder is the only possible outright winner. This invariant does not force termination.

## A win condition for the analysis

Let \(X_n\) be the three labeled, ordered hands at a turn boundary, and let \(X_{n+1}=F(X_n)\) be the fixed transition. If \(X_r=X_s\) for \(r<s\), induction gives \(X_{r+k}=X_{s+k}\) for all \(k\geq0\). The continuation is periodic from r onward. The first-repeat certificate gives period 520 in our example.

The analysis can therefore stop with either of two certificates: one player holds all 51 active cards, or a complete state repeats. The finite state space guarantees that every unlimited deterministic run eventually reaches one of these outcomes. This does not supply a small general running-time bound.

A repeated inventory, count vector, or square sum supplies a weaker observation. Distinct ordered hands can share it. The full state and the transition rule establish the periodic future.

We label turn n by the existing \(y_n\) through the available 1,566 numerical records, ending at stored ordinate 2052.407790192401. Heights are external labels here: the game rule never reads their values. Moving those labels while retaining event order leaves the game unchanged. The encoded input number is a separate dependency, and moving it can change the game.

The game thus has an exact tail certificate. A relation constraining unobserved zeta zeros would additionally need to show that the retained state and transition govern those zeros. This experiment has not established that relation.

## Ace or two as I

The null test held all hand positions fixed. It replaced A♣ by 2♣ in one position, while changing the excluded marker from 2♣ to A♣. Every other card stayed put.

| Null face | Finishes, 64 starts | Exact cycles | Capped |
| --- | ---: | ---: | ---: |
| 2♣ | 6 | 58 | 0 |
| A♣ | 6 | 58 | 0 |

Seven durations changed; no finish-versus-cycle outcome changed. The two choices tie on termination frequency in this sample. They agree exactly on the square identities below. We retain 2♣ for a stable transport key and call its role I; the test establishes no universal advantage for either face.

## The 51/52 square relation

After one player is eliminated, surviving active counts satisfy

$$S=a+b=51,\qquad D=a-b,\qquad Q=a^2+b^2,\qquad 2Q=S^2+D^2.$$

D is odd. Assigning I physically to either hand, while leaving it nonplayable, gives (a+1,b) or (a,b+1). The physical total becomes 52 and the difference becomes D+1 or D-1, now even:

$$(D\pm1)^2-D^2=\pm2D+1.$$

The original seed-3 run first leaves counts 39 and 12. With I assigned to the larger hand, the physical counts are 40 and 12, difference 28, square sum 1744. Assigned to the smaller hand, they are 39 and 13, difference 26, square sum 1690. Active counts remain 39 and 12.

For the explicit objective of minimizing physical count imbalance or square sum, placing I with the smaller hand is always optimal. The square increments are 2a+1 and 2b+1. This is an optimum for marker placement in the ledger, not for the shuffled deal or game duration.

During an actual two-player turn, one net card moves from loser to winner. Using pre-turn counts,

$$\Delta Q=2(c_{\mathrm{winner}}-c_{\mathrm{loser}})+2.$$

All 1,510 two-player transitions in the illustrative pair satisfy this identity. Q increased 767 times, decreased 742 times, and stayed equal once. The square sum is not monotone. Its boundedness therefore does not certify completion; the repeated full state certifies periodic continuation.

## The reusable work of I

Once agreed, I provides a recognizable boundary, an excluded control, and a check connecting 51 active cards to 52 physical cards. That convention can be reused without transmitting a new definition on every turn. The initial agreement remains part of the description.

The account retains the card key, mode, rank and suit orders, null choice, byte scale, shuffle, return order, frame order, termination, and required history. I is useful because its meaning stays stable under the permitted moves. That meaning alone does not select a next zero ordinate.

## The complete data transport

The 51 visible Unicode components are ranked by expected conditional information contribution over the existing uniform 1,438-symbol inventory. The visible contributions total 10.317040568840 bits and the absent-trailing END event adds 0.172807391599 bits, giving log2(1438)=10.489847960439 bits per complete symbol. These are inventory averages, separate from game strengths.

In component mode, a complete symbol becomes leading card, vowel card, and trailing card or I. All 1,438 legal hands are distinct. Cards may be returned before the next symbol. The inverse uses the existing Unicode, radix, and delta32 conventions.

In full-deck mode, there are 51! arrangements with I fixed, giving log2(51!)=219.880563405562 bits of capacity. The framed byte packet becomes a sequence of permutation ranks.

| File | Source bytes | Delta32 bytes | Three-card symbols | Full-deck arrangements |
| --- | ---: | ---: | ---: | ---: |
| Original 1,438 records | 25,206 | 7,571 | 5,775 | 277 |
| Latest 1,566 records | 27,510 | 8,239 | 6,284 | 301 |

Both transports recover each source file byte for byte. One pack can be redealt, but retaining the message requires retaining the frame sequence. These sizes describe the stated literal transport, not an absolute shortest program for regenerating the numbers.

## What this adds to v7.1

Section 3's shared convention is now physical. Section 5's fiber criterion appears as identical counts and scores with different decoded integers and continuations. Section 6's distinct measurements remain explicit: card-frequency entropy, permutation capacity, and zero-state weighted entropy measure different objects. Section 7's arrangement can be inspected by hand.

An information model over ordered decks can represent order. This experiment identifies what the selected observation retains and discards. It does not strengthen the hypotheses of the paper's existing fiber theorem.

A possible compact addition in the paper's voice:

> A fixed card can hold the boundary while the other cards move. The inventory stays the same; the continuation need not. Return the winnings to the hand, and an arrangement begins to work on its own future. The rule has been supplied, and the record must still say which rule. When the full state comes back, the continuation comes back with it. The fixed marker helps us recognize the account. It does not replace the account.

The nine-page v7.2 paper ends with an informative reading map and citations. The package includes the conventions, input decimals, maps, tested outcomes, complete illustrative logs, height and square ledgers, inverse checks, and printable materials. No optimal-compression claim is made for the War grouping.

## Forgiveness and the game-theory check

See FORGIVENESS.md for the added rule, proof, and full results. All 128 tested starting configurations finished under this rule, using 0–24 interventions and 55–28,834 turns. The ordinary swapped example becomes a finish at turn 12,048 after 12 interventions, with 27 cards in P2's hand and 24 in escrow. Both illustrative games reverse exactly when the escrow actions are kept in the ledger.

The players compete with one another. I is a table-level accounting role and optional intervention rule. The card arrangement recovers a number by the agreed code; interpreting it as a numerical zero ordinate is context supplied by the source. The game responds to order and rank, not to that interpretation.
