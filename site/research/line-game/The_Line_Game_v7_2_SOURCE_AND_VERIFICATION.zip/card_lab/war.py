"""Three-player War with a frozen return order and an exact move ledger.

The height labels come from existing numerical records. They label turns;
they are deliberately not an undeclared input to the winning rule.
"""
from pathlib import Path
from collections import deque, Counter
import csv, hashlib, json, random
from cards import ACTIVE,FACES,NULL,rank_deck,unrank_deck,parse_records,serialize

ROOT=Path(__file__).resolve().parent
LIMIT=32768
SEEDS=64
Q={face:i for i,face in enumerate(FACES)}

def shuffled_hands(deck,seed):
    positions=list(range(51));random.Random(seed).shuffle(positions)
    order=[deck[i] for i in positions]
    return [order[p::3] for p in range(3)],positions

def state_key(hands):
    return bytes([*[Q[c] for c in hands[0]],52,*[Q[c] for c in hands[1]],53,*[Q[c] for c in hands[2]]])

def play(initial,limit=LIMIT,keep_log=False,keep_trace=1566):
    hands=[deque(h) for h in initial];seen={state_key(hands):0}
    all_cards=[c for h in hands for c in h]
    assert len(all_cards)==len(set(all_cards))==51 and set(all_cards)<=set(FACES)
    highest=max(all_cards,key=Q.__getitem__)
    owner=next(p for p,h in enumerate(hands) if highest in h)
    history=[[len(h) for h in hands]];events=[];eliminations=[]
    first_repeat=None;cycle_length=None;winner=None;status='capped'
    for step in range(1,limit+1):
        live=[p for p,h in enumerate(hands) if h]
        if len(live)==1:
            status='finished';winner=live[0];step-=1;break
        drawn={p:hands[p].popleft() for p in live}
        win=max(live,key=lambda p:Q[drawn[p]])
        return_players=[(win+k)%3 for k in range(3) if (win+k)%3 in drawn]
        pot=[drawn[p] for p in return_players]
        hands[win].extend(pot)
        counts=[len(h) for h in hands]
        assert sum(counts)==51 and highest in hands[owner]
        for p in live:
            if not hands[p]:eliminations.append({'turn':step,'player':p+1})
        if step<=keep_trace:history.append(counts)
        if keep_log:events.append({'turn':step,'drawn':{str(p+1):card for p,card in drawn.items()},
          'winner':win+1,'returned':pot,'counts_after':counts})
        if max(counts)==51:
            status='finished';winner=counts.index(51);break
        key=state_key(hands)
        if key in seen:
            status='cycle';first_repeat=seen[key];cycle_length=step-first_repeat;break
        seen[key]=step
    else:step=limit
    if winner is not None:assert winner==owner
    return {'status':status,'turns_observed':step,'winner':None if winner is None else winner+1,
      'highest_card':highest,'highest_card_initial_owner':owner+1,
      'cycle_entry_turn':first_repeat,'cycle_period':cycle_length,'eliminations':eliminations,
      'last_counts':[len(h) for h in hands],'final_hands':[list(h) for h in hands],
      'history':history,'events':events}

def undo(final_hands,events):
    hands=[deque(h) for h in final_hands]
    for event in reversed(events):
        win=event['winner']-1
        for face in reversed(event['returned']):assert hands[win].pop()==face
        for player,face in event['drawn'].items():hands[int(player)-1].appendleft(face)
    return [list(h) for h in hands]

def recover_deck(initial_hands,positions):
    shuffled=[initial_hands[p][i] for i in range(17) for p in range(3)]
    active=[None]*51
    for face,index in zip(shuffled,positions):active[index]=face
    return active+[NULL]

def summarize(run):
    return {k:v for k,v in run.items() if k not in ['history','events','final_hands']}

def main():
    raw=b''.join((ROOT/'inputs'/f).read_bytes() for f in ['zeros_1438.txt','zeros_1439_1502.txt','zeros_1503_1566.txt'])
    heights=raw.decode().splitlines();source=raw.decode().splitlines()[0]
    x=parse_records(raw)[0];before=unrank_deck(x);after=unrank_deck(x-1)
    pairs=[];runs=[]
    for seed in range(SEEDS):
        h1,positions=shuffled_hands(before,seed);h2,positions2=shuffled_hands(after,seed)
        assert positions==positions2
        r1=play(h1);r2=play(h2)
        common=min(len(r1['history']),len(r2['history']))
        first=next((i for i in range(1,common) if r1['history'][i]!=r2['history'][i]),None)
        pairs.append({'seed':seed,'before':summarize(r1),'after':summarize(r2),
          'first_count_difference_turn_within_height_window':first,
          'same_outcome':(r1['status'],r1['winner'])==(r2['status'],r2['winner']),
          'same_duration':r1['turns_observed']==r2['turns_observed']})
        runs.extend([r1,r2])
    # Use a real differing pair; prefer a completed-vs-cycle contrast if observed.
    candidates=[p for p in pairs if p['first_count_difference_turn_within_height_window'] is not None]
    pick=min(candidates,key=lambda p:(p['same_outcome'],p['same_duration'],p['seed']))
    seed=pick['seed'];initial,positions=shuffled_hands(before,seed);initial2,_=shuffled_hands(after,seed)
    example1=play(initial,keep_log=True);example2=play(initial2,keep_log=True)
    recovered=undo(example1['final_hands'],example1['events'])
    recovered2=undo(example2['final_hands'],example2['events'])
    assert recovered==initial and recovered2==initial2
    assert rank_deck(recover_deck(recovered,positions))==x
    assert rank_deck(recover_deck(recovered2,positions))==x-1
    # Relabeling the same turns leaves the frozen game unchanged. The ordinate
    # vector is not an argument to play(); no geometric coupling was supplied.
    relabelled=[str(float(y)+1) for y in heights]
    assert len(relabelled)==len(heights)
    statuses=Counter(r['status'] for r in runs)
    finished=[r['turns_observed'] for r in runs if r['status']=='finished']
    cycles=[r['cycle_period'] for r in runs if r['status']=='cycle']
    summary={'model':'three_player_war_v1','initial_hands':[17,17,17],'null':NULL,'ace_value':1,
      'rank_order':'A,2,3,4,5,6,7,8,9,10,J,Q,K','suit_order':['S','H','D','C'],
      'winning_rule':'largest q=4(v-1)+s','return_rule':'winner first, then clockwise players; append to bottom',
      'seeds':list(range(SEEDS)),'paired_runs':SEEDS,'total_runs':len(runs),'turn_cap':LIMIT,
      'statuses':dict(statuses),'finished_turn_range':None if not finished else [min(finished),max(finished)],
      'cycle_period_range':None if not cycles else [min(cycles),max(cycles)],
      'pairs_different_outcome':sum(not p['same_outcome'] for p in pairs),
      'pairs_different_duration':sum(not p['same_duration'] for p in pairs),
      'pairs_with_count_difference_within_1566':len(candidates),
      'known_height_labels':len(heights),'last_known_height_label':heights[-1],
      'height_labels_only':True,'card_mass_invariant':51,
      'highest_card_owner_invariant':True,'paper_modified':False,
      'example_seed':seed,'example_before':summarize(example1),'example_after':summarize(example2),
      'example_first_count_difference':pick['first_count_difference_turn_within_height_window'],
      'example_source_before':source,'example_source_after':serialize([x-1]).decode().strip(),
      'source_hash':hashlib.sha256(raw).hexdigest(),'source_byte_count':len(raw),
      'reverse_ledger_and_unshuffle_recover_both_deck_ranks':True}
    out=ROOT/'war';out.mkdir(exist_ok=True)
    (out/'WAR_RESULTS.json').write_text(json.dumps(summary,indent=2)+'\n')
    (out/'paired_runs.json').write_text(json.dumps(pairs,indent=2)+'\n')
    (out/'example_before.json').write_text(json.dumps({'seed':seed,'initial_hands':initial,'shuffle_positions':positions,**example1},indent=2)+'\n')
    (out/'example_after.json').write_text(json.dumps({'seed':seed,'initial_hands':initial2,'shuffle_positions':positions,**example2},indent=2)+'\n')
    with (out/'height_ledger.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['turn','stored_y_n_label','before_P1','before_P2','before_P3','after_P1','after_P2','after_P3'])
        for n,y in enumerate(heights,1):
            a=example1['history'][n] if n<len(example1['history']) else ['stopped']*3
            b=example2['history'][n] if n<len(example2['history']) else ['stopped']*3
            w.writerow([n,y,*a,*b])
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
