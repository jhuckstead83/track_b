"""Printable card demonstration and correctly sized physical card fronts."""
from pathlib import Path
import argparse,json,math
from xml.sax.saxutils import escape
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,Color,white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from cards import RANKS,SUITS,NULL,face_display

ROOT=Path(__file__).resolve().parent
R=json.loads((ROOT/'CARD_RESULTS.json').read_text())
M=json.loads((ROOT/'card_alphabet.json').read_text())
MAP={x['card']:x for x in M['cards']}
W=json.loads((ROOT/'war/WAR_RESULTS.json').read_text())
N=json.loads((ROOT/'war/NULL_RESULTS.json').read_text())
E=json.loads((ROOT/'war/example_before.json').read_text())
EA=json.loads((ROOT/'war/example_after.json').read_text())
F=json.loads((ROOT/'war/FORGIVENESS_RESULTS.json').read_text())
INK=HexColor('#253735');MUTED=HexColor('#596d66');GREEN=HexColor('#356557')
RED=HexColor('#a3333d');LINE=HexColor('#cbd6ce');PALE=HexColor('#edf3ed')
FONTROOT=Path('/usr/share/fonts/truetype/dejavu')
pdfmetrics.registerFont(TTFont('Body',str(FONTROOT/'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('BodyBold',str(FONTROOT/'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFont(TTFont('Title',str(FONTROOT/'DejaVuSerif.ttf')))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='BodyBold',italic='Body',boldItalic='BodyBold')

def para(c,text,x,y,w,size=10,leading=None,color=INK):
    text=text.replace('–','-').replace('—','-').replace('‑','-')
    p=Paragraph(text,ParagraphStyle('p',fontName='Body',fontSize=size,leading=leading or size*1.43,textColor=color))
    _,h=p.wrap(w,1000);p.drawOn(c,x,y-h)
    return y-h

def top(c,number,kicker,title):
    c.setFillColor(GREEN);c.setFont('BodyBold',8.4);c.drawString(42,754,kicker.upper())
    c.setFillColor(INK);c.setFont('Title',24);c.drawString(42,714,title)
    c.setStrokeColor(LINE);c.line(42,694,570,694)
    c.setFillColor(MUTED);c.setFont('Body',8);c.drawString(42,26,'LIGHTHOUSE | Playing-card demonstration | 19 September 2026')
    c.drawRightString(570,26,str(number))

def card(c,face,x,y,w=36,h=50,annotate=False):
    red=face[-1] in 'HD';color=RED if red else INK
    null=face==NULL
    c.setFillColor(PALE if null else white);c.setStrokeColor(GREEN if null else LINE)
    c.setLineWidth(1.1 if null else .65);c.roundRect(x,y,w,h,max(3,w*.045),stroke=1,fill=1)
    rank=face[:-1];suit=face_display(face)[-1]
    c.setFillColor(color);corner=max(8,w*.15)
    c.setFont('BodyBold',corner);c.drawString(x+w*.10,y+h-corner*1.25,rank)
    c.setFont('Body',corner);c.drawString(x+w*.10,y+h-corner*2.35,suit)
    c.saveState();c.translate(x+w,y+h);c.rotate(180)
    c.setFont('BodyBold',corner);c.drawString(w*.10,h-corner*1.25,rank)
    c.restoreState()
    c.setFont('Body',w*.36);c.drawCentredString(x+w*.5,y+h*.44,suit)
    if null:
        c.setFont('BodyBold',max(5,w*.065));c.drawCentredString(x+w*.5,y+h*(.64 if annotate else .27),'I / NULL')
    if annotate:
        if null:label='END / invariant marker I';score=M['ending_event_expected_bits'];cp='Control q=7 | A=1'
        else:
            r=MAP[face];label='Tile '+r['role']+' | '+r['code_point'];score=r['importance_bits_per_complete_symbol'];cp=f"Card q={r['q']:02d} | suit residue {r['suit_residue']}"
        c.setFillColor(MUTED);c.setFont('Body',7.1)
        c.drawCentredString(x+w/2,y+75,label)
        c.drawCentredString(x+w/2,y+63,f'Inventory contribution: {score:.6f} bits')
        c.drawCentredString(x+w/2,y+51,cp)

def deck_grid(c,deck,x,y,w=36,h=50,gap=4,number=True):
    for i,face in enumerate(deck):
        col=i%13;row=i//13;xx=x+col*(w+gap);yy=y-row*(h+14)
        card(c,face,xx,yy,w,h)
        if number:
            c.setFillColor(MUTED);c.setFont('Body',6);c.drawCentredString(xx+w/2,yy-8,f'{i+1:02d}')

def game_pages(c):
    top(c,1,'I / three-way war','Three hands, seventeen cards')
    para(c,'Set aside <b>2♣ as I</b>, the invariant marker. Deal the other 51 cards into three ordered hands of 17. Below is the tested starting deal (shuffle seed 3). Read each column downward; the first row is played first.',42,677,528,10.3)
    columns=[115,285,455]
    c.setFillColor(GREEN);c.setFont('BodyBold',11)
    for p,x in enumerate(columns):c.drawCentredString(x,607,f'PLAYER {p+1}')
    for i in range(17):
        y=584-i*21
        if i%2==0:c.setFillColor(PALE);c.rect(42,y-6,528,20,fill=1,stroke=0)
        c.setFillColor(MUTED);c.setFont('Body',8);c.drawString(48,y,f'{i+1:02d}')
        for p,x in enumerate(columns):
            face=E['initial_hands'][p][i]
            c.setFillColor(RED if face[-1] in 'HD' else INK);c.setFont('BodyBold',13)
            c.drawCentredString(x,y,face_display(face))
    para(c,'<b>Play.</b> Every nonempty hand reveals its top card. Higher rank wins: A=1, J=11, Q=12, K=13. Equal ranks use ♠ &lt; ♥ &lt; ♦ &lt; ♣. The winner puts its own revealed card on the bottom first, then the other revealed cards in clockwise player order. Repeat; captured cards return to play.',42,218,528,10.0,14)
    para(c,'A player with no cards is out. With two players, the same rule continues. Keep I outside the contest. Log the full ordered hands if you want to distinguish a long game from an exact repeat.',42,130,528,10.0,14)
    para(c,'This is a specified War variant. Suit tie-breaking and the return order are part of the rule. No grouping is assumed optimal.',42,67,528,8.8,12,color=GREEN)
    c.showPage()

    top(c,2,'Feedback / measured results','One swap changes the continuation')
    para(c,'The starting deck encodes 14.134725141735. Swap its final two active cards before applying the same shuffle; it then encodes 14.134725141734. Card inventory and assigned total score are unchanged.',42,677,528,10.3)
    rows=[('Observed item','Original arrangement','After one swap'),
      ('First player out','P1 at turn 86','P3 at turn 83'),
      ('Continuation','P2 wins at turn 144','Exact cycle'),
      ('Cycle certificate','Not needed','State 1015 = state 1535'),
      ('Cycle period','-','520 turns')]
    for j,row in enumerate(rows):
        y=594-j*29
        if j%2==1:c.setFillColor(PALE);c.rect(39,y-8,534,28,fill=1,stroke=0)
        c.setFillColor(GREEN if j==0 else INK);c.setFont('BodyBold' if j==0 else 'Body',9)
        for x,t in zip([42,225,405],row):c.drawString(x,y,t)
    para(c,'<b>A closed tail for this game.</b> A repeated full state, together with this deterministic rule, forces every later turn to repeat. A repeated card count alone is insufficient: the order within each hand is part of the state.',42,441,528,10.4,15)
    para(c,'Across 64 matched shuffles (128 runs), we found <b>15 finishes and 113 exact cycles</b>. Finishes took 55 to 151 turns; cycle periods ranged from 312 to 4,004. The one-swap pairs differed in observed stopping time in 63 of 64 cases, and in finish-versus-cycle outcome in 7.',42,350,528,10.1,14)
    para(c,'<b>Which null?</b> A separate matched test replaced A♣ with 2♣ at the same hand position, thereby changing the excluded marker from 2♣ to A♣. Each choice gave 6 finishes and 58 cycles. Seven durations changed; no finish-versus-cycle outcome changed. This sample gives no termination advantage to either face.',42,245,528,10.1,14)
    para(c,'Turn n is logged beside the stored height y_n, through the available 1,566 records. Height values do not enter this winning rule. Their labels can move without moving the game; changing the encoded input arrangement can change the game.',42,125,528,9.9,14)
    c.showPage()

    top(c,3,'I / the 51-to-52 ledger','The square relation is exact')
    para(c,'After the first elimination, before any escrow, two players hold a and b active cards. Their sum is 51. The reserved marker I contributes one physical card and zero playable cards. Test assigning it to either hand in a separate physical-count ledger.',42,677,528,10.4)
    c.setFillColor(PALE);c.roundRect(42,521,528,72,5,fill=1,stroke=0)
    c.setFillColor(INK);c.setFont('BodyBold',13)
    c.drawString(57,566,'S = a+b = 51        D = a-b        Q = a²+b²')
    c.drawString(57,539,'2Q = S²+D²        With I: S becomes 52; D becomes D±1')
    para(c,'The original run first reaches two players with <b>39 and 12</b> cards. The difference is 27. The two marker placements give:',42,502,528,10.4)
    data=[('Ledger','Physical counts','Difference','Square sum'),('I with larger hand','40, 12','28','1,744'),('I with smaller hand','39, 13','26','1,690')]
    for j,row in enumerate(data):
        y=430-j*28
        if j:c.setFillColor(PALE);c.rect(39,y-8,534,26,fill=1,stroke=0)
        c.setFillColor(GREEN if j==0 else INK);c.setFont('BodyBold' if j==0 else 'Body',9)
        for x,t in zip([42,224,372,467],row):c.drawString(x,y,t)
    para(c,'If the objective is the smallest physical count imbalance or square sum, assigning I to the smaller hand is always best. The result follows from comparing increments 2a+1 and 2b+1. It is identical for an ace marker or a two marker.',42,340,528,10.4,15)
    para(c,'<b>What the real game does.</b> In a two-player turn, the winner gains one net card and the loser loses one. The square sum changes by 2(winner count - loser count)+2. In the two logged runs, it increased 767 times, decreased 742 times, and stayed equal once. It is a checked measurement, not a quantity that always rises.',42,235,528,10.1,14)
    para(c,'<b>The reusable work of I.</b> The shared convention checks the boundary and keeps 51 active cards distinct from 52 physical cards. It needs no new symbol each turn. Predicting a continuation additionally uses the ordered hands and the transition rule.',42,112,528,10.0,14)
    c.showPage()

def forgiveness_page(c):
    top(c,4,'I / hold or forgive','A rule that makes progress')
    para(c,'The players compete with each other. I belongs to the table\'s accounting and an optional intervention rule. Ordinary War has no choices after the shuffle; the holder of I chooses whether a detected loop is left intact or interrupted.',42,677,528,10.4)
    c.setFillColor(PALE);c.roundRect(42,516,528,83,5,fill=1,stroke=0)
    para(c,'<b>Forgive an exact repeat.</b> Each live player puts its top card under I, permanently outside further contests. Begin a fresh recurrence ledger and continue with the same contest rule. Repeat this intervention whenever another full state repeats.',55,584,502,10.5,15)
    para(c,'The invariant account is now <b>cards in hands + cards under I = 51</b>. Including the marker makes 52 physical cards. The circulating count strictly decreases at each intervention; the preserved total includes escrow.',42,496,528,10.4)
    para(c,'<b>Why it terminates.</b> A finite deterministic phase must finish or repeat. At every repeat the intervention removes at least two circulating cards. There can be at most 25 interventions. Eventually one live hand remains, or all remaining cards enter escrow. The survivor may collect escrow; an empty table is a draw.',42,416,528,10.4,15)
    rows=[('Tested 128 starts','Hold I','Forgive every repeat'),('Finishes','15','128'),('Certified loops','113','0'),('Observed interventions','0','0 to 24')]
    for j,row in enumerate(rows):
        y=287-26*j
        if j%2:c.setFillColor(PALE);c.rect(39,y-7,534,25,fill=1,stroke=0)
        c.setFillColor(GREEN if j==0 else INK);c.setFont('BodyBold' if j==0 else 'Body',9)
        for x,t in zip([42,285,410],row):c.drawString(x,y,t)
    para(c,'The swapped example finishes at turn <b>12,048</b> after 12 interventions, with 27 cards in P2\'s hand and 24 in escrow. Its ordinary version cycles forever. Withholding forgiveness preserves that detected cycle; some other starting deals finish normally.',42,175,528,10.1,14)
    para(c,'This is a proved rule for this finite model. Generous tit-for-tat in the Prisoner\'s Dilemma concerns a different payoff game. Here the strict decrease supplies the termination proof; applying such a claim to zeros would require a corresponding proved rule.',42,79,528,9.1,12)
    c.showPage()

def guide(path):
    c=canvas.Canvas(str(path),pagesize=(612,792));c.setTitle('Playing Cards: Field Guide');c.setAuthor('LIGHTHOUSE / Cerebral Graphix')
    demo=R['handheld_demo'];deck=demo['cards_before']
    game_pages(c)
    forgiveness_page(c)
    top(c,5,'Handle the arrangement','A number in your hands')
    y=para(c,'Use an ordinary 52-card pack, with no jokers. Keep the <b>2 of clubs</b> as the null at the bottom. Arrange the cards below: read each row left to right, then downward. Card 01 is on top.',42,676,528,10.6)
    deck_grid(c,deck,48,557)
    y=para(c,'Now swap cards <b>50 and 51</b>. Leave card 52, the null, where it is.',42,309,528,11)
    c.setFont('BodyBold',9);c.setFillColor(GREEN);c.drawString(57,263,'BEFORE: LAST THREE CARDS');c.drawString(327,263,'AFTER: LAST THREE CARDS')
    for i,face in enumerate(deck[-3:]):card(c,face,57+i*70,162,62,87)
    for i,face in enumerate(demo['cards_after'][-3:]):card(c,face,327+i*70,162,62,87)
    para(c,'The card count, suit counts, one-card frequencies, and total assigned score remain the same. The null is still fixed. What did the swap change?',42,131,528,11)
    para(c,'Turn the page to read the number and the rule.',42,68,528,9.4,color=GREEN)
    c.showPage()

    top(c,6,'Open the convention','The number changed')
    c.setFillColor(MUTED);c.setFont('BodyBold',9);c.drawString(42,666,'BEFORE');c.drawString(320,666,'AFTER THE SWAP')
    c.setFillColor(INK);c.setFont('Body',21);c.drawString(42,630,demo['height_before']);c.drawString(320,630,demo['height_after'])
    y=para(c,'This is the first stored zero ordinate, at 12 decimal places. The swap lowers that stored value by exactly 0.000000000001. It changes a decimal record; it is not a claim that the exact zeta zero moved.',42,601,528,10.4)
    c.setFont('BodyBold',13);c.setFillColor(INK);c.drawString(42,518,'The suit gives a residue mod 4')
    for i,(symbol,name) in enumerate([('♠','Spades'),('♥','Hearts'),('♦','Diamonds'),('♣','Clubs')]):
        x=42+i*132;c.setFillColor(PALE);c.roundRect(x,441,123,60,5,fill=1,stroke=0)
        c.setFillColor(RED if i in (1,2) else INK);c.setFont('Body',24);c.drawString(x+12,470,symbol)
        c.setFont('BodyBold',10);c.drawString(x+43,477,name);c.setFont('Body',9);c.drawString(x+43,458,'residue '+str(i))
    para(c,'Ranks have values A=1, 2 through 10, J=11, Q=12, K=13. Suits have s=0 through 3. The card address is <b>q=4(v-1)+s</b>. The null 2 of clubs has q=7, while its fixed deck position is 52.',42,424,528,10.4)
    c.setFont('BodyBold',13);c.drawString(42,343,'Read an order, not a bag')
    para(c,'Use the active reference order A-spades, A-hearts, A-diamonds, A-clubs, then 2-spades, 2-hearts, 2-diamonds, then the threes, and so on. Omit the null. At each position, count the still-unused reference cards that precede the chosen card.',42,326,528,10.3)
    c.setFillColor(PALE);c.roundRect(42,212,528,55,5,fill=1,stroke=0)
    c.setFillColor(INK);c.setFont('BodyBold',11);c.drawString(57,243,'Deck rank = sum of d_i times (51-i)!')
    c.setFont('Body',10);c.drawString(57,225,'Stored height = deck rank / 1,000,000,000,000')
    para(c,'Here the rank is 14,134,725,141,735. Swapping the final two active cards changes only the last binary choice and subtracts one. The calculation trace is included with the source files.',42,195,528,10.3)
    para(c,'A fixed null checks the frame boundary. Moving it away from the bottom makes the deck invalid under this mode. A valid rearrangement of the other 51 cards carries a different rank.',42,116,528,10.3)
    c.showPage()

    top(c,7,'The alphabet behind the cards','51 components, one null')
    para(c,'The active cards are ranked by expected contribution to the known symbol budget. L means leading component, V vowel, and T trailing. I is an inventory contribution in bits per complete symbol, not a hand value to add while decoding. The null is an unranked control.',42,676,528,9.8)
    for group in range(3):
        x=42+176*group;yy=590
        c.setFillColor(GREEN);c.setFont('BodyBold',7.7)
        for dx,label in [(0,'q'),(18,'Card'),(48,'Tile'),(76,'Code'),(130,'I')]:c.drawString(x+dx,yy,label)
        for j,r in enumerate(M['cards'][group*17:(group+1)*17]):
            y=yy-20*(j+1)
            if j%2==0:c.setFillColor(PALE);c.rect(x-3,y-5,170,19,fill=1,stroke=0)
            c.setFillColor(MUTED);c.setFont('Body',7.7);c.drawString(x,y,str(r['q']))
            c.setFillColor(RED if r['card'][-1] in 'HD' else INK);c.setFont('BodyBold',8.7);c.drawString(x+18,y,r['card_display'])
            c.setFillColor(INK);c.setFont('Body',7.7);c.drawString(x+48,y,r['role']);c.drawString(x+76,y,r['code_point'])
            c.drawRightString(x+163,y,f"{r['importance_bits_per_complete_symbol']:.6f}")
    c.setFillColor(PALE);c.roundRect(42,190,528,40,5,fill=1,stroke=0)
    para(c,'<b>2♣ / q=7 / I:</b> the expected ending contribution is 0.172807 bits. It completes the ledger: 10.317041 + 0.172807 = 10.489848 bits per complete symbol.',53,221,505,9.1,12)
    for i,face in enumerate(['AS','AC',NULL]):card(c,face,42+i*56,76,49,69)
    para(c,'<b>Three cards make one symbol.</b><br/>A♠ / A♣ / 2♣ reads radix digit zero. The null here means the trailing component is absent. Its occurrence can vary in data hands; its position stays fixed only in full-deck frames. Return cards before dealing the next hand.',230,145,340,9.8,14)
    c.showPage()

    top(c,8,'The full transfer and the paper','What this demonstration carries')
    y=para(c,'The card versions recover the original decimal files exactly. A three-card hand represents one encoded symbol; a full-deck frame uses the order of all 51 active cards, with the null fixed at the bottom.',42,676,528,10.2)
    cols=[42,295,430];y=596
    for x,label in zip(cols,['Measured item','Original prefix','Latest file']):c.setFillColor(GREEN);c.setFont('BodyBold',9);c.drawString(x,y,label)
    data=[['Zero records','1,438','1,566'],['Decimal source bytes','25,206','27,510'],['Packed byte payload','7,571','8,239'],['Three-card hands','5,775','6,284'],['Full-deck frames','277','301']]
    for j,row in enumerate(data):
        yy=y-25*(j+1)
        if j%2==0:c.setFillColor(PALE);c.rect(39,yy-7,534,24,fill=1,stroke=0)
        c.setFillColor(INK);c.setFont('Body',10)
        for x,value in zip(cols,row):c.drawString(x,yy,value)
    para(c,'One frame has 51! possible orders: about <b>219.88 bits</b> of capacity. The full latest file needs 301 ordered arrangements in this format. You may reuse one physical pack, but the sequence of deals must be retained. A bag of the cards alone does not retain the data.',42,444,528,10.2)
    c.setFillColor(INK);c.setFont('BodyBold',13);c.drawString(42,342,'Where it fits in v7.2')
    evidence=[('Section 3 - shared convention','The card key and decoder make the same records readable in another medium.'),
      ('Section 6 - the fiber criterion','The inventory and summed score stay fixed while a decoded number changes.'),
      ('Section 7 - different measurements','Histogram entropy, order capacity, and zero-state entropy measure different objects.'),
      ('Section 8 - finite continuation','A repeated full state certifies the game; forgiveness adds strict progress.')]
    yy=324
    for title,desc in evidence:
        yy=para(c,'<b>'+title+'</b><br/>'+desc,42,yy,528,9.5,13)-12
    para(c,'The full ordered state and a fixed rule certify a periodic future for a repeating card game. The zero-height labels are external to that rule. A connection constraining unobserved zeros would require an additional proved relation.',42,92,528,9.1,12)
    c.save()

def printable(path):
    c=canvas.Canvas(str(path),pagesize=(612,792));c.setTitle('Playing Cards: 51 Components and One Null');c.setAuthor('LIGHTHOUSE / Cerebral Graphix')
    faces=[r['card'] for r in M['cards']]+[NULL]
    for page in range(9):
        c.setFillColor(GREEN);c.setFont('BodyBold',9);c.drawString(27,755,'LIGHTHOUSE / 51 COMPONENTS + ONE NULL')
        c.setFillColor(MUTED);c.setFont('Body',8.5);c.drawString(27,737,'Print at 100% / Actual Size. Cut on the card outlines. Fronts only.')
        for j,face in enumerate(faces[page*6:(page+1)*6]):
            col=j%3;row=j//3
            card(c,face,27+189*col,396-270*row,180,252,True)
        c.setStrokeColor(INK);c.setLineWidth(.6);c.line(27,62,99,62);c.line(27,59,27,65);c.line(99,59,99,65)
        c.setFillColor(MUTED);c.setFont('Body',8);c.drawString(109,59,'This line must measure 1 inch. Cards are 2.5 x 3.5 inches.')
        c.drawString(27,34,'I scores are fixed inventory contributions; data are carried by the declared card order.')
        c.drawRightString(585,34,f'{page+1} / 9')
        c.showPage()
    c.save()

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=ROOT/'pdf');args=p.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    guide(args.out/'Playing_Cards_Field_Guide.pdf');printable(args.out/'Playing_Cards_Printable_Set.pdf')
    print(json.dumps({'guide':str(args.out/'Playing_Cards_Field_Guide.pdf'),'guide_pages':8,
      'cards':str(args.out/'Playing_Cards_Printable_Set.pdf'),'card_pages':9,'card_size_inches':[2.5,3.5]}))

if __name__=='__main__':main()
