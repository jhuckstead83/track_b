"""Exact component weights and a finite-block equal-budget byte codec."""
from collections import Counter
from fractions import Fraction
import math,struct,zlib
from codec import RADIX,compose_coordinates,glyphs,parse_records,serialize

TREE=Counter()
PATHS=[]
for d in range(RADIX):
    triple=compose_coordinates(d)
    path=[triple[:k] for k in range(4)]
    PATHS.append(path)
    TREE.update(path)

def edge_probabilities(d,counts=None):
    if counts is None:mass=TREE
    else:
        assert len(counts)==RADIX and all(c>=0 for c in counts)
        mass=Counter(TREE)
        for leaf,c in enumerate(counts):
            if c:
                for prefix in PATHS[leaf]:mass[prefix]+=int(c)
    p=PATHS[d]
    return [Fraction(mass[child],mass[parent]) for parent,child in zip(p,p[1:])]

def verify_tree(counts=None):
    mass=Counter(TREE)
    if counts is not None:
        for d,c in enumerate(counts):
            for prefix in PATHS[d]:mass[prefix]+=int(c)
    largest=0.
    for d,p in enumerate(PATHS):
        probs=[Fraction(mass[c],mass[v]) for v,c in zip(p,p[1:])]
        joint=math.prod(probs)
        expected=Fraction(1,RADIX) if counts is None else Fraction(int(counts[d])+1,sum(map(int,counts))+RADIX)
        assert joint==expected
        cost=sum(math.log2(q.denominator/q.numerator) for q in probs)
        largest=max(largest,abs(cost+math.log2(float(expected))))
    return largest

def equal_pack(digits,block=5):
    assert 1<=block<=255 and all(0<=d<RADIX for d in digits)
    word=0;bits=0
    for start in range(0,len(digits),block):
        part=digits[start:start+block]
        width=(RADIX**len(part)-1).bit_length()
        x=0
        for d in part:x=x*RADIX+int(d)
        word=(word<<width)|x;bits+=width
    header=struct.pack('>3sHBI',b'EQ2',RADIX,block,len(digits))
    assert len(header)==10
    body=word.to_bytes((bits+7)//8,'big')
    out=header+body
    ledger={'symbols':len(digits),'block_length':block,'ideal_bits':len(digits)*math.log2(RADIX),
      'integer_field_bits':bits,'rounding_excess_bits':bits-len(digits)*math.log2(RADIX),
      'byte_padding_bits':8*len(body)-bits,'header_bits':80,'total_bytes':len(out)}
    return out,ledger

def equal_unpack(raw):
    magic,radix,block,n=struct.unpack('>3sHBI',raw[:10])
    assert magic==b'EQ2' and radix==RADIX and block>0
    sizes=[min(block,n-start) for start in range(0,n,block)]
    widths=[(RADIX**b-1).bit_length() for b in sizes]
    bits=sum(widths);assert len(raw)==10+(bits+7)//8
    word=int.from_bytes(raw[10:],'big');assert word<2**bits if bits else word==0
    digits=[]
    for size,width in zip(reversed(sizes),reversed(widths)):
        x=word&((1<<width)-1);word>>=width
        assert x<RADIX**size
        for _ in range(size):x,d=divmod(x,RADIX);digits.append(d)
        assert x==0
    assert word==0
    return digits[::-1]

def zencode(raw,dictionary=None):
    kw={'level':9,'method':zlib.DEFLATED,'wbits':15,'memLevel':8,'strategy':zlib.Z_DEFAULT_STRATEGY}
    if dictionary is not None:kw['zdict']=dictionary
    z=zlib.compressobj(**kw)
    return z.compress(raw)+z.flush()

def zdecode(raw,dictionary=None):
    kw={'wbits':15}
    if dictionary is not None:kw['zdict']=dictionary
    z=zlib.decompressobj(**kw)
    out=z.decompress(raw)+z.flush()
    assert z.eof and not z.unused_data and not z.unconsumed_tail
    return out

def gap_rows(vals):
    rows=[];last=0
    for x in vals:
        gap=x-last;last=x
        assert 0<gap<RADIX**5
        row=[0]*5
        for j in range(4,-1,-1):gap,row[j]=divmod(gap,RADIX)
        rows.append(row)
    return rows

def decode_rows(digits,start=0):
    assert len(digits)%5==0
    vals=[];x=start
    for offset in range(0,len(digits),5):
        gap=0
        for d in digits[offset:offset+5]:gap=gap*RADIX+d
        assert gap>0
        x+=gap;vals.append(x)
    return serialize(vals)

def flat(rows):return [d for row in rows for d in row]
