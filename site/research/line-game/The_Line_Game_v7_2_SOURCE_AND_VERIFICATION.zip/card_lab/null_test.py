"""Controlled null-identity comparison and the 51/52 square ledger."""
from collections import Counter
from pathlib import Path
import csv,json
from cards import FACES,unrank_deck,parse_records
from war import play,shuffled_hands,summarize,LIMIT

ROOT=Path(__file__).resolve().parent

def square_ledger(counts):
    ids=[i for i,c in enumerate(counts) if c]
    assert len(ids)==2
    a,b=[counts[i] for i in ids];d=a-b;s=a+b
    assert s==51 and d%2==1
    q=a*a+b*b
    placements=[]
    for target,(aa,bb) in enumerate([(a+1,b),(a,b+1)]):
        dd=aa-bb;qq=aa*aa+bb*bb
        assert aa+bb==52 and dd in [d-1,d+1]
        assert 2*qq==52**2+dd**2
        placements.append({'null_assigned_to_player':ids[target]+1,'physical_counts':[aa,bb],
          'physical_total':52,'active_total':51,'imbalance':dd,'squared_count_sum':qq,
          'square_increment':qq-q,'imbalance_square_increment':dd*dd-d*d})
    preferred=min(placements,key=lambda p:p['squared_count_sum'])
    assert preferred['null_assigned_to_player']==ids[0 if a<b else 1]+1
    return {'live_players':[i+1 for i in ids],'active_counts':[a,b],'active_total':51,
      'active_imbalance':d,'active_squared_count_sum':q,
      'identity_2Q_equals_S2_plus_D2':2*q==s*s+d*d,
      'null_placements':placements,'least_square_placement':preferred['null_assigned_to_player'],
      'null_face_changes_square_ledger':False}

def first_elimination(run):
    for event in run['events']:
        if sum(c>0 for c in event['counts_after'])==2:
            return {'turn':event['turn'],**square_ledger(event['counts_after'])}
    return None

def main():
    seed_count=64
    original=(ROOT/'inputs/zeros_1438.txt').read_bytes();x=parse_records(original)[0]
    deck=unrank_deck(x);pairs=[];totals={'2C':Counter(),'AC':Counter()}
    for seed in range(seed_count):
        hands,_=shuffled_hands(deck,seed)
        # Hold every position and every other face fixed. The club at the one
        # changed position is AC when 2C is null, and 2C when AC is null.
        alternate=[[('2C' if c=='AC' else c) for c in h] for h in hands]
        r2=play(hands);ra=play(alternate)
        totals['2C'][r2['status']]+=1;totals['AC'][ra['status']]+=1
        same=(r2['status'],r2['winner'])==(ra['status'],ra['winner'])
        pairs.append({'seed':seed,'null_2C':summarize(r2),'null_AC':summarize(ra),'same_outcome':same,
          'same_duration':r2['turns_observed']==ra['turns_observed']})
    examples={}
    for variant in ['before','after']:
        run=json.loads((ROOT/f'war/example_{variant}.json').read_text())
        examples[variant]=first_elimination(run)
    # Check exact square identities at every observed two-player transition.
    checked=0;decreases=0;increases=0
    for variant in ['before','after']:
        run=json.loads((ROOT/f'war/example_{variant}.json').read_text())
        prev=[17,17,17]
        for event in run['events']:
            counts=event['counts_after'];win=event['winner']-1
            if sum(c>0 for c in prev)==2:
                other=next(p for p,c in enumerate(prev) if p!=win and c>0)
                difference=sum(c*c for c in counts)-sum(c*c for c in prev)
                assert difference==2*(prev[win]-prev[other])+2
                decreases+=difference<0;increases+=difference>0;checked+=1
            prev=counts
    results={'null_candidates':['2C','AC'],'matched_shuffles':seed_count,'turn_cap':LIMIT,
      'control':'Replace AC by 2C in the same slot; preserve all other cards and their positions.',
      'statuses':{k:dict(v) for k,v in totals.items()},
      'pairs_different_outcome':sum(not p['same_outcome'] for p in pairs),
      'pairs_different_duration':sum(not p['same_duration'] for p in pairs),
      'square_bookkeeping':'tie: null identity has no effect',
      'shorter_hand_minimizes_post_marker_sum_of_squares':True,
      'first_elimination_examples':examples,
      'two_player_transitions_checked':checked,'square_increases':increases,'square_decreases':decreases,
      'all_two_player_square_differences_match_identity':True,
      'optimization_scope':'Compare termination frequency on these 64 matched deterministic runs only; no universal winner claimed.'}
    out=ROOT/'war'
    (out/'NULL_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
    (out/'null_paired_runs.json').write_text(json.dumps(pairs,indent=2)+'\n')
    (out/'SQUARE_LEDGER.json').write_text(json.dumps(examples,indent=2)+'\n')
    print(json.dumps(results,indent=2))

if __name__=='__main__':main()
