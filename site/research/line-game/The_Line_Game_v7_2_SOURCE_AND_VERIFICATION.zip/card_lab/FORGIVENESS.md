# I: holding a cycle or forgiving it

The players compete with each other. Ordinary play is the deterministic three-hand War variant in CARD_RULE.md. The marker I is outside the contest. The initial shuffle matters; after the deal, the ordinary rule supplies every move. Calling the intervention “forgiveness” is an interpretation of the added rule, not a claim that ordinary War is a tit-for-tat strategy game.

## The exact rule

1. Record the three labeled, ordered hands at the beginning of a phase and after each turn. Empty hands remain labeled. Counts alone are insufficient.
2. If at most one hand remains, stop: one remaining player is the survivor; no remaining players is a draw.
3. When a full ordered state repeats within the current phase, either hold I and preserve the certified cycle, or intervene.
4. To forgive, each live player removes its top card and places it permanently in escrow under I. These cards take no further part in contests. Record which player supplied each card and its identity.
5. Start a fresh recurrence ledger with the resulting hands. Continue with the same contest and return-order rule. The automatic forgiveness policy repeats this intervention at every recurrence.

A survivor may collect the escrow after play. Returning escrow to circulation during play would be another rule, to which the proof below does not automatically apply. The fixed-null face is 2C; the controlled AC comparison is a separate experiment.

## Two finite-model proofs

**Holding I.** At a detected recurrence, the state is the complete set of ordered hands and the transition rule is deterministic. Equal states have equal next states. Induction therefore repeats the same future, with the recorded period, forever if the rule is left unchanged. This certifies that particular cycle. It does not assert that every initial deal cycles.

**Forgiving every recurrence.** During a phase, the circulating cards are fixed. There are finitely many ways to distribute and order these distinct cards among three labeled hands. The deterministic phase therefore terminates or repeats a state. Every nonterminal recurrence has at least two live players, so an intervention removes at least two cards from circulation. Starting with 51 circulating cards allows at most 25 interventions. After finitely many finite phases, play consequently reaches a survivor or an empty-table draw. This proves eventual termination under this rule, without a useful short bound on the number of turns.

The accounting invariant is

    cards in hands + cards in escrow = 51.

Including I gives 52 physical cards. Circulating count strictly decreases at interventions. Once escrow is nonempty, the earlier two-player identity a+b=51 must instead read a+b=51−B, where B is the escrow count. The square ledger must use that updated total.

## Measured continuation

The experiment used the same 128 initial configurations as the ordinary comparison: seeds 0 through 63, with the exact original card record and its one-swap variant under each shared position permutation. Saved initial hands permit direct replay without relying on the random-number generator.

| Observation | Hold I | Forgive every recurrence |
|:--|--:|--:|
| Finished with a survivor | 15 | 128 |
| Certified full-state cycles | 113 | 0 |
| Runs stopped by the chosen turn cap | 0 | 0 |
| Observed turns to a finish | 55–151 | 55–28,834 |
| Observed interventions | 0 | 0–24 |

Ordinary play had a 32,768-turn cap; forgiveness had a 200,000-turn cap. These are finite samples, not outcome probabilities for all possible shuffles. The proof, rather than the sample completion rate, establishes termination of the automatic intervention rule.

In the published seed-3 example, the original arrangement finishes at turn 144 with player 2 holding all 51 cards. After swapping the final two active positions before the same shuffle, ordinary play has identical full states at turns 1,015 and 1,535: a period of 520. Forgiving each recurrence makes that variant finish at turn 12,048 after 12 interventions, with 27 cards in player 2's hand and 24 in escrow. Both illustrative histories, including escrow, reverse exactly using their recorded ledgers.

See war/FORGIVENESS_RESULTS.json, war/forgiveness_runs.json, and the two war/forgiveness_example_*.json files. forgiveness.py generates the results; audit.py checks the saved examples and accounting; the HTML implementation was compared against the Python outcomes for both policies, giving 256 matching games.

## What this can support

The demonstration puts a complete state, a recurrence certificate, an intervention, and a conserved total in the reader's hands. It illustrates why an ordered record can determine a continuation while an inventory or scalar score leaves distinctions unresolved. Its decoded number can be identified with a stored zero ordinate by an external convention; the War transition does not inspect that interpretation.

The existing zero heights may label turns, but the labels do not enter the transition rule. No proved map takes these card recurrences or the decreasing circulating count to unseen zeta zeros. The game therefore gives a finite example for the paper's information argument, not an RH-tail estimate or an RH proof.

Generous tit-for-tat belongs to a different payoff game. A primary study is C. Wedekind and M. Milinski, “Human cooperation in the simultaneous and the alternating Prisoner's Dilemma: Pavlov versus Generous Tit-for-Tat,” PNAS 93 (1996), 2686–2689, https://www.pnas.org/doi/10.1073/pnas.93.7.2686. It does not supply the termination theorem above; that theorem follows from the explicit finite-state and decreasing-circulation assumptions.
