"""Check saved transports, exact strings, square identities, and recurrence."""
from pathlib import Path
from collections import Counter,deque
import hashlib,json,math,unicodedata
from cards import alphabet,FACES,ACTIVE,NULL,RADIX,HANGUL_BASE,rank_deck,unrank_deck,decode_packet,decode_components
from war import Q,undo,recover_deck,state_key
from forgiveness import undo as undo_forgiveness

ROOT=Path(__file__).resolve().parent
checks=[]
def check(name,value):
    assert value,name
    checks.append(name)
mapping,ending=alphabet();lookup={r['component']:r['card'] for r in mapping}
hands=[]
for d in range(RADIX):
    parts=unicodedata.normalize('NFD',chr(HANGUL_BASE+d));h=[lookup[c] for c in parts]
    if len(h)==2:h.append(NULL)
    check('three distinct cards in symbol '+str(d),len(h)==len(set(h))==3)
    hands.append(tuple(h))
check('all 1438 symbol hands unique',len(set(hands))==1438)
check('suit residues correct',all(FACES.index(r['card'])%4==r['suit_residue'] for r in mapping))
prefix=(ROOT/'inputs/zeros_1438.txt').read_bytes();latest=prefix+(ROOT/'inputs/zeros_1439_1502.txt').read_bytes()+(ROOT/'inputs/zeros_1503_1566.txt').read_bytes()
for name,raw in [('prefix_1438',prefix),('latest_1566',latest)]:
    frames=json.loads((ROOT/f'transports/{name}_deck_frames.json').read_text())['frames']
    check(name+' saved deck frames decode exactly',decode_packet(frames)==raw)
    check(name+' each frame is a valid inverse',all(unrank_deck(rank_deck(d))==d for d in frames))
    transcript=(ROOT/f'transports/{name}_component_cards.txt').read_text().split()
    check(name+' saved component transcript decodes exactly',decode_components(transcript,mapping)==raw)
for value in [0,1,2,math.factorial(51)-2,math.factorial(51)-1,14134725141735]:
    check('rank/unrank boundary '+str(value),rank_deck(unrank_deck(value))==value)
demo=json.loads((ROOT/'HANDHELD_DEMO.json').read_text());r=demo['rank_before']
check('exact displayed integer',r==14134725141735)
check('exact 44-bit representation',bin(r)[2:]=='11001101101011111111010001010110010011100111')
check('six-byte big-endian representation',r.to_bytes(6,'big').hex()=='0cdaff4564e7')
check('swap changes rank by one',rank_deck(demo['cards_after'])==r-1)
for variant in ['before','after']:
    e=json.loads((ROOT/f'war/example_{variant}.json').read_text())
    initial=undo(e['final_hands'],e['events']);check('reverse full game '+variant,initial==e['initial_hands'])
    value=rank_deck(recover_deck(initial,e['shuffle_positions']))
    check('recover encoded integer '+variant,value==r-(variant=='after'))
    f=json.loads((ROOT/f'war/forgiveness_example_{variant}.json').read_text())
    check('reverse forgiveness with escrow '+variant,undo_forgiveness(f)==f['initial_hands'])
e=json.loads((ROOT/'war/example_after.json').read_text());h=[deque(x) for x in e['initial_hands']];states={0:state_key(h)}
for event in e['events']:
    drawn={p:h[p].popleft() for p in range(3) if h[p]}
    check('saved move replay '+str(event['turn']),{str(p+1):c for p,c in drawn.items()}==event['drawn'])
    win=max(drawn,key=lambda p:Q[drawn[p]])
    check('saved winner '+str(event['turn']),win+1==event['winner'])
    pot=[drawn[(win+k)%3] for k in range(3) if (win+k)%3 in drawn]
    h[win].extend(pot)
    if event['turn'] in [1015,1535]:states[event['turn']]=state_key(h)
check('full-state cycle equality at 1015 and 1535',states[1015]==states[1535])
for a in range(1,51):
    b=51-a;d=a-b;q=a*a+b*b
    check('51/52 square identity '+str(a),2*q==51**2+d*d and 2*((a+1)**2+b*b)==52**2+(d+1)**2 and 2*(a*a+(b+1)**2)==52**2+(d-1)**2)
f=json.loads((ROOT/'war/FORGIVENESS_RESULTS.json').read_text())
check('all 128 forgiveness samples finish',f['statuses']=={'finished':128})
check('observed intervention bound',f['observed_intervention_range'][1]<=25)
receipt={'status':'PASS','checks_passed':len(checks),'complete_symbol_hands':1438,'source_latest_sha256':hashlib.sha256(latest).hexdigest(),
 'exact_card_string':' '.join(demo['cards_before']),'exact_integer':r,'exact_decimal':'14.134725141735','exact_binary':bin(r)[2:],
 'exact_hex_bytes':r.to_bytes(6,'big').hex(' ').upper(),'active_order_capacity_bits':math.log2(math.factorial(51)),
 'certified_cycle':{'entry':1015,'repeat':1535,'period':520},'forgiveness_sample':f['statuses'],'proof_intervention_bound':25,
 'scope':'Checks saved finite-model records and supplied decimal byte transport; does not certify zeta zeros or an RH tail.'}
(ROOT/'AUDIT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
