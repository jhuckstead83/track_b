# Playing cards and invariant I

Start with Playing_Cards_Field_Guide.pdf (8 pages) at the top level of the complete package. It gives a playable three-hands-of-17 deal, the observed feedback, the square ledger, and the exact card transport. The separate printable set is 9 sheets of six standard 2.5 by 3.5 inch fronts (last sheet has four). Print at Actual Size; check the inch scale. Ordinary playing cards work too. Regenerating the PDFs with the command below writes them into this folder's pdf/ subdirectory.

Read CARD_RULE.md for the frozen conventions and Paper_Support_and_Card_Transfer.md for scope, results, and paper support. The original v7.1 paper remains eight pages and unchanged. The new v7.2 paper incorporates the card record and continuation results in nine pages.

## Reproduce

Use Python 3.12 with the pinned dependencies in `../paper_source/requirements.txt`. DejaVu fonts are required for PDF generation; update FONTROOT in make_pdfs.py if necessary.

Run from this folder:

    python cards.py
    python war.py
    python null_test.py
    python forgiveness.py
    python audit.py
    python make_pdfs.py --out pdf

cards.py reads the supplied numerical byte files; it does not generate or certify new zeta zeros. war.py uses seeds 0..63 and a 32,768-turn cap, with no randomness after initial shuffling. Saved example files include the actual initial hands and position permutation, so their replay need not rely on a particular RNG implementation.

## Files

- inputs/: original 1,438-record prefix and two successive 64-record extensions, all at 12 decimal places.
- card_alphabet.csv and .json: exact mapping, face addresses, component importance, and Unicode code points.
- transports/: full-file component transcripts and deck sequences, with delta32 bytes.
- HANDHELD_DEMO.json: one-deck integer example and full factorial rank trace.
- war/WAR_RESULTS.json and paired_runs.json: one-swap sample results.
- war/example_before.json and example_after.json: complete illustrative games, shuffle, and moves.
- war/height_ledger.csv: observed counts labeled by existing y_n; stopped runs are explicitly marked.
- war/NULL_RESULTS.json and null_paired_runs.json: matched ace/two comparison.
- war/SQUARE_LEDGER.json: both marker placements at first elimination.
- AUDIT.json: final checks of saved-file inversion, uniqueness, cycle, and square identities.
- MANIFEST.sha256 at the package's top level: file hashes.

I is a fixed role. The printed face remains 2C in the transport. The ace alternative is a controlled game-only experiment, explicitly separate from that key. For actual game play, I stays out; assigning it to a hand in the physical-count ledger does not activate it as a card.

The supplement's formulas and proofs derive from the stated finite model. The earlier Unicode importance model and decimal files come from the completed zero-text experiment. Surprise Is Not Meaning v7.2 develops the shared convention in sections 3–4, the limits of an observation in section 6, the numerical model in section 7, and the finite card continuation in section 8.

The optional forgiveness rule and its exact termination argument are in FORGIVENESS.md. Results and full illustrative escrow logs are under war/.
