# Card convention and invariant I

This revision incorporates three hands of 17, A=1, suit addresses mod 4, return-to-hand feedback, and an ace/two null comparison. It supersedes the unpublished A,K,Q,...,2 draft address order. Source decimals are unchanged.

## Addresses and importance

Use all 52 ordinary faces. Rank values are A=1, 2,...,10, J=11, Q=12, K=13. Suits are spades, hearts, diamonds, clubs, with s=0,1,2,3. The face address is q=4(v-1)+s; q mod 4 is the suit. The transport null is 2C, q=7, named I. Its fixed full-deck position is 52. The 51 active faces follow ascending q with 2C omitted. Their suit counts are 13,13,13,12.

Rank the 51 Unicode components by their expected conditional information contribution per uniformly chosen complete symbol in the existing 1,438-symbol inventory. Sort descending after rounding to 12 decimal places; break ties by code point. Assign that list to the active faces in ascending q. Importance rank, face value, and game strength are separate quantities.

The visible contributions sum to 10.317040568840 bits, and absent-trailing END contributes 0.172807391599 bits, totaling log2(1438). The null accounts for END in this ledger. A static printed score is an inventory average, not a replacement for contextual probabilities.

## Exact transports

Component mode: leading card, vowel card, trailing card or null. Every symbol uses three distinct cards; cards may recur in later symbols. Inverse lookup, NFC composition, radix inversion, and delta32 decoding recover the original bytes. The null occurrence varies to communicate the ending choice in this mode.

Full-deck mode: lexicographic permutation rank of 51 active faces, then I at position 52. Capacity is log2(51!)=219.880563405562 bits. Package the delta32 payload in a PC51 packet with a 16-byte length/CRC32 header and nonzero sentinel. Express its integer in radix 51! and retain the ordered frame sequence. The original 1,438 records need 277 frames; the latest 1,566 need 301. Both recover byte for byte.

The handheld example directly encodes integer 14134725141735, with scale 10^12 supplied. Swapping positions 50 and 51, KS and 10D, subtracts one from its rank. I stays at 52. This direct-integer mode and the complete-file packet are distinct declared modes.

## Three-way War

Apply a recorded pseudorandom position shuffle. Deal round robin into P1, P2, P3, 17 cards each. At every turn, all nonempty hands reveal their first card. Largest q wins. Append the winning card first, then the other revealed cards in clockwise player order, to the bottom of the winner's hand. Empty players are eliminated. Two-player play uses the same rule. I is never drawn.

The rule is deterministic after the initial shuffle, with no recursive tie battle. Its complete state is three labeled, ordered queues at a turn boundary. An exact repeated state proves periodic continuation. The maximum active card cannot be captured; its initial owner is the only possible outright winner, although cycles can prevent an outright win.

No partition is called optimal. The random distribution follows the feedback proposal. Component importance scores do not decide winners.

## I, units, and squares

Every active card is one trade unit, whatever its face. A three-player winner gains two net cards; a two-player winner gains one. Rescaling the unit changes the numerical ledger, not the physical game.

After the first elimination, a+b=51. For a separate physical-card ledger assign the excluded marker to either hand: (a+1,b) or (a,b+1). Playable counts remain (a,b). Write S=a+b, D=a-b, Q=a^2+b^2. Then 2Q=S^2+D^2. The marker changes S from 51 to 52 and D by +1 or -1. Putting I with the smaller hand minimizes the physical imbalance and square sum. These identities do not depend on which face is I.

For the null comparison, replace AC by 2C in exactly the same hand position and set AC aside instead. Hold every other face and position fixed. Compare 64 matched starts. The published transport key remains fixed during this game-only variant.

## Height labels and cost ledger

Turn n is logged beside the existing numerical y_n for n<=1566. These ordinates label events; they are not arguments of the War transition. Changing the labels leaves the game unchanged. Changing a number supplied to the deck encoder can change the arrangement and game. These are distinct dependencies.

After agreement, I can be reused without another transmitted definition each turn. The key, mode, rank/suit order, null, shuffle, transition, scale, frame order, termination, and required history remain in the ledger. A full reversible game log plus its endpoint and the recorded shuffle recovers the input arrangement.

The analysis has two stopping certificates: absorption (one player holds 51 active cards) or exact recurrence (the full state repeats). Since this deterministic game has finitely many states, every unlimited run must eventually meet one of them. A numerical cap alone is neither certificate.

## Optional forgiveness rule

At an exact within-phase repeat, each nonempty hand places its top card under I, permanently out of circulation. Reset the recurrence ledger and continue. Conserved total: hands + escrow = 51, with I making 52 physical cards. Every intervention removes at least two circulating cards, hence at most 25 interventions are possible. Each finite deterministic phase ends or repeats, proving eventual termination as a survivor or empty-table draw. An eventual survivor may collect escrow after play. Withholding intervention at an exact repeat preserves the ordinary loop. This added rule is separate from the ordinary game and from a game-theoretic claim about Prisoner's Dilemma payoffs.

After escrow begins, surviving active counts sum to 51 minus the escrow count. The earlier 51/52 two-hand square calculation applies before escrow; include the bank thereafter.
