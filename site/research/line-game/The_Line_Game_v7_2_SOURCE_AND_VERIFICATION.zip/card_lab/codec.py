"""Explicit lossless codec and reversible TFG/Unicode maps for the probe."""
from __future__ import annotations
import bz2
from fractions import Fraction
import lzma
import struct
import unicodedata
import zlib
import zstandard as zstd

RADIX=1438
HANGUL_BASE=0xAC00
CJK_BASE=0x4E00
BLOCK=32
CODECS=('raw','zlib9','bz2_9','lzma9','zstd19','delta32')

def parse_records(raw):
    text=raw.decode('ascii')
    assert text.endswith('\n')
    lines=text.splitlines()
    assert lines and all(s.count('.')==1 and len(s.split('.')[1])==12 for s in lines)
    vals=[int(s.replace('.','')) for s in lines]
    assert all(x>0 for x in vals) and all(a<b for a,b in zip(vals,vals[1:]))
    assert serialize(vals)==raw
    return vals

def serialize(vals):
    return ''.join(f'{x//10**12}.{x%10**12:012d}\n' for x in vals).encode('ascii')

def delta_encode(raw):
    vals=parse_records(raw)
    out=bytearray(b'ZD1'+struct.pack('>IBBQ',len(vals),12,BLOCK,vals[0]))
    gaps=[b-a for a,b in zip(vals,vals[1:])]
    for start in range(0,len(gaps),BLOCK):
        block=gaps[start:start+BLOCK]
        width=max(block).bit_length()
        assert width<256
        out.append(width)
        word=0
        for gap in block: word=(word<<width)|gap
        out.extend(word.to_bytes((width*len(block)+7)//8,'big'))
    return bytes(out)

def delta_decode(raw):
    assert raw[:3]==b'ZD1'
    n,precision,blocksize,first=struct.unpack('>IBBQ',raw[3:17])
    assert precision==12 and blocksize==BLOCK and n>0
    vals=[first]; offset=17
    while len(vals)<n:
        width=raw[offset];offset+=1
        size=min(blocksize,n-len(vals))
        nbytes=(size*width+7)//8
        word=int.from_bytes(raw[offset:offset+nbytes],'big');offset+=nbytes
        mask=(1<<width)-1
        ds=[0]*size
        for i in range(size-1,-1,-1):
            ds[i]=word&mask;word>>=width
        assert word==0
        for d in ds: vals.append(vals[-1]+d)
    assert offset==len(raw)
    return serialize(vals)

def compress(raw,method):
    if method=='raw': return raw
    if method=='zlib9': return zlib.compress(raw,9)
    if method=='bz2_9': return bz2.compress(raw,compresslevel=9)
    if method=='lzma9': return lzma.compress(raw,preset=9)
    if method=='zstd19': return zstd.ZstdCompressor(level=19).compress(raw)
    if method=='delta32': return delta_encode(raw)
    raise ValueError(method)

def decompress(raw,method):
    if method=='raw': return raw
    if method=='zlib9': return zlib.decompress(raw)
    if method=='bz2_9': return bz2.decompress(raw)
    if method=='lzma9': return lzma.decompress(raw)
    if method=='zstd19': return zstd.ZstdDecompressor().decompress(raw)
    if method=='delta32': return delta_decode(raw)
    raise ValueError(method)

def pack_digits(raw):
    """A sentinel preserves every byte including leading zeros and length."""
    v=int.from_bytes(b'\x01'+raw,'big')
    digits=[]
    while v:
        v,d=divmod(v,RADIX);digits.append(d)
    return digits[::-1]

def unpack_digits(digits):
    v=0
    for d in digits:
        assert 0<=d<RADIX
        v=v*RADIX+d
    raw=v.to_bytes((v.bit_length()+7)//8,'big')
    assert raw[0]==1
    return raw[1:]

def glyphs(digits,base=HANGUL_BASE):
    return ''.join(chr(base+d) for d in digits)

def read_glyphs(text,base=HANGUL_BASE):
    ds=[ord(c)-base for c in text]
    assert all(0<=d<RADIX for d in ds)
    return ds

def compose_coordinates(d):
    return d//588,(d%588)//28,d%28

def tfg_address(k):
    assert 1<=k<=RADIX
    return Fraction(RADIX*(RADIX-1)+k,RADIX)

def tfg_inverse(frac):
    r,d=frac.numerator,frac.denominator
    n=(r+d-1)//d
    assert n%d==0
    return n,(n//d)*(r-d*(n-1))

def roundtrip(raw,method):
    packed=compress(raw,method)
    ds=pack_digits(packed)
    text=glyphs(ds)
    unfolded=unicodedata.normalize('NFD',text)
    recovered=decompress(unpack_digits(read_glyphs(unicodedata.normalize('NFC',unfolded))),method)
    assert recovered==raw
    return packed,ds,text,unfolded
