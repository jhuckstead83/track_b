# Invariant — The Line Game | Surprise Is Not Meaning

Standalone HTML card game and decoder accompanying paper v7.2 and Cerebral Graphix v1.13.5.

The interface has two cleanly separated experiences. **Play & explain** teaches the published paired game with milestones, recurrence proof, and optional forgiveness. **Prediction from data** starts fresh, exposes the three exact strength queues without interpretation, withholds the guided certificate and recurrence announcement, and asks the player to take a position on the next winner. A prediction can move until the round is played; playing settles it and moves **Play next round** onto the selected hand. Opening the answer-level data withdraws that round's clean prediction and requires the round to be played before another can be made.

Open dist/index.html in a modern browser; no external JavaScript dependencies. The three PDF links are bundled beside it.

Run node verify_game.mjs to compare the JavaScript engine against 256 saved Python outcomes (128 starting configurations, two policies). Game rules and termination proof are described in the paper and HTML.

The browser layout and optional WebMCP hooks could not be exercised in this buildless static-preview environment. Mathematical outcomes and the HTML scripts were checked locally.
