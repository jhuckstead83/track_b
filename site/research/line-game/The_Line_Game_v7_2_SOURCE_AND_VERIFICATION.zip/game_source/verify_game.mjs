import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const html=fs.readFileSync(new URL('./dist/index.html',import.meta.url),'utf8');
const script=id=>{
  const match=html.match(new RegExp('<script id="'+id+'"[^>]*>([\\s\\S]*?)<\\/script>'));
  assert(match,`Missing script ${id}`);
  return match[1];
};
const context=vm.createContext({});
vm.runInContext(script('game-engine'),context);
new vm.Script(script('game-ui'));
const {CardGame,rankDeck,decimalRank,compatibleCount,compatibleLog2,TOKENS}=context.InvariantEngine;
const data=JSON.parse(script('experiment-data'));

const swapped=[...data.deck];
[swapped[49],swapped[50]]=[swapped[50],swapped[49]];
assert.equal(rankDeck(data.deck),14134725141735n);
assert.equal(decimalRank(rankDeck(data.deck)),'14.134725141735');
assert.equal(rankDeck(swapped),14134725141734n);
assert.equal(decimalRank(rankDeck(swapped)),'14.134725141734');
for(const bad of [[],data.deck.slice(1),[...data.deck.slice(0,51),'AS'],[...data.deck.slice(1),data.deck[0]]]) assert.throws(()=>rankDeck(bad));

assert(data.deck.slice(0,51).every((card,index)=>TOKENS[card].classId===TOKENS[swapped[index]].classId));
const baselineCount=67305847895575919030981099520000000n;
assert.equal(compatibleCount('weight',[],data.deck.slice(0,51)),baselineCount);
assert.equal(compatibleLog2('weight',[],data.deck.slice(0,51)).toFixed(6),'115.696287');
assert.equal(compatibleCount('weight',[49],data.deck.slice(0,51)),baselineCount/18n);
assert.equal(compatibleCount('weight',[49,49],data.deck.slice(0,51)),baselineCount/18n);
assert.equal(compatibleCount('weight',Array.from({length:35},(_,index)=>index),data.deck.slice(0,51)),20922789888000n);
assert.equal(compatibleCount('identity',[],data.deck.slice(0,51)),1n);
assert.equal(compatibleCount('weight',[],data.deck.slice(0,51),true),1n);
assert.throws(()=>compatibleCount('weight',[-1],data.deck.slice(0,51)));

const cases=JSON.parse(fs.readFileSync(new URL('./test_fixtures.json',import.meta.url),'utf8'));
let checked=0;
for(const item of cases) for(const forgiveness of [false,true]) {
  const game=new CardGame(item.initial,{forgiveness});
  while(game.status==='playing'&&game.turn<200000) game.step();
  const expected=forgiveness?item.forgiven:item.ordinary;
  assert.equal(game.status,expected.status,`status ${item.seed} ${item.variant} ${forgiveness}`);
  assert.equal(game.winner,expected.winner,`winner ${item.seed} ${item.variant} ${forgiveness}`);
  assert.equal(game.turn,forgiveness?expected.turns:expected.turns_observed,`turn ${item.seed} ${item.variant} ${forgiveness}`);
  if(forgiveness) {
    assert.equal(game.interventions,expected.interventions);
    assert.equal(game.bank.length,expected.escrow_count);
  } else if(game.status==='cycle') {
    assert.equal(game.cycle.entry,expected.cycle_entry_turn);
    assert.equal(game.cycle.period,expected.cycle_period);
  }
  checked+=1;
}
assert.equal(checked,256);

const original=new CardGame(data.before,{variant:'original',permutation:data.positions});
const changed=new CardGame(data.after,{variant:'one-swap',permutation:data.positions});
original.step();changed.step();
assert.equal(original.last.drawn.map(item=>item.card).join(','),'7C,10D,4S');
assert.equal(changed.last.drawn.map(item=>item.card).join(','),'7C,KS,4S');
assert.equal(original.last.winner,2);assert.equal(changed.last.winner,2);
while(original.turn<15) original.step();
while(changed.turn<15) changed.step();
assert.equal(original.last.winner!==changed.last.winner,true);
assert.equal(original.hands.map(hand=>hand.length).join(','),'17,20,14');
assert.equal(changed.hands.map(hand=>hand.length).join(','),'14,23,14');
while(original.status==='playing') original.step();
while(changed.status==='playing') changed.step();
assert.equal(original.status,'finished');assert.equal(original.turn,144);assert.equal(original.winner,2);
assert.equal(changed.status,'cycle');assert.equal(changed.turn,1535);assert.equal(changed.cycle.entry,1015);assert.equal(changed.cycle.period,520);
const certificate=changed.certificate();
assert.equal(JSON.stringify(certificate.cycle.entryState),JSON.stringify(certificate.cycle.repeatState));
assert.equal(certificate.accounting.total,52);
assert.equal(certificate.permutation.length,51);

const key=JSON.stringify(changed.hands);
for(let index=0;index<520;index+=1) changed.replayStep();
assert.equal(JSON.stringify(changed.hands),key);
assert.equal(changed.cycle.period,520);
assert.equal(changed.turn,2055);

const manual=new CardGame(data.after);
while(manual.status==='playing') manual.step();
manual.forgive();
assert.equal(manual.bank.length,2);
assert.equal(manual.hands.flat().length,49);
assert.equal(manual.status,'playing');
assert.throws(()=>manual.forgive());

const kcCase=cases.find(item=>item.seed===2&&item.variant==='after');
assert(kcCase);
assert.equal(kcCase.initial.findIndex(hand=>hand.includes('KC'))+1,2);
const kcForgiven=new CardGame(kcCase.initial,{forgiveness:true});
while(kcForgiven.status==='playing'&&kcForgiven.turn<200000) kcForgiven.step();
assert.equal(kcForgiven.status,'finished');
assert.equal(kcForgiven.winner,1);
assert.equal(kcForgiven.turn,15011);
assert.equal(kcForgiven.interventions,13);

const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(match=>match[1]);
assert.equal(new Set(ids).size,ids.length);
for(const id of [...html.matchAll(/\$\('([^']+)'\)/g)].map(match=>match[1])) assert(ids.includes(id),'Missing element '+id);
assert(!html.includes('__EXPERIMENT_DATA__'));
assert(html.includes('Play &amp; explain'));
assert(html.includes('Prediction from data'));
assert(html.includes('Predict the next winner'));
assert(html.includes('Play next round'));
assert(html.includes('prior picks, progress, and score were not carried in'));
assert(html.includes('this round cannot carry an answer'));
const ui=script('game-ui');
assert(ui.includes("experienceMode==='challenge'"));
assert(ui.includes('predictionStats.streak'));
assert(ui.includes('peekLocked=true'));
assert(ui.includes("(target||$('game-step-home')).append(gameStepButton)"));
assert(ui.includes("if(experienceMode!=='guided')return"));

const report={
  status:'PASS',
  python_javascript_games_compared:checked,
  exact_card_rank:true,
  one_swap_minus_one:true,
  position_weight_profile_preserved:true,
  exact_compatible_count:true,
  counter_reveal_and_identity_boundaries:true,
  published_pair_milestones:true,
  full_state_certificate_checked:true,
  kc_forgiveness_counterexample_checked:true,
  manual_forgiveness_checked:true,
  guided_and_data_modes_checked:true,
  prediction_position_and_peek_forfeit_checked:true,
  ui_javascript_syntax_valid:true,
  unique_element_ids:true,
  browser_visual_review:'NOT RUN: no supported browser executable was available in the build environment.',
  webmcp_browser_validation:'NOT RUN: no permitted supported browser context was available.'
};
fs.writeFileSync(new URL('./GAME_VERIFICATION.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
