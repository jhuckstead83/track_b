# Paper selection for Alpha, with companion display accounting

Keep the additions short and merge them into existing prose, preserving the nine-page aim and the thirteen-page ceiling. The mathematical transition, exact card string, recorded sample results, and existing proofs remain the controlling baseline. The later source-reading pass strengthens the language around work already carried by the receiver, memory, and the boundary of an account. The display accounting at the end belongs in the HTML or supplement. These are merge notes; Alpha's publication and website have not been rebuilt here.

**For §3, let the prior work sharpen the paragraph about the shared convention.** Suggested replacement for the paragraph beginning "The capstone lets eleven fractions":

> The capstone lets eleven fractions recover `hello world`. A reader who knows ASCII can make the last transition almost at once. The ease is real: the message calls on a convention the receiver already carries. A later reader needs that convention too, even when the later reader is the person who made the record. The description on the page is only part of the account; the rule, the retained record, and the work of reading belong in it together.

Keep this within the existing discussion of what was paid in advance. It makes the source of the economy visible without pricing a reader's effort in joules. The existing Landauer/Bennett paragraph in §2 already provides the right discipline: identify the operation before charging a cost.

**For §4, strengthen the observation from an unchanged sum to an unchanged profile.** Suggested replacement for the weaker score sentence:

> Under the companion's uniform-symbol model, the final eighteen active reference cards have equal expected information contributions. The swap leaves the component weight at every position unchanged. The same complete weight profile therefore permits two different decoded records [13].

The weights must be identified as this model's component contributions, not probabilities of drawing cards or the paper's folded-zero masses. Their equality comes from the selected inventory and model. Keep the exact context-count proof and the 35/16 factorial explanation in the supplement unless space makes one short clarification useful. The new weighted-order check supplies the evidence for this stronger sentence and should accompany the release sources.

**For §4, connect the nonnumeric symbols to the recovered mathematics.** One compact sentence is enough:

> The faces need not carry numerals: any one-to-one relabeling, read through its matching inverse, recovers the same stored heights, their order, and their gaps.

This is the inverse-map identity already explained in the handoff. It applies to the valid encoded records, including a sequence of frames when the complete table is carried. The identification of those heights with the zero source remains supplied by the source and mathematical context.

**For the closing prose in §8, retain the generic War illustration and let memory enter here.** Suggested passage:

> In ordinary War, the stack keeps an order the players may no longer know. Earlier reveals may still be carried in memory or written in a ledger. Another tie can be the surprise: one familiar label, another delay, a growing contest. To measure that surprise, we must say what the observer retains and how the remaining possibilities are weighted. The same reveal can carry different surprisal for players with different histories. What it means to them still depends on the sequence and what is now at stake.

This describes familiar ordinary War and the experience of a sequence. Concealing a stack changes access to its order; it does not erase that order. The label "tie" groups many distinct states, while remembered history can distinguish some of them. This is the late connection Jeffery wants the reader to reach, rather than a new definition announced in the opening. The tested variant resolves equal ranks immediately by suit; its long runs and exact cycles remain separate results.

**Editorial support for that closing passage; no additional lemma is needed.** Equation (1) already supplies the measure. With retained information \(h\) and a declared probability model, use \(I_P(x\mid h)=-\log_2 P(x\mid h)\) for positive conditional probability. If the model assigns equal weight to \(N\) compatible initial orders and \(m\) of them produce the next event \(x\), the value is \(\log_2(N/m)\). This is a counting interpretation under stated assumptions, not a new calculation performed on the published games. Countability alone does not establish equal weighting, and repeated ties need not have increasing conditional surprisal. The existing game audits measure finite behavior; they do not measure a player's felt anticipation. The paper's existing [Shannon reference](https://web.mit.edu/6.441/www/reading/shannon1948.pdf) supports the information-theoretic bridge.

Jeffery's phrase "a delta from what can be known" should therefore be refined to surprise relative to the information available to a specified observer. If "delta" instead means the change from prior to posterior beliefs, that is a separate formal notion of [Bayesian surprise](https://papers.nips.cc/paper_files/paper/2005/hash/0172d289da48c48de8c5ebf3de9f7ee1-Abstract.html), not an interchangeable name for Equation (1). The short paper passage need not introduce this second measure.

Keep the immune-memory analogy in this editorial ledger unless the paper needs another example. In the human example, memory B and T cells provide a mechanism ([CDC explanation](https://www.cdc.gov/covid/vaccines/how-they-work.html)). The supplied *Cost of Surprise* also clarifies Jeffery's DNA remark: in bacterial CRISPR immunity, retained invader-derived DNA spacers are literal records, and adding or removing particular spacers can change resistance ([Barrangou et al., 2007, primary-paper abstract](https://pure.psu.edu/en/publications/crispr-provides-acquired-resistance-against-viruses-in-prokaryote/)). The earlier human-only reply was too narrow as a reading of this broader program. Keep the two biological mechanisms distinct. Neither analogy by itself supplies a numerical surprise value or a measurement of subjective feeling.

**Use this attribution ledger while editing.** It need not become another table in the paper.

| Statement | What supplies it |
|:--|:--|
| The stored ordinate | Supplied numerical data at the stated precision |
| Equal component contributions | Chosen Unicode inventory and uniform-symbol model |
| The encoded arrangement | Declared factorial encoder and supplied integer |
| A finish, recurrence, or forgiveness result | The specified finite-game transition and its proof or recorded run |
| The generic War example | Concealed order, continued ties, retained history, and the interpretation of a developing sequence |
| A conditional surprisal value | A specified observer's information and a declared probability model; not the event label alone |
| The immune-memory analogy | A biological response shaped by previous exposure; editorial context, not a new paper result |
| Recoverability through other symbols | Bijective relabeling with the corresponding inverse |

Do not promote divisibility, a new decimal-tail contest, or the suspected high-card behavior into launch claims. The recent review corrections still apply wherever the paper or interface mentions them: turn 15 is the first count/winner difference, not the first difference in full states; the KC-holder guarantee applies to ordinary play, not to the forgiveness policy.

The thread to retain is affirmative: a convention can carry exact mathematical content through arbitrary symbols; a chosen measurement or event label can leave distinctions unresolved; memory can retain some of those distinctions; and surprise acquires significance within a sequence someone is experiencing.

## What the supplied papers contribute

Read the three working manuscripts and the central essays, capstone, ledger, and design notes in both supplied archives as sources of framing and wording. This was an inspiration pass, not a fresh audit of their biological, psychological, financial, or thermodynamic claims.

| Supplied source | Keep for the current paper |
|:--|:--|
| *Moments of Memory*, v0.7, especially §§4, 6, 11 | A retained trace supports a later reconstruction; the later reader may be the same person with a changed history. Keep the trace, its use, and the judgment distinguishable. |
| *The Cost of Surprise*, v1.2, especially §§2, 5–6 | Earlier work can make a later encounter easier to handle. The usable rule and recognition machinery belong in the account alongside the small incoming record. |
| *The Price of Construction*, title/convention note V2 | Carrying a convention through time requires successive uses of it. Apply this to the reader and decoder here; the cancer argument belongs to its own paper. |
| *The Toll, the Rule, and the Iota*; *Two Readings, One Construction* | Distinguish a contingent record from a rule that reconstructs specified structure. Name what must survive for reconstruction to remain possible. Restore the invitation to check something by hand. |
| *When the Description Outgrows the Described*; capstone and FABLE ledger | Prefer a short, checkable description and declare the convention before interpreting its patterns. Alphabet, checksum, exact address, and reader judgment answer different questions. |

The mathematical connection to memory is already covered by Lemma 2. If the observation is \(K(x)\) and a separate retained record is \(M(x)\), the available observation becomes \((K(x),M(x))\). Its fibers can be smaller. Recovery of a target still requires that target to be constant on those joint fibers. If \(M\) is itself only a function of \(K\), it supplies no missing distinction. This is a direct application of the existing lemma, not another lemma for the paper.

This also explains the boundary of the account: a distinction absent from the displayed quantity may remain in another record. The decoder convention must be fixed or disclosed; a convention selected to encode the answer carries information too. A card face, stored order, remembered reveal, and source citation should each be credited for what it actually supplies.

Keep the older voice without importing its broadest assertions. The statement "complete, exact, finite—choose two" is not a general theorem: a declared finite string can be described completely and exactly. A reproducible rule still requires its premises, representation, and a means of execution. Landauer's bound concerns specified logically irreversible operations under physical assumptions; it is not a universal rent on storing a bit or reading a symbol ([Bennett's account](https://arxiv.org/abs/physics/0210005)). The card inventory identity is not an energy-conservation measurement. Likewise, the current fiber result establishes the limits of a stated observation, not a theorem that meaning is universally unmeasurable.

Use the §3 paragraph as a replacement and fit the War passage into the existing §8 close. Preserve the opening's delayed recognition and the final line, "The count can be exact while what counts remains open." The reading map can credit the companion framing if needed; no new biology section or lemma is required.

## Exact counts available to the HTML

The useful display is **what this view leaves unresolved**. Declare the candidate domain: all permutations of the 51 distinct active tokens, with the marker fixed and the component-weight assignment known. This is a count of representations, not of possible zeta zeros or measured human beliefs.

| Information retained by the modeled observer | Compatible initial orders | Base-two logarithm of the count |
|:--|:--|--:|
| Inventory only | \(51!\) | 219.880563 |
| Component weight at every position | \(2!\,1!\,9!\,1!\,9!\,11!\,18!\) | 115.696287 |
| Exact token identity at every position | \(1\) | 0 |

The middle count is exactly **67,305,847,895,575,919,030,981,099,520,000,000**. The seven class sizes are **2, 1, 9, 1, 9, 11, 18**. Each class can be permuted within its assigned positions independently, giving the product of factorials. For this reading pass, the classes were independently recovered from exact integer coefficients of prime logarithms in the 1,438-symbol model and checked against `card_alphabet.json`; factorial arithmetic gives the integer above. Equality of the classes is not inferred from rounded displayed decimals.

If the modeled observer retains the identities at \(r_j\) distinct original positions in class \(j\), and has no other constraints, the compatible count becomes

\[
N_{\rm compatible}=\prod_{j=1}^{7}(m_j-r_j)!.
\]

This makes a small reveal-and-memory demonstration inexpensive: retain an explicit list of observed original positions and recompute the factorial product. Hiding a card can leave that list intact; clearing the modeled memory removes the listed constraint. Neither button erases a real reader's memory or the application's source record. Label the assumption about the observer explicitly. If the only candidates are the published original and swapped decks, start with those two candidates instead of all \(51!\).

Show exact compatible counts first. Their logarithms become conditional Shannon entropies only under a stated uniform distribution on the compatible orders. Tracking beliefs during a War run requires conditioning on that run's observations and rule; these static counts must not be presented as the player's live uncertainty after arbitrary game history.

Beside these counts, the existing HTML can display the decoded integer, the known weight class, the modeled observation ledger, and circulating/escrow/marker totals. A reveal changes available information; a relabeling with its inverse preserves the record; the published swap changes the record inside an unchanged weight profile. These are three different operations and should be logged separately. Physical energy remains unmeasured unless a physical implementation and measurement boundary are supplied.

This display specification is ready for Alpha's implementation pass. No new interface, game rule, deployment, or publication claim was added here.
