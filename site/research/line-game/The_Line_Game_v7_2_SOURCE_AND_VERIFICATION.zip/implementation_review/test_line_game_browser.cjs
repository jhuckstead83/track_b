const assert = require('node:assert/strict');
const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const { chromium } = require('playwright');

const root=path.resolve(process.argv[2]);
const out=path.resolve(process.argv[3]);
fs.mkdirSync(out,{recursive:true});
const mime={'.html':'text/html; charset=utf-8','.json':'application/json; charset=utf-8','.pdf':'application/pdf','.zip':'application/zip','.txt':'text/plain; charset=utf-8','.png':'image/png','.webp':'image/webp'};
const server=http.createServer((req,res)=>{
  const raw=decodeURIComponent(new URL(req.url,'http://local').pathname);let target=path.resolve(root,`.${raw}`);
  if(!target.startsWith(`${root}${path.sep}`)&&target!==root){res.writeHead(403).end('forbidden');return;}
  if(fs.existsSync(target)&&fs.statSync(target).isDirectory())target=path.join(target,'index.html');
  if(!fs.existsSync(target)){res.writeHead(404).end('not found');return;}
  res.writeHead(200,{'content-type':mime[path.extname(target)]||'application/octet-stream'});fs.createReadStream(target).pipe(res);
});
const report={release:'1.13.5-pre-doi',browser:null,checks:[],layouts:[],screenshots:[],limitations:['Desktop Chromium emulation is not physical-device testing.']};
const check=(name,pass,detail)=>{const row={name,pass:Boolean(pass),...(detail===undefined?{}:{detail})};report.checks.push(row);if(!pass)throw new Error(`${name}: ${JSON.stringify(detail)}`);};
(async()=>{
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin=`http://127.0.0.1:${server.address().port}`;
  const browser=await chromium.launch({headless:true,args:['--no-sandbox']});report.browser=await browser.version();
  try{
    for(const width of [320,390,440,600,768,1440]){
      const context=await browser.newContext({viewport:{width,height:900},reducedMotion:'reduce'});const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(String(e)));
      await page.goto(`${origin}/research/line-game/`,{waitUntil:'load'});await page.waitForTimeout(80);
      const metrics=await page.evaluate(()=>({viewport:innerWidth,pageWidth:document.documentElement.scrollWidth,buttons:[...document.querySelectorAll('button')].every(button=>button.tabIndex>=0),title:document.title}));
      report.layouts.push({width,...metrics,errors});check(`layout_${width}`,metrics.pageWidth<=width+1&&errors.length===0&&metrics.buttons,{metrics,errors});
      if([390,600,1440].includes(width)){const file=path.join(out,`line-game-${width}.png`);await page.screenshot({path:file,fullPage:true});report.screenshots.push(file);}
      await context.close();
    }
    const context=await browser.newContext({viewport:{width:390,height:900},reducedMotion:'reduce'});const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(String(e)));await page.goto(`${origin}/research/line-game/`,{waitUntil:'load'});
    await page.locator('#swap-action').click();check('swap_updates_active_record',await page.locator('#record-swapped').evaluate(node=>node.classList.contains('active')));
    await page.locator('#labels-symbols').click();check('symbol_view_is_distinguishable',(await page.locator('#observer-deck .symbol').allInnerTexts()).filter((v,i,a)=>a.indexOf(v)===i).length===51);
    await page.locator('#observer-deck button[data-position="49"]').click();check('class_18_reveal_divides_count',await page.locator('#compatible-count').innerText()==='3739213771976439946165616640000000');
    await page.locator('#include-rank').check();check('including_rank_sets_count_one',await page.locator('#compatible-count').innerText()==='1');
    await page.locator('#game-restart').click();
    await page.locator('.prediction-player[data-player="2"]').click();check('prediction_moves_play_button_to_selected_player',await page.locator('#original-prediction-2 #game-step').count()===1);
    await page.locator('#peek-next summary').click();check('peek_forfeits_and_locks_prediction',await page.locator('#game-step-home #game-step').count()===1&&await page.locator('.prediction-player:disabled').count()===3&&(await page.locator('#prediction-status').innerText()).includes('cannot carry an answer'));
    await page.locator('#game-step').click();check('peeked_round_unlocks_next_clean_pick',await page.locator('.prediction-player:not(:disabled)').count()===3&&!(await page.locator('#peek-next').evaluate(node=>node.open)));
    await page.locator('.prediction-player[data-player="3"]').click();await page.locator('#game-step').click();check('clean_prediction_is_rewarded',(await page.locator('#prediction-score').innerText()).includes('Clean reads 1/1')&&(await page.locator('#prediction-score').innerText()).includes('streak 1'));
    await page.locator('#run-difference').click();await page.waitForFunction(()=>document.querySelector('#original-status')?.textContent.includes('Turn 15'));check('first_count_difference_turn_15',(await page.locator('#original-detail').innerText()).includes('[17,20,14]')&&(await page.locator('#swapped-detail').innerText()).includes('[14,23,14]'));
    await page.locator('#run-certificate').click();await page.waitForFunction(()=>document.querySelector('#swapped-status')?.textContent.includes('1535'),null,{timeout:20000});check('published_certificate_visible',(await page.locator('#certificate-summary').innerText()).includes('1015')&&(await page.locator('#certificate-summary').innerText()).includes('1535'));
    await page.locator('#mode-challenge').click();check('data_challenge_starts_fresh_and_removes_guidance',(await page.locator('#original-status').innerText()).includes('turn 0')&&await page.locator('#challenge-data').isVisible()&&!(await page.locator('#run-certificate').isVisible())&&(await page.locator('#original-hands .front-card').first().innerText())==='?'&&(await page.locator('#prediction-score').innerText()).includes('0/0'));
    await page.locator('.prediction-player[data-player="2"]').click();check('data_challenge_position_moves_button',await page.locator('#original-prediction-2 #game-step').count()===1);await page.locator('#game-step').click();check('data_challenge_clean_read_resolves',(await page.locator('#prediction-score').innerText()).includes('Clean reads 1/1'));
    await page.locator('#mode-guided').click();check('mode_boundary_carries_no_answer_or_progress',(await page.locator('#original-status').innerText()).includes('turn 0')&&(await page.locator('#prediction-score').innerText()).includes('0/0')&&await page.locator('#run-certificate').isVisible());
    check('significant_interactions_have_no_errors',errors.length===0,errors);await context.close();
    const nojs=await browser.newContext({viewport:{width:390,height:900},javaScriptEnabled:false});const staticPage=await nojs.newPage();await staticPage.goto(`${origin}/research/line-game/`,{waitUntil:'load'});check('nojs_content_and_downloads',(await staticPage.locator('body').innerText()).includes('Interactive play uses JavaScript')&&await staticPage.locator('a[href="Exact_Card_String.txt"]').count()===1);await nojs.close();
  }finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
  report.summary={checks:report.checks.length,passed:report.checks.filter(x=>x.pass).length,failed:report.checks.filter(x=>!x.pass).length,layoutCases:report.layouts.length};report.status=report.summary.failed?'FAIL':'PASS';fs.writeFileSync(path.join(out,'browser-report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report.summary,null,2));assert.equal(report.status,'PASS');
})().catch(error=>{try{server.close();}catch{}console.error(error.stack||error);process.exit(1);});
