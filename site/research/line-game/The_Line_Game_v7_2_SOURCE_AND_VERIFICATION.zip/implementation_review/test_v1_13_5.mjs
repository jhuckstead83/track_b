import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';

const [siteArg, baselineArg, sourceArg, outputArg] = process.argv.slice(2);
if (!outputArg) throw new Error('usage: node test_v1_13_5_final.mjs SITE BASELINE SOURCE OUTPUT_JSON');
const site = path.resolve(siteArg);
const baseline = path.resolve(baselineArg);
const source = path.resolve(sourceArg);
const output = path.resolve(outputArg);
const checks = [];
const check = (name, pass, detail) => checks.push({name,pass:Boolean(pass),...(detail===undefined?{}:{detail})});
const read = (root,rel) => fs.readFileSync(path.join(root,rel),'utf8');
const exists = rel => fs.existsSync(path.join(site,rel));
const sha = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const walk = root => fs.readdirSync(root,{withFileTypes:true}).flatMap(entry=>{
  const target=path.join(root,entry.name);
  return entry.isDirectory()?walk(target):[target];
});

const jsonFailures=[];
for(const file of walk(site).filter(file=>file.endsWith('.json'))){
  try{JSON.parse(fs.readFileSync(file,'utf8'));}catch(error){jsonFailures.push({file:path.relative(site,file),error:String(error)});}
}
check('all_json_parses',jsonFailures.length===0,jsonFailures);

const route='research/line-game/index.html';
const html=read(site,route);
check('permanent_route_exists',exists(route));
check('dual_title_and_canonical_metadata',html.includes('<title>The Line Game | Surprise Is Not Meaning — Invariant</title>')&&html.includes('https://cerebralgraphix.com/research/line-game/'));
check('final_doi_is_linked',html.includes('https://doi.org/10.5281/zenodo.22851517')&&html.includes('10.5281/zenodo.22851517')&&!html.includes('DOI is pending'));
check('no_private_chatgpt_site_url',!walk(site).filter(file=>!file.match(/\.(?:pdf|png|webp|ico|zip)$/i)).some(file=>fs.readFileSync(file,'utf8').includes('chatgpt.site')));
const placeholderHits=walk(site).filter(file=>!file.match(/\.(?:pdf|png|webp|ico|zip)$/i)).reduce((sum,file)=>sum+(fs.readFileSync(file,'utf8').match(/__DOI_PENDING__/g)||[]).length,0);
check('no_doi_placeholders',placeholderHits===0,placeholderHits);
check('no_javascript_fallback_is_substantive',html.includes('Interactive play uses JavaScript')&&html.includes('Turn 15 is the first different winner')&&html.includes('67305847895575919030981099520000000'));
check('all_six_public_assets_are_present',[
  'The_Line_Game_Surprise_Is_Not_Meaning_v7_2.pdf','Invariant.html','Invariant_v7_2.html','Playing_Cards_Field_Guide.pdf','Playing_Cards_Printable_Set.pdf','Exact_Card_String.txt','The_Line_Game_v7_2_SOURCE_AND_VERIFICATION.zip'
].every(file=>exists(`research/line-game/${file}`)));

const scripts=id=>html.match(new RegExp(`<script id="${id}"[^>]*>([\\s\\S]*?)<\\/script>`))?.[1];
const context=vm.createContext({});
vm.runInContext(scripts('game-engine'),context);
new vm.Script(scripts('game-ui'));
check('prediction_and_forfeited_peek_are_wired',html.includes('Predict the next winner')&&html.includes('Play next round')&&html.includes('this round cannot carry an answer')&&scripts('game-ui').includes('predictionStats.streak')&&scripts('game-ui').includes('peekLocked=true'));
check('guided_and_data_challenge_modes_are_separate',html.includes('Play &amp; explain')&&html.includes('Prediction from data')&&html.includes('prior picks, progress, and score were not carried in')&&scripts('game-ui').includes("experienceMode==='challenge'")&&scripts('game-ui').includes("$('use-forgiveness')"));
check('distinct_marker_is_html_only',html.includes('Ⅰ')&&!/(?<![A-Za-z0-9_])I(?![A-Za-z0-9_])/.test(html));
const originalHtml=read(site,'research/line-game/Invariant_v7_2.html');
check('original_v7_2_html_is_available',originalHtml.includes('A card table for <em>Surprise Is Not Meaning</em>')&&originalHtml.includes('Ⅰ')&&!/(?<![A-Za-z0-9_])I(?![A-Za-z0-9_])/.test(originalHtml)&&originalHtml.includes('10.5281/zenodo.22851517'));
const originalScript=[...originalHtml.matchAll(/<script(?: [^>]*)?>([\s\S]*?)<\/script>/g)].at(-1)?.[1];new vm.Script(originalScript);
const data=JSON.parse(scripts('experiment-data'));
const E=context.InvariantEngine;
const swapped=data.deck.slice();[swapped[49],swapped[50]]=[swapped[50],swapped[49]];
check('swap_ranks_are_exact',E.rankDeck(data.deck)===14134725141735n&&E.rankDeck(swapped)===14134725141734n);
check('position_weight_profile_is_identical',data.deck.slice(0,51).every((card,index)=>E.TOKENS[card].classId===E.TOKENS[swapped[index]].classId));
const baselineCount=67305847895575919030981099520000000n;
check('counter_baseline_exact',E.compatibleCount('weight',[],data.deck.slice(0,51))===baselineCount&&E.compatibleLog2('weight',[],data.deck.slice(0,51)).toFixed(6)==='115.696287');
check('counter_reveal_boundaries',E.compatibleCount('weight',[49],data.deck.slice(0,51))===baselineCount/18n&&E.compatibleCount('weight',[49,49],data.deck.slice(0,51))===baselineCount/18n&&E.compatibleCount('weight',Array.from({length:35},(_,i)=>i),data.deck.slice(0,51))===20922789888000n);
check('counter_exact_rank_boundary',E.compatibleCount('identity',[],data.deck.slice(0,51))===1n&&E.compatibleCount('weight',[],data.deck.slice(0,51),true)===1n);
const original=new E.CardGame(data.before,{variant:'original',permutation:data.positions});
const changed=new E.CardGame(data.after,{variant:'one-swap',permutation:data.positions});
while(original.status==='playing') original.step();
while(changed.status==='playing') changed.step();
check('published_pair_exact',original.status==='finished'&&original.turn===144&&original.winner===2&&changed.status==='cycle'&&changed.turn===1535&&changed.cycle.entry===1015&&changed.cycle.period===520);
const certificate=changed.certificate();
check('certificate_full_states_equal',JSON.stringify(certificate.cycle.entryState)===JSON.stringify(certificate.cycle.repeatState)&&certificate.accounting.total===52&&certificate.permutation.length===51);

const primaryPages=['index.html','papers/index.html','papers/research-index.html','atlas/index.html','site-index.html',route];
const duplicateIds=[];const broken=[];const badJsonLd=[];
for(const page of primaryPages){
  const body=read(site,page);const ids=[...body.matchAll(/\bid="([^"]+)"/g)].map(match=>match[1]);
  if(new Set(ids).size!==ids.length)duplicateIds.push(page);
  for(const match of body.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)){try{JSON.parse(match[1]);}catch(error){badJsonLd.push({page,error:String(error)});}}
  for(const match of body.matchAll(/\b(?:href|src)="([^"]+)"/g)){
    const ref=match[1];if(/^(?:https?:|mailto:|tel:|data:|javascript:|#)/.test(ref))continue;
    const url=new URL(ref,`https://local/${page}`);let target=path.join(site,decodeURIComponent(url.pathname).replace(/^\//,''));
    if(fs.existsSync(target)&&fs.statSync(target).isDirectory())target=path.join(target,'index.html');
    if(!fs.existsSync(target)&&!path.extname(target))target+='.html';
    if(!fs.existsSync(target))broken.push({page,ref});
  }
}
check('primary_pages_have_unique_ids',duplicateIds.length===0,duplicateIds);
check('primary_page_json_ld_parses',badJsonLd.length===0,badJsonLd);
check('primary_local_links_resolve',broken.length===0,broken);

const catalogue=JSON.parse(read(site,'papers/active-research.json'));
const line=catalogue.records.find(item=>item.record_id==='22851517');
check('catalogue_count_policy_preserved',catalogue.count===61&&catalogue.records.length===61&&new Set(catalogue.records.map(item=>item.record_id)).size===61);
check('catalogue_line_game_has_durable_local_route',line?.landing_url==='/research/line-game/'&&!/active development/i.test(line.summary||''));
const feed=read(site,'papers/feed.xml');
check('feed_keeps_61_records_plus_local_postmaster',((feed.match(/<item>/g)||[]).length===62)&&feed.includes('https://cerebralgraphix.com/research/line-game/')&&feed.includes('https://zenodo.org/records/22851517'));
const atlas=JSON.parse(read(site,'atlas/atlas-data.json'));const lineNode=atlas.nodes.find(node=>node.id==='line-game');
check('atlas_line_game_has_three_typed_connections',lineNode?.url==='/research/line-game/'&&lineNode.connections?.length===3&&lineNode.connections.every(item=>item.label&&item.type&&item.why&&item.source));
check('postmaster_remains_primary_feature',read(site,'index.html').indexOf('Triangular-n Postmaster')<read(site,'index.html').indexOf('The Line Game')&&read(site,'papers/index.html').indexOf('Triangular-n Postmaster')<read(site,'papers/index.html').indexOf('The Line Game'));
check('site_index_sitemap_and_headers_include_release',read(site,'site-index.json').includes('/research/line-game/Invariant_v7_2.html')&&read(site,'site-index.html').includes('/research/line-game/Invariant_v7_2.html')&&read(site,'sitemap.xml').includes('/research/line-game/Invariant_v7_2.html')&&read(site,'_headers').includes('/research/line-game/'));
check('final_release_metadata_has_doi',JSON.parse(read(site,'release-v1.13.5.json')).research.assigned_doi==='10.5281/zenodo.22851517'&&JSON.parse(read(site,'release-v1.13.5.json')).status==='final_release');
check('site_version_is_1_13_5',primaryPages.filter(page=>page!==route).every(page=>read(site,page).includes('Website v1.13.5'))&&JSON.parse(read(site,'release-v1.13.5.json')).release==='1.13.5');

const protectedPrefixes=['finance/','functions/'];
const protectedNames=['assets/phi_finance_grid_v2.js','assets/phi_finance_grid_v2.css','assets/finance-refinement-v1-13-2.css','_redirects','_routes.json'];
const collect=root=>walk(root).map(file=>path.relative(root,file).replaceAll(path.sep,'/')).filter(rel=>protectedPrefixes.some(prefix=>rel.startsWith(prefix))||protectedNames.includes(rel)).sort();
const beforeNames=collect(baseline),afterNames=collect(site);const changedProtected=[];
for(const name of beforeNames)if(!afterNames.includes(name)||sha(path.join(baseline,name))!==sha(path.join(site,name)))changedProtected.push(name);
check('finance_functions_routes_and_data_byte_identical',JSON.stringify(beforeNames)===JSON.stringify(afterNames)&&changedProtected.length===0,changedProtected);
check('source_engine_receipt_passes_256',JSON.parse(read(source,'game_source/GAME_VERIFICATION.json')).status==='PASS'&&JSON.parse(read(source,'game_source/GAME_VERIFICATION.json')).python_javascript_games_compared===256);
check('paper_receipt_passes_36',JSON.parse(read(source,'paper_source/V7_2_VERIFICATION.json')).status==='PASS'&&JSON.parse(read(source,'paper_source/V7_2_VERIFICATION.json')).passed===36);

const report={release:'1.13.5-final',status:checks.every(item=>item.pass)?'PASS':'FAIL',checks,summary:{checks:checks.length,passed:checks.filter(item=>item.pass).length,failed:checks.filter(item=>!item.pass).length},limitations:['Browser/device review is recorded separately.','Finance overnight live-provider validation is outside this build.','Deployment and public smoke testing are outside this artifact build.']};
fs.mkdirSync(path.dirname(output),{recursive:true});fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report.summary,null,2));
for(const item of checks.filter(item=>!item.pass))console.error('FAIL',item);
assert.equal(report.status,'PASS','v1.13.5 static checks failed');
