# Alpha website delta — closed revision and implementation review

**The Line Game | Surprise Is Not Meaning · paper v7.2 · Cerebral Graphix v1.13.5**  
**Interactive supplement: Invariant**  
Prepared 19 September 2026 for Jeffery Lyn Huckstead / Cerebral Graphix.

## 1. Build brief and controlling scope

Build the public experience around one checkable act: change an arrangement while preserving its entire component-weight profile, recover a different record, and compare the two finite continuations. Let readers encounter the result before expanding the explanation.

The recent memory and cost discussion adds a useful second act: show what a selected observation retains, what remains unresolved, and what a retained record can restore. This is an account of supplied information. It does not require a new game rule, a theory of human memory, or a physical energy estimate.

This document consolidates the originating conversation's website recommendations and resolves conflicts in earlier suggestions. Alpha owns the complete build and its return for implementation review. The frozen v7.2 engine, encodings, source data, and mathematical results remain controlling. The paper-only note supplies proposed prose changes; this document controls the website brief.

**Review basis:** the supplied Alpha plan, the existing portable prototype, saved game fixtures and audits, the exact weighted-order check, and the subsequent memory/cost reading. The full v1.13.4 website and Alpha's newly merged implementation were not available to this review. Full-site compatibility and Finance preservation must be checked against Alpha's actual baseline.

The closed build includes the paired swap demonstration, provenance, nonnumeric relabeling, an exact initial-arrangement observation counter, the frozen game with its explicit I intervention, useful downloads, and public-site integration. Keep alternative transitions, divisibility experiments, extended War tie battles, and an experimental-lab menu outside this revision. Existing research records can remain in the verification sources.

## 2. First screen and reader route

Use the exact publication identity in the page title and publication metadata. The visible heading may wrap at the separator:

> **The Line Game | Surprise Is Not Meaning**  
> Invariant — the interactive supplement
>
> Move two cards. Keep the exact weight profile. Read a different number.
>
> Then deal both arrangements under the same rule. Choose when to see the result.

Primary action: **Swap the two cards**. Secondary action: **Build it from the beginning**. Keep **Read the paper** available without competing with the primary action.

Use one short route through the page:

1. **Try the swap:** highlight active positions 50 and 51, show the two records, and show the unchanged profile.
2. **See what the view retains:** reveal the seven contribution classes and the compatible-order counter.
3. **Change the alphabet:** transport the same abstract tokens into distinguishable nonnumeric marks.
4. **Compare the continuations:** run the matched deal, step or fast-forward, inspect the certificate, and optionally apply forgiveness.
5. **Read or verify:** paper, tabletop guide, printable cards, exact string, source, and Zenodo record.

Do not autoplay to the result. Keep the final outcomes in the result/verification view until requested. A reader who wants the sequence to unfold should be able to step through it; another reader should be able to jump to the exact certificate. On small screens, use a shared comparison strip with a switch between the original and swapped games.

The optional explanatory sentence that carries the recent discussion is:

> The message calls on a convention the reader already carries. A later reader may be the person who made the record.

Place it after the reader has decoded something. Keep the opening concrete.

## 3. Copy and provenance contract

Keep a small **Where each fact enters** display. These are distinct sources of information, not a causal claim that the weights generated the number.

| Layer | Public explanation |
|:--|:--|
| Source | Supplies a stored numerical approximation to a zero ordinate. |
| Model | Supplies the component contributions and their exact equal-weight classes. |
| Encoding | Uses the supplied integer and a shared reference order to select an arrangement. |
| Rule | Determines the card continuation from the complete state. |
| Reader | Recognizes what the recovered record refers to and why the result matters. |

Keep these exact labels and distinctions:

- **Original record:** `14.134725141735`, decoded from integer `14134725141735` at scale `1000000000000`.
- **One-swap record:** `14.134725141734`, a synthetic one-unit edit. Do not label it another verified zero.
- **Unchanged:** inventory, frequencies, encoding convention, and component weight at every position.
- **Changed:** token order, decoded integer, and the continuation in the published matched experiment.
- **Model contribution:** expected conditional information contribution in bits under the declared uniform model on 1,438 complete Unicode symbols. It is not a card probability, win probability, or folded-zero mass.
- **Token identity:** the underlying token and its displayed card face or component mark. Replace the earlier proposed label “Source identity.”
- **Game strength:** the fixed rank/suit key. Only this comparison key decides contests.

The seven exact class sizes are **2, 1, 9, 1, 9, 11, 18**. The last class consists of `T10` through `T27`, occupying reference faces `9D` through `KC`. Each has contribution `51 log2(28) / 1438`. Their equality follows from exact context counts.

The original integer satisfies `15! <= R < 16!`. Thus its first 35 active cards agree with the reference order; the remaining 16 move entirely inside the 18-card tie. The reference, original, and swapped decks have identical complete weight profiles. Explain the nearly regular suit/rank order through this encoding, rather than presenting it as an unexplained pattern in zero data.

The 1,438-symbol representation inventory, the 1,438-record entropy prefix, and the larger 1,566-record transport file have different roles. One pack carries the example record; the complete latest transport uses **301 ordered arrangements** of the reusable pack. The 51 tokens are not 51 individual zeros.

Suggested RH connection:

> The cards carry a recorded zero height through a shared convention. The experiment shows how the same measured profile can leave different records and futures unresolved. Its continuation certificate comes from the complete card state and a specified rule. A result about uncomputed zeros would need a proved relation for those zeros. RH remains open.

## 4. Exact display: “Orders matching this view”

This is the new display recommended for this revision. Keep it in an expandable inspector attached to the initial arrangement, not on every game turn.

Default label: **Orders matching this view**. Supporting text:

> This count uses only the information selected here. The application retains the full arrangement.

Declare the default candidate set: all `51!` permutations of the 51 distinct active tokens, with I fixed outside the ranking and the token-to-weight assignment known.

| Selected information | Exact compatible count | Displayed log2 count |
|:--|:--|--:|
| Inventory only | `51!` | 219.880563 |
| Component weight at every position | `2! × 1! × 9! × 1! × 9! × 11! × 18!` | 115.696287 |
| Exact identity at every position | `1` | 0 |
| Exact decoded integer and the reference key | `1` | 0 |

The middle count is exactly:

```text
67305847895575919030981099520000000
```

**The decoded integer is information too.** Given the factorial key, it uniquely determines the arrangement. If that information is included in the modeled observation, the count is one even while the card faces are hidden. If the inspector excludes the integer, say so. Do not display a large count as the reader's total uncertainty while silently ignoring the record already shown beside it.

The counts are exact sizes of sets. Their logarithms become conditional Shannon entropies only under an explicitly uniform model on the compatible candidates. Keep the default wording as counts and log2 counts. Do not call the display felt surprise, memory strength, energy, or a probability of RH.

### Remembered reveals

In the weight-profile view, let `r[j]` be the number of distinct original positions whose token identities are retained in class `j`, of size `m[j]`. With no other constraints:

```text
compatible = product(factorial(m[j] - r[j]))
```

In inventory-only view, retaining `r` distinct original positions leaves `(51-r)!` orders. Exact rank plus key overrides either count to one. Conflicting observations are an invalid record, not something to clamp or silently repair.

Use these controls:

- **Reveal this position:** records its stable token ID and original position.
- **Hide the faces:** changes visibility while retaining recorded reveals.
- **Clear recorded reveals:** removes constraints from this modeled observation ledger.
- **Include the decoded integer and key:** makes that additional information explicit.

Make the scope visible: these are **recorded reveals in this demonstration**, not a measurement or erasure of the visitor's actual memory. When the same position is revealed twice, count it once. Keep separate observation ledgers for distinct initial arrangements; switching or swapping must not carry contradictory evidence into another deck.

Do not apply the factorial formula to arbitrary War histories. Current queue positions, captures, and past contests impose different constraints. The inspector concerns original positions in a static arrangement. The game's move ledger separately records its evolving state.

If a panel restricts its candidates to the published original and swapped decks, it has **two** candidates, not `51!`. Its full weight profile still leaves two. Revealing an unchanged position leaves two; revealing position 50 or 51 leaves one. Label this candidate set separately from the all-orders inspector.

### Arithmetic and data representation

Use exact `BigInt` arithmetic for factorials, general permutation ranks, and compatible counts. Store them in JSON as decimal strings. Use separate floating-point sums of logarithms only for the approximate log2 display. JavaScript `Number` cannot preserve these large integers exactly; `BigInt` also needs explicit JSON serialization. [MDN: BigInt](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/BigInt)

Use declared class IDs backed by the exact model, not grouping by rounded displayed weights. The class membership is:

| Class | Token roles | Size |
|:--|:--|--:|
| 1 | L0–L1 | 2 |
| 2 | L2 | 1 |
| 3 | V0–V8 | 9 |
| 4 | V9 | 1 |
| 5 | T1–T9 | 9 |
| 6 | V10–V20 | 11 |
| 7 | T10–T27 | 18 |

These classes were independently recovered from exact integer coefficients of prime logarithms and checked against the existing card alphabet in the preceding review. The product-of-factorials count is a new derived display result; it is not an addition to the old 4,585-check total.

## 5. Relabeling and concealment

Give the reader **Cards / Symbols** views. The faces need not carry numerals. Preserve stable internal IDs, the reference order, decoder, strength key, marker role, current game state, and observation history when the labels change.

All 51 visible symbols must remain distinguishable. Where supplied component glyphs look alike, add a distinguishable category mark and an accessible name. Include a compact reversible legend. Check the actual browser fonts for missing or indistinguishable glyphs. A correct internal mapping alone does not make a usable demonstration.

In the game view, an optional face-down presentation may conceal queued cards until revealed. **Reveal the stacks** must expose the existing order without reversing, shuffling, redealing, or advancing it. Do not silently reset a run on a display toggle. Retain the same concealment semantics for assistive-technology users.

Jeffery's generic-War observation concerns the experience: continued rank ties can delay resolution and increase the stakes. Preserve that idea in the later explanation. The published variant resolves equal ranks immediately by suit, so it has no extended tie battle. An exact contribution tie, an ordinary-War rank tie, and a repeated full state are different things.

## 6. Paired game, milestones, and I

Use the published pair as the principal game. Apply the same recorded position permutation to the original and swapped initial orders. Load the existing fixture; do not assume that entering seed 3 into another random generator reproduces it.

The published rule stays fixed: 2C is I; 51 active cards form three ordered hands of 17; A=1, J=11, Q=12, K=13; suits are S < H < D < C. Each live hand reveals its front card. Maximum strength wins. Append the winner's card first, followed by the other revealed cards in clockwise player order. I does not contest.

Controls: **Play one turn**, **Run to first count difference**, **Run to certificate**, **Pause**, and **Restart this deal**. Show initial deal, first count difference, eliminations, and terminal/cycle events as milestones. Run in bounded batches so pause and the page remain responsive.

| Published-pair fact | Correct display |
|:--|:--|
| Initial states | Already different |
| Turn 1 | P2 reveals 10D in the original and KS in the swap; both winners are P2 |
| Turn 15 | First different winner and count vector: original `[17,20,14]`, swap `[14,23,14]` |
| Original | P1 is eliminated at 86; P2 survives at 144 |
| Swap | P3 is eliminated at 83; full states at 1015 and 1535 agree; period 520 |

Keep separate turn counters for both games. Once the original finishes, leave it marked **Finished at 144** while the swapped game advances. A computational cap means **Paused — unresolved at this limit**, never a cycle certificate.

If retaining a prediction prompt, use **Will this order finish or repeat?** for ordinary play. Explain, when requested:

> Under ordinary play, if this deal finishes, its survivor must be the initial holder of KC.

KC cannot be captured under the ordinary comparator. This guarantee ends when forgiveness is enabled, because KC itself may enter escrow. Do not make a player-winner prediction the main challenge. Sample frequencies are results of supplied starts, not probabilities for all shuffles.

At an exact recurrence, use:

- **Continue unchanged — replay the certified cycle**
- **Use forgiveness — move one card per live hand to escrow**

The second action explicitly changes the continuation policy. At each repeat, remove the top card from every live hand permanently from circulation, then reset the phase recurrence ledger. Show:

```text
circulating + escrow = 51
circulating + escrow + marker = 52
```

Automatic forgiveness has at most 25 interventions and eventually ends with a survivor or an empty-table draw. The circulating count decreases at interventions, not on ordinary turns. Preserve escrow in the final accounting; do not silently return it to circulation. “Continue unchanged” means continued motion through the cycle, not frozen hands.

Move the prototype's square-sum and numerical-height annotations into an advanced explanatory disclosure. State their definitions and provenance there. They are not game-strength inputs, termination certificates, or physical energy measurements. Keep the ace-versus-two comparison in the research record; the published demonstration uses the fixed 2C marker.

Exploration remains a secondary action after the published pair. Export its exact shuffle permutation and initial hands, as well as the seed, generator, algorithm, and version when applicable. A new shuffle is one exploration, not a new statistical study.

## 7. Certificates and local ledgers

At recurrence, provide **Compare repeated states** and **Download certificate**. Show all three labeled ordered queues at entry and repeat, with entry turn, repeat turn, period, and the rule/policy that was in force.

The certificate must permit an independent replay from the initial state. Include:

- certificate schema version, engine/rule version, source arrangement and encoding version;
- marker, comparison and return-order convention, and intervention policy;
- exact shuffle permutation and initial ordered hands;
- entry/repeat turn indices and both full ordered states;
- intervention history and phase identity if applicable;
- outcome and final circulating/escrow accounting.

A seed or a pair of equal hashes alone is insufficient. Verification must reproduce the claimed states and indices. Use direct state equality for cycle detection, or confirm any hash match by comparing the complete state.

Keep a compact human-readable event ledger alongside downloadable JSON. Distinguish **reveal/hide**, **relabel**, **swap**, **game turn**, and **forgiveness**. They respectively change access, labels, source arrangement, dynamic state, and continuation policy. The observation ledger is local demonstration data; no new server or analytics service is needed for these displays.

Existing aggregate engagement collection, if retained by Alpha, records actions rather than understanding. It is not a prerequisite for this revision. Do not turn reader agreement, a prediction, or a download into evidence for the paper's interpretation.

## 8. Site integration, metadata, and downloads

Create the permanent route **`/research/line-game/`** using the site's existing canonical origin and visual language. Keep Postmaster v5.1 as the principal featured reading work.

Suggested homepage release line:

> The Line Game v7.2 — move two cards, recover another record, and compare the continuations.

Add one compact Papers entry with **Play / Read / Verify** actions. The verification view exposes the source download and Zenodo record. Update the catalogue, feed, Atlas, structured data, site index, sitemap, and relevant headers from the same publication metadata. Preserve earlier editions and their working links.

Atlas connections should name their relation:

- *A Message Hidden as an Address*: exact recovery through a shared convention;
- *TN Postmaster*: folded coordinates and the boundary of a retained weight;
- an already-public finite-observer or memory work, if present in the catalogue: a retained record and the observation available later.

Do not create public entries for the newly supplied working manuscripts solely because they informed this review. A working source is not automatically another launch publication.

Use durable public descriptions in place of “back in active development” or workshop-status copy. Preserve every Finance file byte-for-byte against the actual baseline. The separately planned overnight Finance validation is outside this build review.

The route and portable `Invariant.html` need:

- exact dual title, author, version, citation, final DOI and relevant paper links;
- canonical URL, description, Open Graph/social metadata, and structured publication/application relationships;
- a Cerebral Graphix return link;
- paper, field guide, printable card set, exact card string, source-and-verification archive, and Zenodo links;
- a useful static explanation and downloads when scripts are disabled.

Use the existing public design assets for social preview; no new illustration is necessary. Suggested description:

> Swap two cards without changing their complete weight profile, decode a different record, and compare exact continuations in a finite card game.

Keep one internal DOI placeholder until the assigned identifier is available. Omit unresolved DOI links from previews; the release gate must reject unresolved placeholders. Sweep public staging files, generated PDF links, and source instructions for the owner-only `chatgpt.site` URL. The private prototype is not the canonical publication route.

Use one shared data source for both hosted and portable builds. Verify relative downloads after packaging and core interaction from local `file://` use; do not depend on a fetch that only works on the hosted route. Catalogue totals must follow a recorded counting policy for works or editions. The existence of a new DOI does not define that policy.

## 9. Mobile, accessibility, and no-JavaScript behavior

Stack the three hands when their game pane is narrower than roughly 700 px. In paired desktop layout, each pane may be narrow even when the viewport is wide; do not rely only on a viewport media query. At phone widths, preserve both statuses while showing one selectable game pane at a time.

Check 320, 390, 440, 600, 768, and 1440 CSS-pixel widths. The former 441–600 px failure band must be explicitly exercised. Ensure readable ordered queues, usable controls, and no page-wide horizontal overflow. Provide scrolling or a dedicated inspection view for intrinsically long exact strings. Test text enlargement and reflow. [W3C: Reflow](https://www.w3.org/WAI/WCAG22/Understanding/reflow.html)

Use native keyboard-operable controls, visible focus, text labels alongside color, accessible token identities, and readable comparison tables. Honor reduced-motion preferences. Announce significant outcomes and errors without moving focus; do not announce every fast-forward turn. [W3C: Status messages](https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html)

Without JavaScript, retain the exact card string, the two decoded values, the unchanged/changed comparison, a short rule description, the result summary, and working publication downloads. Suggested notice:

> Interactive play uses JavaScript. The exact arrangement, worked comparison, and downloadable paper and guides remain available below.

## 10. Required review checks

These are acceptance criteria for the implemented return, not claims that a new build has passed.

| Area | Required result |
|:--|:--|
| Swap | Original rank is `14134725141735`; swapping active positions 50/51 gives `14134725141734`; every position's contribution is unchanged. |
| Relabel | Decode, game state, strength ordering, observation ledger, and certificate remain the same under the matching inverse. |
| Counter, baseline | The seven classes yield exactly `67305847895575919030981099520000000`. |
| Counter, reveals | A first reveal in the 18-card class divides that count by 18. Repeating the same reveal does not divide it again. Revealing the first 35 original positions leaves `16! = 20922789888000`. |
| Counter, boundaries | Full order or exact rank plus key gives one. Hiding recorded faces leaves the count unchanged. Clearing records changes only the modeled ledger. Invalid or cross-deck evidence is rejected/reset visibly. |
| Counter, two candidates | Both profiles agree; an unchanged-position reveal leaves two candidates, while a position-50/51 reveal leaves one. |
| Published pair | Turn-1 cards, turn-15 counts, finish at 144, and recurrence 1015→1535 agree with saved fixtures. |
| Certificate | A separate verifier replays from the exported initial state to both claimed identical full states. Export/import preserves large integers exactly. |
| I | Ordinary conservation, phase reset, circulation decrease, and end accounting match the frozen implementation. Verify the KC guarantee is removed under forgiveness. |
| KC counterexample | Saved seed-2 swapped forgiveness fixture: initial KC holder P2, eventual survivor P1, turn 15011, 13 interventions. |
| Engine parity | Re-run the existing 256 JavaScript/Python outcomes against the actual release engine. Keep legacy and new-check totals separately identified. |
| Browser | Record actual browser/device versions and screenshots at the requested widths; inspect keyboard use, pause, symbols, reduced motion, and no-JavaScript content. |
| Public artifacts | Hosted and portable interaction, downloads, citations, canonical metadata, and final DOI agree; private links and placeholders are absent. |
| Whole site | Run the final site's static/link checks and compare the full Finance path set and bytes with the baseline. |
| Paper/build | Integrate accepted paper deltas, rebuild deterministically, require both current PDF and current build log, and pass all 36 retained paper checks. Missing artifacts must fail or be reported incomplete. |

The historical baseline reported 4,585 card checks and 256 parity outcomes; Alpha reported 38/38 checks for the prior website. These are starting evidence, not passes for v1.13.5. No actual browser/device review of the new implementation has occurred in this conversation.

Preserve the nine-page paper aim and thirteen-page maximum. Use the correct PyMuPDF/`fitz` dependency and the retained pinned requirements proposal; remove obsolete `pypdf` instructions where the retained code does not use it. Use a fixed `SOURCE_DATE_EPOCH` and verify deterministic output on the final toolchain. Freeze hashes after the final build and review.

## 11. Return package and close condition

Alpha's final deliverables remain:

1. `The_Line_Game_v7_2_ZENODO_FILES.zip`
2. `CerebralGraphix_v1_13_5_FULL_SITE.zip`
3. `RELEASE_CARD.md`

Keep the six public Zenodo files: dual-titled paper PDF, portable `Invariant.html`, field-guide PDF, printable-card PDF, exact-card-string text, and one source-and-verification ZIP. The source ZIP must include the inputs, exact class definitions, counter implementation/checks, frozen rule, replay fixtures, and verifier needed for the public claims. Omit redundant publication copies and archival `prior_work/` material from that public source archive.

For the implementation review, the release card should identify the baseline and candidate versions, assigned or still-pending DOI, implemented sections of this delta, changed paths, exact test commands/results, browser evidence, Finance comparison, outstanding blockers, and hashes of the actual return files. Mark an unperformed gate **NOT RUN**, not PASS. Keep this review material inside the concise coordinated return rather than creating another public download collection.

The release sequence remains: insert assigned DOI and final routes → rebuild and complete browser review → freeze final bytes/hashes → verify the Zenodo draft → publish the record → deploy the matching website → smoke-test both public fronts. A pre-DOI build can be returned for implementation review; its hashes are not the final release freeze.

The revision is ready to close when the reader can perform the swap, see exactly what was preserved, recover the record in either alphabet, inspect what a selected view leaves unresolved, and replay a valid finite continuation certificate. Those acts carry the paper's argument without adding a new claim about the zero tail or the reader's private experience.
