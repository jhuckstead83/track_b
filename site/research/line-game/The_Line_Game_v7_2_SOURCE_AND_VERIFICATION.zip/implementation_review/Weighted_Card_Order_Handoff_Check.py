"""Check the handoff's new weighted-order observation using standard Python.

Usage: python Weighted_Card_Order_Handoff_Check.py PATH_TO_EXTRACTED/card_lab
The JSON receipt is written beside this script. No source files are changed.
"""
from collections import Counter
from pathlib import Path
import argparse
import json
import math

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('card_lab', type=Path)
args = parser.parse_args()
lab = args.card_lab
rows = json.loads((lab / 'card_alphabet.json').read_text())['cards']
demo = json.loads((lab / 'HANDHELD_DEMO.json').read_text())
lookup = {row['card']: row for row in rows}
reference = [row['card'] for row in sorted(rows, key=lambda row: row['q'])]
before, after = [demo['cards_' + mode][:-1] for mode in ('before', 'after')]
assert demo['cards_before'][-1] == demo['cards_after'][-1] == '2C'
assert len(reference) == 51 and set(reference) == set(before) == set(after)

weight = lambda face: lookup[face]['importance_bits_per_complete_symbol']
profiles = [[weight(card) for card in order] for order in (reference, before, after)]
assert profiles[0] == profiles[1] == profiles[2]
assert all(a >= b for a, b in zip(profiles[1], profiles[1][1:]))
assert before[:35] == reference[:35] and before[35] != reference[35]

# Count exact terminal contexts for the specified consecutive Hangul inventory.
# Each syllable digit has address (leading, vowel, terminal), with terminal=0 END.
coordinates = [(d // 588, (d % 588) // 28, d % 28) for d in range(1438)]
parent_counts = Counter((L, V) for L, V, T in coordinates)
signatures = {
    str(t): dict(Counter(parent_counts[L, V] for L, V, T in coordinates if T == t))
    for t in range(10, 28)
}
assert all(signature == {28: 51} for signature in signatures.values())
assert [lookup[c]['role'] for c in reference[33:]] == [f'T{t}' for t in range(10, 28)]
assert set(before[35:]) <= set(reference[33:])
w = 51 * math.log2(28) / 1438
assert all(abs(weight(c) - w) < 1e-14 for c in reference[33:])

# Independently decode both arrangements relative to the declared face order.
def rank(order):
    remaining = reference.copy()
    value = 0
    for face in order:
        index = remaining.index(face)
        value += index * math.factorial(len(remaining) - 1)
        remaining.pop(index)
    return value

R = rank(before)
assert R == 14134725141735 == demo['rank_before']
assert rank(after) == R - 1
assert math.factorial(15) <= R < math.factorial(16)

receipt = {
    'status': 'PASS',
    'scope': 'Release verification for the exact weighted-order observation integrated into paper v7.2 and site v1.13.5.',
    'order': '51 active cards; fixed null I is outside this ranking.',
    'weight_definition': 'Expected conditional information contribution per uniform complete symbol in the 1438-symbol Unicode inventory; not zeta-state mass.',
    'tie_provenance': 'The chosen alphabet and uniform conditional model create the ties before card assignment. The numerical zero heights do not determine these weights.',
    'whole_position_weight_profiles_equal_reference_before_after': True,
    'nonincreasing_weight_order': True,
    'unchanged_reference_prefix_length': 35,
    'permuted_suffix_size': 16,
    'lowest_tied_class_size': 18,
    'lowest_tied_class_roles': 'T10 through T27',
    'exact_contribution_formula': '51 * log2(28) / 1438',
    'contribution_bits': w,
    'exact_terminal_context_signatures': signatures,
    'rank': R,
    'rank_after_swap': rank(after),
    'factorial_15': math.factorial(15),
    'factorial_16': math.factorial(16),
    'consequence': 'Same full position-by-position weight profile; different decoded integers. Different published game outcomes are in the existing War results.',
    'qualification': 'Equality of tied contributions follows from identical exact context counts. Decimal evaluation is only the displayed approximation.'
}
out = Path(__file__).with_suffix('.json')
out.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'status': receipt['status'], 'receipt': str(out.resolve()),
                  'weight_profiles_equal': True, 'ranks_differ_by_one': True}, indent=2))
