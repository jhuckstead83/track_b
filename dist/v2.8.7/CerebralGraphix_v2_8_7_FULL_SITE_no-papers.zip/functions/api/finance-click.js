/*
  Cloudflare Pages Function: /api/finance-click

  Path:
    functions/api/finance-click.js

  Optional storage:
    Create a KV namespace and bind it to this Pages project as PHI_CLICK_LOGS.
    Without KV, this endpoint still returns ok and writes to console logs,
    but it does not persist events.

  Boundary:
    market_truth: NOT_PROVEN_BY_RECEIPT
    trade_permission: NO
*/

export async function onRequest(context) {
  const { request, env } = context;

  if (request.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders() });
  }

  if (request.method !== "POST") {
    return json({ ok: false, error: "POST only" }, 405);
  }

  let payload;
  try {
    payload = await request.json();
  } catch (err) {
    return json({ ok: false, error: "Invalid JSON" }, 400);
  }

  const now = new Date();
  const safeEvent = {
    event: String(payload.event || "unknown").slice(0, 80),
    lens: String(payload.lens || "unknown").slice(0, 40),
    page: String(payload.page || "").slice(0, 200),
    href: String(payload.href || "").slice(0, 500),
    client_time_iso: String(payload.client_time_iso || ""),
    client_time_et: String(payload.client_time_et || ""),
    server_time_iso: now.toISOString(),
    market_truth: "NOT_PROVEN_BY_RECEIPT",
    trade_permission: "NO"
  };

  const key = "click/" + now.toISOString().replace(/[:.]/g, "-") + "/" + crypto.randomUUID();

  let persisted = false;
  if (env.PHI_CLICK_LOGS && typeof env.PHI_CLICK_LOGS.put === "function") {
    await env.PHI_CLICK_LOGS.put(key, JSON.stringify(safeEvent), {
      metadata: {
        event: safeEvent.event,
        lens: safeEvent.lens,
        page: safeEvent.page
      }
    });
    persisted = true;
  } else {
    console.log("PHI_CLICK_EVENT", key, JSON.stringify(safeEvent));
  }

  return json({ ok: true, persisted, key });
}

function corsHeaders() {
  return {
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "POST, OPTIONS",
    "access-control-allow-headers": "content-type",
    "cache-control": "no-store"
  };
}

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: {
      ...corsHeaders(),
      "content-type": "application/json;charset=utf-8"
    }
  });
}
