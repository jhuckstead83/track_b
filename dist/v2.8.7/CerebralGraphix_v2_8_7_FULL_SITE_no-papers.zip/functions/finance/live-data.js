/*
  Cloudflare Pages Function: /finance/live-data

  Purpose:
    Same-origin browser bridge for the public finance chamber grid.
    The browser calls cerebralgraphix.com/finance/live-data.
    This function fetches the R2 live rail server-side, so browser CORS
    is no longer part of the public-grid data path.

  Membrane:
    - Prefer the future chamber_grid_public.json only if it is free of
      forbidden named-asset keys.
    - Otherwise fetch sector_plot_data.json and sanitize every row through
      an explicit aggregate-field allowlist before returning it.
    - Named constituent fields never pass through this bridge.

  Boundary:
    market_truth: NOT_PROVEN_BY_RECEIPT
    trade_permission: NO
*/

const LIVE_ORIGIN = "https://live.cerebralgraphix.com";
const UPSTREAM_BASE = `${LIVE_ORIGIN}/finance/latest`;

const FORBIDDEN_PUBLIC_KEYS = new Set([
  "ticker",
  "symbol",
  "returned_symbol",
  "leader",
  "leader_symbol",
  "laggard",
  "laggard_symbol",
  "abs2_symbol",
  "look_here_top_symbol",
  "look_here_symbols",
  "constituents",
  "quote",
  "bid",
  "ask",
  "last_price",
  "account",
  "order",
  "position"
]);

const SAFE_SECTOR_FIELDS = Object.freeze([
  "snapshot_utc",
  "snapshot_et",
  "market_date_et",
  "plot_time_label",
  "sector_code",
  "sector_label",
  "avg_bps",
  "median_bps",
  "weighted_avg_bps",
  "net_breadth",
  "fresh_ratio",
  "rolling_5read_median_bps",
  "rolling_5read_weighted_avg_bps",
  "rolling_5read_net_breadth"
]);

export async function onRequestGet() {
  // Stage 4 future path: prefer the native chamber-only payload once it exists.
  const future = await fetchUpstreamJson("chamber_grid_public.json");
  if (
    future.ok &&
    isFuturePublicPayload(future.data) &&
    !containsForbiddenKey(future.data)
  ) {
    return jsonResponse(future.data, 200, "chamber_grid_public.json");
  }

  // Current path: sanitize the known safe aggregate plot data.
  const current = await fetchUpstreamJson("sector_plot_data.json");
  if (!current.ok || !Array.isArray(current.data)) {
    return jsonResponse(
      {
        ok: false,
        error: "LIVE_AGGREGATE_UNAVAILABLE",
        market_truth: "NOT_PROVEN_BY_RECEIPT",
        trade_permission: "NO"
      },
      502,
      "unavailable"
    );
  }

  const sanitized = current.data
    .map(sanitizeSectorRow)
    .filter(row => row.sector_code && row.snapshot_utc);

  if (!sanitized.length) {
    return jsonResponse(
      {
        ok: false,
        error: "LIVE_AGGREGATE_EMPTY_AFTER_SANITIZE",
        market_truth: "NOT_PROVEN_BY_RECEIPT",
        trade_permission: "NO"
      },
      502,
      "empty"
    );
  }

  return jsonResponse(sanitized, 200, "sector_plot_data.json");
}

async function fetchUpstreamJson(filename) {
  const url = `${UPSTREAM_BASE}/${filename}`;
  try {
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "accept": "application/json"
      },
      redirect: "follow"
    });

    if (!response.ok) {
      return { ok: false, status: response.status, data: null };
    }

    const text = await response.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch (_err) {
      return { ok: false, status: 502, data: null };
    }

    return { ok: true, status: response.status, data };
  } catch (_err) {
    return { ok: false, status: 502, data: null };
  }
}

function sanitizeSectorRow(row) {
  const clean = {};
  for (const key of SAFE_SECTOR_FIELDS) {
    if (Object.prototype.hasOwnProperty.call(row || {}, key)) {
      clean[key] = row[key];
    }
  }
  return clean;
}

function containsForbiddenKey(value) {
  if (Array.isArray(value)) {
    return value.some(containsForbiddenKey);
  }
  if (value && typeof value === "object") {
    for (const [key, child] of Object.entries(value)) {
      if (FORBIDDEN_PUBLIC_KEYS.has(String(key).toLowerCase())) {
        return true;
      }
      if (containsForbiddenKey(child)) {
        return true;
      }
    }
  }
  return false;
}

function isFuturePublicPayload(data) {
  return Boolean(
    data &&
    typeof data === "object" &&
    !Array.isArray(data) &&
    Array.isArray(data.chambers)
  );
}

function jsonResponse(payload, status = 200, source = "unknown") {
  return new Response(JSON.stringify(payload), {
    status,
    headers: {
      "content-type": "application/json;charset=utf-8",
      "cache-control": "no-store, max-age=0, must-revalidate",
      "x-content-type-options": "nosniff",
      "x-phi-live-source": source,
      "x-phi-market-truth": "NOT_PROVEN_BY_RECEIPT",
      "x-phi-trade-permission": "NO"
    }
  });
}
