# Cerebral Graphix v1.13.7 — Telescope 51 link

- Based on the complete v1.13.6 site package.
- Adds the exact `Telescope_51_Beta_Draft_v0_1.html` beside the maintained v7.2 game.
- Adds a teal `Play Telescope 51 β` link after `Play v7.2` in both Line Game entry pages.
- Leaves v7.2, the live paper, the card order, and every other site file unchanged.
- Keeps every deployable file below 25,000,000 bytes.

