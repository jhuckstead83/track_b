# v1.6 Front-Fold Patch

Scope: homepage only.

Changes:
- Removed the visible Finance Weather beta banner from the homepage tool-card row.
- Replaced the old fraction-message hero with a current site-level front door focused on the Chamber-Lift Atlas, Polar Shell Renderer, papers, and tools.
- Reduced top navigation to newcomer-facing routes.
- Fixed the hero markup so the right-side hero card closes before the tools section.

Deploy:
1. Upload `index.html` to the site root, replacing the existing homepage.
2. No sitemap update is required for this patch.
3. Click-test: `/`, `/tools/chamber_lift_atlas.html`, `/tools/polar_shell_renderer.html`, `/papers/chamber_lift_series.html`, `/finance/`.
