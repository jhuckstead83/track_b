# Private Finance Path — Access Boundary

## Non-negotiable

The deployable site release contains the private **page shell only**. It contains no named asset payload.

Before serving real named data, protect both the page and data route under the same real access-control policy:

- `/finance/private/*`
- `/finance/private/latest/*`

Recommended deployment pattern: protect the full `/finance/private/*` path at the edge, then serve `private_chamber_grid.json` only inside that protected namespace.

`robots.txt`, `<meta name=robots>`, `_headers`, a hard-to-guess URL, or client-side JavaScript are not authentication. They are defense-in-depth only.

## Expected private payload

The renderer is aligned to the notebook's real `build_phi_chamber_grid_frame(...)` output fields, including:

- `sector_code`, `sector_label`, `row`, `col`, `kind`
- `headline_bps`, `median_bps`, `avg_bps`, `weighted_avg_bps`
- `net_breadth`, `up_count`, `down_count`, `flat_count`
- `fresh_ratio`, `row_count`
- `leader_symbol`, `leader_bps`
- `laggard_symbol`, `laggard_bps`
- `abs2_symbol`, `abs2_bps`
- `trade_permission: NO`
- `market_truth: NOT_PROVEN_BY_RECEIPT`

The notebook is not modified in this release.
