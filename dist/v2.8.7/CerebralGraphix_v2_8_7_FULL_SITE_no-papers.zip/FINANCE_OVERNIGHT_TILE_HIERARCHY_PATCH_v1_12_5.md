# Finance overnight tile-hierarchy patch - v1.12.5

## Scope

This is a collapsed-tile presentation correction for `/finance/live` built on the
v1.12.4 overnight field-selection fix.

## Collapsed tile hierarchy

When the overnight overlay is enabled:

1. `c.overnight` is the primary full-grid number.
2. The primary number uses the established cyan/blue overnight color and the same
   headline scale formerly occupied by the close.
3. `c.base` moves underneath as `prior close ... bps` in a quieter comparison style.
4. Base-period breadth is removed from the default collapsed tile.
5. The overnight overlay takes precedence over the breadth headline control. The
   breadth control is disabled until the overlay is switched off.

When the overnight overlay is disabled:

- median mode restores the official close as the primary number;
- the collapsed median tile does not add breadth as a secondary line;
- breadth remains available as an explicit alternate headline view and in the
  expanded detail/ranking views.

## Missing-data rule

A genuinely absent overnight value remains an em dash in the blue headline. The
prior close remains visible underneath, but it is never substituted for the missing
overnight read. This includes a chamber such as Utilities when its overnight rail
legitimately contains no value.

## Preserved boundaries

- No notebook, R2, provider, normalization, schema, chamber order, drag behavior,
  expanded-tile calculation, or market-truth fence changed.
- Null is not coerced to zero.
- The production script query advances from `v=4` to `v=5` for cache invalidation.

