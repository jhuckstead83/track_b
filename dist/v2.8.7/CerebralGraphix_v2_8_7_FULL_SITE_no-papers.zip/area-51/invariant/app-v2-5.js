import {atomic,readWallet,ready,getCreditSnapshot,subscribeCredits,POLICY} from '../assets/credits-v2-0b3.js';
import {post} from '../assets/wallet-core-v2-0b3.js';
const {CardGame,rankDeck,decimalRank,FACES}=InvariantEngine;
const DATA=JSON.parse(document.getElementById('experiment-data').textContent);
const SYMBOLS=await (await fetch('../assets/SYMBOLS_51.json')).json(),symbols=new Map(SYMBOLS.symbols.map(x=>[x.card,x]));
const $=id=>document.getElementById(id),clone=x=>JSON.parse(JSON.stringify(x));
const glyph={S:'♠',H:'♥',D:'♦',C:'♣'},face=c=>c.slice(0,-1)+glyph[c.slice(-1)];
let record,game,busy=false,running=false,customDeck;
const uid=()=>crypto.randomUUID();
function shuffled(){const a=FACES.filter(c=>c!=='2C');for(let i=a.length-1;i>0;i--){let n;const x=new Uint32Array(1),limit=4294967296-4294967296%(i+1);do{crypto.getRandomValues(x);n=x[0];}while(n>=limit);const j=n%(i+1);[a[i],a[j]]=[a[j],a[i]];}return [0,1,2].map(p=>a.filter((_,i)=>i%3===p));}
function fresh(source='before',policy='hold'){const initial=source==='random'?shuffled():source==='custom'?[0,1,2].map(p=>DATA.positions.map(i=>customDeck[i]).filter((_,i)=>i%3===p)):clone(source==='after'?DATA.after:DATA.before);return {session:uid(),source,policy,initial,operations:[],exposed:source!=='random',shown:false,symbols:false,peeks:{},observations:[],predictions:[]};}
function replay(s){const g=new CardGame(s.initial,{forgiveness:s.policy==='forgive',nullFace:'2C'});let count=0;for(const op of s.operations){if(op.type==='forgive'){g.forgive();continue;}if(op.type==='replay'){g.replayStep();continue;}if(op.type!=='step'||!Number.isInteger(op.count)||op.count<1||count+op.count>200000)throw Error('Invalid saved continuation.');for(let i=0;i<op.count;i++)g.step();count+=op.count;}return g;}
function advance(s,g,n=1){let done=0;for(;done<n&&g.status==='playing';done++)g.step();if(done){const last=s.operations.at(-1);if(last?.type==='step')last.count+=done;else s.operations.push({type:'step',count:done});}}
function conflict(){return Object.assign(Error('Another tab moved this table. The saved table is reloaded; choose again.'),{code:'CONFLICT'});}
function accept(r){record=r;game=replay(r.state);if(r.state.source==='custom'&&!$('start').querySelector('[value="custom"]')){const o=document.createElement('option');o.value='custom';o.textContent='Your decoded order';$('start').appendChild(o);}$('start').value=r.state.source;$('policy').value=r.state.policy;}
async function commit(work){if(busy||!record)return false;busy=true;render();try{const result=await atomic(w=>{const current=w.apps.invariant;if(current.revision!==record.revision)throw conflict();const s=clone(current.state),g=replay(s);work(s,g,w);const next={revision:current.revision+1,state:s};w.apps.invariant=next;return next;});accept(result.value);$('ui-status').textContent='';return true;}catch(e){if(e.code==='CONFLICT'){const w=await readWallet();accept(w.apps.invariant);}running=false;$('ui-status').textContent=e.message;return false;}finally{busy=false;render();}}
function card(c,hidden=false,useSymbols=false){if(!c)return '<span class="a51-muted">Out</span>';if(hidden)return '<span class="a51-card back" role="img" aria-label="Hidden card">Ⅰ</span>';if(useSymbols){const x=symbols.get(c);return '<span class="a51-card symbol" role="img" aria-label="'+x.id+' '+x.codePoint+'">'+x.symbol+'<small>'+x.id+'</small></span>';}
const r=c.slice(0,-1),s=glyph[c.slice(-1)];return '<span class="a51-card '+(/[HD]$/.test(c)?'is-red':'')+'" role="img" aria-label="'+face(c)+'"><span class="corner">'+r+'<small>'+s+'</small></span><span aria-hidden="true">'+s+'</span><span class="corner bottom" aria-hidden="true">'+r+'<small>'+s+'</small></span></span>';}
function render(){if(!record)return;CardUI.close(false);const s=record.state,snap=game.snapshot(),active=game.status==='playing',money=getCreditSnapshot().balanceCents;
$('hands').innerHTML=game.hands.map((h,p)=>{const seen=s.shown||s.peeks[game.turn+':'+p];return '<article class="a51-hand '+(game.last?.winner===p+1?'win ':'')+(!h.length?'out':'')+'"><div class="a51-hand-head"><span>Player '+(p+1)+'</span><b>'+h.length+'</b></div><div class="next-card">'+card(h[0],!seen,s.symbols)+'</div>'+(s.shown?'<div class="a51-queue">'+h.map(c=>'<span class="a51-token '+(/[HD]$/.test(c)?'red':'')+'">'+(s.symbols?symbols.get(c).symbol:face(c))+'</span>').join('')+'</div>':'<div class="a51-hidden-queue">'+h.length+' ordered cards<br>Queue face-down</div>')+(h.length&&!seen?'<button data-peek="'+p+'" '+(busy||running||!active||money<600?'disabled':'')+'>Reveal top · 6 jbits</button>':'')+'</article>';}).join('');
for(const b of document.querySelectorAll('[data-peek]'))b.onclick=()=>peek(Number(b.dataset.peek));
bindCardActions(s,active,money);
$('turn').textContent=game.turn;$('circulation').textContent=game.hands.flat().length;$('escrow').textContent=game.bank.length;$('mass').textContent=game.hands.flat().length+' in hands + '+game.bank.length+' in escrow + Ⅰ = 52.';
let title=game.turn?'Turn '+game.turn+' · Player '+game.last?.winner+' takes the cards':'Ready to play',detail='Higher rank wins. A = 1. Equal ranks use ♠ < ♥ < ♦ < ♣.';
if(game.status==='finished'){title='Player '+game.winner+' survives';detail=game.turn+' turns · '+game.interventions+' concession interventions.';}
if(game.status==='cycle'){title='The future repeats';detail='Full state '+game.cycle.entry+' = state '+game.cycle.repeat+'. Period '+game.cycle.period+'. Hold Ⅰ or concede to Ⅰ.';}
if(game.status==='draw'){title='The cards are in escrow';detail='This continuation ends in a draw.';}
$('status-title').textContent=title;$('status-detail').textContent=detail;
$('height').textContent=game.turn&&game.turn<=DATA.heights.length?'Stored label y_'+game.turn+' = '+DATA.heights[game.turn-1]+'. The turn selects this label; the card rule does not generate it.':game.turn>DATA.heights.length?'The game passed the supplied '+DATA.heights.length+' labels. It continues from its finite card state. No further zero is being computed.':'The turn selects a supplied y_n label. No label enters the card transition.';
$('events').innerHTML=game.events.slice(-6).map(e=>'<li>'+(e.kind==='play'?'Turn '+e.turn+': '+e.drawn.map(d=>'P'+d.player+' '+face(d.card)).join(' · ')+'. P'+e.winner+' takes the pot.':'Ⅰ moves '+e.moved.length+' cards into escrow.')+'</li>').join('');
for(const id of ['step','run','fast','reset','show-hands','symbols','export','deal-code'])$(id).disabled=busy||running||(['step','run','fast'].includes(id)&&!active&&!(id==='step'&&game.status==='cycle'));
$('pause').disabled=!running;$('forgive').disabled=busy||running||game.status!=='cycle';$('start').disabled=$('policy').disabled=busy||running;
$('show-hands').textContent=s.shown?'Hide the hands':'Show the hands';$('show-hands').setAttribute('aria-pressed',String(s.shown));$('symbols').textContent=s.symbols?'Use card faces':'Use symbols';$('symbols').setAttribute('aria-pressed',String(s.symbols));
const predictionOpen=active&&s.source==='random'&&!s.exposed&&!s.shown;
$('predict').disabled=busy||running||!predictionOpen||money<100||!$('prediction').value||!game.hands[Number($('prediction').value)-1]?.length;
$('prediction-note').textContent=s.predictions.length?'Last call: P'+s.predictions.at(-1).choice+' · actual P'+s.predictions.at(-1).winner+' · returned '+s.predictions.at(-1).payout+' jbits.':predictionOpen?'A correct call returns '+game.hands.filter(h=>h.length).length+' jbits. This is a declared game price, not calculated odds.':'Predictions open on a fresh hidden shuffle. Published or exposed orders are free to watch.';
$('card-call-status').textContent=s.predictions.length?$('prediction-note').textContent:'';
}
function bindCardActions(s,active,money){
 for(const [p,node] of [...$('hands').querySelectorAll('.next-card')].entries()){
  if(!game.hands[p].length)continue;
  const seen=s.shown||s.peeks[game.turn+':'+p],c=game.hands[p][0];
  CardUI.activate(node,trigger=>CardUI.open(trigger,{
   title:'Player '+(p+1)+(seen?' · '+face(c):' · face down'),
   info:active&&s.source==='random'&&!s.exposed&&!s.shown?'Call costs 1 jbit; a correct call returns '+game.hands.filter(h=>h.length).length+' jbits gross. Declared payout, not calculated odds.':game.hands[p].length+' cards. Predictions require a fresh hidden shuffle.',
   focusFallback:$('step'),
   actions:[
    {label:'Call P'+(p+1)+' & play · 1 jbit',primary:true,disabled:busy||running||!active||s.source!=='random'||s.exposed||s.shown||money<100,run:()=>{$('prediction').value=String(p+1);$('predict').onclick();}},
    !seen?{label:'Reveal this top card · 6 jbits',disabled:busy||running||!active||money<600,run:()=>peek(p)}:CardUI.fromButton('symbols',s.symbols?'Show card faces':'Show paper symbols'),
    {label:'Prediction details',run:()=>CardUI.reveal('prediction')}
   ]
  }), 'Player '+(p+1)+(seen?' '+face(c):' face-down card')+' · predictions and reveal');
 }
}
async function peek(p){await commit((s,g,w)=>{if(!g.hands[p].length||g.status!=='playing'||s.shown||s.peeks[g.turn+':'+p])throw Error('This top card is already known or unavailable.');post(w,{id:'invariant:'+s.session+':peek:'+g.turn+':'+p,source:'invariant',kind:'identity-reveal',deltaCents:-600},Date.now());s.peeks[g.turn+':'+p]=true;s.observations.push({turn:g.turn,player:p+1,kind:'peek',priceJbits:6});});}
$('step').onclick=()=>commit((s,g)=>{if(g.status==='cycle'){g.replayStep();s.operations.push({type:'replay'});}else advance(s,g);});
$('reset').onclick=()=>{const source=$('start').value,policy=$('policy').value;commit(s=>{Object.assign(s,fresh(source,policy));});};
$('forgive').onclick=()=>commit((s,g)=>{g.forgive();s.operations.push({type:'forgive'});});
$('show-hands').onclick=()=>commit(s=>{s.shown=!s.shown;if(s.shown){s.exposed=true;s.observations.push({kind:'full-order',turn:game.turn});}});
$('symbols').onclick=()=>commit(s=>{s.symbols=!s.symbols;});$('prediction').onchange=render;
$('predict').onclick=()=>{const choice=Number($('prediction').value);commit((s,g,w)=>{if(s.source!=='random'||s.exposed||s.shown||g.status!=='playing'||!g.hands[choice-1]?.length)throw Error('Choose a live player on an unexposed shuffle.');const id='invariant:'+s.session+':prediction:'+g.turn,live=g.hands.filter(h=>h.length).length;post(w,{id:id+':stake',source:'invariant',kind:'prediction-stake',deltaCents:-100},Date.now());advance(s,g);const winner=g.last.winner,payout=winner===choice?live:0;if(payout)post(w,{id:id+':return',source:'invariant',kind:'prediction-return',deltaCents:payout*100},Date.now());s.predictions.push({turn:g.turn,choice,winner,stake:1,payout});});};
async function run(fast){if(running||busy||!record)return;running=true;const limit=game.turn+50000;render();while(running&&game.status==='playing'&&game.turn<limit){if(!await commit((s,g)=>advance(s,g,fast?250:1)))break;await new Promise(r=>setTimeout(r,fast?0:600));}running=false;render();if(game.status==='playing'&&game.turn>=limit)$('ui-status').textContent='Paused after 50,000 turns. Continue to extend this finite-game search.';}
$('run').onclick=()=>run(false);$('fast').onclick=()=>run(true);$('pause').onclick=()=>{running=false;render();};window.addEventListener('a51surfacechange',()=>{running=false;});document.addEventListener('visibilitychange',()=>{if(document.hidden)running=false;});
function download(name,data){const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
$('export').onclick=async()=>{if(await commit(s=>{s.exposed=true;s.observations.push({kind:'export',turn:game.turn});}))download('Invariant_v2_Move_Ledger.json',{schema:'invariant-v2',ruleVersion:'v7.2',collected:false,initial:game.initial,final:game.hands,escrow:game.bank,certificate:game.snapshot(),events:game.events,observations:record.state.observations,predictions:record.state.predictions});};
function decode(){try{const d=$('deck-input').value.trim().toUpperCase().split(/\s+/),r=rankDeck(d);$('decoded').textContent=decimalRank(r);$('decoded-rank').textContent='Integer '+r+' · '+r.toString(2).length+' binary digits in this record.';$('decode-error').textContent='';$('deck-grid').innerHTML=d.map(c=>'<span>'+face(c)+'</span>').join('');return d;}catch(e){$('decode-error').textContent=e.message;return null;}}
function fill(d){$('deck-input').value=d.join(' ');decode();}
$('decode-action').onclick=decode;$('restore').onclick=()=>fill(DATA.deck);$('swap').onclick=()=>{const d=decode();if(d){[d[49],d[50]]=[d[50],d[49]];fill(d);}};
$('deal-code').onclick=async()=>{const d=decode();if(!d)return;customDeck=d;if(!$('start').querySelector('[value="custom"]')){const option=document.createElement('option');option.value='custom';option.textContent='Your decoded order';$('start').appendChild(option);}if(await commit(s=>Object.assign(s,fresh('custom','hold'))))location.hash='play';};
try{await ready;const r=await atomic(w=>{if(!w.apps.invariant)w.apps.invariant={revision:1,state:fresh()};replay(w.apps.invariant.state);return w.apps.invariant;});accept(r.value);fill(DATA.deck);render();}catch(e){$('status-title').textContent='Table unavailable';$('status-detail').textContent=e.message;for(const b of document.querySelectorAll('button'))b.disabled=true;}

let lastBalance;subscribeCredits(s=>{if(lastBalance!==s.balanceCents){lastBalance=s.balanceCents;if(record&&!busy)render();}});
