# Build Checks v1.1

```json
{
  "checks": {
    "tools_rational_address_showpiece_index_html_exists": true,
    "tools_rational_address_showpiece_method_html_exists": true,
    "tools_forge_os_v12_html_exists": true,
    "tools_forge_os_v16_3_html_exists": true,
    "tools_sound_volume_source_note_forge_v12_html_exists": true,
    "tools_sound_volume_source_note_forge_v12_md_exists": true,
    "homepage_has_showpiece": true,
    "homepage_has_forge": true,
    "tools_index_has_forge": true,
    "tools_index_has_showpiece": true,
    "site_index_has_all": true,
    "site_json_has_all": true,
    "sitemap_has_all": true,
    "sitemap_xml_valid": true,
    "json_valid": true,
    "routes_no_global_exclude": true,
    "js_syntax_tools_rational_address_showpiece_index_html": true,
    "js_syntax_tools_forge_os_v12_html": true,
    "js_syntax_tools_forge_os_v16_3_html": true
  },
  "node": {
    "tools/rational_address_showpiece/index.html": {
      "return_code": 0,
      "stderr": ""
    },
    "tools/forge_os_v12.html": {
      "return_code": 0,
      "stderr": ""
    },
    "tools/forge_os_v16.3.html": {
      "return_code": 0,
      "stderr": ""
    }
  }
}
```
