# Cerebral Graphix v2.8.1 · unpublished merge

27 September 2026. Based on the supplied v2.8.0 draft. All input files are retained, including 51 Twins, SEDAPS v0.4, the Postmaster v5.2 source ZIP, Formula 51, and the Prospect rename. No deployment or DOI publication was performed.

## Finance

- The main default board now uses the same dated Google baseline as the hero and monitor. A current measured reading, including a genuine zero, retains priority.
- After expiry, the held weather value fades into the Google median with the existing quote-age support clock. At rest, it stays on that dated reference. Missing reference sectors retain the original decay behavior.
- The reference is checked every five minutes; validated cache and a dated bundled seed provide downtime coverage. Live weather packets retain their 30-second refresh.
- Source/date labels distinguish reference, fading and current readings. The reference is not added to measured history. Jbit movement fields, eligibility and wallet code are unchanged; the reference does not activate the live indicator.

## Hero

- Untouched cards rotate every six seconds; the existing ghost arrows remain.
- Hover, keyboard focus, arrows or swipe pause rotation and reveal a matching Play control. Play resumes rotation and becomes Pause. Reduced-motion users start paused.
- Finance remains one read-only linked face. No bottom control bar or card counter was added.

## Research review

- Independent Python verifies all 20 four-for-four SEDAPS deals and the 336-state exclusion of branch 10 at turn 84. UI wording now makes the elapsed-turn condition explicit.
- Twins copy distinguishes sampled finite-census signs from a global first-failure certificate, and accurately describes the card verifier’s scope.
- Formula 51’s ceiling-function proof step is repaired; its conclusions and score table remain intact. Replay matches all table data, with only CRLF/LF differences.
- See `FRONTIER_HANDOFF_v0_4.md` for independent results, limits and the next Claude/Colab tasks.

## Validation

Nine focused model/DOM/timer groups, six inherited game continuity checks, 13 changed-page link checks (416 local references), the Twins card replay, and all six default notebook code cells pass. Postmaster interface audit: 67/67. Receipts are in `VALIDATION_v2_8_1.json`.

No rendered-browser, physical touch-device, deployed feed or production deployment check is claimed. The supplied Postmaster source archive is preserved; v5.2 PDFs and pending DOIs remain separate publication work. RH remains OPEN.
