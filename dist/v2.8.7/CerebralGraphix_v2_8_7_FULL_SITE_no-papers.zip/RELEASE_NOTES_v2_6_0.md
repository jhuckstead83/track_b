# Cerebral Graphix v2.6.0 — Prospect rewards

Downloadable update based on v2.5.0. This package has not been deployed.

## Telescope

Value, Rank, Color, and Suit remain whole words with a bold first letter. The previous base stylesheet made the nested bold letter a block, overriding the intended word flow. That declaration is now explicitly inline in the Telescope page itself.

## Prospect 51

The center row remains the single scoring line. The approved scorer, payout table, entry price, redraw inventory, archive rule, and reel controller are unchanged.

- **Scoring cards:** a gold outline, warm face, and star identify exactly the cards that make the final hand. The supplied Three kings example highlights rotors 2, 3, and 5. A paying pair highlights two cards; two pair or four of a kind highlights four; three of a kind highlights three. Straights, flushes, full houses, straight flushes, and royals use all five. Nonpaying hands have no scoring highlight.
- **Reward lights:** small brass-colored lamps around the reel frame glow briefly after a winning settlement. The marked cards retain a static highlight afterward, including after reload and when turned to their paper symbols.
- **Jbit coins:** a bounded burst travels from the scoring cards toward the existing bank. The award amount counts up to the recorded gross payout. The bank itself always shows its committed balance; the animation does not credit it in installments.
- **Sound:** a visible Sound toggle enables original synthesized reel ticks, stop clicks, Hold/Release clicks, bells, and a short award flourish. Sound starts off, remembers the chosen setting, and activates audio only through a user gesture. Muting or leaving the page stops the cues. Audio failure cannot block play.
- **Timing:** reward animation begins after all moving reels stop. It never postpones the next available action. Starting another hand, resizing, hiding the page, or leaving an example clears the effect. Reloading restores the hand and highlights without replaying its celebration.
- **Quiet outcomes:** a one-jbit return gets static highlights and a small sound cue when enabled. A no-award hand gets no winning lamps, coins, or award sound. Reduced motion keeps static highlights and the exact final amount, with no coin travel or count-up.
- **Try the screenshot hand:** open **Awards · archive key & examples → Three kings**. This preview shows the lights and coins without spending or awarding jbits. Its coins end at the example result, not the bank. Royal flush also previews the larger effect. The illustration banner stays visible.

The new sounds are generated from oscillators in `sounds-v2-6.js`; no sampled recordings, music files, or branded sound effects are included. The lamp and coin graphics are original CSS. This update adds no external media requests or third-party effect libraries.

## Preservation and installation

Only the Telescope and Prospect HTML entrypoints change among existing v2.5 files. New Prospect scripts/styles and verification files are added. All existing wallet/account files, game engines, papers, stamps, Finance pages, homepage, and other game pages retain their v2.5 bytes. Existing jbits, hands, holds, and receipts continue through the same account schema.

- **Full site:** extract `CerebralGraphix_v2_6_0_FULL_SITE.zip` at the site root.
- **Patch:** overlay `CerebralGraphix_v2_6_0_DELTA_FROM_v2_5_0.zip` on the exact v2.5.0 full package from this conversation. No deletions are required. Use the full site for an uncertain or mixed installation.
- Upload the new assets with the two updated HTML pages. Prospect requests fresh v2.6 application/effect URLs; unchanged v2.5 presentation assets remain in use.
- Keep browser site storage to retain the bank and saved hands.

## Verification

| Check | Result |
|---|---|
| Site, engine, wallet, and integration assertions | 402 passed |
| Shared Prospect account, including all 32 hold masks | 15 passed |
| Storage fallback and failure policy | 8 passed |
| IndexedDB transaction model | 5 passed |
| Card interactions across the five games | 14 passed |
| Reload and cross-game continuity | 6 passed |
| Reel/settlement coordination | 5 passed |
| Decision shortcuts and odds lifecycle | 6 passed |
| Shared stamps and mobile interaction flows | 12 passed |
| Startup, overlay, animation, and Double behavior | 8 passed |
| Control CSS regressions, including Telescope's inline letter | 5 passed |
| New hand highlights, reward lifecycle, and audio behavior | 10 passed |

New checks cover every scoring category, the exact three-Kings hand, a winning redraw that waits for the reels, the no-spend preview, the settled bank, mute and delayed audio activation, absence of Web Audio, reduced motion, resize, page hiding, and reload without reward replay. ZIP integrity, preservation, and exact patch reconstruction are recorded in the package checks.

These checks use an in-memory DOM, authored CSS, controlled animation frames, and a mock Web Audio scheduler. **Native rendering and listening review remain pending.** After uploading, check Telescope's words on a phone, then use Three kings and Royal flush to inspect the lights, coin paths, and sound level. Turn Sound on to hear the cues. Confirm that the fixed Spin/Draw control and Hold buttons remain easy to use.

Run `npm ci` and `npm test` inside `tests/v2_6/`. Earlier suites and receipts remain historical records.

## Implementation references

The implementation follows browser guidance on creating/resuming audio after interaction and providing audio control. Motion effects are brief and also honor reduced-motion settings.

- [Chrome: Web Audio, Autoplay Policy and Games](https://developer.chrome.com/blog/web-audio-autoplay/)
- [MDN: Web Audio API best practices](https://developer.mozilla.org/en-US/docs/Web/API/Web_Audio_API/Best_practices)
- [W3C: Three Flashes or Below Threshold](https://www.w3.org/WAI/WCAG21/Understanding/three-flashes-or-below-threshold/)
