# v2.0B.6 — jbit reserve browser-cache hotfix

Observed browser reproduction: open site -> Finance -> back four tiles at 2 jbits each -> reserve continues to add jbits.

Root cause: Hotfix 5 changed the holdings-aware wallet code under the existing `credits-v2-0b2.js` / `wallet-core-v2-0b.js` URLs. A browser that had loaded Hotfix 4 could continue to execute those cached modules while the newer Finance UI was already visible.

Fix:
- Versioned the live wallet chain to `wallet-core-v2-0b3.js` and `credits-v2-0b3.js`.
- Versioned the bank display, Finance jbit controller, and active Area 51 game adapters so every live surface imports the new holdings-aware wallet module.
- Reserve rule remains: refill only while `available bank + active finance holdings < 8 jbits`.
- No balance reset and no position migration are required; storage keys are unchanged.

Expected regression test:
1. Begin with 8 jbits.
2. Back four Finance tiles at 2 jbits each.
3. Bank shows 0 and holdings show approximately 8 (subject to BPS marking).
4. If total owned value is >= 8, the reserve must not mint and should report `Reserve covered by holdings`.
5. If marked holdings fall below 8, recovery may fill only the shortfall toward 8.
