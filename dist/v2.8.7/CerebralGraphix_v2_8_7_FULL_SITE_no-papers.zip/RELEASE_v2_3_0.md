# Cerebral Graphix v2.3.0 — mobile cards and shared stamps (revision 3)

Built from the supplied **Finance Weather v2.1.0 full site**, retaining Prospect 51's approved v0.3 mathematics. This downloadable build replaces revision 2. It has not been deployed.

## This pass

- **Homepage:** Finance leads a six-card rotation, followed by the five Area 51 games. Swipe or use the arrows; pause is available and reduced motion stops automatic rotation. A game card opens Area 51; its explicit Play button opens that game. The redundant header links are consolidated under Explore, and the two separate hero buttons are removed.
- **Invariant:** setup and prediction controls use wrapping grids with bounded inputs, addressing the narrow desktop overlap in the screenshot. Decode sits beside Play turn, Watch, and Run. The older foundation is presented in the archive disclosure below the game.
- **Research navigation:** the “The table” tabs are removed. Research links open the live paper below the active game. Card shortcuts open and focus the relevant disclosure without replacing the table. Longer explanations keep their instructional order.
- **Blackjack 51:** tapping an undealt card now opens useful decision-market instructions. During play, card menus show the current safe/bust market and priced odds. Hit, Stand, Deal, and legal Double/Split remain the primary table controls. A paid quote is reused for the same state, and the face-down dealer identity stays hidden.
- **Telescope 51:** compact rule tiles and three card windows replace the cramped text presentation. Hidden cards have anonymous house backs. A paid reveal stamps the exact symbol on the back for the rest of that round; the card can then be turned to its familiar face for free. Settled identities are also stamped. The reveal still costs 6 jbits. Card menus retain reference odds and the selected player's ticket action stays beside that player.
- **Memory 51:** prompts and answers use the same house cards and exact vector stamps. Correct, unassisted four-choice recall earns the card's stamp alongside the existing jbit reward. The collection, pair explorer, and flip/practice controls appear beneath both Memory and Telescope.
- **Interactive lower panels:** Telescope gains a three-card rule demonstration with a slider through V → R → C → S. Both games have a shared 51-stamp collection. Going from Telescope to Memory through a practice shortcut saves the walk; the Return link restores its round, selected rule/player, and revealed cards.
- **Prospect 51:** each reel has a direct HOLD toggle that lights when selected. The separate Bank button is removed. The master button draws the unheld cards, or reads **Keep five · collect** when all five are held. Card taps still offer hold odds and symbol inspection. The useful lower research panels remain.
- **Prospect motion:** a visible setting offers System, Scrolling reels, and Reduced motion. Reel travel uses transform-only animation with a requestAnimationFrame fallback if Web Animations is unavailable or throws. Interruption reveals the already committed result without another draw or payout.

## Stamps and jbits

An unassisted correct recall earns **2 jbits**, up to the existing **8-jbit daily recall limit**. A new stamp can still be earned after that limit. Each card enters the collection once. Wrong or assisted answers do not earn stamps; inspecting the current answer in the pair explorer marks that prompt as assisted. Existing certified recall receipts also contribute to the collection.

Stamps and recall awards commit together in the shared local wallet. Retrying the same answer cannot duplicate either. A revealed Telescope stamp describes the current card; earning its permanent collection mark requires recall in Memory. Card flips and the lower demonstrations are free.

Prospect's opening deal costs **1 jbit**; its single redraw is free. No holds means a five-card redraw. All five held means keeping and collecting the original hand. The approved gross awards remain **1, 2, 3, 4, 6, 9, 25, 50, 250**. The exact initial archive key reserves the incremented meter, which starts at **51 jbits** and adds **0.01** per entry; it resets to 51 on a hit. A reserved bonus survives redraw and pays once at settlement.

These are browser-local play balances and collections, with no cash value. There is no new opening grant or resettable bank. The previous wallet safeguards remain: persistent checkpoints, idempotent receipts, stale-tab rejection, serialized fallback writes, and retention of unreadable saves.

## Research and preservation

- The original **13-page Project 51 v0.3 PDF**, exact identity dictionary, token renderer, poker evaluator, and sampling engine are unchanged.
- The original source/demo/verification archive and website integration notes remain included.
- All **66 Finance files** and the existing deposited PDFs remain byte-identical to v2.1. Finance continues to share the existing wallet. The homepage is changed as requested.
- Telescope's V → R → C → S rules, fixed walk, reference census, ticket prices, and awards are unchanged. The paid identity reveal now remains visibly stamped instead of disappearing after a timed peek.
- Telescope card odds are labeled as uniform reference probabilities, not conditional predictions of its recorded walk. Invariant's declared gross awards remain distinguished from calculated odds.

## Verification

| Check | Result |
|---|---|
| Current regression suite | 403 assertions passed |
| Shared-account adapter | 15 checks passed, including all 32 hold masks |
| Storage failure and fallback policy | 8 checks passed |
| IndexedDB transaction model | 5 checks passed |
| Card-action DOM checks | All five games passed |
| Reload and cross-game UI continuity | 6 checks passed |
| Reel/settlement coordination | 5 checks passed |
| Decision shortcuts and odds lifecycle | 6 checks passed |
| Stamps, return journey, direct holds, fallback motion, and homepage routing | 12 checks passed |
| Original engine verification retained from this release | 33 checks; all 2,349,060 opening hands enumerated |
| Independent opening census | All 10 categories agree |
| Project 51 paper audit | 65 checks passed, including 1,566 archived records |

The live previous revision's reels visibly animated in the inspected Chrome session; the reported desktop failure was not reproduced there. This revision adds an explicit motion choice and animation fallback, but the user's Chrome case still needs to be rechecked.

**The new build's rendered layout check remains pending.** The automated interaction tests use an in-memory DOM, and the storage tests include simulated IndexedDB. They verify behavior, not CSS appearance, native multi-window storage, Safari, physical phones, or assistive technology. Local interactive previews were unavailable in this environment.

For the next visual pass, check 320, 390, and 600 CSS pixels and narrow desktop: the Finance hero and swipe targets; Invariant setup wrapping; Blackjack's starting market shortcut; Telescope's rule labels and card stamps; Memory's answer tiles; and Prospect's five Hold buttons and explicit Scrolling reels mode. Check the Telescope → Memory → Return trip, portrait/landscape changes, and a saved Prospect hand reload.

## Install

**FULL_SITE.zip:** extract to a fresh directory. Its root is the deployment root, containing `index.html`, `_headers`, and `_redirects`.

**DELTA_FROM_v2_1_0.zip:** overlay onto the supplied v2.1.0 Finance Weather site. This is a cumulative patch from v2.1.0, not a v2.2.x patch. No deletions are required. The packaging check proves that applying it reconstructs the full build file for file.

Verification sources and result receipts are under `tests/v2_3/`. Run `npm ci` there, then `npm test`. The original paper and census runners are in the included Project 51 source archive.
