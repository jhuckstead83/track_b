# Chamber Release Deploy Notes

Added public chamber-series front door and prime-numerator shell renderer.

## New files

- `/tools/chamber_lift_atlas.html`
- `/tools/polar_shell_renderer.html`
- `/papers/prime_numerators_tfg.pdf`

## Updated files

- `/index.html`
- `/tools/index.html`
- `/papers/index.html`
- `/site-index.html`
- `/site-index.json`
- `/sitemap.xml`

## Release posture

- Chamber-Lift Atlas is the front door/index.
- Polar Shell Renderer is the live proof-object for the prime-numerator shell paper.
- The paper claim stays fenced as: lens, not a new prime law.

## After Zenodo

Replace any placeholder/no-Zenodo link text with the assigned DOI/record URL for `prime_numerators_tfg.pdf`.


## v1.5 Zenodo/OEIS update

Added /papers/chamber_lift_series.html as the public chamber-lift series index.
Updated homepage, tools index, papers index, site-index.html, site-index.json, and sitemap.xml.
Added outbound links for Zenodo record 21200042 and OEIS draft A394477.
Added missed portfolio links: Odd Perfect Number Chamber Lift, Goldbach Chamber Lift, and Jordan Chamber Lift.
