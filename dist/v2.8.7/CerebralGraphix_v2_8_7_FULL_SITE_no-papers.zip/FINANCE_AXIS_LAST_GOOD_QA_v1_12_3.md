# Finance Axis and Last-Known-Good QA — v1.12.3

Overall automated result: **PASS**

- PASS — `axis_top_defensive_up`
- PASS — `axis_bottom_cyclical_down`
- PASS — `axis_container_not_rotated`: display:flex;flex-direction:column;justify-content:space-between;align-items:center;color:var(--muted);font:10px var(--mono);letter-spacing:.1em;padding:8px 0
- PASS — `legacy_width_100`
- PASS — `legacy_height_100`
- PASS — `legacy_no_111_crop`
- PASS — `legacy_no_auto_height`
- PASS — `last_good_bundled_16`: 16
- PASS — `last_good_explicit_state`
- PASS — `last_good_not_fresh_claim`
- PASS — `js_rejects_empty_plate`
- PASS — `js_public_last_good_first`
- PASS — `js_null_not_zero_guard`
- PASS — `js_last_good_label`
- PASS — `javascript_syntax`: node --check passed
- PASS — `notebook_version`
- PASS — `notebook_repair_before_loop`
- PASS — `notebook_outputs_cleared`
- PASS — `repair_json_safe`
- PASS — `repair_publishes_last_good`
- PASS — `repair_fails_soft`
- PASS — `repair_cell_syntax`: compile passed
- PASS — `last_good_canonical_codes`: UTILITIES,REAL_ESTATE,FOOD,HEALTHCARE,DEFENSE,BANKS,MACRO_ETF,TELECOM,ENERGY,MATERIALS,AI_BIG,MEDIA,AI_SEMIS,INDUSTRIALS,AUTOS_EV,RETAIL

## Visual browser note

System Chromium terminated in crashpad initialization; static DOM/CSS and JavaScript logic checks were used instead.
