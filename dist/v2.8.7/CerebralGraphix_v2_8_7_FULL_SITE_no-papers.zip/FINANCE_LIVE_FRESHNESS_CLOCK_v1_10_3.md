# Φ Finance Weather — v1.10.3 Live Freshness Clock

## Scope

Website side only. The notebook is untouched.

## Freshness control behavior

The freshness surface now performs two jobs:

1. Live age clock
   - Computes `current browser time - snapshot_utc`.
   - Updates once per second.
   - Continues counting without a page refresh.

2. Manual live refresh
   - Clicking the top freshness pill, desktop freshness button, or mobile Fresh button fetches the newest public aggregate and rerenders the grid.
   - A brief `REFRESHING…` state appears during the fetch.
   - Success flashes `REFRESHED`.
   - Failure flashes `REFRESH FAILED` and keeps the last rendered data visible.

## One-time disclosure behavior

The freshness/receipt explanation opens once on the first freshness click of each page load.

It is intentionally not persisted:
- no localStorage;
- no sessionStorage;
- no cookie.

After the first click, later freshness clicks refresh silently and show only the brief flash.

## Age display

Age is formatted as:
- under 1 hour: seconds;
- under 1 day: hours/minutes/seconds;
- 1 day or more: days/hours/minutes/seconds.

The technical receipt panel still shows exact `age_seconds`.

## Notebook status

No notebook files were modified.
No Colab runtime changes.
No history-tail changes.
