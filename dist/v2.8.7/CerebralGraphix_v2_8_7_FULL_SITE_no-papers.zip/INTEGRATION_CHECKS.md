# Integration Checks

```json
{
  "checks": {
    "patched_index_exists": true,
    "tool_folder_exists": true,
    "tool_index_exists": true,
    "tool_app_exists": true,
    "tool_method_exists": true,
    "homepage_has_card": true,
    "homepage_open_link": true,
    "homepage_method_link": true,
    "six_cardinal_preserved": true,
    "finance_preserved": true,
    "tool_python_tests_passed": true,
    "tool_js_syntax_passed": true
  },
  "python_test": {
    "return_code": 0,
    "stdout": "All centered rational chamber tests passed.",
    "stderr_note": "External runtime warmup warnings, if any, are not package failures."
  },
  "node_check": {
    "available": true,
    "return_code": 0,
    "stdout": "",
    "stderr": ""
  }
}
```
