# Cerebral Graphix v2.4.0 — Prospect reels and Blackjack Double

Downloadable review build, based on **v2.3.0 revision 3**. It has not been deployed. The full site also includes the earlier Finance-first homepage, Invariant layout changes, inline research, and shared Telescope/Memory stamps.

## Prospect bank fix

The failure was reproduced on the live site. Its new HTML omitted the separate Bank button, while an older `app-v2-3.js` still tried to attach that button's click handler. The resulting exception stopped startup before the bank and hand could be displayed.

This release uses distinct **v2.4 entrypoint, application, reel controller, action-panel, and style filenames**. A single entrypoint loads the bank, approved game dependencies, and interface in sequence. The shared bank can display independently of the reel interface. A startup error now reports the failure and offers Reload Prospect instead of leaving an unexplained dash.

The existing wallet and Prospect account schema are retained. Saved hands, holds, jbits, receipts, and the archive meter are not reset or migrated to a second bank. **Do not clear site storage to install this update.**

## Reels and actions

- Five rectangular windows with metal surrounds and a fixed center line, following the supplied slot-machine references.
- Light reel bands show neighboring symbols above and below the active card, with shading at the window edges.
- The actual symbol bands move vertically using animation-frame updates. Travel no longer depends on Web Animations support. Reels stop in sequence; held reels stay still.
- Familiar rank/suit tiles remain the default. The selected center card can turn to its exact Project 51 paper mark without changing its identity or hand.
- Tapping a center card opens its compact action panel **over the reel area**. Hold/Release, face/mark, and odds shortcuts remain attached to that selection. The lit Hold buttons stay directly beneath their reels.
- One master control performs the free draw, or **Keep five · collect** when all five cards are held. No holds means drawing five replacements, under the approved rules.
- System, Scrolling reels, and Reduced motion remain available. Reveal now, resizing, or hiding the page finishes the presentation of the committed result; it cannot redraw or pay again.

## Blackjack

**Hit · Stand · Double** use three equal columns during a live hand. Double keeps its place and disables when the hand or balance makes it unavailable. When legal, it doubles the stake, takes one card, and stands. Split appears on a separate row when available. The rules and payouts are unchanged.

## Preservation

The homepage, Invariant, Telescope, Memory, shared stamp code, Finance pages/data, and deposited PDFs are unchanged from v2.3 revision 3. The original Project 51 v0.3 engine, dictionary, and token renderer remain byte-identical to the supplied source. The approved R51-0.3 scoring, one-jbit entry, free redraw, and local archive-meter behavior are unchanged.

## Verification

| Check | Result |
|---|---|
| Current regression suite | 401 assertions passed |
| Shared-account adapter | 15 checks, including all 32 hold masks |
| Storage failure and fallback policy | 8 checks |
| IndexedDB transaction model | 5 checks |
| Card-action DOM checks | All five games passed |
| Reload and cross-game continuity | 6 checks |
| Reel/settlement coordination | 5 checks |
| Decision shortcuts and odds lifecycle | 6 checks |
| Shared stamps and mobile interaction flows | 12 checks |
| v2.4 startup, saved hands, reel overlay, frame travel, and Double | 8 checks |

The earlier exhaustive engine census and paper-audit receipts remain included; their underlying mathematics is unchanged. The packaging check verifies ZIP integrity, preservation hashes, and exact reconstruction of the full build from the v2.3 revision 3 patch.

**Rendered-device review remains pending.** The new behavior was checked with an in-memory DOM and controlled animation frames. These checks do not certify CSS appearance or actual mobile/desktop rendering. The live-site startup failure was reproduced in Chrome, but the new v2.4 files have not been deployed for a visual pass there.

After publishing, check Prospect's bank and a saved-hand reload first, then the rectangular windows, visible reel travel, center-card overlay, and Hold controls at 320/390 CSS pixels and desktop. In Blackjack, check the three-button row and legal/disabled Double states.

## Install

- **Full site:** extract `CerebralGraphix_v2_4_0_FULL_SITE.zip` into a fresh deployment directory. Its root is the site root.
- **Patch:** overlay `CerebralGraphix_v2_4_0_DELTA_FROM_v2_3_0.zip` onto **v2.3.0 revision 3**, the previous full-site package from this conversation. No deletions are required. For v2.1, v2.2, or an uncertain/mixed installation, use the full site.
- Keep the matching new HTML, scripts, and styles together. The new filenames address the observed stale-script mismatch without clearing browser data.

Run the maintained checks with `npm ci` and `npm test` inside `tests/v2_4/`. Historical v2.3 receipts remain under `tests/v2_3/`.
