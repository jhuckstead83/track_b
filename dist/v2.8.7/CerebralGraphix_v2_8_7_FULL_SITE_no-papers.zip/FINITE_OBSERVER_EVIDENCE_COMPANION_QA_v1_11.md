# Finite-Observer Evidence Companion integration QA

```json
{
  "release": "v1.11-finite-observer-evidence-companion",
  "base_release": "v1.10.3-live-freshness-clock",
  "integration_date": "2026-07-13",
  "zenodo_record": "https://zenodo.org/records/21336985",
  "new_tool_path": "/tools/finite_observer_ledger/",
  "new_papers": [
    "/papers/From_Measure_to_Flux_Jeffery_Huckstead_FIGURE_ENHANCED_FINAL.pdf",
    "/papers/The_Finite_Observer_Ledger_Jeffery_Huckstead_FIGURE_ENHANCED_FINAL.pdf"
  ],
  "claim_manifest_records": 34,
  "figure_manifest_records": 6,
  "figure_png_assets": 6,
  "tool_relative_refs_checked": 0,
  "tool_relative_refs_missing": [],
  "tool_inline_javascript_syntax": "PASS",
  "homepage_updated": true,
  "tools_directory_updated": true,
  "papers_shelf_updated": true,
  "human_site_index_updated": true,
  "machine_site_index_updated": true,
  "sitemap_updated": true,
  "zenodo_link_in_tool": true,
  "zenodo_link_on_homepage": true,
  "zenodo_link_on_tools_page": true,
  "zenodo_link_on_papers_page": true,
  "finance_subtree_byte_identical_to_base": true,
  "_redirects_unchanged": true,
  "_routes_json_unchanged": true,
  "finance_live_data_function_unchanged": true,
  "guardrail_present": true
}
```
