# Cerebral Graphix v1.13.8 — Telescope 51 archive addressing

- Uses the live v1.13.7 package as the frozen base.
- Leaves the approved `Play Telescope 51 β` button exactly where it is. Both Line Game entry pages remain byte-identical to v1.13.7.
- Makes the Telescope page self-canonical and indexable, and adds it to the sitemap, human site index, `llms.txt`, citation catalogue, BibTeX and citation guide.
- Adds the six-page, referenced `Telescope 51: What a Rule Can See` v0.2 working paper. The calendar collar remains outside this paper and in Lunacy.
- Adds an exact archive-addressing corollary and a machine-readable statement: `14! < 103,800,788,359 < 15! <= 18!`.
- Keeps the boundary explicit: the cards can carry a declared archive index inside one equal-weight fiber; the external archive supplies the ordinate. No new zero, uncomputed tail, archive extension or RH claim is made.
- Replays the actual Telescope evaluator on all 20,825 unordered triples and preserves the exact `15,222 + 3,760 + 1,220 + 623` census.
- Keeps all deployable files below Cloudflare's 25,000,000-byte per-file limit; the largest is 18,766,967 bytes.

## Citation

For Telescope-specific results, cite Jeffery Lyn Huckstead, *Telescope 51: What a Rule Can See*, v0.2 working edition, Cerebral Graphix, 20 September 2026, using the canonical Telescope page. When describing the fixed card order, outside marker or factorial decoder, also cite *The Line Game | Surprise Is Not Meaning* v7.2, DOI `10.5281/zenodo.22851517`.
