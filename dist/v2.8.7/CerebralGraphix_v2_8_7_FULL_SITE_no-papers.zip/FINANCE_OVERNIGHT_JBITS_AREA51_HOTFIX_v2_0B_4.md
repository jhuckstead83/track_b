# Finance overnight + jbits + Area 51 hotfix · v2.0B.4

## Changes

1. **Overnight state:** session identity is no longer suppressed solely because global coverage is below 60%. Fresh `active=true`, `session=OVERNIGHT`, `status=OK` payloads with at least one finite chamber reading enter teal mode. Coverage grade remains visible; `REJECT` is shown as `OVERNIGHT · LIMITED`, and missing cells remain dashes. Stale, inactive, error, wrong-session and empty overlays still fail closed.
2. **Overnight trace:** Finance Live records unique overnight global-median samples observed by that browser (maximum 96) and draws a small line trace. A gap longer than 90 minutes starts a new local trace so separate nights are not visually connected. It is explicitly browser-local and does not alter the public ledger.
3. **Shared jbits:** Finance imports the same Area 51 v2.0B2 wallet. A finance stake has a 2-jbit minimum and may be increased with the shared stake selector. Each tile position marks as `stake × (1 + Δbps / 10,000)` from its entry reading. `Exit & clear` settles the marked value back to the shared bank and removes the local position. Positions freeze at their last mark if the displayed rail changes or a live mark has aged past 12 hours.
4. **Area 51 bridge:** Finance hub, live grid and historical chart navigation now link directly to `/area-51/`.

## Boundary

The finance wager is a local game layer on descriptive market data. It places no market trades, jbits have no cash value, and Landauer's principle is used only as a design metaphor for non-free recorded state change—not as a physical unit conversion.
