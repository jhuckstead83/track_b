# Area 51 v2.0B — Hotfix 2

Date: 2026-09-21

This patch is intentionally limited to the two reported defects.

## Fixed

1. **The shared jbit bank no longer stays on “Opening bank…” when IndexedDB is unavailable, blocked, or never answers.**
   - IndexedDB remains the primary store.
   - A one-second open guard now moves the same wallet API to same-origin local storage.
   - If all persistent browser storage is disabled, the current page still receives an in-memory bank so the games can deal and play.
   - Existing valid v2 and legacy wallet records are retained when they can be read.
   - The new cache-fingerprinted entry points are used by the Area 51 hub, Invariant, Blackjack 51, Telescope 51, and Memory 51 so every table opens the same fixed bank implementation.

2. **The Telescope 51 table is centered.**
   - The page’s later `.game` margin shorthand had overwritten the shared `.shell` centering.
   - `.game.shell` now explicitly restores automatic inline margins without changing the accepted table width or internal layout.

## Deployment

- The full-site archive can replace the current site package.
- The delta archive is relative to `CerebralGraphix_v2_0B_AREA_51_HOTFIX_FULL_SITE.zip` (the preceding hotfix).
- Preserve paths when applying the delta; it contains new `v2-0b2` browser assets plus the HTML entry-point updates.
- Old fingerprinted assets are intentionally retained for safe rollback and cached open tabs.

## Verification receipt

- 339 focused checks passed.
- Reproduced a hung IndexedDB open and confirmed prompt fallback, an 8-jbit opening balance, a funded action, and reload persistence.
- Rechecked Blackjack’s persistent shoe, settlement, and shared-wallet reconciliation.
- Rechecked Telescope ticket repeat protection and Invariant’s published finish/cycle fixtures.
- Parsed all maintained HTML and JavaScript entry points and verified local references.

Not claimed: a rendered multi-device browser pass or real simultaneous-tab stress test. No browser executable is available in this build environment.
