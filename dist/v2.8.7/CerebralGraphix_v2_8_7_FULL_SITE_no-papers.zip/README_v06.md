Cerebral Graphix site v06 runway + glossary

Public-entry cleanup:
- plain-language hero
- one fraction-to-character demo on homepage
- builder-facing notes removed or rephrased
- Maker’s Mark full payload moved to /tools/makers-mark.html
- homepage Maker’s Mark is now a teaser
- Finance Weather casing normalized
- Finance Weather glossary added at /finance/glossary.html
- site-index.json and site-index.html updated when possible

Upload this ZIP to Cloudflare Pages as a new production deployment.
