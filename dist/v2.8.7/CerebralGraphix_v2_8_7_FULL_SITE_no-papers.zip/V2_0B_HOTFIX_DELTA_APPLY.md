# v2.0B hotfix delta

Apply this overlay only to the exact supplied baseline:

`CerebralGraphix_v2_0B_REVIEW_FULL_SITE.zip`  
SHA-256: `eeb9c0b01467a1513f335e672c2d9e3ec83c9a48095574dcf70df5c30c9e58b4`

Extract the delta at the deployed site root and allow matching files to be replaced. The delta adds fingerprinted assets and updates the six entry pages, shared wallet source, and focused test. It deletes nothing.

After deployment, hard-refresh and check:

1. `/` — the green Invariant hero card is styled.
2. `/area-51/` — the bank displays a number rather than an em dash.
3. `/area-51/invariant/` — `Deal this order` and `Play one turn` work.
4. `/area-51/blackjack-51/` — `Deal a hand` produces cards and debits the selected stake.
5. `/area-51/telescope-51/` — the round and bank initialize.
6. `/area-51/memory-51/` — the same balance appears and recall remains playable.

The complete change boundary is recorded in `AREA_51_v2_0B_HOTFIX_NOTES.md`.
