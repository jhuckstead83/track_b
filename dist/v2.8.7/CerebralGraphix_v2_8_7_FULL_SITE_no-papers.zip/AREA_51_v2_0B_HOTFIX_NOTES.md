# Cerebral Graphix v2.0B — Area 51 startup hotfix

Date: 21 September 2026  
Baseline: `CerebralGraphix_v2_0B_REVIEW_FULL_SITE.zip`  
Scope: homepage hero, shared jbit startup, and playable deal controls only.

## Fixed

- The homepage now loads the Area 51 hero rules from the new fingerprinted asset `/assets/site-v2-0b.css`. This removes the reused-asset cache ambiguity that caused the earlier hero regression.
- The maintained Area 51 entry scripts are fingerprinted as `v2-0b`, so a deployment cannot combine the new pages with an older wallet or game module.
- The shared wallet accepts the deployed `cerebralgraphix.area51.credits.v1` legacy shape, including a balance expressed in jbits rather than hundredths.
- An unreadable or incompatible early bank can no longer stop every game from initializing. It safely opens the current 8-jbit play bank instead. This may reset an incompatible pre-release balance; no paper, proof, or research record is affected.
- Memory 51 now shows a loading mark until the shared bank answers instead of displaying a hard-coded `8` that could conceal a failed connection.

## Preserved

- The supplied v2.0B UI and table layout are unchanged.
- Invariant's published transition, finish, loop, decoder, and `y_n` boundary are unchanged.
- Blackjack rules and persistent-shoe engine are unchanged.
- Telescope and Memory rules are unchanged.
- Finance, papers, archives, metadata, and live-data code are unchanged.

## Validation

- 334 scoped assertions passed.
- Seven maintained HTML pages, 25 scripts, and 175 local references passed the package checks.
- Shared-wallet migration, rollback, duplicate receipts, Blackjack deal/settlement, cross-game balance, Telescope repeat protection, Invariant finish/loop, and all fingerprinted entry points passed.
- Largest deployable file: 18,766,967 bytes; no file exceeds the 25,000,000-byte Cloudflare limit.

No browser executable was available in this build environment. The required final gate is a live hard-refresh check of `/`, `/area-51/`, and each of the four game routes after deployment.
