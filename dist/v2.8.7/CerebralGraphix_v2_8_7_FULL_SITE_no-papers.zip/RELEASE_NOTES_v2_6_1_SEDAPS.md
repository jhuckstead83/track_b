# Cerebral Graphix v2.6.1 — SEDAPS sidecar + small UI repairs

Patch prepared from the supplied v2.6.0 full-site package.

## New

- Added `/area-51/sedaps-51/` with the 51 SEDAPS four-predecessor demo, local CSS/JS, an exact witness verifier, the Astra handoff, and a working-note source/PDF.
- Added 51 SEDAPS to the Area 51 hub, game menus, and research index.

## Blackjack 51

- Mobile observation history now stays visible and stacks below **Look before you leap**; only its extra heading copy is hidden on small screens.
- Scoped the ledger first-column width rule to the ledger so Rule Card price tables no longer collapse the first column into one-character wrapping.
- Replaced visible uses of the outside card marker `I` with the Roman numeral `Ⅰ`.

## Telescope 51

- Wallet snapshot notifications no longer rebuild all player cards when the balance has not changed. This keeps a tapped-card action dialog anchored/persistent instead of dropping out during repeated unchanged credit snapshots.

## Marker glyph sweep

- Updated current Invariant, Blackjack, Memory, shared card helper, and Prospect token labels so the outside marker is displayed as Roman numeral `Ⅰ`, not pronoun-style `I`. Historical versioned source copies were not rewritten.

## Scope

The 51 SEDAPS predecessor theorem is for the published three-queue capture rule. The four-seat Spades adapter remains visibly open; no theorem is transferred to four-player Spades yet. RH remains open.
