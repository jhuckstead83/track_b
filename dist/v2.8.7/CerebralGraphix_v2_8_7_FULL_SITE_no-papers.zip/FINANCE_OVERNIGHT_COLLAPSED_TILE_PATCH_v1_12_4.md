# Finance overnight collapsed-tile hotfix - v1.12.4

## Scope

This is a renderer-only correction for `/finance/live`.

The transport and normalization paths were already working: the live overnight overlay reached
the browser and appeared in the expanded tile. The collapsed tile still selected the base-close
field in median mode, while its subline selected base-period breadth. When breadth was absent,
the collapsed tile therefore said `awaiting` despite holding a valid overnight median.

## Correction

- Median mode with the overlay enabled now selects `c.overnight` for the collapsed headline.
- The collapsed subline retains `c.base` as the comparison close.
- Turning the overlay off restores the base-close headline and base breadth subline.
- Breadth mode remains the declared base-period `c.breadth`; no overnight breadth is invented.
- A chamber with a genuinely missing overnight median remains missing instead of silently
  substituting its close.
- The production script query was bumped from `v=3` to `v=4` so Cloudflare/browser caches do
  not preserve the defective renderer.

## Preserved boundaries

- No notebook, R2, provider-selection, schema, chamber placement, drag behavior, CSS, or
  Cloudflare Function change.
- Null values are not coerced to zero.
- The canonical 16-cell order is unchanged.
- `market_truth: NOT_PROVEN_BY_RECEIPT` and `trade_permission: NO` are unchanged.

## Live-feed verification input

At audit time, the public overlay reported:

- session: `OVERNIGHT`
- 16 canonical chamber rows
- 15 finite `overlay_median_bps` values
- 16 finite `base_close_bps` values
- one intentionally missing overnight median

Expected collapsed median-mode behavior is therefore 15 overnight numbers and one explicit
missing number, each with its close retained underneath.
