# Cerebral Graphix v2.8.2 · Finance tab hotfix

Based on v2.8.1. No deployment performed.

- Remove the separate dotted drag grip. Drag the Finance label itself with mouse or touch; arrow keys move it when focused.
- The larger chevron is a separate 44-pixel button that shows/hides only the grid. The collapsed tab stays visible during downtime and across page reloads after engagement.
- The X retains the confirmation dialog and remembered hide preference. Cancel keeps the monitor; the footer restores it.
- Preserve the assigned colors, reference baseline, live indicator, hero timing, games and research.

Four focused interaction groups passed: collapse during reference downtime; label pointer/keyboard movement; reload and reopen; X confirmation/cancel/restore. See VALIDATION_v2_8_2.json. These are simulated DOM checks, not a rendered-browser or physical-device check.

The regression test is tests/v2_8_2/check-dock.cjs (requires linkedom 0.18.13). The input screenshot was reviewed directly. All v2.8.1 files remain present; MANIFEST_v2_8_2.json records the delta.
