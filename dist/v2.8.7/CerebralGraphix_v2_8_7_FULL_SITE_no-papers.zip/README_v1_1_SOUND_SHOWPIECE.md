# Cerebral Graphix v1.1 — Sound + Showpiece Integration

This package folds the current website, the returned Rational Address Showpiece package, and the Forge OS Sound artifacts into one reviewable website distribution.

## Added routes

```text
/tools/rational_address_showpiece/
/tools/rational_address_showpiece/method.html
/tools/rational_address_showpiece_portable.html
/tools/forge_os_v16.3.html
/tools/sound_volume_source_note_forge_v12.html
/tools/sound_volume_source_note_forge_v12.md
/tools/forge_os_v12.html
```

## Public posture

- Rational Address Showpiece = classical composite geometry instrument.
- Forge OS v16.3 = The Rhythm Forge, an offline just-intonation synth/sequencer.
- Forge OS v12 = documented before/source artifact for the Sound volume.
- Sound source note = explanatory source material, not a claim page.

## Homepage changes

The homepage Tools section now includes:

1. Rational Address Showpiece
2. Forge OS v16.3 — The Rhythm Forge, with links to the origin note and v12 source

## Use options

### Full site replacement

Use:

```text
cerebralgraphix_site_v1_1_sound_showpiece.zip
```

### Overwrite patch

Use:

```text
cerebralgraphix_v1_1_overwrite_patch.zip
```

Copy its contents over the current site root.

## Checks

```json
{
  "tools_rational_address_showpiece_index_html_exists": true,
  "tools_rational_address_showpiece_method_html_exists": true,
  "tools_forge_os_v12_html_exists": true,
  "tools_forge_os_v16_3_html_exists": true,
  "tools_sound_volume_source_note_forge_v12_html_exists": true,
  "tools_sound_volume_source_note_forge_v12_md_exists": true,
  "homepage_has_showpiece": true,
  "homepage_has_forge": true,
  "tools_index_has_forge": true,
  "tools_index_has_showpiece": true,
  "site_index_has_all": true,
  "site_json_has_all": true,
  "sitemap_has_all": true,
  "sitemap_xml_valid": true,
  "json_valid": true,
  "routes_no_global_exclude": true,
  "js_syntax_tools_rational_address_showpiece_index_html": true,
  "js_syntax_tools_forge_os_v12_html": true,
  "js_syntax_tools_forge_os_v16_3_html": true
}
```

## Node syntax checks

```json
{
  "tools/rational_address_showpiece/index.html": {
    "return_code": 0,
    "stderr": ""
  },
  "tools/forge_os_v12.html": {
    "return_code": 0,
    "stderr": ""
  },
  "tools/forge_os_v16.3.html": {
    "return_code": 0,
    "stderr": ""
  }
}
```
