# Jbits total-ownership hotfix — v2.0B.5

The reserve now uses **available bank + active finance holdings** when deciding whether the passive refill is eligible.

- If bank + holdings is **8 jbits or more**, the recovery cursor is pinned and no timed jbits are issued.
- If bank + holdings is **below 8**, the existing 1-jbit-per-5:10 reserve can refill only the gap to 8.
- Finance holdings use the latest locally observed marked value (`lastValueCents`, falling back to `stakeCents`).
- A user with `0 bank + 8 held` now sees **Reserve covered by holdings** instead of a refill countdown.
- The bank and finance holdings remain browser-local play state; jbits have no monetary value.
