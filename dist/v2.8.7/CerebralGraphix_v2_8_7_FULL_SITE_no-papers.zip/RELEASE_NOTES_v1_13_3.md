# Cerebral Graphix v1.13.3

Status: built and checked; not deployed.

## Finance Weather

- A fresh public overnight artifact now puts the board into automatic teal `OVERNIGHT` mode. There is no manual overlay switch.
- Overnight tiles show the overnight BPS reading and coverage only. Close, base and delta comparisons are removed from the browser renderer.
- Activation requires `active: true`, `session: OVERNIGHT`, `status: OK`, a valid creation time no more than 20 minutes old, usable global coverage, and at least one finite chamber reading.
- `REJECT` and `INACTIVE` coverage, a reported coverage ratio below 60%, stale output, error output, or missing readings fail closed to the regular or last-known-good view.
- The page checks for newer public data every five minutes. If an active overnight artifact expires while the page is open, its regular context is restored and a refresh begins.
- The chart history remains a full visual feature directly below the grid.

The Cloudflare Functions, routes, data endpoints, stored Finance data and notebook are unchanged in this website release.

## Research and public copy

- The local Reading Volume remains document v4.7. Its current publication link is Zenodo record 22844194, repository record v41.
- The catalogue contains 61 repository records. That is not a claim of 61 distinct works.
- Zenodo record 22844207 is linked in both directions with record 20792999 as an updated edition of the same dual-titled work.
- Public presentation gives **The Line Game** the lead position. **Surprise Is Not Meaning** remains the second title and the proposition examined by the game, not a philosophical conclusion visitors must accept.
- The Postmaster status guide now explains five claim labels in reader-facing language and points to the exact sections that define the open boundary.
- Temporary release-cutoff language and other update-workbench copy have been removed from public pages.

## Validation

- 30 static source, structure, asset, content and preservation checks passed.
- The isolated overnight renderer suite passed fresh, stale, inactive, wrong-session, error, missing-time, missing-reading and rejected-coverage cases.
- Both XML files and every JSON file parse successfully.
- The hosted v4.7 PDF is byte-identical to the uploaded document.
- A Chromium browser suite is included for a preview environment, but it was not executed here because this runtime did not contain a browser binary and could not download one.
- No live provider, Cloudflare preview, or physical iPhone/Safari test was performed.

