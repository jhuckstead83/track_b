# Cerebral Graphix beta-unblind patch

Updated files in this overlay:

- `index.html`
- `tools/index.html`
- `finance/index.html`
- `finance/live.html`
- `site-index.html`
- `site-index.json`
- `sitemap.xml`

Purpose:

- Unblind Finance Weather as a public beta dashboard.
- Add explicit beta/firewall language.
- Add direct `/finance/live.html` references.
- Add Six Cardinal Picone tool references.
- Update sitemap with stable pages only.

Boundary:

```text
market_truth: NOT_PROVEN_BY_RECEIPT
trade_permission: NO
```

Apply by dropping these files over the matching paths in the existing website folder, then redeploying the full folder or merged ZIP to Cloudflare Pages.
