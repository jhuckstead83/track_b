# Φ Finance Weather — v1.10.1 Same-Origin Live-Data Bridge

## Scope

Website side only. The notebook is untouched and may continue running.

The public browser no longer fetches the live R2 JSON directly across origins.
Instead:

1. Browser requests `/finance/live-data` from `cerebralgraphix.com`.
2. A Cloudflare Pages Function fetches the R2 live rail server-side.
3. The Function prefers the future `chamber_grid_public.json` only when it
   passes the public membrane check.
4. Until Stage 4, it falls back to `sector_plot_data.json`, sanitizing each
   row through an explicit aggregate-field allowlist.
5. If the live bridge is unavailable, the browser still falls back to the
   bundled static aggregate snapshot.

## Public browser chain

`/finance/live-data` -> current R2 safe aggregate -> bundled static fallback

No browser-to-R2 CORS dependency remains in the primary live path.

## Membrane

The current aggregate bridge returns only these fields when adapting
`sector_plot_data.json`:

- snapshot_utc
- snapshot_et
- market_date_et
- plot_time_label
- sector_code
- sector_label
- avg_bps
- median_bps
- weighted_avg_bps
- net_breadth
- fresh_ratio
- rolling_5read_median_bps
- rolling_5read_weighted_avg_bps
- rolling_5read_net_breadth

Named asset fields are not forwarded.

## Notebook status

No notebook file was modified.

The long historical tail, public export surgery, and ledgered `cell_status`
remain deferred until the later one-window notebook surgery.

## Deployment caveat

Cloudflare Pages Functions must be deployed through Git integration or
Wrangler. Cloudflare's current documentation says dashboard Direct Upload is
not supported with Functions.

If this project is deployed by dashboard Direct Upload only, use the R2 CORS
policy route instead of expecting this Function to activate.
