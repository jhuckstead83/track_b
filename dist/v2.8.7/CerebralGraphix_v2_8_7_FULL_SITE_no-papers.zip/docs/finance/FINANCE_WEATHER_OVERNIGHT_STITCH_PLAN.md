# Finance Weather overnight stitch · implementation draft

## Freeze the semantic object

The 16-cell board remains canonical:

| | Upstream / input | Production | Transmission | Downstream / consumer |
|---|---|---|---|---|
| Defensive | Utilities | Real Estate | Food | Healthcare |
| Upper middle | Defense | Banks | Macro ETF | Telecom |
| Lower middle | Energy | Materials | AI Big | Media |
| Cyclical | AI Semis | Industrials | Autos / EV | Retail |

The board is not a ranked list. Its rows encode **defensive → cyclical** and its columns encode **upstream → downstream**. Those coordinates must remain in the data contract even when another view ranks features.

## Overnight is an overlay, not a source replacement

The primary/base chamber plate remains readable underneath. During the overnight window, publish a second typed ledger:

- base provider: E*TRADE;
- base role: primary close plate;
- overlay provider: Alpaca;
- feed: `OVERNIGHT_DERIVED`;
- quote state: `REALTIME_INDICATIVE`;
- coverage scope: `NON_CONSOLIDATED`;
- overlay role: `OVERNIGHT_VS_CLOSE`;
- market truth: `NOT_PROVEN_BY_RECEIPT`;
- trade permission: `NO`.

Each tile shows:

1. `BASE CLOSE`, the existing chamber median;
2. `OVERNIGHT`, the fresh overnight chamber median;
3. `Δ`, overnight minus base;
4. fresh-symbol coverage, such as `8/10 · USABLE_PARTIAL`.

Missing overnight coverage leaves the base tile intact. It never turns a missing reading into zero.

## Public artifact contract

Add:

```text
/finance/latest/overnight_overlay.json
/finance/latest/overnight_overlay_chambers.csv
```

The JSON should carry:

```text
session
active
provider
feed
quote_state
trade_state
coverage_scope
base_provider
base_role
overlay_role
global_overlay_median_bps
global_coverage_ratio
chambers[]
```

Each chamber record carries canonical `row`, `col`, and `cell` plus the base, overlay, difference, and coverage fields.

## UI behavior

- Default: fixed 4×4 board.
- Overnight overlay: on/off toggle.
- Rank shelf: optional secondary list sorted by base pressure, overnight difference, or breadth.
- The rank shelf does not move or relabel the semantic board.
- A future movement animation may use visible one-cell king steps, but no tile may silently acquire a new semantic coordinate.
- On narrow screens, keep the 4×4 board intact inside a horizontal scroll frame rather than collapsing it into a misleading one-dimensional list.

## Rollout order

1. Clear all notebook outputs containing authorization links, request tokens, or verifier text.
2. Paste and run `PHI_OVERNIGHT_OVERLAY_PATCH_v0_1.py` after the publisher definition.
3. Run one forced diagnostic call:

```python
result, chambers, symbols = phi_build_overnight_overlay(force=True)
display(chambers)
```

4. Confirm no secret values are printed or persisted.
5. Confirm all 16 canonical chamber rows are present, even when overlay coverage is absent.
6. Confirm `overnight_overlay.json` is written and uploaded by the existing R2 all-latest-files uploader.
7. Test Sunday evening, weekday overnight, pre-market, regular, after-hours, Friday after 4 a.m., and Saturday closed states.
8. Test the design artifact at 320, 360, 390, 412, 430, 768, and desktop widths.
9. Hand the functioning artifact to Claude for visual polish only. Preserve the contract and fences.

## Current status

Verified from saved outputs:

- the base 5-minute pipeline runs;
- the 16-chamber board definition exists and is fixed on two axes;
- the free `overnight` probe returns usable live indicative quote timestamps;
- direct `boats` access returns an entitlement error;
- the production router does not yet aggregate the overnight feed into all 16 chambers;
- the published overnight overlay file does not yet exist.

Therefore the remaining work is integration and testing, not purchase of a subscription.
