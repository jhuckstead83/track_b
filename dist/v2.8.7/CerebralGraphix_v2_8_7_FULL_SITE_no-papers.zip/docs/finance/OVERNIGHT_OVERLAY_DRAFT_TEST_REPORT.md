# Draft test report

## Passed

- Python patch compiles with `py_compile`.
- Mock provider aggregation produced all 16 canonical chambers and 32 test symbol rows.
- Mock full coverage graded `COMPLETE` for all 16 chambers.
- Overlay median and base-difference arithmetic matched the locked expected values.
- Ten session-boundary cases passed, covering Sunday open, weekday overnight, pre-market, regular, after-hours, Friday close, and Saturday closed.
- Embedded Design Component JavaScript passed Node syntax validation.
- The design seed contains exactly 16 canonical cells in row/column order.

## Not yet proven

- No live provider request was made from this environment.
- No R2 upload was performed from this environment.
- The `.dc.html` file was not visually rendered here because the local headless Chromium process did not terminate reliably with the Claude Design support runtime. Claude Design/browser review remains required.
- Mobile visual QA remains required at the listed widths.

## Security note

The shared notebook currently contains saved OAuth authorization output. Clear all outputs before distributing another public notebook copy, even when the displayed request token is believed expired.
