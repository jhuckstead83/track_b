# Φ-OVERNIGHT-CHAMBER-OVERLAY-v0.1
# Paste/run AFTER:
#   - Φ-PUBLIC-EXTENDED-HOURS-BRIDGE-v0.2
#   - chamber placement and basket cells
#   - intraday publisher definition
#
# Purpose:
#   Preserve the canonical 4×4 chamber board and publish a separate overnight
#   indicative overlay. The overlay never replaces the E*TRADE/base plate.
#
# Public boundary:
#   market_truth: NOT_PROVEN_BY_RECEIPT
#   trade_permission: NO
#   provider: Alpaca free derived overnight feed
#   quote state: indicative, non-consolidated

from pathlib import Path
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import json, math, shutil, zipfile
import pandas as pd

PHI_OVERNIGHT_OVERLAY_VERSION = "Φ-OVERNIGHT-CHAMBER-OVERLAY-v0.1"
PHI_OVERNIGHT_FEED = "overnight"
PHI_OVERNIGHT_QUOTE_MAX_AGE_SECONDS = 180
PHI_OVERNIGHT_MIN_DIAGNOSTIC_RATIO = 0.60
PHI_OVERNIGHT_MIN_USABLE_RATIO = 0.80
PHI_OVERNIGHT_MARKET_TRUTH = "NOT_PROVEN_BY_RECEIPT"
PHI_OVERNIGHT_TRADE_PERMISSION = "NO"
PHI_OVERNIGHT_TZ = ZoneInfo("America/New_York")


def phi_market_session_et_v2(now=None):
    """Explicit regular, pre/post, overnight, and closed session classifier."""
    current = pd.Timestamp(now) if now is not None else pd.Timestamp.now(tz=PHI_OVERNIGHT_TZ)
    if current.tzinfo is None:
        current = current.tz_localize(PHI_OVERNIGHT_TZ)
    else:
        current = current.tz_convert(PHI_OVERNIGHT_TZ)

    wd = int(current.weekday())  # Monday=0, Sunday=6
    minute = current.hour * 60 + current.minute

    overnight = (
        (wd == 6 and minute >= 20 * 60) or
        (wd in {0, 1, 2, 3} and (minute < 4 * 60 or minute >= 20 * 60)) or
        (wd == 4 and minute < 4 * 60)
    )

    if overnight:
        session = "OVERNIGHT"
    elif wd <= 4 and 4 * 60 <= minute < 9 * 60 + 30:
        session = "PREMARKET"
    elif wd <= 4 and 9 * 60 + 30 <= minute < 16 * 60:
        session = "REGULAR"
    elif wd <= 4 and 16 * 60 <= minute < 20 * 60:
        session = "AFTER_HOURS"
    else:
        session = "CLOSED"

    return {
        "session": session,
        "now_et": current.isoformat(),
        "is_overnight_window": session == "OVERNIGHT",
        "is_extended_window": session in {"PREMARKET", "AFTER_HOURS", "OVERNIGHT"},
        "is_regular_window": session == "REGULAR",
    }


def _phi_overlay_grade(ratio):
    ratio = float(ratio or 0.0)
    if ratio >= 1.0 - 1e-12:
        return "COMPLETE"
    if ratio >= PHI_OVERNIGHT_MIN_USABLE_RATIO:
        return "USABLE_PARTIAL"
    if ratio >= PHI_OVERNIGHT_MIN_DIAGNOSTIC_RATIO:
        return "DIAGNOSTIC_ONLY"
    return "REJECT"


def _phi_overlay_float(value):
    try:
        f = float(value)
        return f if math.isfinite(f) else None
    except Exception:
        return None


def _phi_overlay_timestamp(value):
    ts = pd.to_datetime(value, errors="coerce", utc=True)
    return None if pd.isna(ts) else ts


def _phi_overlay_all_baskets():
    out = {}
    for code, meta in (globals().get("SECTOR_BOOK") or {}).items():
        code = str(code).upper().strip()
        if code == "GLOBAL_STACK":
            continue
        symbols = []
        for raw in str((meta or {}).get("symbols") or "").split(","):
            symbol = raw.upper().strip()
            if symbol and symbol not in symbols:
                symbols.append(symbol)
        if symbols:
            out[code] = symbols
    return out


def _phi_overlay_latest_symbol_frame():
    for name in ["latest_symbol_pressure", "multi_sector_floor_df", "floor_df"]:
        frame = globals().get(name)
        if isinstance(frame, pd.DataFrame) and not frame.empty:
            return frame.copy()
    return pd.DataFrame()


def _phi_overlay_baseline_map():
    """Recover prior-close anchors from the already collected primary/base rail."""
    frame = _phi_overlay_latest_symbol_frame()
    out = {}
    if frame.empty:
        return out

    sym_col = "returned_symbol" if "returned_symbol" in frame.columns else "symbol"
    for _, row in frame.iterrows():
        symbol = str(row.get(sym_col) or "").upper().strip()
        if not symbol:
            continue

        previous_close = None
        for key in ["previousClose", "previous_close", "prev_close"]:
            previous_close = _phi_overlay_float(row.get(key))
            if previous_close and previous_close > 0:
                break

        price = None
        for key in ["price", "lastTrade", "last_price", "close"]:
            price = _phi_overlay_float(row.get(key))
            if price and price > 0:
                break

        base_bps = None
        for key in ["preferred_weather_move_bps", "move_bps", "median_bps"]:
            base_bps = _phi_overlay_float(row.get(key))
            if base_bps is not None:
                break

        if (previous_close is None or previous_close <= 0) and price and base_bps is not None:
            denom = 1.0 + base_bps / 10000.0
            if denom > 0:
                previous_close = price / denom

        if previous_close and previous_close > 0:
            out[symbol] = previous_close
    return out


def _phi_overlay_fetch_snapshots(symbols):
    """Free derived overnight rail. This is distinct from direct BOATS entitlement."""
    headers = _phi_alpaca_headers()
    session = globals().get("PHI_PROVIDER_HTTP_SESSION")
    if session is None:
        import requests
        session = requests.Session()

    snapshots = {}
    request_ids = []
    unique = []
    for symbol in symbols:
        s = str(symbol).upper().strip()
        if s and s not in unique:
            unique.append(s)

    chunks = _phi_chunked(unique, 50) if "_phi_chunked" in globals() else [unique[i:i+50] for i in range(0, len(unique), 50)]
    for chunk in chunks:
        response = session.get(
            "https://data.alpaca.markets/v2/stocks/snapshots",
            params={"symbols": ",".join(chunk), "feed": PHI_OVERNIGHT_FEED},
            headers=headers,
            timeout=25,
        )
        request_id = response.headers.get("X-Request-ID")
        if request_id:
            request_ids.append(request_id)
        if response.status_code >= 400:
            body = response.text[:500]
            if "_phi_redact_provider_text" in globals():
                body = _phi_redact_provider_text(body)
            raise RuntimeError(f"Alpaca overnight HTTP {response.status_code}: {body}")
        payload = response.json()
        returned = payload.get("snapshots", payload) if isinstance(payload, dict) else {}
        if isinstance(returned, dict):
            snapshots.update(returned)
    return snapshots, sorted(set(request_ids))


def _phi_overlay_quote(snapshot):
    quote = (snapshot or {}).get("latestQuote") or {}
    trade = (snapshot or {}).get("latestTrade") or {}

    bid = _phi_overlay_float(quote.get("bp", quote.get("bid_price")))
    ask = _phi_overlay_float(quote.get("ap", quote.get("ask_price")))
    qts = _phi_overlay_timestamp(quote.get("t", quote.get("timestamp")))

    price = None
    source = None
    if bid and ask and bid > 0 and ask > 0 and ask >= bid:
        price = (bid + ask) / 2.0
        source = "indicative_midpoint"
    elif bid and bid > 0:
        price = bid
        source = "indicative_bid"
    elif ask and ask > 0:
        price = ask
        source = "indicative_ask"
    else:
        price = _phi_overlay_float(trade.get("p", trade.get("price")))
        qts = _phi_overlay_timestamp(trade.get("t", trade.get("timestamp")))
        source = "delayed_trade_fallback" if price else None

    age = None
    if qts is not None:
        age = max(0.0, (pd.Timestamp.now(tz="UTC") - qts).total_seconds())
    return price, qts, age, source


def phi_build_overnight_overlay(force=False):
    session = phi_market_session_et_v2()
    baskets = _phi_overlay_all_baskets()
    expected_symbols = sorted({s for values in baskets.values() for s in values})

    result = {
        "ledger": PHI_OVERNIGHT_OVERLAY_VERSION,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "session": session["session"],
        "active": bool(session["is_overnight_window"]),
        "provider": "ALPACA",
        "feed": "OVERNIGHT_DERIVED",
        "source_label": "ALPACA · OVERNIGHT_DERIVED",
        "quote_state": "REALTIME_INDICATIVE",
        "trade_state": "DELAYED_FALLBACK_ONLY",
        "coverage_scope": "NON_CONSOLIDATED",
        "base_provider": "ETRADE",
        "base_role": "PRIMARY_CLOSE_PLATE",
        "overlay_role": "OVERNIGHT_VS_CLOSE",
        "market_truth": PHI_OVERNIGHT_MARKET_TRUTH,
        "trade_permission": PHI_OVERNIGHT_TRADE_PERMISSION,
        "chambers": [],
    }

    if not session["is_overnight_window"] and not force:
        result["status"] = "INACTIVE_OUTSIDE_OVERNIGHT_WINDOW"
        return result, pd.DataFrame(), pd.DataFrame()

    baselines = _phi_overlay_baseline_map()
    snapshots, request_ids = _phi_overlay_fetch_snapshots(expected_symbols)
    now_utc = pd.Timestamp.now(tz="UTC")
    symbol_rows = []

    symbol_to_sectors = {}
    for sector, symbols in baskets.items():
        for symbol in symbols:
            symbol_to_sectors.setdefault(symbol, []).append(sector)

    for symbol in expected_symbols:
        price, qts, age, source = _phi_overlay_quote(snapshots.get(symbol) or {})
        previous_close = baselines.get(symbol)
        fresh = bool(
            price and price > 0 and
            previous_close and previous_close > 0 and
            age is not None and age <= PHI_OVERNIGHT_QUOTE_MAX_AGE_SECONDS
        )
        overlay_bps = ((price / previous_close) - 1.0) * 10000.0 if fresh else None
        for sector in symbol_to_sectors.get(symbol, []):
            symbol_rows.append({
                "sector_code": sector,
                "symbol": symbol,
                "previous_close": previous_close,
                "overlay_price": price,
                "overlay_bps": overlay_bps,
                "quote_timestamp_utc": qts.isoformat() if qts is not None else None,
                "age_seconds": age,
                "fresh": fresh,
                "price_source": source,
                "provider": "ALPACA",
                "feed": "OVERNIGHT_DERIVED",
                "market_truth": PHI_OVERNIGHT_MARKET_TRUTH,
                "trade_permission": PHI_OVERNIGHT_TRADE_PERMISSION,
            })

    symbols_df = pd.DataFrame(symbol_rows)
    base_sector = globals().get("latest_sector_comparator")
    if not isinstance(base_sector, pd.DataFrame):
        base_sector = pd.DataFrame()

    chamber_rows = []
    for code, symbols in baskets.items():
        rows = symbols_df[symbols_df["sector_code"].eq(code)].copy() if not symbols_df.empty else pd.DataFrame()
        fresh_rows = rows[rows["fresh"].eq(True)].copy() if not rows.empty else pd.DataFrame()
        expected = len(symbols)
        fresh_count = int(fresh_rows["symbol"].nunique()) if not fresh_rows.empty else 0
        ratio = fresh_count / expected if expected else 0.0
        overlay_median = _phi_overlay_float(fresh_rows["overlay_bps"].median()) if not fresh_rows.empty else None
        overlay_average = _phi_overlay_float(fresh_rows["overlay_bps"].mean()) if not fresh_rows.empty else None

        base_median = None
        if not base_sector.empty and "sector_code" in base_sector.columns:
            hit = base_sector[base_sector["sector_code"].astype(str).str.upper().eq(code)]
            if not hit.empty:
                base_median = _phi_overlay_float(hit.iloc[0].get("median_bps"))

        delta = overlay_median - base_median if overlay_median is not None and base_median is not None else None
        place = (globals().get("PHI_CHAMBER_GRID") or {}).get(code, {})
        chamber_rows.append({
            "sector_code": code,
            "row": place.get("row"),
            "col": place.get("col"),
            "cell": place.get("cell"),
            "base_median_bps": base_median,
            "overlay_median_bps": overlay_median,
            "overlay_average_bps": overlay_average,
            "delta_from_base_bps": delta,
            "fresh_symbol_count": fresh_count,
            "expected_symbol_count": expected,
            "coverage_ratio": ratio,
            "coverage_grade": _phi_overlay_grade(ratio),
            "provider": "ALPACA",
            "feed": "OVERNIGHT_DERIVED",
            "quote_state": "REALTIME_INDICATIVE",
            "coverage_scope": "NON_CONSOLIDATED",
        })

    chambers_df = pd.DataFrame(chamber_rows).sort_values(["row", "col"], na_position="last")
    usable = chambers_df[chambers_df["overlay_median_bps"].notna()] if not chambers_df.empty else pd.DataFrame()
    result.update({
        "status": "OK" if not usable.empty else "NO_USABLE_OVERLAY_ROWS",
        "request_ids": request_ids,
        "global_overlay_median_bps": _phi_overlay_float(usable["overlay_median_bps"].median()) if not usable.empty else None,
        "global_overlay_average_bps": _phi_overlay_float(usable["overlay_median_bps"].mean()) if not usable.empty else None,
        "global_coverage_ratio": _phi_overlay_float(symbols_df.groupby("symbol")["fresh"].max().mean()) if not symbols_df.empty else 0.0,
        "chambers": chambers_df.to_dict(orient="records"),
    })
    return result, chambers_df, symbols_df


def _phi_overlay_write_json(path, payload):
    Path(path).write_text(json.dumps(payload, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")


def phi_publish_overnight_overlay(publish_result, force=False):
    result, chambers_df, symbols_df = phi_build_overnight_overlay(force=force)
    finance_root = Path(publish_result["finance_root"])
    latest_dir = finance_root / "latest"
    daily_dir = finance_root / "daily" / str(publish_result["day"])
    latest_dir.mkdir(parents=True, exist_ok=True)
    daily_dir.mkdir(parents=True, exist_ok=True)

    _phi_overlay_write_json(latest_dir / "overnight_overlay.json", result)
    _phi_overlay_write_json(daily_dir / "overnight_overlay.json", result)
    chambers_df.to_csv(latest_dir / "overnight_overlay_chambers.csv", index=False)
    chambers_df.to_csv(daily_dir / "overnight_overlay_chambers.csv", index=False)
    symbols_df.to_csv(daily_dir / "overnight_overlay_symbols.csv", index=False)

    manifest_path = latest_dir / "public_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else publish_result.get("manifest", {})
    manifest.setdefault("latest", {})["overnight_overlay_json"] = "/finance/latest/overnight_overlay.json"
    manifest["overnight_overlay"] = {
        "active": result.get("active"),
        "session": result.get("session"),
        "status": result.get("status"),
        "provider": result.get("provider"),
        "feed": result.get("feed"),
        "quote_state": result.get("quote_state"),
        "coverage_scope": result.get("coverage_scope"),
        "global_coverage_ratio": result.get("global_coverage_ratio"),
        "global_overlay_median_bps": result.get("global_overlay_median_bps"),
        "overlay_role": result.get("overlay_role"),
    }
    _phi_overlay_write_json(manifest_path, manifest)
    _phi_overlay_write_json(finance_root / "public_manifest.json", manifest)

    # Rebuild the public ZIP because the base publisher created it before this overlay.
    drive_zip = Path(publish_result["drive_zip"])
    if drive_zip.exists():
        drive_zip.unlink()
    with zipfile.ZipFile(drive_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for p in finance_root.rglob("*"):
            if p.is_file():
                z.write(p, p.relative_to(finance_root.parent))
    content_zip = Path(publish_result["content_zip"])
    content_zip.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(drive_zip, content_zip)

    publish_result["manifest"] = manifest
    publish_result["overnight_overlay"] = result
    globals()["latest_overnight_overlay"] = result
    globals()["latest_overnight_overlay_chambers"] = chambers_df
    globals()["latest_overnight_overlay_symbols"] = symbols_df
    print("Published:", PHI_OVERNIGHT_OVERLAY_VERSION)
    print("session:", result.get("session"), "status:", result.get("status"))
    print("overlay coverage:", result.get("global_coverage_ratio"))
    print("market_truth:", PHI_OVERNIGHT_MARKET_TRUTH)
    print("trade_permission:", PHI_OVERNIGHT_TRADE_PERMISSION)
    return publish_result


# Publisher wrapper. The normal base plate is published first; the overlay is then
# added as a separate public artifact before the existing R2 uploader runs.
if "_phi_publish_intraday_finance_bundle_base" not in globals():
    _phi_publish_intraday_finance_bundle_base = publish_intraday_finance_bundle


def publish_intraday_finance_bundle(manual_note=""):
    publish_result = _phi_publish_intraday_finance_bundle_base(manual_note)
    return phi_publish_overnight_overlay(publish_result, force=False)


print("Loaded:", PHI_OVERNIGHT_OVERLAY_VERSION)
print("Canonical 4×4 grid remains fixed; overnight is a separate overlay artifact.")
print("The existing R2 uploader will include overnight_overlay.json because it uploads every finance/latest file.")
print("market_truth:", PHI_OVERNIGHT_MARKET_TRUTH)
print("trade_permission:", PHI_OVERNIGHT_TRADE_PERMISSION)
