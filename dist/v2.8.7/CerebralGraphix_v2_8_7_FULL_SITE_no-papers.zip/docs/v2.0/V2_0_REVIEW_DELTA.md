# Cerebral Graphix v2.0 — review checkpoint and continuation delta

**Checkpoint date:** 2026-09-21. **Status:** implemented integration checkpoint; not deployed, visually approved, or a publication freeze. Work stops here at the owner's request to conserve the remaining budget and continue with Alpha and owner review.

Start from `CerebralGraphix_v2_0_REVIEW_FULL_SITE.zip`, or apply the accompanying delta to the exact `CerebralGraphix_v1_13_10_AREA_51_CORE_PAIR_FULL_SITE.zip` baseline. If the other side has newer work, compare changes before applying the overlay. The full site is the simplest review object. No additional DOI is assigned or needed for this checkpoint.

## The mission to preserve

The homepage has two clear entrances: **Watch Live Finance** and **Enter Area 51**. Area 51 is a place to play a precise experiment, encounter a question, and open the rule card when that question matters. Its order is **Invariant → Blackjack 51 → Telescope 51 → Memory 51**. Invariant is the cornerstone, with its own name and explicit lineage to **The Line Game | Surprise Is Not Meaning**, v7.2. It must not be reduced to another interchangeable card tile.

Every maintained game opens at the table. Rules, research, citations, versions, and functional explanations sit behind a clear **Rule Card / Live Paper** control. Use the Blackjack Alpha green felt, cream cards, gold accents, and readable hands across the family. Keep the rest of the homepage useful and preserve the Finance work.

The play balance is called **jbits**. This is a chosen game unit. Do not present it as measured Shannon information, physical energy, financial value, or proof of learning. Retain the distinction between a stored record, an encoding convention, what a player has seen, and what the game rule does with the order.

## Implemented in this checkpoint

| Surface | Implemented behavior |
| --- | --- |
| Homepage | Finance/Area 51 entrances and a prominent green Invariant hero; existing sections remain below. |
| Area 51 | Game-first hub with the requested hierarchy and shared visual language. |
| Invariant | New playable front at `/area-51/invariant/`; unchanged published v7.2 transition; published finish and one-swap cycle; hidden/visible hands, symbols, exact decoder, stepping/running, forgiveness, local prediction ledger and export. |
| Invariant research | Former maintained research interface retained at `/area-51/invariant/rule-card.html`, reachable from the table. The frozen `/research/line-game/` deposit is retained. |
| Blackjack 51 | Alpha table and persistent shoe/unfinished-hand engine integrated with the shared bank; 1/2/4/8 stakes, fractional settlements, paid observation, recall-game pop-out, replay and rule-card view. Keyboard play shortcuts pause while the rule card is open. |
| Blackjack odds | Safe/bust quote conditions on the dealer's completed blackjack check. A viewed quote is recorded with the saved game rather than a separate browser key. |
| Telescope 51 | Existing experiment presented table first in the green family style; theory behind Rule Card; shared bank adapter; repeated known positions and exposed twin positions become study rather than new funded tickets. |
| Memory 51 | All 51 exact published symbol/card pairs; study/reveal, four-choice recall, mixed or directed prompts, explicit next prompt, return to Blackjack. The answer is hidden before the response. |
| Shared bank | Integer hundredths, one IndexedDB transaction for bank/receipt/game checkpoint, idempotent receipts, cross-tab notification, capped timed recovery, conservative legacy-balance migration. |
| Routing and metadata | New rule-card route in sitemap, asset/header updates, release status file, and initial Area 51 research metadata updates. Full discovery metadata reconciliation remains open below. |

The two superseded Blackjack modules, `area-51/blackjack-51/app.js` and `blackjack-core.js`, are removed from the maintained route. The integrated HTML contains the Alpha engine and interface; `wallet-adapter.js` bridges them to the shared bank. Former Area 51 test entry points now invoke the new scoped suite.

## Current jbit rules — explicit, revisable game prices

| Event | Rule |
| --- | --- |
| First use | 8 jbits on this browser origin. |
| Recovery | +1 every 310 seconds while below 8; the final increment can be fractional. Winnings above 8 remain. No reload grant or accumulated refill bonus while already full. |
| Blackjack | Stakes 1, 2, 4, or 8; normal engine settlement, including 3:2 natural payout. Shoes continue across hands until the declared cut/rule change. |
| Full identity peek | 6 jbits in the maintained games that offer it. This is a declared price inspired by the six binary digits needed for a fixed-width address among 51 identities; it is not a universal information price. |
| Blackjack odds view | 1 jbit for the current decision, with a stable receipt. |
| Blackjack next-card forecast | 1-jbit stake; displayed safe/bust gross return comes from its conditional model and is rounded down to a hundredth. It is not an independent new strategy study. |
| Invariant next-turn prediction | 1-jbit stake in unexposed random exploration; correct prediction returns the current live-player count. This is a declared payoff, not a claim of equal winning probabilities. Published/source-known or exposed states are study. |
| Telescope ticket | 1-jbit stake where eligible; existing 4/17/51/100 reward schedule. Each fixed branch/round can fund once in this local ledger. Subsequent attempts are study. |
| Memory | Correct, unassisted four-choice recall earns 2 jbits, capped at 8 per UTC day. Study, incorrect answers, opening a window, and waiting in it earn no recall reward. |

The earlier proposal to reward time in Memory was replaced with an explicit response. Guessing can still succeed: the reward records a correct response under the displayed rule, not demonstrated comprehension. Daily timing is local-device timing in this checkpoint.

Wallet values use integer hundredths. Names such as `credits.js` and older receipt schema fields remain internal compatibility names; visible currency is jbits. The wallet is local to a browser origin. Clearing storage, altering code/data, or changing a device clock is outside the trusted-account model. A different hostname or localhost has a different bank. There is no site account or server-enforced economy in this delivery.

Existing site-wide v1 credit-ledger balances migrate without another opening grant. Legacy standalone Blackjack hands and separate standalone balances are **not** silently combined with that bank; an explicit migration decision would be needed. The new Blackjack engine and bank checkpoints are saved together. A reload restores their current state rather than granting a fresh shoe or balance.

## Mathematical and editorial boundaries

Keep the provenance chain visible: **source → model → order → rule → interpretation**. The stored integer selects an order within freedom left unresolved by the weight profile. Weights do not generate the ordinate. A bijective token relabeling, with its inverse, carries the same record; cards need not be numeric labels. The original and one-swap orders can share the complete model-weight profile while decoding different integers and producing different finite continuations under the fixed rule.

The encoding transports the supplied ordinate record; it does not independently compute a zeta zero or certify the tail of the zero set. Neither a surprising animation nor reader recognition upgrades the result into an RH proof. Preserve the source/precision statements and published DOI already in the baseline. Do not invent a verification height from the earlier conversation's uncertain recollection.

Generic War is useful explanatory context: concealed order, memory of revealed cards, repeated rank ties, and long sequences support anticipation. The published Invariant transition has a declared rank-and-suit order; its weight ties are not contest ties. Do not add generic-War tie rules, decimal tails, ace/two alternatives, or a new divisibility rule to the frozen engine. Put any future variants in a labeled lab.

Hiding information after it was exposed does not erase the observer's knowledge. “Surprise” needs an observer, prior information, a forecast or declared comparison, and an observed outcome. If a later interface uses `−log₂ p`, label the probability model and conditioning information. Jbit spending alone is not this quantity. Biological analogies, energy claims, and tail extrapolations remain outside the launch claims.

## What was checked, and what was not

The scoped checkpoint suite passed **326 assertions** in its first completed run: seven HTML pages, 175 local references, 17 script parses, wallet arithmetic/migration/receipts/recovery/recall limits, and selected game cases. The included final report is authoritative if those counts change after a subsequent edit.

- Invariant engine text matches the frozen v7.2 engine. The original finishes at turn **144**; the adjacent-swap run repeats from **1015** to **1535**, period **520**. Forgiveness preserves the 51-active-card accounting.
- Blackjack checks cover continued use of a shoe, a 3:2 natural settlement, fractional balance replay, and an independently enumerated conditional odds case.
- A simulated IndexedDB check exercises the actual wallet and adapter: transaction rollback, duplicate receipts, stale revision rejection, stake/settlement persistence, outside earnings, and Telescope replay restrictions.
- Baseline comparison found **82 Finance-named files**, **12 frozen Line Game files**, and all baseline PDFs byte-identical. No Finance source or live data was changed.

These are software checkpoint checks, not a new paper audit or a full browser pass. The prior Alpha and standalone test totals are historical; they do not certify the integrated v2 interface. The available browser could not open the local preview (`ERR_BLOCKED_BY_CLIENT`), so screenshots, touch behavior, real multiple-window behavior, and device rendering remain unverified. There is no deployment or live smoke-test claim.

Reproduce the scoped checks with Node after installing the pinned lockfile dependencies:

```sh
cd tests/v2
npm ci
node check.mjs
```

Serve the site root over HTTP for interactive review. Opening an HTML file directly is not the supported integration path for ES modules, fetches, or the shared IndexedDB origin.

## Remaining work, in priority order

1. **Owner/Alpha review of the actual table experience.** Open the homepage, hub, Invariant, Blackjack, Telescope and Memory. Confirm the intended hierarchy and that the table dominates the initial view. Compare with the separate newer build before merging any edits.
2. **Real-browser gate.** Inspect 320, 390, 440, 600, 768 and 1440 px, especially three-hand wrapping, card legibility, fixed controls, keyboard focus, reduced motion, no-JavaScript content, rule-card navigation and pop-out return. Exercise an unfinished Blackjack hand through reload and a Memory reward arriving in another window. Check stale-tab conflicts and storage-unavailable handling. No blanket retest of the published mathematics is requested.
3. **Finish discovery metadata coherently.** Reconcile page/social descriptions, Area 51 `research.json` nested legacy entries, `llms.txt`, site index, catalogue, Papers, Atlas, feed and sitemap dates. Some retain baseline release wording. Keep paper versions and deposited identifiers distinct from website v2.0; preserve older editions. Do not hard-code publication counts without checking the existing records.
4. **Review the economy as a product rule.** Approve the chosen 6-jbit peek, 2-jbit recall reward/8 daily cap, recovery interval, and forecast pricing as deliberate rules. Inspect whether legacy rule-card demonstrations could be mistaken for the shared bank; their research receipts must remain visibly separate. Decide whether a server-authoritative bank or explicit standalone-save importer is wanted later.
5. **Add compact observer accounting where helpful.** A next revision can show known/exposed identities, unresolved candidates under the selected projection, declared forecast probability, observation cost, realized outcome and net jbits. Show those separately rather than compressing them into one “information score.” Make free full exposure clearly a study action; paid limited reveals and repeated hiding must retain observation history.
6. **Refine the paired Invariant presentation.** The current table lets readers select and run both published starts. A stronger later comparison can synchronize both games, jump to first divergence (the reported turn 15 needs an explicit UI check), show the full repeated-state certificate, and retain a shared comparison strip on phones. This paired animation and a dedicated compact certificate download are not completed here. Preserve the frozen transition.
7. **Optional local engagement accounting.** Track actions such as swap, decode, symbols opened, game run, loop reached, forgiveness and paper opened only if wanted. Do not present engagement as comprehension. There is no new analytics collection in this checkpoint.
8. **Only after review:** freeze the accepted package, update its release status and hashes, deploy through the existing site process, and smoke-test both public entrances and every game/rule-card route. The checkpoint itself is not marked release-ready.

## Deferred: Finance weather-tile prediction bank

The owner proposed that jbits can be allocated freely among live weather tiles and move with bps. **This is not implemented.** Finance files remain untouched. There is no hidden or simulated live integration to enable.

The next side should first identify what the existing tile's displayed bps actually measures. Distinguish a cumulative level from a per-interval change or an index score before choosing a payout formula. Do not interpret every bps label as an investable return or apply a price-return formula without that agreement.

The desired interaction is: choose a tile and direction, choose an allocation up to the available bank, inspect the entry mark and timestamp, watch its value with fresh data, then close or move the allocation through explicit transactions. A simple fixed-point scale is preferred. Keep **available jbits**, **committed principal**, and **unrealized change** separately visible.

The integration needs stable tile/position IDs, an entry snapshot, subsequent data timestamps, a stated update/settlement formula, rounding rules, and explicit handling of stale/missing data and adverse moves. Moving an allocation must not spend the same principal twice. Refunds and realized changes need idempotent receipts. Decide whether values stop at zero or allow negative values before enabling positions. Record any game-issued gains/losses in the bank ledger instead of silently changing its balance.

`area-51/assets/credits.js` exposes the single atomic wallet/checkpoint transaction and receipt API; extend that shared state deliberately. No API call for weather trading is authorized or required here. This remains a play-unit experiment until its metric and rules are agreed and implemented.

## Files for the next side

- `CerebralGraphix_v2_0_REVIEW_FULL_SITE.zip` — the full current review object, including this delta, scoped checks and a file hash inventory.
- `CerebralGraphix_v2_0_INTEGRATION_DELTA.zip` — changed/added files under `overlay/`, explicit deletions, and a baseline comparison manifest. Apply only to the identified baseline or merge intentionally with later work.
- `V2_0_REVIEW_DELTA.md` — this standalone handoff for quick review.

The next action is review and merge of this concrete checkpoint, followed by the listed interface gates. Do not re-open the published paper or expand the research claims merely to finish the website.
