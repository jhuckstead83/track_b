# Beta card-game lab → Area 51 Alpha delta

## Preserved beta results

The received beta package passed its 52-file SHA-256 manifest. Its controlling
archive SHA-256 is
`8cae4f067d2f926234b664c5b633026a6a1366174d3be4e1b2de1787faed14ed`.

Blackjack 51 preserves these exact conclusions:

1. The published adjacent swap is `K♠ ↔ 10♦` at active positions 50 and 51.
2. The physical cards and published War strengths differ: 48 versus 38.
3. Blackjack maps both cards to value class `T = 10`.
4. All 129 beta A/B full value streams agreed.
5. All 258 beta A/B logical-trace comparisons agreed across the two ace rules.
6. Under the fixed beta hit-below-17 protocol, changing only the ace valuation
   changed 7 of 64 source outcomes and 9 of 64 matched-control outcomes.
7. `A+6` and `10+7` both display 17, but appending the same ten produces hard
   17 versus bust 27. A displayed total is not a closed state variable.

These results remain explicitly separate from the Alpha game additions.

## New Alpha design decisions

The beta protocol did **not** include wagers, split, double, paid observation,
forecast contracts, persistent banks, refill timers or Memory 51. Area 51 Alpha
adds and versions each of those rules.

| Addition | Alpha purpose | Evidential status |
| --- | --- | --- |
| Playable blackjack | Familiar entry into contextual valuation | New implementation |
| One value-matched split | Preserves the value-only K/10 equivalence | Declared rule |
| Paid next-card observation | Separates hidden state from observer access | Declared rule |
| Forecast contract | Makes a prediction position explicit | Declared payoff |
| Shared credits | Links games without calling currency information | Declared economy |
| Memory 51 | Learns card ↔ symbol/meaning in both directions | New game |
| Passive generator switch | Allows later learning-only scarcity | Release policy |

## Memory correction folded in

The beta found that Memory Wager credits and prediction accuracy move
differently: on the fresh three-player observer model, no-peek accuracy is
`1/3` with expected net credits `8/3`, while one peek raises optimal accuracy to
`946/1785` but lowers expected net credits to `702/595`. Therefore Area 51 does
not interpret credits as the value of information.

The beta also found that an export during a paid unresolved peek omitted the
pending observation while already showing the lower balance. Blackjack 51
writes an observation to the round immediately, with status `pending`,
`consumed`, or `unconsumed-at-settlement`.

Memory 51 is not a rename of Memory Wager. It is the bidirectional,
customizable flash-card object specified after the beta return.

