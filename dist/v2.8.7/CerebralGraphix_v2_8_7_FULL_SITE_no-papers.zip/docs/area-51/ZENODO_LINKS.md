# Area 51 — copy-ready current links for Zenodo

These URLs are intentionally unversioned current-entry links. A Zenodo record
can cite one of them while retaining its own frozen files, version, date, and
license metadata.

## Laboratory

**Area 51 — live interactive research laboratory**  
https://cerebralgraphix.com/area-51/

Suggested relation: `isSupplementTo` or `isNewVersionOf` only when that relation
is true for the specific deposit; otherwise include it as a related URL in the
description.

## Current Game 51 links

**Invariant — maintained v7.2 interactive foundation**  
https://cerebralgraphix.com/area-51/invariant/

**Telescope 51 — rule version 0.1 public beta**  
https://cerebralgraphix.com/area-51/telescope-51/

**Memory 51 — rule version memory51-alpha-0.1**  
https://cerebralgraphix.com/area-51/memory-51/

**Blackjack 51 — rule version blackjack51-alpha-0.2**  
https://cerebralgraphix.com/area-51/blackjack-51/

## Foundation and license record

Jeffery Lyn Huckstead, *The Line Game | Surprise Is Not Meaning*, v7.2  
https://doi.org/10.5281/zenodo.22851517

The DOI identifies the frozen deposited foundation and its license. Memory 51
and Blackjack 51 public Alpha are maintained web research extensions, not
separate deposits under that DOI. For a reproducible citation, name the exact
game, rule version, access or release date, canonical URL, and the foundation
DOI when the claim relies on the fixed card object.
