# Area 51 research and credit contract — Alpha 0.1

## 1. Series architecture

Area 51 is an HTML-forward research series:

```text
fixed object → declared rule → playable experiment → reproducible receipt → result → paper
```

Invariant owns the fixed 51-card object and outside `2♣` marker `Ⅰ`. A numbered
game may change valuation, observation, transition, decision or payoff, but it
must name the changed layer. It may not silently rewrite the card object.

## 2. Memory 51 is not Memory Wager

The maintained Invariant **Memory Wager** is an observation-and-prediction
experiment. **Memory 51** is a separate, conventional flash-card game:

```text
ordinary card ↔ Area 51 symbol and declared meaning
```

It supports both directions and user customization. Each edit increments the
mapping version and resets that card's schedule. Objective recall checks and
self-graded study reviews are stored as different event types.

The starter meanings are mechanical observation coordinates. They do not claim
that a card has a unique psychological, physical or number-theoretic meaning.
`3♥` is visibly retained as Jeffery's lucky sentinel and has no rule, scheduling
or payout effect.

## 3. Units that must not be collapsed

| Quantity | What it is | What it is not |
| --- | --- | --- |
| Credits | Designed game currency under a versioned payoff rule | Bits, entropy, intelligence or proof of learning |
| Paid observation | A declared access event and cost | Exclusive knowledge after the card is later revealed |
| Prediction result | A selected outcome, declared probability basis and realized event | General predictive ability |
| Recall correctness | Correct/incorrect response for one mapping version and direction | Long-term retention by itself |
| Active learning seconds | Visible, non-idle time banked only when a recall check completes | All time with the tab open |
| Six-bit card address | Fixed-width capacity sufficient for 51 identities | Human memory capacity |

The receipt retains these in separate fields even when the UI presents them
together.

## 4. Alpha issuance modes

`area-51/assets/economy-config.js` owns the release policy.

### Current hybrid Alpha

- Opening bank: 8 credits, once per browser storage origin.
- Passive recovery: 1 credit every 310 seconds while below 8.
- Memory learning: 1 credit per 310 completed active-recall seconds.
- Memory device-day issuance cap: 8 credits.
- Opening a page, opening a pop-out, revealing a study card or leaving a tab idle
  issues no Memory credit.

### Future learning-only release

Set `passiveGeneratorEnabled` to `false`. The ledger and balances remain; the
timer reports `generator offline`; new issuance can come from Memory 51 work.

### Public learning economy boundary

The Alpha ledger is local and user-editable. It cannot create defensible rarity.
A later public economy needs at minimum:

1. server-owned balances and monotone transaction identifiers;
2. signed game/review receipts with rule and mapping versions;
3. explicit opt-in for research use;
4. human/bot and duplicate-account controls stated as limitations;
5. an appeal/correction path for lost or rejected work;
6. no cash-value or scarcity claim before economic, legal and security review.

The existing local schema is designed so those changes can replace trust level
`client-*` with a validated status without relabeling old events.

## 5. Blackjack 51 additions

Blackjack 51 Alpha declares:

- 51 active cards and outside `2♣` marker;
- contextual ace `1/11` or explicit alternative `Ace = 1`;
- dealer stands on hard and soft 17;
- hit, stand, double and one value-matched split;
- natural blackjack pays 3:2 on even stakes;
- an observation costs 2 credits, reveals the unchanged next card for 1.6
  seconds and is written immediately as pending;
- a next-card forecast contract costs 1 credit and draws immediately;
- exact unseen-card odds determine its gross return, rounded downward to a
  hundredth of a credit.

The observation stays in the exported receipt even if the round ends before
the card is consumed. Exporting or reloading a receipt awards nothing.

## 6. Data policy

Alpha sends nothing. Receipts are local, identity-free exports. Passive traffic,
page views and client-side credits are not human-study evidence—especially on a
site with bot-heavy traffic.

A later collection route should accept only deliberate, consented receipt
submission and preserve:

- object, rule, mapping and economy versions;
- game/review direction and state;
- completed and pending observations;
- result, cost, reward and balance as different fields;
- local/client trust status;
- inclusion/exclusion reason for each research analysis.

## 7. Citation

Every page carries visible and machine-readable attribution to:

Jeffery Lyn Huckstead, *The Line Game | Surprise Is Not Meaning*, v7.2,
DOI `10.5281/zenodo.22851517`.

Blackjack 51, Memory 51 and Area 51 Alpha are maintained web research
extensions, not themselves deposited papers in this draft.

