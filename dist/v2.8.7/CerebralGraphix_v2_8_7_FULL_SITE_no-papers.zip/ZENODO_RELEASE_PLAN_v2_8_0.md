# Zenodo plan for v2.8.0: records, files, cross-links, placeholders

This file is a checklist for minting DOIs alongside the site upload. **No DOI in this release was invented:** every new link is marked `data-doi-pending="…"` in the page source. Search that attribute, paste the DOI you mint, and the site is cross-linked. The only DOIs already cited are the TN Postmaster concept DOI (10.5281/zenodo.21968915) and the Line Game v7.2 DOI (10.5281/zenodo.22851517).

## Records to mint

| # | Record | Mint as | Upload | Placeholder id |
|---|---|---|---|---|
| 1 | TN Postmaster Volume I v5.2 | new version under concept 10.5281/zenodo.21968915 | `papers/TN_Postmaster_Volume_I_v5_2_SOURCE.zip`; add the two PDFs once built | `tn-postmaster-v5-2` |
| 2 | 51 SEDAPS v0.4 research update | new version of the 51 SEDAPS record, or a new record if the v0.1 note has none | the v0.4 files below | `sedaps-51-v0-4` |
| 3 | 51 Twins v1: exact still plates and twin calibration | new record | a zip of `area-51/twins-51/` | `twins-51-v1` |
| 4 | Formula 51: uniqueness by deduction | new version of the Formula 51 Concise Method record, or a new record | `research/project-51/formula51/` | `formula51-deduction` |
| 5 | Cerebral Graphix site v2.8.0 (optional) | new version of the site record, if you keep one | the full site zip | none |

**Files for record 2**, all in `area-51/sedaps-51/`:
- `RESEARCH_UPDATE_v0_4.md`
- `sedaps-lemma-v0-4.js`
- `sedaps-v0-4.js`
- `verify-sedaps-v0-4.cjs`
- `VERIFY_v0_4.json`
- `dstart4-certificates-v0-4.json`
- the inherited `sedaps-core-v0-2.js` and `reachable-certificate-v0-3.json`

## Cross-links (Zenodo "related identifiers")

- **1 → 3:** isSupplementedBy. **3 → 1:** isSupplementTo. The plates and the calibration report draw on Dossier §§69A–69B.
- **2 → 3:** isSupplementedBy. **3 → 2:** references. Plates II–IV draw on SEDAPS v0.4.
- **3 → Project 51 v0.3** (your existing DOI): references, for plate V.
- **3 → Volume I: Exact Geometry and Symbolic Foundations** (your existing DOI): references. The trapped tip is used only as a drawing device.
- **4 → Project 51 v0.3 and Line Game v7.2 (10.5281/zenodo.22851517):** references.
- **1 → arXiv:2608.13637 and arXiv:2609.02882:** references. These are reference entries [121] and [66].

## Pasting the DOIs into the site

1. **Postmaster page.** In `research/postmaster/index.html`, the v5.2 source link carries `data-doi-pending="tn-postmaster-v5-2"`. Add the DOI next to it. When the PDFs are built, also add them to `papers/` and to the page's reading links.
2. **SEDAPS page.** In `area-51/sedaps-51/index.html`, the research-update link carries `sedaps-51-v0-4`.
3. **51 Twins page.** The page is generated. Edit the "Cite" line in `area-51/twins-51/build-twins-page-v1.cjs` (`twins-51-v1`), then run `node area-51/twins-51/build-twins-page-v1.cjs --write`. Editing `index.html` by hand makes the build check report it as stale.
4. **Project 51 page.** In `research/project-51/index.html`, the deduction link carries `formula51-deduction`.
5. **Manifest.** Refresh the hashes of any file you edit in `MANIFEST_v2_8_0.json`, or regenerate the manifest.

## Before record 1: build the v5.2 PDFs

Put the source zip in My Drive, then run this Colab cell. It uses pandoc 3.1.3, the version the v5.0 build used. `build_baseline_v51.py` rebuilds v5.1 in the same environment, so the page count is compared like for like:

```python
from google.colab import drive; drive.mount('/content/drive')
!unzip -q -o "/content/drive/MyDrive/TN_Postmaster_Volume_I_v5_2_SOURCE.zip" -d /content
%cd /content/TN_Postmaster_Volume_I_v5_2
!wget -q https://github.com/jgm/pandoc/releases/download/3.1.3/pandoc-3.1.3-1-amd64.deb && dpkg -i pandoc-3.1.3-1-amd64.deb > /dev/null
!apt-get -qq update && apt-get -qq install -y texlive-latex-recommended texlive-latex-extra texlive-fonts-recommended texlive-fonts-extra texlive-lang-english lmodern > /dev/null
!pip -q install pymupdf
!python qa/build_release.py both
!python qa/build_baseline_v51.py reading
!python qa/check_v52_interface.py
```

Once the build receipts exist, `check_v52_interface.py` enforces the Reader's 101-page ceiling.
