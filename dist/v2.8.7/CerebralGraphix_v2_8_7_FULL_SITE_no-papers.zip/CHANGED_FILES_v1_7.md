# Changed files — v1.7 visual front door

- Changed existing files: **11**
- Added files: **11**

## Changed existing files
- `index.html`
- `papers/chamber_lift_series.html`
- `papers/index.html`
- `site-index.html`
- `site-index.json`
- `site.webmanifest`
- `sitemap.xml`
- `tools/index.html`
- `tools/polar_shell_renderer.html`
- `tools/six_cardinal_picone.html`
- `tools/six_cardinal_picone_cdn.html`

## Added files
- `BUILD_CHECKS_v1_7.json`
- `BUILD_CHECKS_v1_7.md`
- `WEBSITE_UPDATE_NOTES_v1_7.md`
- `assets/polar_density_hygiene.png`
- `assets/polar_shell_hero.png`
- `docs/website_repositioning_research_2026-07-09.md`
- `papers/annular_shell_isolation.pdf`
- `papers/polar_shell_renderer.pdf`
- `papers/polar_shell_renderer.tex`
- `plots/index.html`
- `tools/polar_shell_prime_numerator_legacy.html`
