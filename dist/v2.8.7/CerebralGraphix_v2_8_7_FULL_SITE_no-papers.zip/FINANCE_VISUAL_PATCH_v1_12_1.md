# Finance visual patch v1.12.1

- The fixed 4×4 semantic board is unchanged.
- Chamber accents now use sixteen distinct colors in both the notebook and the HTML renderer.
- The legacy history chart moves its legend below the plot, eliminating the reserved right-side legend rail.
- The legacy HTML now displays the complete tight PNG at 100% width rather than cropping a live image.
- `overnight_overlay.json` remains a separate typed overlay and does not replace the E*TRADE close plate.
