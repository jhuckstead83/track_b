# Cerebral Graphix v2.8.0

September 27, 2026. Full-site continuation of v2.7.0. This release adds the 51 Twins exhibit, SEDAPS v0.4, the TN Postmaster v5.2 source edition and the Formula 51 deduction, and finishes the Rotor 51 → Prospect 51 rename. **RH STATUS: OPEN.**

## 51 Twins (new: `/area-51/twins-51/`)

An exhibit of exact still plates, not a game and not a simulation. A "twin" is a pair of runs that one rule cannot separate and another rule can.

- **I · The pair.** ζ and its Davenport–Heilbronn twin enter the same Widder rung ladder through the same functional equation. Both pass every computed rung through W₁₆₅₈₈. The twin fails W₁₆₅₈₉ at x = 7140.07, because its zero 0.8085 + 85.699i is off the line. ζ continues through K_H ≈ 4.7 × 10¹² (CERT) into an open tip. The tip is drawn with Volume I's trapped-tip cascade, labelled as a drawing device, not an identity.
- **II · At the table.** The four legal pasts of the SEDAPS turn-85 present. A "Run the tape" playhead runs them backward: 01 and 11 stop at once, 10 stops at turn 66, and only 00 reaches the 17–17–17 deal. Forward, the present loops forever with period 3,744 = 52 × 72. Viewers can guess a past first. There are no jbits and no wallet; reduced motion shows the final frame.
- **III · Four for four.** A certified turn-32 present whose four pasts come from four different deals.
- **IV · The periodic remnant.** The cycle lengths of 1,652 non-ending games (of 2,000). Every one is a multiple of 52 (EVID).
- **V · Order twins.** Prospect's archive key 10♠ J♦ J♥ K♠ 10♦ and its twin with the red jacks swapped. Poker scores both as two pair; only the key opens the lock.
- **Other contents.**
  - A status ledger, and a proposed "51 Twins as a game system" section, not built.
  - `calibration.html`: the public twin calibration report (Dossier v5.2 §§69A–69B numbers).
  - `verify-twins-v1.cjs` rebuilds `twins-data-v1.js` from the shipped SEDAPS rule, certificates and Prospect engine, byte for byte.
  - `build-twins-page-v1.cjs` redraws the page from that data.
- **Layout.** Every plate has a wide and a tall SVG layout, so phones get readable plates with no sideways scrolling.

Linked from the Area 51 hub (new tile 07), the SEDAPS rule card, the Prospect rule card, the Project 51 page and the Postmaster page. The Games menu is unchanged.

## 51 SEDAPS v0.4

- **The turn-85 present has exactly one past from a fair deal.**
  - 01 and 11 fail the mod-3 clock (PROVED): with three queues live, every length is ≡ 17 − t (mod 3).
  - 10 is excluded by a complete backward search under the proved time-aware shape lemma (COMPUTED). Its deepest history reaches turn 66.
  - v0.3's "01 and 10 remain open" is closed.
- **"Apply 17-card start" now leaves one past.** Labels name the reason for each exclusion. v0.3 scripts are retained unchanged, and the page loads the new `sedaps-lemma-v0-4.js` and `sedaps-v0-4.js`.
- **Four is sharp among reached states.** v0.3 left this open; five certified presents (turns 32, 35, 41, 50 and 53) have all four pasts reached from different deals (`dstart4-certificates-v0-4.json`).
- **The periodic remnant (EVID).** 1,652 of 2,000 seeded deals never end. Their 12 cycle lengths all divide by 52 = 51 + 1, and the same n + 1 pattern holds for every odd deck size tested.
- **Files.** `RESEARCH_UPDATE_v0_4.md`, and `verify-sedaps-v0-4.cjs`, which writes `VERIFY_v0_4.json` and covers the deck sweep with `--decks`.

## TN Postmaster Volume I v5.2 (source edition)

- `papers/TN_Postmaster_Volume_I_v5_2_SOURCE.zip` (22.5 MB) holds:
  - the Markdown masters and build scripts;
  - the standard-library interface check (67 checks, PASS);
  - the twin evidence;
  - the v5.1 and v5.0 provenance.
- **The PDFs are not built yet.** The v5.1 PDFs stay the typeset edition. The Postmaster page gains a v5.2 section.
- **New content** is in the Dossier: §§69A–69C, with (TW.1)–(TW.2) PROVED and (TW.3) EVID. The Reader stays within its 101-page ceiling (measured against the v5.1 layout).

## Formula 51 deduction (`/research/project-51/formula51/`)

- 51 is the unique self-describing alphabet size (PROVED).
- Among the self-describing radices, 1437–1440 are decoder-optimal, and 1438 alone has balanced partial classes.
- A more legible table exists at N = 1353–1356.
- The script reproduces `f51_band.json` byte for byte. The Project 51 page gains a "Why 51, by deduction" section and an "Order twins" pointer.

## Rotor 51 → Prospect 51

What changed:
- the engine header, in both `engine.js` and the demo;
- the page surface tag, now `data-cg-surface="prospect51"`;
- the Project 51 page note.

What was kept on purpose:
- the saved-hand ids `project51.rotor51.demo.v0.3` and `project51.rotor51.v0.3.tab-demo`, so unfinished hands survive;
- the `/area-51/rotor-51/` redirect, and its `_redirects` lines;
- "rotor" as the name of the five reels;
- the Project 51 v0.3 paper, which still uses "Rotor 51". Revising it would need a v0.3.1 build and a new Zenodo version.

## Index files

`sitemap.xml` gains SEDAPS, 51 Twins and the calibration report (82 URLs; well-formed). Both `llms.txt` files gain 51 SEDAPS and 51 Twins entries with their status fences. `area-51/research.json` lists SEDAPS v0.4 and 51 Twins, with site_version 2.8.0.

## Verification and delivery

See `VALIDATION_v2_8_0.json`.

- **Replays.** Twins data rebuilt byte for byte; page current; SEDAPS v0.4 verifier PASS, deck sweep included; Formula 51 rerun byte-identical; TN v5.2 interface check 67/67.
- **Links.** All local links in the nine changed or added pages and notes resolve (211 references).
- **Rendered checks.** These ran in a real browser against a local server at 1280 × 900 and 375 × 812:
  - the plates in both layouts;
  - the Run animation and its reduced-motion path;
  - the SEDAPS start filter;
  - Prospect boot after the rename;
  - the calibration tables, with no horizontal page scroll.
- **Not run: the inherited v2.x DOM test suites.** They need npm packages (linkedom, fake-indexeddb, cssom, css-what) that were not installed here.
- **Not verified: the live Finance feed.** It rejects a localhost origin (CORS), as before.
- **Not claimed:** real-device touch tests.

This is an upload-ready site archive, not a live deployment. Upload at the site root with the existing hosting configuration. All v2.7.0 files remain present. `MANIFEST_v2_8_0.json` lists every changed and added file with before and after hashes. `ZENODO_RELEASE_PLAN_v2_8_0.md` lists the records to mint and the placeholders to fill.
