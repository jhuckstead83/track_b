# Cerebral Graphix v1.11 — Finite-Observer Evidence Companion integration

Base release:
`cerebralgraphix_site_v1_10_3_live_freshness_clock_release`

Integrated source:
`finite_observer_evidence_companion_FULL_RELEASE_2026-07-13`

Zenodo record:
`https://zenodo.org/records/21336985`

## New public tool

`/tools/finite_observer_ledger/`

The companion includes:
- exact semidiscrete reflection symbol;
- odd reflected-power law;
- matched-pair falsifier;
- certification atlas;
- 34-record claim/provenance/open/diagnostic manifest;
- six receipt-bound final figures with SHA-256;
- direct links to both final paper PDFs;
- direct link to Zenodo record 21336985.

## New papers

- `/papers/From_Measure_to_Flux_Jeffery_Huckstead_FIGURE_ENHANCED_FINAL.pdf`
- `/papers/The_Finite_Observer_Ledger_Jeffery_Huckstead_FIGURE_ENHANCED_FINAL.pdf`

## Navigation and indexing updated

- homepage featured objects
- homepage research spine
- tools directory
- papers shelf
- `site-index.html`
- `site-index.json`
- `sitemap.xml`

## Guardrail

**A visualization may expose evidence; it may not create evidentiary status.**

## Finance boundary

The entire `finance/` subtree, `_redirects`, `_routes.json`, and finance live-data function remain byte-identical to v1.10.3.
