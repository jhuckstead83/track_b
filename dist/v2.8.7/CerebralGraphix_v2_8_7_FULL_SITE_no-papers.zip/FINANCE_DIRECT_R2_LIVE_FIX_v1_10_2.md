# Φ Finance Weather — v1.10.2 Direct-R2 Live Fix

## Diagnosis

The live grid was rendering the bundled static fallback, not current Colab output.

The stale screen values matched the old June 16 fallback exactly, including:
- BANKS +176.0
- AI_BIG -128.0
- AUTOS_EV -291.5
- AI_SEMIS -482.5
- GLOBAL_STACK -43.0

The current Colab run showed different live values, proving the live JSON path was not being consumed.

## Why legacy can update while the chamber grid does not

The legacy view can display remote PNG/SVG images directly.

The chamber grid needs JavaScript to read JSON. Browser JavaScript is subject to CORS when reading from:
- page origin: https://cerebralgraphix.com
- JSON origin: https://live.cerebralgraphix.com

## Loader chain in v1.10.2

1. `/finance/live-data`
   - Same-origin Pages Function route when deployed via Git or Wrangler.

2. `https://live.cerebralgraphix.com/finance/latest/sector_plot_data.json`
   - Direct R2 live aggregate.
   - Supports dashboard Direct Upload deployments.
   - Requires the included R2 CORS policy.

3. `finance/static/sector_plot_data.json`
   - Last-resort bundled fallback only.

## R2 CORS policy

Apply the included file:

`R2_CORS_POLICY_cerebralgraphix.json`

to the `cerebralgraphix-live` R2 bucket.

The allowed browser origin is exactly:

`https://cerebralgraphix.com`

No trailing slash.

## Notebook

Untouched.

No Colab runtime changes.
No export changes.
No history-tail changes.

## After deploy

Purge these cached URLs:
- https://cerebralgraphix.com/finance/live
- https://cerebralgraphix.com/assets/phi_finance_grid_v1.js
- https://live.cerebralgraphix.com/finance/latest/sector_plot_data.json
