# Φ Finance Weather — v1.10 Cell-Status Cherry

## Scope

Site-side only. The notebook is untouched.

Adds one reconstruction-fidelity descriptor per live chamber:

- `stratified`
- `diffuse`
- `opaque`

## Aggregate-only classifier

Inputs:

- `median_bps`
- `avg_bps`
- `net_breadth`
- `up_count`
- `down_count`
- `flat_count`
- `row_count` or stable chamber basket count fallback
- `fresh_ratio`

Named fields such as `leader_symbol`, `laggard_symbol`, and `abs2_symbol` do not enter the classifier.

Starting thresholds:

- `FRESH_MIN = 0.50`
- `BREADTH_HI = 0.60`
- `RELATIVE_SKEW_LO = 0.25`
- `RELATIVE_SKEW_HI = 0.75`
- `SKEW_FLOOR_BPS = 5`

Relative skew:

`abs(avg_bps - median_bps) / max(abs(median_bps), 5)`

The 5 bps floor prevents quiet near-zero medians from making tiny mean-median differences explode into false opacity.

## Migration hook

The browser resolves status as:

`normalizeCellStatus(chamber.cell_status) || cellStatus(chamber)`

Therefore, when Stage 4 later emits a ledgered `cell_status`, that field wins automatically. Until then, the browser computes the identical aggregate-only fallback.

## Notebook status

No notebook files were modified.

Stage 4 remains one later surgery window for:

1. chamber-only public export;
2. bounded history retention;
3. ledgered aggregate-only `cell_status`.

## Private/public membrane

The same word appears on both sides because it is derived from aggregate fields available on both sides.

Private named readouts do not influence status.

## Calibration note

The starting thresholds are now protected against the near-zero median bug, but should still be calibrated against:

- one known calm/coherent day;
- one known volatile/outlier day;
- explicit calm-coherent vs. calm-stale fixtures.
