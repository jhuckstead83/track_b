# Cerebral Graphix v1.13.4

Status: built and checked; not deployed.

## Triangular-n Postmaster v5.1

- The website now presents the v5.1 manuscript package as the frozen local edition: a 101-page Reading Volume, a 281-page Technical Dossier and the complete source and verification package.
- `/research/postmaster/` is rebuilt as a phone-friendly HTML reading route. It introduces the object in plain language, follows all eight parts, states the exact research boundary and links each stage directly into the PDFs.
- The public status explanation is organized around what is established and what remains open. Internal editorial vocabulary and release-workbench language are not used as the reader's introduction.
- V5.1's interface clarifications are represented accurately: reflection-pair indexing and multiplicity are explicit, conjugation remains distinct from reflection, and individual-kernel positivity is restricted to positive real folded nodes.
- The v5.0 finite certificates are described as inherited; this editorial release did not re-run them. No mathematical status is promoted, and the Riemann hypothesis remains open.

## Publication information

- Homepage, Papers, catalogue, Atlas, RSS, site index, metadata and citation copy now point to the v5.1 local edition.
- The durable concept DOI is `10.5281/zenodo.21968915`. V5.1 has not yet received its own Zenodo deposit, so the September repository record is labelled as preceding the local manuscript instead of being silently equated with it.
- The v4.7 PDF and its September 15 record remain available as publication history.
- The Line Game's September 19 record remains searchable in the full catalogue and Atlas. It is no longer a homepage or Papers-page spotlight while the work is active again.
- The catalogue still contains 61 repository records. The local v5.1 manuscript is not counted as an additional repository record.

## Finance preservation

- Finance is unchanged from v1.13.3, including the automatic teal overnight renderer and chart-history promotion.
- No live overnight artifact was available during this publication-only pass, so the real provider transition remains an operational check for the next overnight session.

## Validation

- Local links, page fragments, JSON, XML, structured data, catalogue counts, Atlas data and PDF deep links were checked.
- The hosted v5.1 PDFs and source package are byte-identical to the supplied publication package, and their page counts match its build receipts.
- The full-site and conflict-safe patch archives were replayed against the v1.13.3 baseline and compared byte-for-byte.
- A phone-to-desktop Chromium suite is included for preview testing, but it was not executed here because this runtime did not contain a browser executable. No Cloudflare preview, live-provider test or physical iPhone/Safari test was performed.
