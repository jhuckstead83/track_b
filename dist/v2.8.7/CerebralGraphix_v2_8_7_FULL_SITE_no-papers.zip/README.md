# Cerebral Graphix v2.0 — review checkpoint

This is the Area 51 integration checkpoint, not a deployed release. Start with
[the review delta](docs/v2.0/V2_0_REVIEW_DELTA.md) for implemented changes,
current jbit rules, the remaining review gates, and the deferred Finance
prediction bank.

Game order: **Invariant → Blackjack 51 → Telescope 51 → Memory 51**.
Open `index.html` through an HTTP server at the site root; game pages use
ES modules, fetched data and a shared IndexedDB bank.

Scoped checks: run `npm ci` in `tests/v2`, then `node check.mjs` there.
See `docs/v2.0/VALIDATION_REPORT.json`. Browser/device approval is pending.

The original baseline documentation below is retained for its Finance setup
instructions. Older versioned notes describe earlier releases, not v2 approval.

---

# Φ Finance Live Window click logger v0.1

This packet gives you a browser rolling-window page plus an optional Cloudflare Pages Function.

## What is sandboxed?

Browser JavaScript cannot write directly into your Cloudflare Pages site files. It can:
- refresh image elements,
- save small local logs in localStorage,
- trigger a user download,
- POST to a server/API endpoint.

To persist click events publicly, you need a server-side endpoint. For Cloudflare Pages, that means a Pages Function plus a storage binding such as KV, D1, or R2.

## Files

- `finance/live.html`
  Full-page rolling window.

- `assets/phi_live_window.js`
  Static browser JavaScript. Safe without backend. It cache-busts the chart image, logs clicks to localStorage, and optionally POSTs to `/api/finance-click`.

- `functions/api/finance-click.js`
  Optional Cloudflare Pages Function for click logging. If you bind a KV namespace named `PHI_CLICK_LOGS`, it persists clicks there. Without the binding, it only returns ok and console.logs events.

- `_routes.json`
  Invokes Functions only for `/api/finance-click`, keeping static routes static.

## Add to site

Copy into your site root:

```text
finance/live.html
assets/phi_live_window.js
functions/api/finance-click.js
_routes.json
```

Then deploy.

## Optional KV setup

Create a Cloudflare KV namespace and bind it to the Pages project as:

```text
PHI_CLICK_LOGS
```

Then click events will persist under keys like:

```text
click/2026-06-17T02-18-28-000Z/<uuid>
```

## Boundary

```text
market_truth: NOT_PROVEN_BY_RECEIPT
trade_permission: NO
```
