# Finance Axis, Last-Known-Good, and Publisher Repair — v1.12.3

Date: 2026-07-20

## Purpose

This release repairs three connected production issues without changing the canonical sixteen-cell board:

1. The vertical axis was visually inverted on narrow screens because the entire axis container was rotated.
2. The Legacy image was enlarged to 111.111 percent, which created an awkward mobile crop.
3. The active notebook reached the public publisher with non-finite values and aborted JSON serialization, leaving the website with an empty current plate.

## Website changes

### Axis orientation

The vertical axis no longer rotates as one object. Each word is written vertically, while the arrow glyph remains upright:

- top: `↑ DEFENSIVE`
- bottom: `CYCLICAL ↓`

The horizontal axis remains:

- left: `← UPSTREAM / INPUT`
- right: `DOWNSTREAM / CONSUMER →`

### Legacy image

The shared style now uses:

```css
.legacy-crop img {
  display: block;
  width: 100%;
  height: 100%;
  max-width: 100%;
  object-fit: contain;
  object-position: left top;
}
```

The former `width: 111.111%` and `height: auto` crop behavior is removed.

### Last-known-good display

The live page now rejects a nominal current plate when fewer than twelve chamber values are usable or fewer than four are nonzero. It then searches in this order:

1. public R2 `finance/latest/last_known_good.json`
2. browser-local cache of the latest informative aggregate plate
3. bundled `finance/static/last_known_good.json`
4. bundled historical aggregate adapter

Fallback values are explicitly labeled `LAST KNOWN GOOD`. They are not presented as fresh, and missing values never become zero.

## Notebook changes

The returned notebook is `phi_etrade_weather_workflow_v0491_last_good_repair.ipynb`.

A repair cell is inserted after the integrated overnight publisher and before the automatic loop. It:

- recursively converts NaN and infinity to JSON `null`;
- preserves the newest informative sixteen-cell aggregate from persisted summary history;
- publishes `finance/latest/last_known_good.json` and a daily copy;
- patches an empty base in the overnight overlay from that last-known-good aggregate;
- lets base and last-known-good publication continue if the overnight provider fails;
- exposes the new last-known-good path in the public manifest;
- keeps named-symbol overnight diagnostics private.

## Boundaries

- `market_truth: NOT_PROVEN_BY_RECEIPT`
- `trade_permission: NO`
- no browser-side provider selection
- no raw named-symbol history in the public fallback
- historical fallback is visually and textually distinguished from current data
