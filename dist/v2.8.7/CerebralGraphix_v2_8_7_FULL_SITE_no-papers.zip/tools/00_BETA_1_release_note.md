# Theorem-Addressed Messages — Beta 1

**Status:** Beta 1. Public-facing, shippable, honestly capped.
**Date:** June 2026. **Author:** Jeffery Huckstead, with AI collaboration.
**License:** writing CC BY 4.0; code under a standard software license. Free/libre.

---

## What this is, in one paragraph

A reduced fraction can carry a hidden character through a rule that recovers its *address* on a
triangular grid — not from a stored codebook, but by inverting the grid's own arithmetic. The
theorem recovers an integer; a public convention (ASCII, or UTF-8) turns the integer into a
character; **the reader supplies the meaning.** The machine never supplies meaning. Every step is
verifiable by hand, and the system states plainly where it stops being able to vouch for itself.

## What's in the release

- **The doorway** (`01_bridge_ASCII.html`) — type a message, watch each character become a
  fraction and recover, one operation at a time. Plumbing ledger, off-grid rejection notice that
  shows the surviving remainder, "save my cypher." One file, offline, nothing leaves the device.
- **The alpha** (`02_utf8_alpha.html`) — every script via UTF-8 as the kernel. Choose-your-depth
  readout (text / character / byte), station-board metrics, copy/paste/CSV/in-page chart, a
  Desmos hand-off, and a **live public sentiment ledger** (see below). Beta-flagged.
- **The paper** (`03_capstone_paper.pdf` / full LaTeX pack) — the rigorous build from a plain
  question up to the theorem, with a worked example and an honest limits section.
- **The runnable core** (`04_codex.py`) — generates the ledger, runs the test suite, decodes
  random valid addresses into clean nonsense (structure ≠ meaning, demonstrated).
- **Held architecture** (`05_design_note_utf8_kernel.md`) — the UTF-8-kernel / language-sieves
  plan for a future toolkit, with the lossless proof recorded.
- **Supporting** — announcement, ledger reference, vote-layer deploy guide.

## What's live

The alpha's **public sentiment ledger** is deployed on a free Cloudflare Worker
(`theorem-votes.grid-tria-frac.workers.dev`): two buttons ("reads right" / "looks off"), a
debt-clock-style ticker showing the aggregate, refreshing once a minute. It is the **only** part
that touches the network, and only when someone votes or reads the tally. Local-first, Colab-style
sync, warns honestly when it can't reach the server. The converter itself remains fully offline.

## What this is NOT (the firewall, stated plainly)

- **Not compression.** Measured: it *expands* ~13.5×. It stores addresses, which cost more to
  write than the thing they point at. It is a demonstration, not a transport.
- **Not a secure cipher.** No key. Anyone who knows the rule can read it. A glass envelope.
- **Not a discovery about the world.** A clean decode proves the structure round-tripped — never
  that it means anything physical. **Valid structure ≠ valid interpretation.**
- **Not the Riemann phenomenon.** The construction has zeros, but they are *soft* (measured
  spacing variance ≈ 0.77 / 0.51), not the rigid GUE spacing (≈ 0.18) that makes the Riemann
  zeros extraordinary. Methodological cousin, ontological stranger.
- **Not a predictor** of markets, weather, or anything else. The vote layer records *sentiment* —
  reception — never a forecast. The grid is deterministic and takes no vote.

## What it honestly is

An **objectively valid, self-validating, deterministic instrument** — closer to an abacus or an
engine tuning table than to a theory of reality. It carries structure faithfully and leaves the
meaning to the world. Its dignity is that it claims nothing beyond its operation, and you can check
every claim by hand.

## What I'm watching for in Beta 1

Whether anyone walks through the door. The doorway's job is to surface constructive interest; the
held Python toolkit (the UTF-8 kernel + language sieves) ships when someone wants to build on it.
If something breaks or reads wrong, that's useful — note where. An alpha is for finding the edges.

---

*Built one verified step at a time, at the edge of the author's cognition, with the firewall up the
whole way. Every reach was measured; the ones that didn't survive were let go. What remains is
capped, checkable, and honest about exactly where it stops.*
