# cone_cascade.py — interactive 3D companion for Volume I (downward operator only)
# 45-degree cone (R=H=pi); primary tangent sphere S0 (equator on base, r0=pi/sqrt2);
# trapped-tip cascade contracting by lambda = 3-2*sqrt2 toward the apex.
# Slider steps through S0..Sk; each step reports radius + Pell rung (a/b -> sqrt2).
import math
import numpy as np
import plotly.graph_objects as go
import scalarcore as sc

R = sc.PI; H = sc.PI
N = 5                       # cascade depth shown (S0 .. S_N)
lam   = sc.KISS_RATIO       # 3 - 2*sqrt2
sin_h = sc.SIN_HALF         # 1/sqrt2
SQ2   = math.sqrt(2)

# exact integer Pell pairs (a,b): a + b*sqrt2 = (1+sqrt2)^(2k+1);  a/b -> sqrt2
pell = [(1, 1)]
for _ in range(N):
    a, b = pell[-1]; pell.append((3*a + 4*b, 2*a + 3*b))

# ---- cone surface (apex at z=0, base radius R at z=H) ----
th = np.linspace(0, 2*np.pi, 90); zc = np.linspace(0, H, 90)
TH, Z = np.meshgrid(th, zc); RR = R*(Z/H)
Xc, Yc, Zc = RR*np.cos(TH), RR*np.sin(TH), Z

u = np.linspace(0, 2*np.pi, 40); v = np.linspace(0, np.pi, 26)
U, V = np.meshgrid(u, v)
sx, sy, sz = np.cos(U)*np.sin(V), np.sin(U)*np.sin(V), np.cos(V)
blue = ['#1f4e79', '#2e6da4', '#3b8bd0', '#6aa9e0', '#9cc6ec', '#cfe2f7']

fig = go.Figure()
fig.add_trace(go.Surface(x=Xc, y=Yc, z=Zc, surfacecolor=Z, colorscale='YlOrBr',
    cmin=0, cmax=H, opacity=0.38, showscale=False, name='45 deg cone', hoverinfo='skip'))

radii = []
for k in range(N+1):
    z_c = H*(lam**k); rho = z_c*sin_h; radii.append(rho)
    fig.add_trace(go.Surface(x=rho*sx, y=rho*sy, z=z_c + rho*sz,
        colorscale=[[0, blue[k % 6]], [1, blue[k % 6]]],
        opacity=0.55 if k == 0 else 0.92, showscale=False,
        name=f'S{k} (r={rho:.4f})', hoverinfo='name'))
    ang = np.linspace(0, 2*np.pi, 140); rk = z_c/2.0
    fig.add_trace(go.Scatter3d(x=rk*np.cos(ang), y=rk*np.sin(ang), z=np.full_like(ang, rk),
        mode='lines', line=dict(color='crimson', width=4),
        name=f'kiss {k}', hoverinfo='skip', showlegend=False))

ang = np.linspace(0, 2*np.pi, 200)
fig.add_trace(go.Scatter3d(x=R*np.cos(ang), y=R*np.sin(ang), z=np.full_like(ang, H),
    mode='lines', line=dict(color='black', width=5, dash='dot'),
    name='base plane', hoverinfo='skip', showlegend=False))

def vis_for(kshow):
    v = [True]
    for k in range(N+1):
        on = (k <= kshow); v += [on, on]
    v += [True]
    return v

def step_anno(kshow):
    a, b = pell[kshow]
    sub = "  (sub-visible)" if radii[kshow] < 0.02 else ""
    lines = [f"showing S0 \u2026 S{kshow}   (step k = {kshow})",
             f"S{kshow} radius \u2248 {radii[kshow]:.6f}{sub}",
             f"Pell rung (a, b) = ({a}, {b})",
             f"a/b = {a/b:.7f}  \u2192  \u221a2 = {SQ2:.7f}"]
    if kshow == N:
        lines.append("fill the tip \u2192 exact void left = \u03c0\u2074/84 = 1/28 of the cone")
    return "<br>".join(lines)

fixed_text = ("45\u00b0 cone  (R = H = \u03c0)<br>"
              "S0:  r0 = \u03c0/\u221a2 \u2248 2.2214,  equator on the base plane<br>"
              "each sphere kisses the wall &amp; is tangent to the next<br>"
              "contraction \u03bb = 3\u22122\u221a2 \u2248 0.1716   \u00b7   curvature \u00d7 (1+\u221a2)\u00b2 = 3+2\u221a2<br>"
              "drag to rotate \u2192 the red kiss-circle flattens to the 2D tangent (side view)")

def annos(kshow):
    return [dict(text=step_anno(kshow), x=0.01, y=0.99, xref="paper", yref="paper",
                 showarrow=False, align="left", font=dict(size=12, color="#10314f"),
                 bgcolor="rgba(255,255,255,0.78)", bordercolor="#9cc6ec", borderwidth=1),
            dict(text=fixed_text, x=0.01, y=0.02, xref="paper", yref="paper",
                 showarrow=False, align="left", font=dict(size=11, color="#333"),
                 bgcolor="rgba(255,255,255,0.72)")]

steps = []
for k in range(N+1):
    steps.append(dict(method="update", label=str(k),
        args=[{"visible": vis_for(k)}, {"annotations": annos(k)}]))

fig.update_layout(
    title="PIne Cone \u2014 Downward Operator: step through the trapped-tip cascade",
    scene=dict(xaxis_title='X', yaxis_title='Y', zaxis_title='Z', aspectmode='data'),
    sliders=[dict(active=0, currentvalue={"prefix": "cascade step k = "},
                  pad={"t": 28}, steps=steps)],
    annotations=annos(0), margin=dict(l=0, r=0, t=46, b=0), showlegend=False)

for i, on in enumerate(vis_for(0)):
    fig.data[i].visible = on

fig.write_html("cone_cascade.html", include_plotlyjs=True, full_html=True)
print("wrote cone_cascade.html")
print("radii :", [round(r, 6) for r in radii])
print("pell  :", pell)
print("a/b   :", [round(a/b, 7) for a, b in pell])
