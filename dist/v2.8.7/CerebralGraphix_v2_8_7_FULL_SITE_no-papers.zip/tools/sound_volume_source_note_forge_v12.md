# Sound Volume — source note: Forge OS v12 as the documented "before"

### The fully-wired synesthesia machine, the moment of deflation, and what survived

**Series:** The Sense of Things, Volume II (The Sound of Things). Cerebral Graphix / Jeffery Lyn Huckstead.  
**Status:** Source material, not a tool page. v12 is the expository artifact; v16.3 is the surviving instrument linked at the end.

---

## Why v12 is the right artifact for the Sound volume

Volume II's argument is that a machine was built to bind number to many senses at once, and that when the machine was tested honestly, only one binding — the audio — carried real structure, because harmonic ratios are exact while the other channels' structure was imposed.

Forge OS v12 ("Unified Prime Observatory") is that machine at full assembly, before the later v16.3 build stripped it down to the audio app. It is the before picture. The argument needs a before picture, and this is it, with the mechanism legible in the source.

This note records the four foldable threads, the turning point in the code's own words, and the measurable reason the audio survived.

---

## What v12 is

v12 is four cross-bound channels driven by one prime sieve:

1. **Number → geometry.** A fast prime sieve generates primes; each prime is placed in a 3D point cloud at radius and angle set by `rA = γ · log(p_n) + μ · n`, with `γ = π/2 = 1.5707963267`, `μ` a small topography offset, and `n` the prime index.
2. **Number → sound.** A 16-step sequencer plays eight just-intonation ratios `{1/1, 9/8, 5/4, 4/3, 3/2, 5/3, M7, 2/1}` against a base of 261.63 Hz.
3. **Sound → geometry.** When sequencer notes fire, the entire prime cloud is re-rendered tuned to the loudest note, then returned to its rest tuning.
4. **Geometry → sound.** A radial chaos sweep scanner sweeps the cloud and reads each point's altitude as a frequency.

The UI names the binding outright: a control group labeled "Synesthetic Mixer" with separate Seq Vol and Sweep Vol faders.

---

## Thread 1 — the synesthesia machine fully wired

v12 is the channel-multiplier at maximum: number bound to sight and sound, sound bound back to sight, sight bound back to sound. Four bindings live at once, with a literal mixer to balance them.

This is the artifact the Sound volume describes the threshing of: a machine built to make number perceptible through many senses simultaneously.

---

## Thread 2 — "snap back to reality"

The most important line in the artifact is a comment. In the sequencer step function, a fired beat warps the whole prime cloud to the loudest ratio:

`computeGeometry(BASE_GAMMA * maxRatio);`

and then returns it to rest. When playback stops, the code reads:

`computeGeometry(BASE_GAMMA); // Snap back to reality`

The comment admits that the visual response to sound is a departure from the rest state that must be undone: a warp imposed by the audio, not a property of the primes.

---

## Thread 3 — γ = π/2 tuning both sight and sound

The constant `BASE_GAMMA = 1.5707963267` appears in both roles. It sets the angular placement of the primes in the geometry and also tunes the synth lineage.

One constant tuning both the look and the sound is the synesthesia weld compressed into a single number. The source note treats this as wiring, not proof.

---

## Thread 4 — why the audio survived

The visual channel has free parameters: the topography offset `μ`, the stretch/uncoil, camera choices, and color choices.

The audio channel keeps fixed harmonic ratios: `1/1`, `9/8`, `5/4`, `4/3`, `3/2`, `5/3`, major seventh, and `2/1`.

The Sound volume's claim is not that a prime result was found. It is that the channel which survived is the one where the channel and the structure coincided: frequency ratios are real arithmetic.

---

## Arc for Volume II

1. **The machine (v12).** A synesthesia engine binding number to sight and sound and back again.
2. **The deflation (v12).** The beat warps geometry, then snaps it back to rest. Visual structure has adjustable knobs; audio ratios do not.
3. **What survived (v16.3).** The audio channel became a clean just-intonation step sequencer.

One-line thesis:

> Of all the senses the machine bound number to, sound was the one that paid, because in sound the channel and the structure are the same thing.

---

## Honest framing

- v12 is not presented as a working claim. It is exhibited as a documented construction.
- The prime-placement formula is a visualization choice with free parameters, not a result about primes.
- Just-intonation ratios are classical. The recognition is that audio was the channel that paid in this construction.
- v16.3 is the linked instrument. It is the app, not the argument.

Source artifacts: `forge_os_v12.html` and `forge_os_v16.3.html`.
