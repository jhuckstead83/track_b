/* Centered Rational Chamber Geometry
   Neutral math lab: represent first, verify live, interpret last.
*/

const state = {
  n: 12,
  d: 3,
  convention: "one_to_n",
  points: [],
  pointIndexByKey: new Map(),
  shellCounts: new Map(),
  expectedCounts: new Map(),
  divisors: [],
  selectedIndex: 0,
  path: [],
  rotX: 0.65,
  rotY: -0.65,
  zoom: 250,
  pointSize: 3,
  shellFilter: "all",
  nullStats: null
};

const el = {};
for (const id of [
  "nInput", "nValue", "conventionSelect", "shellFilter", "pointSize",
  "pointSizeValue", "chamberCanvas", "rotX", "rotY", "zoom",
  "verificationBox", "stateBox", "cardinalBars", "shellTable",
  "relationFlags", "randomPointBtn", "stepWalkBtn", "radialPushBtn",
  "shellSeekBtn", "resetPathBtn", "runNullBtn", "nullBox"
]) {
  el[id] = document.getElementById(id);
}

const ctx = el.chamberCanvas.getContext("2d");

function gcd2(a, b) {
  a = Math.abs(a); b = Math.abs(b);
  while (b !== 0) {
    const t = b;
    b = a % b;
    a = t;
  }
  return a;
}

function gcdMany(values) {
  return values.reduce((a, b) => gcd2(a, b), 0);
}

function primeFactors(n) {
  const primes = [];
  let x = n;
  for (let p = 2; p * p <= x; p += (p === 2 ? 1 : 2)) {
    if (x % p === 0) {
      primes.push(p);
      while (x % p === 0) x = Math.floor(x / p);
    }
  }
  if (x > 1) primes.push(x);
  return primes;
}

function jordanTotient(q, d) {
  if (q === 1) return 1;
  let num = BigInt(q) ** BigInt(d);
  let den = 1n;
  for (const p of primeFactors(q)) {
    const pd = BigInt(p) ** BigInt(d);
    num *= (pd - 1n);
    den *= pd;
  }
  return Number(num / den);
}

function divisors(n) {
  const out = [];
  for (let i = 1; i <= n; i++) if (n % i === 0) out.push(i);
  return out;
}

function kValues(n, convention) {
  if (convention === "residue") return Array.from({length: n}, (_, i) => i);
  if (convention === "one_to_n") return Array.from({length: n}, (_, i) => i + 1);
  if (convention === "zero_to_n_inclusive") return Array.from({length: n + 1}, (_, i) => i);
  if (convention === "centered_index") return Array.from({length: n}, (_, i) => i);
  return Array.from({length: n}, (_, i) => i);
}

function centeredCoordinate(k, n, convention) {
  if (convention === "centered_index") {
    if (n === 1) return 0;
    return (2 * k / (n - 1)) - 1;
  }
  return (2 * k / n) - 1;
}

function shellQ(n, kVec) {
  const g = gcdMany([n, ...kVec]);
  return n / g;
}

function buildChamber() {
  const n = state.n;
  const values = kValues(n, state.convention);
  const points = [];
  const counts = new Map();

  for (const kx of values) {
    for (const ky of values) {
      for (const kz of values) {
        const k = [kx, ky, kz];
        const q = shellQ(n, k);
        const x = centeredCoordinate(kx, n, state.convention);
        const y = centeredCoordinate(ky, n, state.convention);
        const z = centeredCoordinate(kz, n, state.convention);
        const rho = Math.sqrt(x*x + y*y + z*z);
        const p = { k, q, x, y, z, rho };
        points.push(p);
        counts.set(q, (counts.get(q) || 0) + 1);
      }
    }
  }

  const pointIndexByKey = new Map();
  points.forEach((p, idx) => pointIndexByKey.set(p.k.join(","), idx));

  state.points = points;
  state.pointIndexByKey = pointIndexByKey;
  state.shellCounts = counts;
  state.divisors = divisors(n);
  state.expectedCounts = new Map(state.divisors.map(q => [q, jordanTotient(q, 3)]));

  if (state.selectedIndex >= points.length) state.selectedIndex = 0;
  if (!state.path.length && points.length) state.path = [points[state.selectedIndex]];

  populateShellFilter();
  updateAll();
}

function populateShellFilter() {
  const previous = state.shellFilter;
  el.shellFilter.innerHTML = '<option value="all">all shells</option>';
  for (const q of state.divisors) {
    const opt = document.createElement("option");
    opt.value = String(q);
    opt.textContent = `q = ${q}`;
    el.shellFilter.appendChild(opt);
  }
  if ([...el.shellFilter.options].some(o => o.value === previous)) {
    el.shellFilter.value = previous;
  } else {
    state.shellFilter = "all";
  }
}

function conventionExpectedTotal() {
  if (state.convention === "zero_to_n_inclusive") {
    return Math.pow(state.n + 1, 3);
  }
  return Math.pow(state.n, 3);
}

function conservationApplies() {
  return state.convention === "residue" || state.convention === "one_to_n" || state.convention === "centered_index";
}

function verifyCounts() {
  let actualTotal = state.points.length;
  let expectedTotal = Math.pow(state.n, 3);
  let shellMatches = true;
  const mismatches = [];

  for (const q of state.divisors) {
    const actual = state.shellCounts.get(q) || 0;
    const expected = state.expectedCounts.get(q) || 0;
    if (actual !== expected) {
      shellMatches = false;
      mismatches.push({q, actual, expected});
    }
  }

  const extraShells = [...state.shellCounts.keys()].filter(q => !state.divisors.includes(q));
  const applies = conservationApplies();
  const totalMatches = actualTotal === expectedTotal;
  const pass = applies && totalMatches && shellMatches && extraShells.length === 0;

  return { actualTotal, expectedTotal, shellMatches, mismatches, extraShells, applies, totalMatches, pass };
}

function originMembershipNote() {
  const n = state.n;
  let exists = false;
  let kDescription = "";
  if (state.convention === "one_to_n" || state.convention === "residue") {
    exists = n % 2 === 0;
    kDescription = exists ? `k = ${n/2}` : "k = n/2 is not an integer";
  } else if (state.convention === "centered_index") {
    exists = (n - 1) % 2 === 0;
    kDescription = exists ? `index k = ${(n-1)/2}` : "middle index is between grid points";
  } else if (state.convention === "zero_to_n_inclusive") {
    exists = n % 2 === 0;
    kDescription = exists ? `k = ${n/2}` : "k = n/2 is not an integer";
  }
  return { exists, kDescription };
}

function updateVerification() {
  const v = verifyCounts();
  const o = originMembershipNote();
  const statusClass = v.pass ? "pass" : (v.applies ? "fail" : "warnText");
  const statusText = v.pass ? "PASS" : (v.applies ? "FAIL" : "CONVENTION-DEPENDENT");
  let appliesText = v.applies
    ? "Jordan conservation expected under this convention."
    : "Jordan conservation is not expected under this fully inclusive convention.";
  if (state.convention === "centered_index") {
    appliesText += " centered_index: shell counts match residue (conservation applies); rendered coordinates use (n−1) scaling, so the cube geometry differs from residue — counts invariant, positions not.";
  }

  el.verificationBox.innerHTML = `
    <div><strong>Status:</strong> <span class="${statusClass}">${statusText}</span></div>
    <div><strong>n:</strong> ${state.n}</div>
    <div><strong>points:</strong> ${v.actualTotal}</div>
    <div><strong>expected n³:</strong> ${v.expectedTotal}</div>
    <div><strong>shell counts:</strong> ${v.shellMatches ? '<span class="pass">match J₃(q)</span>' : '<span class="fail">mismatch</span>'}</div>
    <div><strong>convention:</strong> ${state.convention}</div>
    <div><strong>note:</strong> ${appliesText}</div>
    <div><strong>origin:</strong> ${o.exists ? '<span class="pass">is a chamber point</span>' : '<span class="warnText">between chamber points</span>'} (${o.kDescription})</div>
  `;

  const flags = [];
  flags.push(v.pass ? ["proved", "good"] : [v.applies ? "requires_verification" : "convention_artifact", v.applies ? "bad" : "warn"]);
  flags.push(["observed", "warn"]);
  flags.push(["lossy_projection", "warn"]);
  el.relationFlags.innerHTML = flags.map(([name, cls]) => `<span class="flag ${cls}">${name}</span>`).join("");
}

function updateShellTable() {
  const tbody = el.shellTable.querySelector("tbody");
  tbody.innerHTML = "";
  const qs = [...new Set([...state.divisors, ...state.shellCounts.keys()])].sort((a,b) => a-b);
  for (const q of qs) {
    const actual = state.shellCounts.get(q) || 0;
    const expected = state.expectedCounts.get(q);
    const tr = document.createElement("tr");
    const ok = expected === actual;
    tr.innerHTML = `
      <td>${q}</td>
      <td>${actual}</td>
      <td>${expected === undefined ? "not divisor" : expected}</td>
      <td class="${ok ? "pass" : "warnText"}">${ok ? "match" : "check"}</td>
    `;
    tbody.appendChild(tr);
  }
}

function colorForQ(q) {
  const idx = state.divisors.indexOf(q);
  const h = (idx < 0 ? 0 : (idx * 360 / Math.max(1, state.divisors.length))) % 360;
  return `hsl(${h}, 84%, 66%)`;
}

function rotatePoint(p) {
  let {x, y, z} = p;
  const cx = Math.cos(state.rotX), sx = Math.sin(state.rotX);
  const cy = Math.cos(state.rotY), sy = Math.sin(state.rotY);

  let y1 = y * cx - z * sx;
  let z1 = y * sx + z * cx;
  let x2 = x * cy + z1 * sy;
  let z2 = -x * sy + z1 * cy;

  return {x: x2, y: y1, z: z2};
}

function project(p) {
  const rp = rotatePoint(p);
  const w = el.chamberCanvas.width;
  const h = el.chamberCanvas.height;
  const perspective = 2.8 / (2.8 - rp.z * 0.4);
  return {
    sx: w/2 + rp.x * state.zoom * perspective,
    sy: h/2 - rp.y * state.zoom * perspective,
    depth: rp.z,
    perspective
  };
}

function drawAxes() {
  const axes = [
    [{x:-1.1,y:0,z:0}, {x:1.1,y:0,z:0}, "+x"],
    [{x:0,y:-1.1,z:0}, {x:0,y:1.1,z:0}, "+y"],
    [{x:0,y:0,z:-1.1}, {x:0,y:0,z:1.1}, "+z"]
  ];
  ctx.save();
  ctx.lineWidth = 1.5;
  ctx.strokeStyle = "rgba(143,211,255,0.42)";
  ctx.fillStyle = "rgba(238,242,255,0.75)";
  ctx.font = "12px ui-sans-serif";
  for (const [a,b,label] of axes) {
    const pa = project(a), pb = project(b);
    ctx.beginPath();
    ctx.moveTo(pa.sx, pa.sy);
    ctx.lineTo(pb.sx, pb.sy);
    ctx.stroke();
    ctx.fillText(label, pb.sx + 5, pb.sy + 5);
  }
  ctx.restore();
}

function drawPath() {
  if (state.path.length < 1) return;
  ctx.save();
  ctx.lineWidth = 2;
  ctx.strokeStyle = "rgba(255,255,255,0.85)";
  ctx.beginPath();
  state.path.forEach((p, i) => {
    const pp = project(p);
    if (i === 0) ctx.moveTo(pp.sx, pp.sy);
    else ctx.lineTo(pp.sx, pp.sy);
  });
  ctx.stroke();
  ctx.restore();
}

function drawSelectedVector() {
  const p = state.points[state.selectedIndex];
  if (!p) return;
  const origin = project({x:0,y:0,z:0});
  const pp = project(p);
  ctx.save();
  ctx.lineWidth = 3;
  ctx.strokeStyle = "rgba(255, 209, 102, 0.95)";
  ctx.beginPath();
  ctx.moveTo(origin.sx, origin.sy);
  ctx.lineTo(pp.sx, pp.sy);
  ctx.stroke();
  ctx.fillStyle = "rgba(255, 209, 102, 1)";
  ctx.beginPath();
  ctx.arc(pp.sx, pp.sy, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawChamber() {
  const w = el.chamberCanvas.width, h = el.chamberCanvas.height;
  ctx.clearRect(0,0,w,h);

  drawAxes();

  let points = state.points;
  if (state.shellFilter !== "all") {
    const q = Number(state.shellFilter);
    points = points.filter(p => p.q === q);
  }

  const maxDraw = 42000;
  const stride = Math.max(1, Math.ceil(points.length / maxDraw));
  const drawList = [];
  for (let i = 0; i < points.length; i += stride) drawList.push(points[i]);

  drawList.sort((a,b) => rotatePoint(a).z - rotatePoint(b).z);

  for (const p of drawList) {
    const pp = project(p);
    const alpha = 0.38 + 0.42 * ((pp.depth + 1.4) / 2.8);
    ctx.fillStyle = colorForQ(p.q).replace("hsl", "hsla").replace(")", `, ${Math.max(0.18, Math.min(0.95, alpha))})`);
    ctx.beginPath();
    ctx.arc(pp.sx, pp.sy, state.pointSize * pp.perspective, 0, Math.PI * 2);
    ctx.fill();
  }

  drawPath();
  drawSelectedVector();

  ctx.fillStyle = "rgba(238,242,255,0.7)";
  ctx.font = "12px ui-sans-serif";
  ctx.fillText(`${points.length} points in view${stride > 1 ? `, sampled every ${stride}` : ""}`, 18, h - 18);
}

function cardinalProjection(p) {
  return {
    "+x": Math.max(p.x, 0),
    "-x": Math.max(-p.x, 0),
    "+y": Math.max(p.y, 0),
    "-y": Math.max(-p.y, 0),
    "+z": Math.max(p.z, 0),
    "-z": Math.max(-p.z, 0)
  };
}

function updateSelectedState() {
  const p = state.points[state.selectedIndex] || state.points[0];
  if (!p) return;
  const card = cardinalProjection(p);
  const verification = verifyCounts();
  const relationFlags = verification.pass
    ? ["computed", "verified", "observed"]
    : (verification.applies ? ["computed", "observed", "requires_verification"] : ["computed", "observed", "convention_dependent"]);
  el.stateBox.textContent = JSON.stringify({
    n: state.n,
    convention: state.convention,
    k: p.k,
    q: p.q,
    r: [p.x, p.y, p.z].map(v => Number(v.toFixed(6))),
    rho: Number(p.rho.toFixed(6)),
    path_length: state.path.length,
    relation_flags: relationFlags
  }, null, 2);

  const maxVal = Math.max(1e-9, ...Object.values(card));
  el.cardinalBars.innerHTML = Object.entries(card).map(([name,val]) => `
    <div class="barRow">
      <span>${name}</span>
      <span class="barTrack"><span class="barFill" style="width:${(val/maxVal)*100}%"></span></span>
      <span>${val.toFixed(3)}</span>
    </div>
  `).join("");
}

function updateNullBox() {
  if (!state.nullStats) {
    el.nullBox.textContent = "Run null baseline to compare shell transitions.";
    return;
  }
  el.nullBox.textContent = JSON.stringify(state.nullStats, null, 2);
}

function updateAll() {
  updateVerification();
  updateShellTable();
  updateSelectedState();
  updateNullBox();
  drawChamber();
}

function nearestPointIndexFromK(k) {
  const key = k.join(",");
  const idx = state.pointIndexByKey.get(key);
  return idx !== undefined ? idx : state.selectedIndex;
}

function pointIndexFromPoint(p) {
  if (!p || !p.k) return state.selectedIndex;
  return nearestPointIndexFromK(p.k);
}

function clampK(k) {
  const values = kValues(state.n, state.convention);
  const min = Math.min(...values), max = Math.max(...values);
  return k.map(v => Math.max(min, Math.min(max, v)));
}

function randomPoint() {
  state.selectedIndex = Math.floor(Math.random() * state.points.length);
  state.path = [state.points[state.selectedIndex]];
  state.nullStats = null;
  updateAll();
}

function stepWalk() {
  const p = state.points[state.selectedIndex];
  const axis = Math.floor(Math.random() * 3);
  const dir = Math.random() < 0.5 ? -1 : 1;
  const k = [...p.k];
  k[axis] += dir;
  const values = kValues(state.n, state.convention);
  const min = Math.min(...values), max = Math.max(...values);
  if (k[axis] < min) k[axis] = max;
  if (k[axis] > max) k[axis] = min;
  state.selectedIndex = nearestPointIndexFromK(k);
  state.path.push(state.points[state.selectedIndex]);
  if (state.path.length > 90) state.path.shift();
  updateAll();
}

function radialPush() {
  const p = state.points[state.selectedIndex];
  let best = p, bestRho = p.rho;
  const candidates = neighborCandidates(p);
  for (const c of candidates) {
    if (c.rho > bestRho) { best = c; bestRho = c.rho; }
  }
  state.selectedIndex = pointIndexFromPoint(best);
  state.path.push(best);
  if (state.path.length > 90) state.path.shift();
  updateAll();
}

function shellSeek() {
  const p = state.points[state.selectedIndex];
  const candidates = neighborCandidates(p);
  const changed = candidates.filter(c => c.q !== p.q);
  const choice = changed.length ? changed[Math.floor(Math.random()*changed.length)] : candidates[Math.floor(Math.random()*candidates.length)];
  state.selectedIndex = pointIndexFromPoint(choice);
  state.path.push(choice);
  if (state.path.length > 90) state.path.shift();
  updateAll();
}

function neighborCandidates(p) {
  const out = [];
  const values = kValues(state.n, state.convention);
  const min = Math.min(...values), max = Math.max(...values);
  for (let axis=0; axis<3; axis++) {
    for (const dir of [-1,1]) {
      const k = [...p.k];
      k[axis] += dir;
      if (k[axis] < min) k[axis] = max;
      if (k[axis] > max) k[axis] = min;
      const idx = nearestPointIndexFromK(k);
      out.push(state.points[idx]);
    }
  }
  return out;
}

function mean(values) {
  if (!values.length) return 0;
  return values.reduce((a, b) => a + b, 0) / values.length;
}

function stddev(values) {
  if (values.length < 2) return 0;
  const m = mean(values);
  const variance = values.reduce((acc, v) => acc + (v - m) * (v - m), 0) / values.length;
  return Math.sqrt(variance);
}

function summarizeSeries(values) {
  return {
    mean: Number(mean(values).toFixed(6)),
    stdev: Number(stddev(values).toFixed(6)),
    min: values.length ? Math.min(...values) : 0,
    max: values.length ? Math.max(...values) : 0
  };
}

function realPathStats() {
  const path = state.path && state.path.length >= 2 ? state.path : [];
  const deltaCounts = {};
  let same = 0, changed = 0, up = 0, down = 0;
  const shells = new Set();

  if (path.length) shells.add(path[0].q);

  for (let i = 1; i < path.length; i++) {
    const dq = path[i].q - path[i - 1].q;
    deltaCounts[dq] = (deltaCounts[dq] || 0) + 1;
    shells.add(path[i].q);
    if (dq === 0) same++;
    else {
      changed++;
      if (dq > 0) up++;
      else down++;
    }
  }

  const steps = Math.max(0, path.length - 1);
  const netDeltaQ = path.length ? path[path.length - 1].q - path[0].q : 0;

  return {
    steps,
    same_shell_rate: steps ? Number((same / steps).toFixed(6)) : 0,
    shell_changed_rate: steps ? Number((changed / steps).toFixed(6)) : 0,
    q_increase_rate: steps ? Number((up / steps).toFixed(6)) : 0,
    q_decrease_rate: steps ? Number((down / steps).toFixed(6)) : 0,
    delta_q_counts: deltaCounts,
    shell_changes: changed,
    net_delta_q: netDeltaQ,
    distinct_shells_visited: shells.size
  };
}

function runNullBaseline() {
  const trials = 500;
  const walkLength = Math.max(state.path.length, 50);
  const stepsPerWalk = Math.max(0, walkLength - 1);
  const startPoint = (state.path && state.path.length ? state.path[0] : state.points[state.selectedIndex]) || state.points[0];

  if (!startPoint || !state.points.length) {
    state.nullStats = {
      baseline: "same_length_uniform_random_walk",
      status: "no_points_available"
    };
    updateAll();
    return;
  }

  let same = 0, changed = 0, up = 0, down = 0;
  const deltaCounts = {};
  const shellChangesPerWalk = [];
  const netDeltaQPerWalk = [];
  const distinctShellsVisited = [];

  for (let trial = 0; trial < trials; trial++) {
    let current = startPoint;
    const startQ = current.q;
    let shellChanges = 0;
    const shells = new Set([current.q]);

    for (let step = 1; step < walkLength; step++) {
      const candidates = neighborCandidates(current);
      const next = candidates[Math.floor(Math.random() * candidates.length)];
      const dq = next.q - current.q;

      deltaCounts[dq] = (deltaCounts[dq] || 0) + 1;
      shells.add(next.q);

      if (dq === 0) same++;
      else {
        changed++;
        shellChanges++;
        if (dq > 0) up++;
        else down++;
      }

      current = next;
    }

    shellChangesPerWalk.push(shellChanges);
    netDeltaQPerWalk.push(current.q - startQ);
    distinctShellsVisited.push(shells.size);
  }

  const totalSteps = trials * stepsPerWalk;
  state.nullStats = {
    baseline: "same_length_uniform_random_walk",
    trials,
    walk_length: walkLength,
    steps_per_walk: stepsPerWalk,
    start_k: startPoint.k,
    start_q: startPoint.q,
    per_step_rates: {
      same_shell_rate: totalSteps ? Number((same / totalSteps).toFixed(6)) : 0,
      shell_changed_rate: totalSteps ? Number((changed / totalSteps).toFixed(6)) : 0,
      q_increase_rate: totalSteps ? Number((up / totalSteps).toFixed(6)) : 0,
      q_decrease_rate: totalSteps ? Number((down / totalSteps).toFixed(6)) : 0,
      delta_q_counts: deltaCounts
    },
    path_level_summaries: {
      shell_changes_per_walk: summarizeSeries(shellChangesPerWalk),
      net_delta_q: summarizeSeries(netDeltaQPerWalk),
      distinct_shells_visited: summarizeSeries(distinctShellsVisited)
    },
    real_path_for_reference: realPathStats(),
    status: "baseline_computed"
  };
  updateAll();
}

el.nInput.addEventListener("input", () => {
  state.n = Number(el.nInput.value);
  el.nValue.textContent = state.n;
  state.path = [];
  state.nullStats = null;
  buildChamber();
});

el.conventionSelect.addEventListener("change", () => {
  state.convention = el.conventionSelect.value;
  state.path = [];
  state.nullStats = null;
  buildChamber();
});

el.shellFilter.addEventListener("change", () => {
  state.shellFilter = el.shellFilter.value;
  drawChamber();
});

el.pointSize.addEventListener("input", () => {
  state.pointSize = Number(el.pointSize.value);
  el.pointSizeValue.textContent = state.pointSize;
  drawChamber();
});

el.rotX.addEventListener("input", () => {
  state.rotX = Number(el.rotX.value) / 100;
  drawChamber();
});

el.rotY.addEventListener("input", () => {
  state.rotY = Number(el.rotY.value) / 100;
  drawChamber();
});

el.zoom.addEventListener("input", () => {
  state.zoom = Number(el.zoom.value);
  drawChamber();
});

el.randomPointBtn.addEventListener("click", randomPoint);
el.stepWalkBtn.addEventListener("click", stepWalk);
el.radialPushBtn.addEventListener("click", radialPush);
el.shellSeekBtn.addEventListener("click", shellSeek);
el.resetPathBtn.addEventListener("click", () => { state.path = [state.points[state.selectedIndex]]; state.nullStats = null; updateAll(); });
el.runNullBtn.addEventListener("click", runNullBaseline);

buildChamber();
randomPoint();
