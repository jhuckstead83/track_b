# SPEC: Centered Rational Chamber Geometry

## 1. Chamber

For dimension \(d\):

\[
C_d(n)=
\left\{
\left(\frac{k_1}{n},\dots,\frac{k_d}{n}\right)
\right\}.
\]

For the main spatial build:

\[
d=3.
\]

## 2. GCD Collapse

Given integer chamber address:

\[
(k_1,\dots,k_d)
\]

define:

\[
g=\gcd(n,k_1,\dots,k_d)
\]

and:

\[
q=\frac{n}{g}.
\]

The value \(q\) is the reduced common denominator shell.

## 3. Jordan Totient

The expected population of shell \(q\) in dimension \(d\) is the Jordan totient:

\[
J_d(q)=q^d\prod_{p\mid q}\left(1-p^{-d}\right).
\]

Equivalent integer form:

\[
J_d(q)=q^d\prod_{p\mid q}\frac{p^d-1}{p^d}.
\]

For \(d=1\), this is Euler's totient:

\[
J_1(q)=\varphi(q).
\]

For \(d=3\):

\[
J_3(q)=q^3\prod_{p\mid q}\left(1-p^{-3}\right).
\]

## 4. Conservation Law

For residue classes modulo \(n\):

\[
\sum_{q\mid n}J_d(q)=n^d.
\]

For \(d=3\):

\[
\sum_{q\mid n}J_3(q)=n^3.
\]

This is the live conservation counter.

## 5. Boundary Conventions

Supported conventions:

### `residue`

\[
0\le k<n.
\]

This is the clean modular convention.

### `one_to_n`

\[
1\le k\le n.
\]

This is shell-count equivalent to `residue` if \(k=n\) is understood as the residue \(0\) for GCD shell purposes. Rendered coordinates differ.

### `zero_to_n_inclusive`

\[
0\le k\le n.
\]

This has \((n+1)^d\) points and is not expected to satisfy the \(n^d\) conservation counter.

### `centered_index`

Uses \(n\) index values but renders them symmetrically. This is useful for visualization. Its shell-count convention should be separately stated.

## 6. Centered Coordinates

The default centered render transform is:

\[
x_i=2\frac{k_i}{n}-1.
\]

For `one_to_n`, this maps to:

\[
(-1,1].
\]

For `residue`, this maps to:

\[
[-1,1-\frac{2}{n}].
\]

These are not the same visual cube, even when shell counts agree.

## 7. Radius-Vector

Given origin \(\mathbf O\):

\[
\mathbf r=\mathbf x-\mathbf O.
\]

If:

\[
\mathbf O=(0,0,0),
\]

then:

\[
\mathbf r=\mathbf x.
\]

The magnitude is:

\[
\rho=\|\mathbf r\|.
\]

The direction:

\[
\hat{\mathbf r}=\frac{\mathbf r}{\rho}
\]

is undefined when \(\rho=0\).

## 8. Origin Parity

Under \(x=2k/n-1\), the coordinate \(x=0\) requires:

\[
k=\frac{n}{2}.
\]

So the origin is a chamber point only when that \(k\) exists in the selected convention.

For odd \(n\), the center may fall between points.

## 9. Six-Cardinal Projection

For:

\[
\mathbf r=(r_x,r_y,r_z),
\]

define:

\[
P_{+x}=\max(r_x,0),\quad P_{-x}=\max(-r_x,0)
\]

and similarly for \(y,z\).

This projection is lossy. It is a directional summary, not a full replacement for \(\mathbf r\).

## 10. Time as Update

A state is:

\[
S_t=(\mathbf O_t,n_t,\mathbf k_t,q_t,\mathbf r_t).
\]

Time is represented as an update:

\[
U:S_t\mapsto S_{t+1}.
\]

No physical time claim is made unless units and dynamics are explicitly added.

## 11. Claim Ladder

1. Rendered
2. Computed
3. Verified
4. Observed relation
5. Null-separated
6. Proven
7. Physically interpreted

The first build should mostly live at Levels 1 to 5.
