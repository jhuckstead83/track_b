# Centered Rational Chamber Geometry Package

**Build posture:** represent first, verify live, interpret last.

This package implements a neutral interactive and audit toolkit for the centered rational chamber model:

\[
C_3(n)=\left\{\left(\frac{k_x}{n},\frac{k_y}{n},\frac{k_z}{n}\right)\right\}
\]

with GCD shell identity

\[
q=\frac{n}{\gcd(n,k_x,k_y,k_z)}.
\]

The package includes:

- `index.html` — standalone browser interactive
- `src/app.js` — chamber math + canvas renderer + live verification
- `src/style.css` — interface styling
- `py/chamber_audit.py` — Python audit/generator CLI
- `tests/test_chamber.py` — minimal test runner
- `SPEC.md` — implementation math/spec
- `RED_TEAM_NOTES.md` — neutral build discipline and risk flags
- `assets/manifest.json` — package manifest

## What this does

The interactive renders a 3D rational denominator chamber, assigns every point a reduced shell \(q\), verifies Jordan-totient shell counts, and lets the user explore:

- boundary conventions
- denominator shells
- centered radius-vectors
- six-cardinal projections
- path dynamics
- null baselines
- relation flags

## What this does not claim

This does not derive physics, the Dirac equation, relativity, quantum mechanics, energy, mass, or spin.

It gives a mathematical geometry laboratory where speculative bridges can be represented as `speculative_bridge`, not promoted as proof.

## Run the HTML

Open:

```text
index.html
```

No server is required.

## Run the Python audit

```bash
python py/chamber_audit.py --n 12 --d 3 --convention residue --pretty
```

Try:

```bash
python py/chamber_audit.py --n 12 --d 3 --convention one_to_n --pretty
python py/chamber_audit.py --n 12 --d 3 --convention zero_to_n_inclusive --pretty
python tests/test_chamber.py
```

## Boundary convention note

The Jordan conservation law

\[
\sum_{q\mid n}J_d(q)=n^d
\]

is guaranteed for residue classes \(0\le k<n\). The \(1\le k\le n\) convention is shell-count equivalent if \(k=n\) is treated as the residue \(0\) for the GCD shell count, though its rendered coordinates differ. Fully inclusive \(0\le k\le n\) has \((n+1)^d\) points and is intentionally marked convention-dependent.

## Origin parity note

With the common centering transform \(x=2k/n-1\), the origin is a chamber point only when the coordinate convention supplies \(k=n/2\), so parity matters. For even \(n\), a center point can exist. For odd \(n\), the center falls between grid points under this transform.

## Relation flags

Use relation flags rather than claim language:

- `proved`
- `observed`
- `requires_verification`
- `convention_artifact`
- `null_consistent`
- `speculative_bridge`


## Patch v0.2: Red-team punch-list fixes

This patched build incorporates the approved punch list:

1. Null baseline is now a same-length uniform random-walk ensemble from the same start point.
2. Point lookup now uses a `Map` keyed by `k.join(",")`, avoiding high-n linear scans during path interaction.
3. Selected-state relation flags now include `verified` when the conservation counter passes.
4. `centered_index` now gets an explicit shell-vs-rendered-geometry note in the live verification panel.
5. Null and six-cardinal panels now include firewall captions.
