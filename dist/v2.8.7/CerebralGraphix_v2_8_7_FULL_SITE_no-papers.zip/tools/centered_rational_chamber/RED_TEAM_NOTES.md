# RED TEAM NOTES: Neutral Build Discipline

## Core posture

Represent first. Verify live. Interpret last.

The model should faithfully incorporate the theory into a mathematical geometry engine without forcing a win condition.

## Must be visible in the interface

- Conservation counter
- Boundary convention
- Expected Jordan shell counts
- Actual shell counts
- Pass/fail status
- Origin parity note
- Vector and six-cardinal projection side by side
- Null baseline for dynamics
- Relation flag status

## High-risk zones

### 1. Physics bridge

Any Dirac, Lorentz, time-spin, momentum, or energy language must be flagged `speculative_bridge` unless implemented algebraically and tested.

### 2. Boundary conventions

Visual asymmetry can be an artifact. The UI must show when the convention causes it.

### 3. Six-cardinal compression

The six-channel projection loses diagonal information. It must not be displayed as the full vector.

### 4. Shell dynamics

A shell transition can be mere divisor arithmetic. The null baseline is required before interpreting a transition pattern.

## Good neutral phrasing

> The model logs this as an observed relation requiring verification.

Avoid:

> This proves the theory.

## Strongest build rule

Do not make the interface a lawyer. Make it a laboratory.
