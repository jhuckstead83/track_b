# PATCH REPORT v0.2

## Applied fixes

- FIX 1: null baseline now runs 500 same-length random walks from the same start point.
- FIX 2: point lookup is indexed by `k.join(',')` via `state.pointIndexByKey`.
- FIX 3: selected-state relation flags now include `verified` when conservation passes.
- FIX 4: `centered_index` live note now states shell-count equivalence and rendered-geometry difference.
- FIX 5: null/cardinal firewall captions added.

## Static acceptance checks

```json
{
  "same_length_null_baseline": true,
  "null_trials_500": true,
  "point_index_map": true,
  "selected_state_verified_flag": true,
  "centered_index_note": true
}
```

## Python test runner

```json
{
  "return_code": 0,
  "stdout": "All centered rational chamber tests passed.",
  "package_status": "passed",
  "note": "Any artifact_tool spreadsheet warmup warning in stderr is an external runtime startup warning, not a package test failure."
}
```

## JavaScript syntax check

```json
{
  "available": true,
  "return_code": 0,
  "stdout": "",
  "stderr": ""
}
```

## Audit samples

```json
[
  {
    "n": 12,
    "convention": "one_to_n",
    "return_code": 0,
    "passed": true,
    "actual_total": 1728,
    "expected_total": 1728,
    "mismatch_count": 0,
    "conservation_applies": true
  },
  {
    "n": 18,
    "convention": "residue",
    "return_code": 0,
    "passed": true,
    "actual_total": 5832,
    "expected_total": 5832,
    "mismatch_count": 0,
    "conservation_applies": true
  },
  {
    "n": 15,
    "convention": "centered_index",
    "return_code": 0,
    "passed": true,
    "actual_total": 3375,
    "expected_total": 3375,
    "mismatch_count": 0,
    "conservation_applies": true
  },
  {
    "n": 10,
    "convention": "zero_to_n_inclusive",
    "return_code": 0,
    "passed": false,
    "actual_total": 1331,
    "expected_total": 1000,
    "mismatch_count": 4,
    "conservation_applies": false
  }
]
```
