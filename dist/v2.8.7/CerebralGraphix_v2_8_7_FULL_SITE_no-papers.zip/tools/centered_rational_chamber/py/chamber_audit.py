#!/usr/bin/env python3
"""
Centered Rational Chamber Audit

A small CLI for verifying denominator-shell counts in rational chambers.

Core formulas:

    q = n / gcd(n, k_1, ..., k_d)

    J_d(q) = q^d * product_{p|q}(1 - p^{-d})

    sum_{q|n} J_d(q) = n^d

Run:

    python py/chamber_audit.py --n 12 --d 3 --convention residue --pretty
"""

from __future__ import annotations

import argparse
import json
import math
import random
from collections import Counter
from itertools import product
from typing import Dict, Iterable, List, Sequence, Tuple


def gcd_many(values: Sequence[int]) -> int:
    g = 0
    for value in values:
        g = math.gcd(g, int(value))
    return abs(g)


def prime_factors(n: int) -> List[int]:
    if n < 1:
        raise ValueError("n must be positive")
    x = n
    factors: List[int] = []
    p = 2
    while p * p <= x:
        if x % p == 0:
            factors.append(p)
            while x % p == 0:
                x //= p
        p += 1 if p == 2 else 2
    if x > 1:
        factors.append(x)
    return factors


def divisors(n: int) -> List[int]:
    return [q for q in range(1, n + 1) if n % q == 0]


def jordan_totient(q: int, d: int) -> int:
    """Return J_d(q) = q^d prod_{p|q}(1 - p^{-d})."""
    if q < 1:
        raise ValueError("q must be positive")
    if d < 1:
        raise ValueError("d must be positive")
    result = q ** d
    for p in prime_factors(q):
        result = result // (p ** d) * (p ** d - 1)
    return result


def k_values(n: int, convention: str) -> List[int]:
    if convention == "residue":
        return list(range(n))
    if convention == "one_to_n":
        return list(range(1, n + 1))
    if convention == "zero_to_n_inclusive":
        return list(range(n + 1))
    if convention == "centered_index":
        return list(range(n))
    raise ValueError(f"unknown convention: {convention}")


def shell_q(n: int, k_vec: Sequence[int]) -> int:
    g = gcd_many([n, *k_vec])
    if g == 0:
        raise ValueError("gcd collapse produced zero")
    return n // g


def centered_coordinate(k: int, n: int, convention: str) -> float:
    if convention == "centered_index":
        return 0.0 if n == 1 else 2.0 * k / (n - 1) - 1.0
    return 2.0 * k / n - 1.0


def shell_counts(n: int, d: int, convention: str) -> Counter:
    values = k_values(n, convention)
    counts: Counter = Counter()
    for k_vec in product(values, repeat=d):
        counts[shell_q(n, k_vec)] += 1
    return counts


def expected_shell_counts(n: int, d: int) -> Dict[int, int]:
    return {q: jordan_totient(q, d) for q in divisors(n)}


def conservation_applies(convention: str) -> bool:
    return convention in {"residue", "one_to_n", "centered_index"}


def verify_conservation(n: int, d: int, convention: str) -> Dict:
    actual = shell_counts(n, d, convention)
    expected = expected_shell_counts(n, d)
    expected_total = n ** d
    actual_total = sum(actual.values())
    mismatches = []
    for q in sorted(set(actual) | set(expected)):
        a = actual.get(q, 0)
        e = expected.get(q, None)
        if a != e:
            mismatches.append({"q": q, "actual": a, "expected": e})
    applies = conservation_applies(convention)
    passed = applies and actual_total == expected_total and not mismatches
    return {
        "n": n,
        "d": d,
        "convention": convention,
        "conservation_applies": applies,
        "actual_total": actual_total,
        "expected_total": expected_total,
        "passed": passed,
        "counts": dict(sorted(actual.items())),
        "expected": dict(sorted(expected.items())),
        "mismatches": mismatches,
    }


def state_metrics(n: int, k_vec: Sequence[int], convention: str = "one_to_n") -> Dict:
    coords = [centered_coordinate(k, n, convention) for k in k_vec]
    rho = math.sqrt(sum(x * x for x in coords))
    cardinal = {
        "+x": max(coords[0], 0.0),
        "-x": max(-coords[0], 0.0),
        "+y": max(coords[1], 0.0) if len(coords) > 1 else None,
        "-y": max(-coords[1], 0.0) if len(coords) > 1 else None,
        "+z": max(coords[2], 0.0) if len(coords) > 2 else None,
        "-z": max(-coords[2], 0.0) if len(coords) > 2 else None,
    }
    return {
        "n": n,
        "k": list(k_vec),
        "convention": convention,
        "q": shell_q(n, k_vec),
        "r": coords,
        "rho": rho,
        "six_cardinal": cardinal,
    }


def one_step_neighbors(n: int, k_vec: Sequence[int], convention: str) -> List[Tuple[int, ...]]:
    values = k_values(n, convention)
    lo, hi = min(values), max(values)
    out = []
    for axis in range(len(k_vec)):
        for delta in (-1, 1):
            k = list(k_vec)
            k[axis] += delta
            if k[axis] < lo:
                k[axis] = hi
            if k[axis] > hi:
                k[axis] = lo
            out.append(tuple(k))
    return out


def null_baseline(n: int, d: int, convention: str, start: Sequence[int] | None, trials: int, seed: int = 0) -> Dict:
    rng = random.Random(seed)
    values = k_values(n, convention)
    if start is None:
        start = tuple(rng.choice(values) for _ in range(d))
    start = tuple(start)
    start_q = shell_q(n, start)
    deltas: Counter = Counter()
    for _ in range(trials):
        nxt = rng.choice(one_step_neighbors(n, start, convention))
        deltas[shell_q(n, nxt) - start_q] += 1
    return {
        "baseline": "one_step_fixed_n_random_neighbor",
        "n": n,
        "d": d,
        "convention": convention,
        "start": list(start),
        "start_q": start_q,
        "trials": trials,
        "delta_q_counts": dict(sorted(deltas.items())),
        "same_shell_rate": deltas.get(0, 0) / trials,
        "shell_changed_rate": 1.0 - deltas.get(0, 0) / trials,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Audit centered rational chamber shell counts.")
    parser.add_argument("--n", type=int, default=12)
    parser.add_argument("--d", type=int, default=3)
    parser.add_argument("--convention", choices=["residue", "one_to_n", "zero_to_n_inclusive", "centered_index"], default="residue")
    parser.add_argument("--pretty", action="store_true")
    parser.add_argument("--null", action="store_true", help="include one-step null baseline")
    parser.add_argument("--trials", type=int, default=1000)
    args = parser.parse_args()

    report = verify_conservation(args.n, args.d, args.convention)
    if args.null:
        report["null_baseline"] = null_baseline(args.n, args.d, args.convention, None, args.trials)

    print(json.dumps(report, indent=2 if args.pretty else None, sort_keys=True))


if __name__ == "__main__":
    main()
