#!/usr/bin/env python3
"""Minimal tests for the centered rational chamber package."""

from pathlib import Path
import importlib.util
import sys

ROOT = Path(__file__).resolve().parents[1]
MOD_PATH = ROOT / "py" / "chamber_audit.py"
spec = importlib.util.spec_from_file_location("chamber_audit", MOD_PATH)
mod = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(mod)

def run():
    for d in (1, 2, 3):
        for n in range(2, 21):
            for convention in ("residue", "one_to_n", "centered_index"):
                report = mod.verify_conservation(n, d, convention)
                assert report["passed"], (n, d, convention, report["mismatches"])
    bad = mod.verify_conservation(6, 3, "zero_to_n_inclusive")
    assert not bad["passed"], "fully inclusive convention should not pass n^d conservation"
    assert mod.jordan_totient(1, 3) == 1
    assert mod.jordan_totient(2, 3) == 7
    assert mod.jordan_totient(3, 3) == 26
    print("All centered rational chamber tests passed.")

if __name__ == "__main__":
    run()
