# Six-Cardinal Picone packet — Delta 2 / Volume I construction

This packet updates the previous apex-outward trapped-ball build into a **single construction object** that carries both Volume I operators at once:

1. the **outward √2 / Pell cone-tip cascade**, and
2. the **inward √3 sphere–cube–sphere recursion**.

This is a **construction tool**, not a claim that the two operators are one mechanism. They share a center and a seed ball, but they remain distinct.

## Verification first
The cube already present in the apex-outward cone figure is **not** the first step of the inward √3 recursion.

- **Cone-figure cube**: half-side `π/2`, side `π`
- **√3-inscribed cube of the same seed ball**: half-side `(π/√2)/√3 ≈ 1.28254983`

These are not equal. The difference is intentional and now shown explicitly in the construction.

## Files

- `six_cardinal_picone.py` — standalone Plotly renderer, no external module dependency.
- `six_cardinal_picone.html` — offline self-contained Plotly HTML.
- `six_cardinal_picone_cdn.html` — smaller HTML that loads Plotly from the CDN.
- `six_cardinal_picone_BUILD_SPEC.md` — integrated build spec for the current construction.
- `six_cardinal_picone_companion_appendix.tex` — updated LaTeX appendix text.
- `ACCEPTANCE_REPORT.txt` — numeric checks from the run.
- `legacy/` — original uploaded single-cone build preserved for provenance.

## What the figure now contains

### Shared seed / frame
- six apex-outward 45° cones along `±x, ±y, ±z`
- one trapped central ball `R0 = r_c = π/√2`
- the **cone-figure cube** (the √2 frame), side `π`
- the cuboctahedron `(±π/2, ±π/2, 0)` and permutations

### Outward engine
- Pell / √2 cascade toward the six cone tips
- ratio `λ = 3 − 2√2`
- legend-group toggle: `pell_cone_tips`

### Inward engine
- nested axis-aligned √3 cubes and spheres at the center
- contraction `R_n = R_0 · 3^{-n/2}`
- default depth `M_in = 4`
- legend-group toggle: `sqrt3_inward`

## Slider meaning
The existing four-value slider remains active and treats the selected scalar as the shared seed radius `R0`:

- `√2`
- `π/√2`
- `√2/π`
- `π`

The figure then rebuilds the shared construction around that seed. The published seating remains `R0 = π/√2`, which gives `D = R0√2 = π`.

## Acceptance anchors
At the published setting:

- `R0 = π/√2 ≈ 2.22144147`
- `λ = 3 − 2√2 ≈ 0.17157288`
- cone-figure cube half-side `= π/2 ≈ 1.57079633`
- inward √3 cube half-side `= (π/√2)/√3 ≈ 1.28254983`
- inward radii:
  - `R1 ≈ 1.28255`
  - `R2 ≈ 0.74048`
  - `R3 ≈ 0.42752`
  - `R4 ≈ 0.24683`

The visible distinction between the **cone cube** and the **√3 cube** is the main new sanity check of this revision.
