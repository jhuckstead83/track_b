# Build spec — Six-Cardinal Picone (Volume I construction)
**For a builder to render. All geometry is closed-form below; do not re-derive — implement.**

Author: Jeffery Huckstead (Cerebral Graphix).

This revision incorporates:
- the **apex-outward trapped-ball** orientation, and
- **Delta 2**: the inward √3 sphere–cube–sphere operator plus the outward Pell / √2 tip cascade,

into one construction object.

---

## What this object is
This is a **construction** that renders two distinct Volume I operators in one shared figure. It is **not** a claim that those two operators are one mechanism.

The object has:
1. a shared center,
2. a shared seed sphere,
3. an outward **√2 / Pell** operator running to the six cardinal tips, and
4. an inward **√3 sphere–cube–sphere** operator running toward the center.

The shared center is the firewall: it lets both operators be seen at once without conflating them.

---

## Verification first
**Question:** is the cube from the apex-outward cone figure already the first step of the inward √3 sphere–cube–sphere recursion?

**Answer: no.** Keep the two cubes distinct.

### Cone-figure cube (from the six kiss circles)
For the published seed ball `R0 = r_c = π/√2`, the kiss-circle cube has
```python
half_side = π/2
side      = π
```
Its edge-midpoints lie on the sphere.

### √3-inscribed cube of the same seed sphere
For a sphere of radius `R0`, the inscribed cube satisfies
```python
space_diagonal = 2*R0
side           = 2*R0/√3
half_side      = R0/√3
```
So for `R0 = π/√2`:
```python
half_side = (π/√2)/√3 ≈ 1.28254983
```
This is not `π/2`. Therefore the cone-figure cube is **not** the √3 cube.

---

## Constants (inline; no external module)
```python
PI    = math.pi
SQ2   = 2 ** 0.5
SQ3   = 3 ** 0.5
LAM   = 3 - 2*SQ2               # Pell unit ≈ 0.17157288
H     = PI                      # cone height
```

## The six axes and their perpendicular frames `(â, û, ŵ)`
Each cone is apex-outward and uses
```python
P(t,θ) = D*â - t*â + t*cosθ*û + t*sinθ*ŵ,    t ∈ [0,H]
```
where `t=0` is the outward apex and `t=H` is the inward mouth rim.

| axis | â | û | ŵ |
|---|---|---|---|
| +z | (0,0,1) | (1,0,0) | (0,1,0) |
| −z | (0,0,−1) | (1,0,0) | (0,1,0) |
| +x | (1,0,0) | (0,1,0) | (0,0,1) |
| −x | (−1,0,0) | (0,1,0) | (0,0,1) |
| +y | (0,1,0) | (1,0,0) | (0,0,1) |
| −y | (0,−1,0) | (1,0,0) | (0,0,1) |

---

## Shared seed ball (the common center)
A 45° cone tangent to a sphere of radius `R0` centered a distance `D` from the apex satisfies
```python
sin45° = R0 / D    ⇒    D = R0 * √2
```
For the published seating:
```python
D  = H = π
R0 = π / √2
```
So the central shared seed is
```python
center = (0,0,0)
R0     = π / √2
```

---

## The cone-figure cube and cuboctahedron (the √2 frame)
The six wall-kiss circles are
```python
K(φ) = (R0/√2)*â + (R0/√2)*cosφ*û + (R0/√2)*sinφ*ŵ
```
Hence each circle has
```python
plane_offset = R0/√2
radius       = R0/√2
```
At the published seating, these are both `π/2`. The six circles are therefore the six face-incircles of the **cone-figure cube**:
```python
half_side = π/2
side      = π
vertices  = (±π/2, ±π/2, ±π/2)
```
Adjacent kiss circles intersect at the 12 points
```python
(±π/2, ±π/2, 0) and coordinate permutations
```
which are the 12 vertices of a cuboctahedron of circumradius `π/√2 = R0`.

This cube and this cuboctahedron are shared by the apex-inward and apex-outward duals.

---

## OUTWARD ENGINE — Pell / √2 cone-tip cascade
This is the outward operator. In each cone, measured inward from its outward tip, a wall-tangent sphere sequence contracts by
```python
LAM = 3 - 2*√2
```
The central ball is the shared `λ^0` seed. The smaller spheres run outward toward the apex.

For step `m = 1,2,3,...`:
```python
radius_m = R0 * LAM**m
z_m      = radius_m * √2
center_m = (D - z_m) * â
```
That places the sphere center along the cone axis between the center and the outward tip.

**Toggle name:** `pell_cone_tips`

Optional small cubes may be inscribed in these spheres, but they are not required for the main construction.

---

## INWARD ENGINE — √3 sphere–cube–sphere recursion
This is the inward operator. Start from the shared seed sphere of radius `R0`.

### Sphere → cube → sphere rule
```python
sphere radius R  →  inscribed cube:   side = 2R/√3,   half-side = R/√3
inscribed cube   →  inscribed sphere: inner radius = side/2 = R/√3
```
So a full inward step contracts the sphere radius by
```python
1/√3
```
Hence the inward radii are
```python
R_n = R0 * (1/√3)**n = (π/√2) * 3**(-n/2)
```
and the corresponding cubes are
```python
cube_n half-side = R_n / √3 = (π/√2) * 3**(-(n+1)/2)
```
Each cube is axis-aligned and centered at the origin.

Use depth
```python
M_in = 4
```
which gives visible radii `R1, R2, R3, R4`.

**Toggle name:** `sqrt3_inward`

Important: these inward cubes must be rendered in a visually distinct style from the cone-figure cube.

---

## The assembled construction
The complete object contains:
1. six apex-outward 45° cones,
2. one trapped central seed ball `R0 = π/√2`,
3. the cone-figure cube and cuboctahedron (the √2 frame),
4. the outward Pell / √2 tip cascade,
5. the inward √3 sphere–cube–sphere nesting.

Two operators, one seed, one center. Shared object, separate mechanisms.

---

## Slider behavior
The existing four-value slider remains. It treats the selected scalar as the shared seed radius:
```python
SCALARS = [ ("√2",      SQ2),
            ("π/√2",    PI/SQ2),
            ("√2/π",    SQ2/PI),
            ("π",       PI) ]
DEFAULT = 1
```
Per step:
```python
R0 = selected scalar
D  = R0 * √2
```
and rebuild the entire construction around that shared seed.

The published seating remains the `π/√2` position because only then does `D = H = π`.

---

## Rendering notes
- Use Plotly `graph_objects`.
- Cones: `Surface`, low opacity, one colorscale, `showscale=False`.
- Central seed ball: `Surface`, semi-opaque, main blue hero sphere.
- Kiss circles: `Scatter3d` lines, crimson.
- Cuboctahedron points: `Scatter3d` crimson diamonds.
- Cone-figure cube: dark wireframe.
- Inward √3 cubes: wireframes in a distinct color family from the cone cube.
- Inward spheres: semi-opaque nested `Surface` traces.
- Pell tip spheres: smaller `Surface` traces in the six cone tips.
- Add visibility toggles for the two engines, e.g. legend-group toggles or buttons:
  - `pell_cone_tips`
  - `sqrt3_inward`
- Keep `scene.aspectmode = 'data'`.

---

## Acceptance numbers (the run must reproduce these)
```python
trapped ball R0 = r_c     = π/√2 ≈ 2.22144147
λ (Pell, outward)         = 3 − 2√2 ≈ 0.17157288
cone-figure cube          side π, half-side π/2 = 1.57079633
√3 cube of R0 (inward)    half-side R0/√3 = (π/√2)/√3 ≈ 1.28254983
inward radii R_n          R1≈1.28255, R2≈0.74048, R3≈0.42752, R4≈0.24683
duality (orientation)     apex-in and apex-out share the same √2 cube & cuboctahedron
separation check          cone half-side 1.5708 ≠ √3 half-side 1.2825
```

*If the inward √3 cube comes out equal to the cone-figure cube, the inward operator was keyed wrong: it must use `side = 2R/√3`, not the kiss-circle cube.*
