# six_cardinal_picone.py — Volume I construction in one object
# Author: Jeffery Huckstead (Cerebral Graphix)
#
# This build assembles two distinct operators around one shared central seed ball:
#   (1) the outward Pell / sqrt(2) cone-tip cascade, and
#   (2) the inward sqrt(3) sphere-cube-sphere recursion.
# It is a construction aid for Volume I, not a claim that the two operators are
# one mechanism.

import math
from itertools import product
from pathlib import Path

import numpy as np
import plotly.graph_objects as go

PI = math.pi
SQ2 = 2 ** 0.5
SQ3 = 3 ** 0.5
SIN45 = 1 / SQ2
LAM = 3 - 2 * SQ2
H = PI
DEFAULT = 1
N_PELL = 3
M_IN = 4

SCALARS = [
    ("√2", SQ2),
    ("π/√2", PI / SQ2),
    ("√2/π", SQ2 / PI),
    ("π", PI),
]

AXES = [
    ("+z", np.array([0.0, 0.0, 1.0]), np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0])),
    ("−z", np.array([0.0, 0.0, -1.0]), np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0])),
    ("+x", np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0]), np.array([0.0, 0.0, 1.0])),
    ("−x", np.array([-1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0]), np.array([0.0, 0.0, 1.0])),
    ("+y", np.array([0.0, 1.0, 0.0]), np.array([1.0, 0.0, 0.0]), np.array([0.0, 0.0, 1.0])),
    ("−y", np.array([0.0, -1.0, 0.0]), np.array([1.0, 0.0, 0.0]), np.array([0.0, 0.0, 1.0])),
]

BALL_COLOR = "#4f81bd"
KISS_COLOR = "crimson"
CONE_COLORSCALE = "YlOrBr"
CONE_CUBE_COLOR = "rgba(35,35,35,0.80)"
SQRT3_CUBE_COLOR = "rgba(18,114,84,0.90)"
TIP_COLOR = "black"
PELL_RAMP = ["#204a87", "#3465a4", "#729fcf"]
SQRT3_SPHERE_RAMP = ["#c8e6c9", "#a5d6a7", "#81c784", "#66bb6a"]


def cone_surface_outward(axis, u_vec, w_vec, D, nt=42, nth=70):
    """Apex-outward cone: P(t,theta)=D*a - t*a + t*cos(theta)*u + t*sin(theta)*w."""
    t = np.linspace(0.0, H, nt)
    theta = np.linspace(0.0, 2 * PI, nth)
    T, TH = np.meshgrid(t, theta, indexing="ij")
    points = (
        D * axis
        - T[..., None] * axis
        + T[..., None] * np.cos(TH)[..., None] * u_vec
        + T[..., None] * np.sin(TH)[..., None] * w_vec
    )
    return points[..., 0], points[..., 1], points[..., 2], T


def sphere_surface(center, radius, nu=40, nv=22):
    u = np.linspace(0.0, 2 * PI, nu)
    v = np.linspace(0.0, PI, nv)
    U, V = np.meshgrid(u, v, indexing="ij")
    unit = np.stack([
        np.cos(U) * np.sin(V),
        np.sin(U) * np.sin(V),
        np.cos(V),
    ], axis=-1)
    points = center + radius * unit
    return points[..., 0], points[..., 1], points[..., 2]


def kiss_circle(axis, u_vec, w_vec, rc, n=180):
    q = rc / SQ2
    phi = np.linspace(0.0, 2 * PI, n)
    points = q * axis + q * np.cos(phi)[:, None] * u_vec + q * np.sin(phi)[:, None] * w_vec
    return points[:, 0], points[:, 1], points[:, 2]


def cube_wireframe(halfside):
    verts = list(product([-halfside, halfside], repeat=3))
    xs, ys, zs = [], [], []
    for i, v1 in enumerate(verts):
        for v2 in verts[i + 1 :]:
            if sum(a != b for a, b in zip(v1, v2)) == 1:
                xs.extend([v1[0], v2[0], None])
                ys.extend([v1[1], v2[1], None])
                zs.extend([v1[2], v2[2], None])
    return xs, ys, zs


def cuboctahedron_points(rc):
    q = rc / SQ2
    pts = []
    for zero_idx in range(3):
        other = [i for i in range(3) if i != zero_idx]
        for s1 in (-1, 1):
            for s2 in (-1, 1):
                p = [0.0, 0.0, 0.0]
                p[other[0]] = s1 * q
                p[other[1]] = s2 * q
                pts.append(p)
    return np.array(pts, dtype=float)


def tip_points(D):
    pts = np.array([D * axis for _, axis, _, _ in AXES], dtype=float)
    return pts[:, 0], pts[:, 1], pts[:, 2]


def pell_sphere_center(axis, D, radius):
    z = radius * SQ2
    return (D - z) * axis


def inward_radii(rc, depth=M_IN):
    return [rc * (1 / SQ3) ** n for n in range(depth + 1)]


def seating_status(D):
    if abs(D - H) < 1e-12:
        return "published seating: cone tips exactly at distance H = π"
    if D < H:
        return "tips sit closer in than the published H = π seating"
    return "tips sit farther out than the published H = π seating"


def annotation_for(label, rc):
    D = rc * SQ2
    cone_cube_half = rc / SQ2
    sqrt3_cube_half = rc / SQ3
    inner = inward_radii(rc)
    r1, r2, r3, r4 = inner[1:5]
    return (
        f"<b>scalar R₀ = r<sub>c</sub> = {label}</b> &nbsp; = {rc:.8f}<br>"
        f"apex distance: D = r<sub>c</sub>√2 = {D:.8f}; H = π = {H:.8f}<br>"
        f"read: {seating_status(D)}<br>"
        f"cone-figure cube half-side = r<sub>c</sub>/√2 = {cone_cube_half:.8f}<br>"
        f"√3 inward cube half-side = r<sub>c</sub>/√3 = {sqrt3_cube_half:.8f}<br>"
        f"separation check: Δ = {cone_cube_half - sqrt3_cube_half:.8f} (must be nonzero)<br>"
        f"inward radii: R₁={r1:.5f}, R₂={r2:.5f}, R₃={r3:.5f}, R₄={r4:.5f}<br>"
        f"outward Pell ratio λ = 3−2√2 = {LAM:.8f}"
    )


def fixed_annotation():
    return (
        "<b>Volume I construction in one object</b><br>"
        "two operators share one seed ball and one center, but remain distinct:<br>"
        "(1) outward √2 / Pell cone-tip cascade, and (2) inward √3 sphere→cube→sphere recursion<br>"
        "do not conflate the two cubes: the cone-figure cube is the √2 frame; the inward cube is the √3 operator's cube<br>"
        "the shared center is a construction device, not a claim of one mechanism"
    )


def layout_annotations(label, rc):
    return [
        dict(
            text=annotation_for(label, rc),
            x=0.01,
            y=0.99,
            xref="paper",
            yref="paper",
            showarrow=False,
            align="left",
            font=dict(size=12, color="#10314f"),
            bgcolor="rgba(255,255,255,0.84)",
            bordercolor="#9cc6ec",
            borderwidth=1,
        ),
        dict(
            text=fixed_annotation(),
            x=0.01,
            y=0.03,
            xref="paper",
            yref="paper",
            showarrow=False,
            align="left",
            font=dict(size=11, color="#333333"),
            bgcolor="rgba(255,255,255,0.78)",
            bordercolor="rgba(0,0,0,0.18)",
            borderwidth=1,
        ),
    ]


def make_figure():
    fig = go.Figure()

    # Dummy legend-group toggles. Clicking these group labels toggles all traces in the group.
    fig.add_trace(
        go.Scatter3d(
            x=[None], y=[None], z=[None],
            mode="markers",
            marker=dict(size=8, color=PELL_RAMP[0]),
            name="pell_cone_tips",
            legendgroup="pell_cone_tips",
            showlegend=True,
            hoverinfo="skip",
        )
    )
    fig.add_trace(
        go.Scatter3d(
            x=[None], y=[None], z=[None],
            mode="markers",
            marker=dict(size=8, color=SQRT3_CUBE_COLOR),
            name="sqrt3_inward",
            legendgroup="sqrt3_inward",
            showlegend=True,
            hoverinfo="skip",
        )
    )

    static_count = len(fig.data)  # legend toggle dummies remain always on
    group_ranges = []

    for scalar_idx, (label, rc) in enumerate(SCALARS):
        group_start = len(fig.data)
        D = rc * SQ2
        cone_cube_half = rc / SQ2

        # Base frame: cones, seed ball, kiss circles, cone-figure cube, cuboctahedron, markers.
        for axis_label, axis, u_vec, w_vec in AXES:
            x, y, z, t = cone_surface_outward(axis, u_vec, w_vec, D)
            fig.add_trace(
                go.Surface(
                    x=x, y=y, z=z,
                    surfacecolor=t,
                    colorscale=CONE_COLORSCALE,
                    cmin=0, cmax=H,
                    opacity=0.15,
                    showscale=False,
                    name=f"{label} cone {axis_label}",
                    hovertemplate=f"cone {axis_label}<br>D={D:.6f}<extra></extra>",
                    showlegend=False,
                )
            )

        sx, sy, sz = sphere_surface(np.array([0.0, 0.0, 0.0]), rc)
        fig.add_trace(
            go.Surface(
                x=sx, y=sy, z=sz,
                colorscale=[[0, BALL_COLOR], [1, BALL_COLOR]],
                opacity=0.64,
                showscale=False,
                name=f"{label} trapped ball",
                hovertemplate=f"seed ball<br>R0={rc:.6f}<extra></extra>",
                showlegend=False,
            )
        )

        for axis_label, axis, u_vec, w_vec in AXES:
            cx, cy, cz = kiss_circle(axis, u_vec, w_vec, rc)
            fig.add_trace(
                go.Scatter3d(
                    x=cx, y=cy, z=cz,
                    mode="lines",
                    line=dict(color=KISS_COLOR, width=5),
                    name=f"{label} kiss {axis_label}",
                    hoverinfo="skip",
                    showlegend=False,
                )
            )

        pts = cuboctahedron_points(rc)
        fig.add_trace(
            go.Scatter3d(
                x=pts[:, 0], y=pts[:, 1], z=pts[:, 2],
                mode="markers",
                marker=dict(size=5, color=KISS_COLOR, symbol="diamond"),
                name=f"{label} cuboctahedron",
                hovertemplate="cuboctahedron vertex<br>x=%{x:.6f}<br>y=%{y:.6f}<br>z=%{z:.6f}<extra></extra>",
                showlegend=False,
            )
        )

        wx, wy, wz = cube_wireframe(cone_cube_half)
        fig.add_trace(
            go.Scatter3d(
                x=wx, y=wy, z=wz,
                mode="lines",
                line=dict(color=CONE_CUBE_COLOR, width=4),
                name=f"{label} cone cube",
                hoverinfo="skip",
                showlegend=False,
            )
        )

        fig.add_trace(
            go.Scatter3d(
                x=[0.0], y=[0.0], z=[0.0],
                mode="markers",
                marker=dict(size=5, color=TIP_COLOR, symbol="circle"),
                name="center",
                hovertemplate="shared center<extra></extra>",
                showlegend=False,
            )
        )

        tx, ty, tz = tip_points(D)
        fig.add_trace(
            go.Scatter3d(
                x=tx, y=ty, z=tz,
                mode="markers",
                marker=dict(size=4, color=TIP_COLOR, symbol="circle"),
                name=f"{label} tips",
                hovertemplate="outward tip<br>x=%{x:.6f}<br>y=%{y:.6f}<br>z=%{z:.6f}<extra></extra>",
                showlegend=False,
            )
        )

        # Outward Pell cone tips.
        for axis_label, axis, _, _ in AXES:
            for m in range(1, N_PELL + 1):
                radius = rc * (LAM ** m)
                center = pell_sphere_center(axis, D, radius)
                px, py, pz = sphere_surface(center, radius, nu=28, nv=16)
                fig.add_trace(
                    go.Surface(
                        x=px, y=py, z=pz,
                        colorscale=[[0, PELL_RAMP[m - 1]], [1, PELL_RAMP[m - 1]]],
                        opacity=0.80,
                        showscale=False,
                        name=f"{label} Pell {axis_label} m={m}",
                        hovertemplate=(
                            f"pell_cone_tips<br>axis={axis_label}<br>m={m}<br>"
                            f"radius={radius:.6f}<extra></extra>"
                        ),
                        legendgroup="pell_cone_tips",
                        showlegend=False,
                    )
                )

        # Inward √3 engine: cube_0 inside R0, then spheres R1..RM and cubes cube_1..cube_{M-1}.
        inner = inward_radii(rc, M_IN)
        for n in range(M_IN):
            halfside = inner[n] / SQ3
            wx, wy, wz = cube_wireframe(halfside)
            fig.add_trace(
                go.Scatter3d(
                    x=wx, y=wy, z=wz,
                    mode="lines",
                    line=dict(color=SQRT3_CUBE_COLOR, width=5 if n == 0 else 3),
                    name=f"{label} √3 cube {n}",
                    hovertemplate=f"sqrt3_inward<br>cube_{n} half-side={halfside:.6f}<extra></extra>",
                    legendgroup="sqrt3_inward",
                    showlegend=False,
                )
            )
            sphere_radius = inner[n + 1]
            sx, sy, sz = sphere_surface(np.array([0.0, 0.0, 0.0]), sphere_radius, nu=28, nv=16)
            fig.add_trace(
                go.Surface(
                    x=sx, y=sy, z=sz,
                    colorscale=[[0, SQRT3_SPHERE_RAMP[n]], [1, SQRT3_SPHERE_RAMP[n]]],
                    opacity=0.18 + 0.06 * (M_IN - n),
                    showscale=False,
                    name=f"{label} √3 sphere {n+1}",
                    hovertemplate=f"sqrt3_inward<br>R{n+1}={sphere_radius:.6f}<extra></extra>",
                    legendgroup="sqrt3_inward",
                    showlegend=False,
                )
            )

        group_ranges.append((group_start, len(fig.data)))

    def visible_for(active_idx):
        visible = [True] * static_count + [False] * (len(fig.data) - static_count)
        lo, hi = group_ranges[active_idx]
        for i in range(lo, hi):
            visible[i] = True
        return visible

    steps = []
    for i, (label, rc) in enumerate(SCALARS):
        steps.append(
            dict(
                method="update",
                label=label,
                args=[
                    {"visible": visible_for(i)},
                    {"annotations": layout_annotations(label, rc)},
                ],
            )
        )

    default_visible = visible_for(DEFAULT)
    for idx, trace in enumerate(fig.data):
        trace.visible = default_visible[idx]

    fig.update_layout(
        title="Six-Cardinal Picone — Volume I construction: outward √2 / Pell and inward √3",
        scene=dict(
            xaxis_title="X",
            yaxis_title="Y",
            zaxis_title="Z",
            aspectmode="data",
            camera=dict(eye=dict(x=1.80, y=1.60, z=1.22)),
        ),
        sliders=[
            dict(
                active=DEFAULT,
                currentvalue={"prefix": "shared seed radius R₀ = "},
                pad={"t": 32},
                steps=steps,
            )
        ],
        annotations=layout_annotations(*SCALARS[DEFAULT]),
        margin=dict(l=0, r=0, t=52, b=0),
        showlegend=True,
        legend=dict(
            x=0.99,
            y=0.99,
            xanchor="right",
            yanchor="top",
            bgcolor="rgba(255,255,255,0.70)",
            bordercolor="rgba(0,0,0,0.18)",
            borderwidth=1,
            groupclick="togglegroup",
        ),
    )

    return fig


def acceptance_rows():
    rows = []
    for label, rc in SCALARS:
        D = rc * SQ2
        cone_cube_half = rc / SQ2
        sqrt3_cube_half = rc / SQ3
        rows.append((label, rc, D, D - H, cone_cube_half, sqrt3_cube_half))
    return rows


def write_outputs(out_dir=".", include_offline=True):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    fig = make_figure()

    slim_html = out / "six_cardinal_picone_cdn.html"
    fig.write_html(slim_html, include_plotlyjs="cdn", full_html=True)

    offline_html = out / "six_cardinal_picone.html"
    if include_offline:
        fig.write_html(offline_html, include_plotlyjs=True, full_html=True)

    r0 = PI / SQ2
    cone_cube_half = r0 / SQ2
    sqrt3_cube_half = r0 / SQ3
    inward = inward_radii(r0, M_IN)

    lines = [
        "Six-Cardinal Picone acceptance report — Delta 2 Volume I construction",
        "====================================================================",
        "",
        "Verification first:",
        "- The cone-figure cube is NOT the first step of the √3 sphere-cube-sphere recursion.",
        "- They are different cubes, by different rules, sharing only a center and a seed sphere.",
        "",
        f"trapped ball R0 = r_c = pi/sqrt(2) = {r0:.12f}",
        f"lambda (Pell, outward) = 3 - 2*sqrt(2) = {LAM:.12f}",
        f"cone-figure cube half-side = pi/2 = {cone_cube_half:.12f}; side = pi = {PI:.12f}",
        f"sqrt3 cube of R0 half-side = R0/sqrt(3) = {sqrt3_cube_half:.12f}",
        f"separation check delta = cone_half - sqrt3_half = {cone_cube_half - sqrt3_cube_half:.12f}",
        "",
        "Inward radii R_n = R0 * 3^(-n/2):",
    ]
    for n, radius in enumerate(inward):
        lines.append(f"- R{n} = {radius:.12f}")
    lines += [
        "",
        "Published cube vertices (cone-figure cube): (±pi/2, ±pi/2, ±pi/2).",
        "Published cuboctahedron vertices: (±pi/2, ±pi/2, 0) and coordinate permutations.",
        "Duality check: apex-in and apex-out builds share the same √2 cube and cuboctahedron.",
        "",
        "Scalar checks:",
    ]
    for label, rc, D, dminus, cone_half, sqrt3_half in acceptance_rows():
        lines.append(
            f"- R0={label:5s}: R0={rc:.12f}; D=R0*sqrt2={D:.12f}; D-H={dminus:.12e}; "
            f"cone_cube_half={cone_half:.12f}; sqrt3_cube_half={sqrt3_half:.12f}; {seating_status(D)}"
        )
    (out / "ACCEPTANCE_REPORT.txt").write_text("\n".join(lines), encoding="utf-8")

    return slim_html, offline_html if include_offline else None


if __name__ == "__main__":
    slim, offline = write_outputs(".", include_offline=True)
    print(f"wrote {slim}")
    print(f"wrote {offline}")
    print(f"LAM = {LAM:.8f}")
    for label, rc, D, dminus, cone_half, sqrt3_half in acceptance_rows():
        print(
            f"{label:5s} R0={rc:.8f} D={D:.8f} D-H={dminus:.6e} "
            f"cone_half={cone_half:.8f} sqrt3_half={sqrt3_half:.8f}"
        )
