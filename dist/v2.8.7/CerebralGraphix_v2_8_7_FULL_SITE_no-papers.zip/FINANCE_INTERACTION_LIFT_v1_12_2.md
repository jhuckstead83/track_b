# Finance Interaction Lift v1.12.2

## Source

- Base package: user-supplied `cerebralgraphix_site_v1_12_1_FLAT_ROOT_DEPLOY (2)(1).zip`.
- Design reference: `Design seat bootstrap(5).zip`, especially `Finance Weather - Live.dc.html`.
- Legacy page and legacy images: preserved from the user-supplied base package without replacement.

## Applied changes

- Reframed the page as **Market Weather Grid** rather than repeating “chamber” across the interface.
- Preserved the canonical 4×4 semantic order:
  - Utilities, Real Estate, Food, Healthcare
  - Defense, Banks, Macro ETF, Telecom
  - Energy, Materials, AI Big, Media
  - AI Semis, Industrials, Autos / EV, Retail
- Added compact descriptions for the ambiguous pairs:
  - AI Semis: `chips & fabs (*NVDA)`
  - AI Big: `AI platforms (*MSFT)`
  - Materials: `metals & chemicals (*LIN)`
  - Industrials: `machinery & freight (*CAT)`
- Added a visible fence stating that parenthetical names are examples only, not current constituents or recommendations.
- Short press/tap lifts a tile and reveals safe aggregate detail.
- Long press toggles board-unlocked mode. Long press again or use **Lock grid** to exit.
- Unlocked movement is snap-only and limited to one adjacent king step per move. An occupied destination swaps with the moved tile.
- Layout is local-device state only and can be restored with **Return to board**.
- Rank sorting remains a separate shelf and never impersonates the semantic board.
- Overnight base/overlay/delta/coverage behavior remains data-driven and zero-safe.
- Fidelity labels remain visible at narrow widths.

## Files changed

- `finance/live.html`
- `finance/index.html`
- `assets/phi_finance_grid_v2.js`
- `assets/phi_finance_grid_v2.css`
- `release-v1.12.json`

## Files deliberately not changed

- `finance/legacy.html`
- `finance/latest/sector_pressure_over_snapshots.png`
- `finance/latest/sector_pressure_average_over_snapshots.png`
- the finance notebook and R2 publisher
