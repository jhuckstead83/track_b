# Finance Interaction QA v1.12.2

## Result

**PASS for deployment packaging.** The live market calls remain production-runtime checks; the browser and data-contract behavior were exercised with typed mock public payloads.

## Verified

- Canonical 16-cell order resolves exactly.
- No tile repeats the word “chamber.”
- AI Semis, AI Big, Materials, and Industrials carry short explanatory shorthand.
- The `*` examples-only fence is visible.
- Short press expands a tile and reveals safe aggregate detail.
- Long press unlocks the grid; a second long press locks it.
- Dragging is snap-only and one adjacent king step per move; occupied cells swap.
- Ranking remains outside the canonical board.
- All 16 fidelity labels remain visible in the narrow layout.
- Overnight-present mock: 16 overnight reads rendered.
- Overnight-missing mock: 0 overnight reads and 16 explicit missing states.
- Null and absent values are not coerced to zero.
- Provider selection remains upstream; the browser only displays supplied provenance.
- The user-supplied legacy page and both legacy PNGs are byte-identical to the base package.

## Widths exercised

- 320 px
- 390 px
- 1440 px

The board may scroll internally at the narrowest width, while the document itself remains contained.

## Legacy preservation hashes

- `finance/legacy.html`
  `53152162dc8c00c05b8a94e173ba0f8ffc7fea5a0c235c6e64c26666982551c3`
- `finance/latest/sector_pressure_over_snapshots.png`
  `595f9d3bda1e0cc75d6604bcaee80167702f323c01798b656a51f6a914bae5af`
- `finance/latest/sector_pressure_average_over_snapshots.png`
  `e75738c3c1d4b33b1e3cbd6527348462d2ecad6a33e9800ef0cbf6d07569cc89`

## Production checks after deploy

1. Confirm the page resolves `/finance/live.html` without stale cache.
2. Confirm `chamber_grid_public.json` supplies all sixteen base cells.
3. Confirm `overnight_overlay.json` adds base, overnight, delta, and coverage during a live overnight cycle.
4. Confirm a closed or missing overlay state stays missing rather than displaying zero.
5. Test long-press behavior on one iOS and one Android browser, because touch gesture timing is device-sensitive.
