# Finance Membrane QA

```json
{
  "release": "v1.8-finance-membrane",
  "notebook_modified": false,
  "public_live_path": "/finance/live.html",
  "legacy_path": "/finance/legacy.html",
  "private_shell_path": "/finance/private/",
  "private_payload_embedded_in_deployable_site": false,
  "public_loader_priority": [
    "future chamber_grid_public.json",
    "current safe sector_plot_data.json",
    "local safe sector_plot_data.json"
  ],
  "removed_public_artifacts_count": 27,
  "removed_public_artifacts": [
    "finance/daily/2026-06-16/intraday_ledger.csv",
    "finance/daily/2026-06-16/intraday_ledger.json",
    "finance/daily/2026-06-16/intraday_ledger.md",
    "finance/daily/2026-06-16/latest_sector_comparator.csv",
    "finance/daily/2026-06-16/latest_sector_comparator.json",
    "finance/daily/2026-06-16/latest_symbol_pressure.csv",
    "finance/daily/2026-06-16/latest_symbol_pressure.json",
    "finance/daily/2026-06-16/look_here.csv",
    "finance/daily/2026-06-16/look_here.json",
    "finance/daily/2026-06-16/sector_weather_history.csv",
    "finance/daily/2026-06-16/sector_weather_history.json",
    "finance/daily/2026-06-17/intraday_ledger.csv",
    "finance/daily/2026-06-17/intraday_ledger.json",
    "finance/daily/2026-06-17/intraday_ledger.md",
    "finance/daily/2026-06-17/latest_sector_comparator.csv",
    "finance/daily/2026-06-17/latest_sector_comparator.json",
    "finance/daily/2026-06-17/latest_symbol_pressure.csv",
    "finance/daily/2026-06-17/latest_symbol_pressure.json",
    "finance/daily/2026-06-17/look_here.csv",
    "finance/daily/2026-06-17/look_here.json",
    "finance/daily/2026-06-17/sector_weather_history.csv",
    "finance/daily/2026-06-17/sector_weather_history.json",
    "finance/latest/latest_sector_comparator.json",
    "finance/latest/latest_symbol_pressure.json",
    "finance/latest/look_here.json",
    "finance/latest/latest_plate.json",
    "assets/phi_live_window.js"
  ],
  "named_asset_key_violations_in_public_json_csv": [],
  "private_path_in_sitemap": false,
  "private_path_in_site_index": false,
  "boundary_stamps": [
    "market_truth: NOT_PROVEN_BY_RECEIPT",
    "trade_permission: NO"
  ],
  "notebook_grid_alignment": {
    "placement": "PHI_CHAMBER_GRID-v1.1",
    "renderer": "build_phi_chamber_grid_frame fields",
    "headline": "median_bps",
    "max_age_seconds": 300
  }
}
```
