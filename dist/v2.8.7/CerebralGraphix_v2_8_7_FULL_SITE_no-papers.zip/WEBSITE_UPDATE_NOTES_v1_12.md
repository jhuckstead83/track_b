# Cerebral Graphix website v1.12

## Integrated

- New selective `/atlas/` site based on the Claude design seat, linked to the preserved detailed Chamber-Lift Atlas.
- Author-supplied 51-record active research index and JSON manifest. Restricted or otherwise served records are treated as deprecated/historical.
- Final C-Geometry live HTML, PDF, supplement, and captures at `/tools/triangular_addressed_c_geometry/`.
- Fixed 4×4 Finance Weather board preserving defensive→cyclical and upstream→downstream coordinates.
- Overnight public overlay support from `/finance/latest/overnight_overlay.json`; base close stays visible and missing values never become zero.
- Rank-by-feature shelf that does not move semantic board coordinates.
- Legacy finance page restyled; rightmost 10% of the notebook image is cropped with CSS only.
- DOI corrections: TFG 21440877, From Measure to Flux 21444339, C-Geometry 21444929.

## Intentionally preserved

- Existing detailed Chamber-Lift Atlas remains at `/tools/chamber_lift_atlas.html`.
- The finance notebook and generated plot files are untouched.
- Atlas islands remain islands when no exact written relationship is earned.
