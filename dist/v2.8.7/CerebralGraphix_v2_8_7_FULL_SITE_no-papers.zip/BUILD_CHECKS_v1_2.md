# Build Checks v1.2

```json
{
  "checks": {
    "index_html_exists": true,
    "papers_index_html_exists": true,
    "papers_Addresses_Are_Not_Meanings_pdf_exists": true,
    "papers_Volume_I_Exact_Geometry_and_Symbolic_Foundations_pdf_exists": true,
    "papers_Kitchen_Scale_Breath_Figures_Measured_v03_pdf_exists": true,
    "sitemap_xml_exists": true,
    "site-index_html_exists": true,
    "site-index_json_exists": true,
    "homepage_has_new_papers": true,
    "homepage_has_zenodo_links": true,
    "papers_index_has_new_papers": true,
    "papers_index_has_abstracts": true,
    "sitemap_has_new_papers": true,
    "site_index_html_has_new_papers": true,
    "site_index_json_has_new_papers": true,
    "sitemap_xml_valid": true,
    "site_index_json_valid": true,
    "pdf_sizes": {
      "Addresses_Are_Not_Meanings.pdf": 325678,
      "Volume_I_Exact_Geometry_and_Symbolic_Foundations.pdf": 412030,
      "Kitchen_Scale_Breath_Figures_Measured_v03.pdf": 2769745
    }
  }
}
```
