# Cerebral Graphix v1.2 Papers Update

This package updates the homepage paper shelf, `papers/index.html`, and crawler-facing paper metadata.

## Added PDFs

```text
papers/Addresses_Are_Not_Meanings.pdf
papers/Volume_I_Exact_Geometry_and_Symbolic_Foundations.pdf
papers/Kitchen_Scale_Breath_Figures_Measured_v03.pdf
```

## Added external record links

```text
https://zenodo.org/records/20777416
https://zenodo.org/records/20768701
```

## Updated files

```text
index.html
papers/index.html
sitemap.xml
site-index.html
site-index.json
```

## Deployment

Use the overwrite patch if the current site is already v1.1:

```text
cerebralgraphix_v1_2_papers_overwrite_patch.zip
```

Or use the full site package:

```text
cerebralgraphix_site_v1_2_papers_update.zip
```

## Checks

```json
{
  "index_html_exists": true,
  "papers_index_html_exists": true,
  "papers_Addresses_Are_Not_Meanings_pdf_exists": true,
  "papers_Volume_I_Exact_Geometry_and_Symbolic_Foundations_pdf_exists": true,
  "papers_Kitchen_Scale_Breath_Figures_Measured_v03_pdf_exists": true,
  "sitemap_xml_exists": true,
  "site-index_html_exists": true,
  "site-index_json_exists": true,
  "homepage_has_new_papers": true,
  "homepage_has_zenodo_links": true,
  "papers_index_has_new_papers": true,
  "papers_index_has_abstracts": true,
  "sitemap_has_new_papers": true,
  "site_index_html_has_new_papers": true,
  "site_index_json_has_new_papers": true,
  "sitemap_xml_valid": true,
  "site_index_json_valid": true,
  "pdf_sizes": {
    "Addresses_Are_Not_Meanings.pdf": 325678,
    "Volume_I_Exact_Geometry_and_Symbolic_Foundations.pdf": 412030,
    "Kitchen_Scale_Breath_Figures_Measured_v03.pdf": 2769745
  }
}
```
