# Forge 51 · coordinator return v0.4

27 September 2026. Controlling input: Claude’s **unpublished** `CerebralGraphix_v2_8_0_FULL_SITE.zip`, SHA256 `834f5929c08a8f50b95e1a96862dfd05993361da404090cf0e6a37c80654c450`. Output site: v2.8.1. RH remains OPEN.

## What survives independent review

| Claim | Coordinator result | Scope |
|---|---|---|
| Four predecessors are sharp inside the equal-deal class | Confirmed by independent Python replay of 20 deals, 844 turns | Five supplied endpoints at turns 32, 35, 41, 50, 53; frozen three-queue rule |
| Turn-85 endpoint has one eligible immediate past | Confirmed | Equal 17–17–17 start **and elapsed turn 85**; branch 10 exhausts 336 admissible states, deepest turn 66 |
| Turn-85 future enters period 3,744 at turn 356 | Supplied JS verifier independently rerun successfully | Exact disclosed state |
| 1,652/2,000 sampled deals cycle, 348 end; period gcd 52 | Reproduced by the shipped Twins verifier | Sample evidence; no general divisibility theorem |
| Prospect order twins share poker score, only one opens archive | Replayed successfully | Shipped Prospect engine and key |
| Formula 51 band and decoder scores | Reproduced all 588 eligible radices after exact NFD count checks across all 11,172 | JSON identical after CRLF/LF normalization; source derivation and scorer unchanged |
| Postmaster v5.2 interface checks | 67/67 pass | Preservation/algebra/interface checks; inherited interval certificates and PDF builds not rerun |
| Twin sign change at k = 16,588 → 16,589 | Independently reproduced with Decimal at 50 and 90 digits | Supplied finite zero census through T=640; one x; no interval/tail certificate |

The SEDAPS core is unchanged: SHA256 `5685a76b3b23debb493d747a20ea4b7f6de4899acbf450218b286f78dacfbdaa`. East/right/+x remains a display convention; no four-player theorem is inferred.

## Corrections made in the website draft

1. **Clock conditioning.** SEDAPS now says “Apply 17-card start + turn 85.” The exclusion is at turn 84, not an unqualified impossibility at every elapsed time.
2. **Twins evidence scope.** The public plate now describes the detected finite-census negative and sampled earlier tests. Its verifier rebuilds card results but copies the analytic constants; “replay everything” was too broad. The calibration labels the displayed numbers as positive-rescaled finite sums and explains the unverified census/tail/global-minimum scope.
3. **Formula proof repair.** The original replacement of ceil(N/588) by ceil(floor(N/28)/21) is not always valid. The repaired proof uses both exact bounds: 28c ≤ N ≤ 28c+27 and 588(c−49) < N ≤ 588(c−48), forcing c=51. The self-description conclusion and decoder table are retained.

The supplied Postmaster source ZIP remains byte-for-byte unchanged. These website audit corrections do not silently revise its historical publication files or mint a DOI.

## New bounded results

All legal ordered three-queue states were exhausted independently for n=3,5,7, excluding terminal self-loops:

| n | states | distinct cycles | periods |
|---|---:|---:|---|
| 3 | 60 | 0 | none |
| 5 | 2,520 | 12 | 6 |
| 7 | 181,440 | 312 | 8 |

Representative cycles also replay with the frozen JavaScript rule. These are exact finite cases; the odd-n conjecture is still open.

At x=7140.066261872734, the independent finite-census scaled sums are approximately +0.0001759280487421 at k=16,588 and −0.0000466009149065 at k=16,589. The 50- and 90-digit runs agree well beyond the displayed digits. The positive value is evaluated at that fixed x; the source’s slightly different positive number reports a refined minimum. Arithmetic precision does not supply zero enclosures or a tail certificate.

A frozen attempt to count all equal-deal histories at the turn-32 endpoint reached **250,000 expanded states and stopped at the state cap**. Result: CAPPED, exact count unknown. Four certified immediate pasts do not mean there are only four complete histories.

## Next work for Claude and Colab

These are reviewable work packets for the user to assign. No external message has been sent.

**A — Exact history counts.** Start with `bounded_history_count.py` and the turn-32 endpoint. Improve counting/compression before spending a much larger state budget. Preserve the frozen rule, labeled queues, elapsed time and start sizes. Return exact counts with replayable code, or CAPPED with both limits and work completed. A necessary shape test passing is not itself a reachability certificate. The Colab notebook includes this run behind an explicit switch.

**B — Odd-deck periods.** Prove divisibility by n+1 or produce a concrete counterexample under the unchanged winner-first rule. State whether the claim covers all legal cycles or only balanced-deal reachability. Our full 3/5/7-card censuses are a stronger small-case check than random deals. Length conservation already forces a two-live-queue cycle to have equal win counts and even length; the additional factor n+1 needs its own argument.

**C — Twin certification.** Target the single negative at k=16,589 and fixed x before claiming global first failure. Supply validated zero enclosures/completeness for the finite region and an explicit omitted-tail bound for this completed twin. Do not reuse a zeta tail bound without proving it applies. A higher-precision finite sum alone remains EVID. The default notebook supplies an independent arithmetic control, not the missing certificate.

**D — Publication follow-through.** Postmaster v5.2 PDFs are not built in this return. Keep the existing source edition and typeset edition labels separate until that build and page-count check finish. All DOI placeholders stay pending. The inherited verified-height constants were not re-derived in this pass.

## Site behavior in v2.8.1

The default Finance board and hero share the same sector display. Current measured weather has priority, including a genuine fresh zero. After a reading expires, the last weather value fades into the dated Google median using remaining quote-age support. At rest, Google remains the baseline. Missing Google sectors keep the original weather decay. The reference is fetched every five minutes, with validated cache and bundled dated seed as fallback.

The bridge is display-only. If W_e is the weather value at expiry e and u(t)=support(t)/support(e), the held display is G+(W_e−G)u(t), clamped to u∈[0,1]. Current weather and its original engine are unchanged. A missing expiry/support anchor falls directly to a usable Google reference. Measured values, observation times, movement indices and jbit eligibility remain separate. Google does not light the live-activity flag; the reference is not inserted into measured history traces.

The untouched hero advances every six seconds. Hover, focus, an arrow or a swipe pauses it and reveals a ghost Play control. Explicit Play resumes and becomes Pause; leaving the card does not undo a chosen pause. Reduced-motion users start paused. The Finance face stays a single read-only link.

Validation: nine targeted model/DOM/timer groups and six existing game continuity checks pass. Changed-page local links resolve. No rendered-browser, physical touch-device, deployed feed or production deployment check is claimed for this return.

## Deliverables

- `CerebralGraphix_v2_8_1_FULL_SITE.zip`: complete unpublished site, all 630 input files retained, release notes and validation receipts included.
- `Forge_51_v0_4_FRONTIER.ipynb`: standalone Colab notebook, embedded hashed inputs, standard library only; default audits plus optional bounded history count.
- `Forge_51_v0_4_REVIEW_PACKAGE.zip`: coordinator notes, independent audit scripts/receipts, source-locked fixtures and notebook.

Use the v2.8.1 website as the next merge base. Preserve the v2.8.0 input hash when comparing Claude’s next return.
