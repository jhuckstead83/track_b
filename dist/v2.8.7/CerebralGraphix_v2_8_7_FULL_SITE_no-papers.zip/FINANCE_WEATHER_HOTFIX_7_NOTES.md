# Finance Weather — Hotfix 7

Prepared September 25, 2026 from the supplied Hotfix 6 full site and Finance Weather notebook v0.4.9.1. This release has not been deployed or published to the live quote feed.

## What changed

- **Broader input pool:** all 16 baskets request 20 contributors. The pool grows from 163 sector memberships / 156 unique tickers to 320 memberships / 312 unique tickers. The Macro ETF basket remains an ETF observation basket; existing sector ETF proxies and ADRs remain explicitly represented in the notebook.
- **One pool for both feeds:** E*TRADE's base requests and Alpaca's overnight sweep use the same definitions. The five added chambers cannot silently fall back to their old ten-name lists. Re-running the definition cells also updates an existing notebook runtime.
- **Clean sector labels:** the example ticker suffixes are removed; sector names, descriptions, order, and website colors remain.
- **Three selectable overnight lines:** choose up to three different sectors, with a dashed teal all-sector median for context. Choices survive reloads. The browser records all 16 sector medians as fresh public snapshots arrive, so switching a line can use samples already observed locally.
- **Repeat jbit backing:** add 2, 4, 6… jbits to an already backed tile. The default increment is 2. Each addition has its own entry BPS and timestamp. The tile displays total marked jbits, total backed, and entry count; **Exit all** settles the combined position.

## Activate the release

1. Deploy the full-site archive, **or** overlay the delta onto the exact supplied Hotfix 6 tree. Both archives put deployable files at the ZIP root. The delta requires no deletions.
2. Open `phi_etrade_weather_workflow_v0492_expanded_sector_pool.ipynb`. Stop any previous automatic loop, run the updated cells from the top using your normal credentials, then run a fresh snapshot/publish and resume the existing loop.
3. Confirm fresh overnight output reports `basket_version: 2026-09-25.v1`, 20 expected contributors per sector, and 312 unique expected contributors globally. Outside the overnight window, verify the regular pool in the notebook and the public manifest's configured basket counts.

The website changes work with the current public payload. **The expanded pool starts only after the updated notebook publishes fresh data.** No provider login, quote pull with your credentials, R2 upload, or public-site deployment was performed here.

## Coverage and history

The median formula, quote providers, 180-second overnight freshness cutoff, coverage grades, last-known-good repair, and 16-cell geometry are preserved. More requested contributors do not guarantee more fresh quotes at a particular time. Missing data remains a dash, never a zero.

Overnight aggregates now include counts for usable, missing-reference, missing-price, missing-timestamp, and stale-quote observations. Named-symbol diagnostics remain private. Provider requests are deduplicated for global overnight coverage; a symbol may still contribute to more than one declared sector.

The new basket version labels newly generated overnight aggregates; the public manifest separately labels the configured universe. Historical records are not relabeled or recomputed. The new notebook clears saved cell output to avoid presenting prior results as measurements of the expanded pool.

The interactive trace is browser-local, retaining up to 96 observed snapshots. It does not reconstruct unattended history. Missing sector samples and gaps over 15 minutes break lines; a gap over 90 minutes starts a new local trace. Legacy global-only samples remain global-only. Repeated or older responses cannot erase newer trace samples.

## Jbit accounting

Each entry marks as `entry stake × max(0, 1 + (current BPS − entry BPS)/10,000)`. Exit sums entries before rounding once to the nearest 0.01 jbit. Example: 2 jbits at 100 BPS, then 2 more at 200 BPS, mark to 4.06 jbits at 300 BPS.

Existing single-entry positions migrate to the entry list. The same storage key and aggregate holding fields remain compatible with the shared bank's reserve cap. A missing reading, feed change, or an entry older than 12 hours holds its last mark; exit before adding to a position that has stopped marking. Switching the displayed headline to breadth does not change the BPS basis used by jbits.

Controls block insufficient funds and duplicate clicks. A position lock serializes additions from modern same-origin browser tabs. A failed position save refunds the new addition. A paid exit that cannot clear its stored record is frozen and can be retried with the same receipt, without a second payout. These remain local play balances with the existing client-side trust model.

## Validation

The included validation receipt reports notebook syntax/configuration and deterministic aggregation checks, plus Chromium interaction checks at 1280-pixel and 390-pixel widths. Browser tests use controlled quote fixtures, not live market measurements. They cover selection persistence, line colors and gaps, missing readings, independent entry marks, reload migration, insufficient funds, failed-save refunds, exit retries, concurrent tabs, and the BPS/breadth distinction. Screenshot previews in the review archive are also fixtures.

The existing overnight-state regression passed. Site references, unique page IDs, exact delta reconstruction, archive integrity, and the 25 MB per-file ceiling are checked. All Area 51 files, the homepage, archived papers, existing finance history, and shared bank modules are byte-identical to Hotfix 6.

## Input maintenance references

- [Alpaca stock snapshot API](https://docs.alpaca.markets/us/reference/stocksnapshots-1) — multi-symbol snapshot fields and separate `overnight`, `boats`, and other feeds.
- [Paramount merger completion](https://ir.paramount.com/news-releases/news-release-details/skydance-media-and-paramount-global-complete-merger-creating/) — supports replacing the old PARA entry with PSKY.
- [Verizon welcomes Frontier](https://www.verizon.com/about/news/introducing-frontier-verizon-company) — the retired FYBR input is removed.
- [Devon/Coterra completion](https://investors.devonenergy.com/investors/press-releases/press-release-details/2026/Devon-Energy-and-Coterra-Energy-Complete-Merger/) — CTRA is not added as a separate current observation.

The expanded baskets are a versioned editorial selection of observation inputs. An authenticated provider run is still needed to measure returned/fresh coverage for these exact symbols.
