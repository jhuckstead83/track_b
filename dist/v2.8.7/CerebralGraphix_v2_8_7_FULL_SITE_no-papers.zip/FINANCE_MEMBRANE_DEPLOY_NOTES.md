# Cerebral Graphix v1.8 — Finance Membrane Site Release

## What changed

- Replaced `/finance/live.html` with the new 4×4 public chamber grid.
- Preserved the former chart window as `/finance/legacy.html`, compliance-cleaned.
- Added `/finance/private/` page shell for Jeff's own named chamber view. No private payload is embedded in this deployable release.
- Added shared renderer assets based on the actual notebook's frozen 4×4 placement and stable chamber colors.
- Public page can run **before notebook surgery** by consuming safe aggregate `sector_plot_data.json`.
- The renderer automatically prefers future `chamber_grid_public.json` when Stage 4 eventually emits it.
- Removed named-asset static finance artifacts from the deployable site copy.
- Sanitized public manifests.
- Added noindex/no-store headers and robots exclusion for `/finance/private/`; these are not authentication.

## Public compatibility bridge

Public loader priority:

1. `https://live.cerebralgraphix.com/finance/latest/chamber_grid_public.json` — future Stage 4 export.
2. `https://live.cerebralgraphix.com/finance/latest/sector_plot_data.json` — current safe chamber aggregate adapter.
3. Local `finance/latest/sector_plot_data.json` — static fallback.

This lets the website launch now without modifying the notebook.

## Compliance strip

Removed from the deployable public site copy: 27 named-asset-bearing or unsafe-path artifacts, including symbol-pressure, look-here, symbol-bearing comparator/history/ledger files, and the old client that linked named data.

## Notebook

Read for structure only. Not modified. The private renderer is aligned to `build_phi_chamber_grid_frame(...)`; the public safe adapter is aligned to `sector_plot_data.json`.

## Stage 4 remains last

When the notebook is finally opened, make the two bundled surgical changes only:

1. public chamber-only export boundary;
2. bounded history retention/windowing so processing remains below the five-minute cadence.
