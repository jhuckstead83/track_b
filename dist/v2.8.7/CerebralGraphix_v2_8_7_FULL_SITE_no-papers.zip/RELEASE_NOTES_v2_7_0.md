# Cerebral Graphix v2.7.0

September 27, 2026. Full-site continuation of v2.6.1, with the supplied SEDAPS v0.2 review merged and extended to v0.3.

## Homepage

- One linked face per card. The Finance face opens Finance; each game face opens that game.
- Six-second automatic rotation, native horizontal swipe, and ghosted side arrows. The bottom bar, count, repeated title and Play/Open/Pause controls are removed. Rotation pauses during hover, keyboard focus, gestures or a hidden tab; reduced-motion users get manual navigation.
- The hero uses the same radial felt gradient as the Area 51 table surface.
- 51 SEDAPS joins the carousel with its Beta label.

## Finance mini view and downtime reference

The Finance hero contains the default four-by-four sector board. It preserves all sixteen assigned colors and positions, reuses the existing v2.1 weather engine, and displays no tile controls or jbit interface. It does not use the user's rearranged full-board layout. Small views omit the bps suffix while retaining the number and sector name.

Live data is read from the existing public `/finance/latest/weather_v2.json` feed every 30 seconds. Local age decay is evaluated every second, using the same UTC formula as the full Finance board and the linked Finance v2.1.0 Colab notebook. Invalid, duplicate-sector, regressed or non-aggregate payloads are rejected.

During an idle or unavailable live feed, the mini view uses **recorded Google sector medians**, with the quote date visible. The already-public Google Sheet's `Summary!A1:C23` refreshes every five minutes while the page is visible. Only its sixteen sector medians and coverage counts are consumed. A verified September 25, 2026 reference is included for first-load downtime; the latest valid reference is retained locally. A refreshed request does not advance the quote date. These medians remain an independent reference and are never blended into the live weather calculation.

The full Finance page has a compact “Google reference” foldout for the same dated readout. The original live board, Finance model, and wallet code are preserved.

The Area 51 hub and six game pages have a small Finance monitor:

- A collapsed flag appears only when current, supported weather has a nonzero displayed reading. A dated reference or an all-zero resting board cannot light this flag.
- Click to expand or collapse. The panel does not auto-scroll. A 550 ms opening transition gives the view time to settle.
- Drag the grip, long-press the label then drag, or focus the grip and use arrow keys. Position stays within the viewport; short screens scroll inside the panel.
- The circled X asks whether to hide it. A one-year, same-site preference cookie remembers visibility and position. “Finance monitor” at the page bottom restores it or opens a downtime peek.
- The monitor does not read or write wallet state. It makes at most one live-feed request per page per refresh, shared with any mini view on that page.

## SEDAPS research

The original constructed witness cannot arise from a 17–17–17 start: its H0 requires a prefix of at least 44 cards under the new necessary queue invariant. The game also includes an endpoint reached in exactly 85 turns from an equal deal, with the full replay certificate. Of its four legal predecessors, one requires a prefix of 33 and is therefore excluded. Only the recorded predecessor is certified reachable; the other two admissible alternatives and reachable-class sharpness remain open.

Both cases have backward recovery and forward replay. The new case offers a 17-card starting-condition filter and a trajectory inspector. Reveal actions have a 600 ms pause plus slower visual transitions; reduced motion is supported. East/right/+x is accepted as the four-seat display convention, with East first to receive a card. The three-queue rule remains unchanged; four-player play rules still need definition.

Read `area-51/sedaps-51/RESEARCH_UPDATE_v0_3.md` for the proof and scope. Historical notes are retained and labelled historical in the current page. No zero-data run or RH claim is introduced.

## Verification and delivery

- 20,160-state predecessor audit and all four original 51-card replays passed.
- The 85-turn certificate passed JavaScript and Python checks, including 85 independent replays through the archived published Python rule.
- Eleven focused model/DOM/timer checks passed, covering live/reference/idle states, carousel timing, history recovery, monitor persistence and wallet isolation.
- Six existing game recovery/continuity checks passed after adding the monitor.
- Forge 51 v0.3 executed all eleven code cells locally. This is a disclosed replay; a fresh v0.3 Colab execution has not yet been observed.
- The public Google Summary request succeeded. Every displayed median and coverage count matched the exact connected Sheet values.
- The live weather endpoint returned HTTP 403 in this execution environment. Its fresh data response was not verified here; the schema, formula and display parity were checked against the existing site and supplied Finance notebook.
- Local HTTP and file previews were blocked by this session's browser policy. CSS and in-memory interactions were checked, but no rendered desktop/phone or real-touch test is claimed.

This is a complete upload-ready site archive, not a live deployment. Retain the existing hosting configuration and upload the archive contents at the site root. All original files remain present; a changed-file manifest accompanies this release. Files unrelated to the listed pages and shared additions remain byte-identical.

Sources: the supplied v2.6.1 site and SEDAPS v0.2 review; the returned Forge 51 replay; [Finance reference Sheet](https://docs.google.com/spreadsheets/d/1d34G7-JIusLnSB6_Ujt4xieVnJDFxyRcfgZZfF3sC5Y/edit); [Finance v2.1.0 notebook](https://colab.research.google.com/drive/1_9yGvCdXu0sS9G95e6d6--hW7jER1A6b); [Google's public spreadsheet query documentation](https://developers.google.com/chart/interactive/docs/spreadsheets).
