# Finance v1.9 Hotfix Notes

## What changed

1. Added an explicit dark-mode button to the public chamber grid, private chamber shell, and legacy finance view.
2. Theme defaults to the phone/OS preference on first load, then the button toggles light/dark in-page. No browser storage is required.
3. Dark mode is OLED-friendly: near-black page/card surfaces and dark-aware pressure fills.
4. Fixed the public fallback bug: v1.8 fetched `latest/sector_plot_data.json` as its final fallback, but `_redirects` sends `/finance/latest/*` to the R2 live rail. That meant the supposed local fallback still depended on R2. v1.9 copies the safe aggregate snapshot to `/finance/static/sector_plot_data.json` and uses that as the true local third fallback.
5. Added explicit extensionless route aliases for `/finance/live` and `/finance/legacy`.
6. Bumped shared finance CSS/JS query versions to `v=2` and added no-cache headers for the hotfix assets.

## Public load chain

1. `https://live.cerebralgraphix.com/finance/latest/chamber_grid_public.json`
2. `https://live.cerebralgraphix.com/finance/latest/sector_plot_data.json`
3. `/finance/static/sector_plot_data.json` (bundled safe aggregate fallback)

## Notebook status

Untouched.
