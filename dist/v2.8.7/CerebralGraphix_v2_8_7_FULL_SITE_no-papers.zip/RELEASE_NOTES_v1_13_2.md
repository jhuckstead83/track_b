# Cerebral Graphix v1.13.2

Status: built and checked; not deployed.

This release is based on the v1.13.1 full-site package. It keeps the existing Finance calculations, sector geometry, data endpoints, Cloudflare Functions and public-data membrane intact.

## Finance: current data owns the session

- The current aggregate plate now remains the source of session truth when a retained extended-hours payload is merged.
- Retained overnight values cannot make an active regular session display as overnight.
- The repeated `official close`, `prior close`, `base close` and `change versus close` labels are removed from the public Finance surfaces.
- During regular or unknown sessions, the grid shows one uncluttered current value per cell. The extended-hours control and ranking option are absent.
- During an explicitly named premarket, postmarket, overnight or extended-hours session, the optional layer can compare that reading with the base snapshot. The language is `base snapshot` and `delta vs base`.
- The failure behavior remains explicit: a failed refresh keeps the previous snapshot and displays a persistent status message.

## Finance: charts over time restored as a primary view

- The live board now includes a full-width `Charts over time` feature immediately below the grid.
- The Finance landing page gives the current grid and the recorded-snapshot chart distinct, visible entrances.
- `/finance/legacy.html` remains the stable URL, but the page is presented as a current aggregate-history view rather than a deprecated legacy artifact.
- The chart page keeps median and average lenses, adds a clear return to the 4x4 grid, and falls back to the bundled chart if the live image rail is unavailable.
- Navigation, the human site index, the machine manifest and the sitemap now recognize the chart as a public view.

## Current research: Reading Volume v4.7

- The attached `TN_Postmaster_Volume_I_v4_7_READING_VOLUME.pdf` is included byte-for-byte unchanged.
- Current links use <https://zenodo.org/records/22772092>.
- Homepage, Papers, catalogue, Atlas, reading guide, RSS feed, site index and metadata now identify Reading Volume v4.7, dated September 15, 2026, at 90 pages.
- Reading-guide anchors were remapped to the v4.7 pagination, including R12 on PDF page 37 and R23 on PDF page 80.
- The research status remains explicit: source rungs W2-W6 are certified in this volume; the all-order fixed-scale source estimate and RH remain open.
- The earlier v4.2 PDF remains in the full site as a preserved file, but it is no longer presented as the current reading volume.

## Validation

Twenty-three source and isolated behavior checks pass. They cover session precedence, stale extended-hours suppression, the missing-session safeguard, named extended-session activation, removal of close messaging, the Finance DOM contract, local links and assets, unique records, v4.7 metadata, PDF byte identity, Atlas status, site-index status and local chart fallbacks.

This is not a live-provider test, a Cloudflare preview deployment or physical iPhone/Safari testing. The cloud browser could inspect production but its security policy blocked the local build, so this release does not claim a fresh browser-rendered viewport pass. The responsive rules retain the previously tested 4x4 internal-scroll boundary for very narrow screens, and the removed regular-session subline reduces mobile cell density.

## Deployment

The full ZIP is flat-root: `index.html`, `functions/`, `_routes.json`, `_headers` and `_redirects` are at the archive root. Preserve the existing function-capable Cloudflare deployment process; dashboard drag-and-drop alone does not compile a `functions/` directory.

The patch is for an unmodified v1.13.1 source tree. Run its conflict check before applying it to any tree that may contain newer work. Preview the resulting complete site before replacing production.
