# Cerebral Graphix v2.5.0

Review build based on the v2.4.0 full site. It has not been deployed.

## Changes

- **Invariant:** the action row, including Decode, centers within the table width and stays centered when it wraps.
- **Blackjack:** centered controls with three equal Hit / Stand / Double columns. Double stays visible during an active hand and disables when the hand or available jbits make it unavailable. Split keeps its separate row when legal.
- **Telescope:** Value, Rank, Color, and Suit each use a single unbroken word with its first letter emphasized. The separate oversized letter is removed; gross awards remain underneath.
- **Memory:** the main card grows from 82 to 108 CSS pixels wide. The answer grid is narrower, its card markers are smaller, and answer buttons retain at least 58 pixels of touch height.
- **Prospect:** the Hold buttons accept clicks, light up when held, and release on a second click. One persistent primary button switches between Spin, Draw, and Keep five, with the same full width and 48-pixel height. Its text and color change in place. The v2.4 reel appearance and animation controller are retained.

## Cause of the missing controls

Live Chrome inspection found v2.4 loading an older shared stylesheet. It contained `pointer-events:none` for Hold, `display:none` for Double and Split, and a two-column action row that made Draw narrower than Spin. This accounts for the screenshot behavior even though the game handlers were present.

All five pages now request a new `card-ui-v2-5.css` URL. The relevant presentation scripts and house-card styles also have fresh URLs, so older cached versions cannot override the current UI. The game-specific styles explicitly enable Hold and display the active Blackjack controls.

## Preservation

The shared wallet, account schemas, saved hands, holds, stamps, receipts, and archive meter are retained. No balance reset or new bank is introduced. Game rules and payouts are unchanged. The Project 51 v0.3 engine, dictionary, token renderer, and v2.4 reel controller remain byte-identical.

Only the five game HTML entrypoints change among existing v2.4 files. All other existing files, including the homepage, Finance, papers, and historical assets, are preserved. New presentation assets and verification files are added.

## Verification

| Check | Result |
|---|---|
| Site, game, and wallet regression assertions | 401 passed |
| Shared Prospect account, including all 32 hold masks | 15 passed |
| Storage failure and fallback checks | 8 passed |
| IndexedDB transaction model | 5 passed |
| Card interactions across all five games | 14 passed |
| Reload and cross-game continuity | 6 passed |
| Reel and settlement coordination | 5 passed |
| Decision shortcuts and odds lifecycle | 6 passed |
| Stamps and mobile interaction flows | 12 passed |
| Startup, overlay, animation, and Double behavior | 8 passed |
| v2.5 controls, stale-style regression, and asset versions | 5 passed |

The new control checks reproduce the old click-blocking and hiding declarations, then verify that current CSS overrides them. They also check Hold/Release persistence, a draw that preserves both held identities, the unchanged primary-button node, and visible disabled Double at zero balance.

These are in-memory DOM, wallet, animation-frame, and authored-CSS checks. They do not perform native pointer hit testing or render the new build. **Visual verification of v2.5 on mobile and desktop remains pending.** The reported v2.4 stylesheet failures were inspected in live Chrome. After upload, check all five pages at phone width, Hold/Release and Draw on Prospect, and legal/disabled Double states on Blackjack.

ZIP integrity, preservation hashes, and exact patch reconstruction are recorded in `CerebralGraphix_v2_5_0_PACKAGE_CHECKS.json`.

## Install

- **Full site:** extract `CerebralGraphix_v2_5_0_FULL_SITE.zip` into the deployment directory. Its root is the website root. Use this for an uncertain or mixed installation.
- **Patch:** overlay `CerebralGraphix_v2_5_0_DELTA_FROM_v2_4_0.zip` onto the exact v2.4.0 full-site package from this conversation. No deletions are required.
- Publish all new assets and the five updated game pages together. The fresh URLs address the observed old-asset mismatch. Keep browser site storage so existing jbits and hands remain available.

Run the current checks with `npm ci` followed by `npm test` inside `tests/v2_5/`. Earlier test suites and receipts remain as historical records.
