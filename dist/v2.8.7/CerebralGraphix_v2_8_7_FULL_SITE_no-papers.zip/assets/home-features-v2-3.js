(() => {
 const track=document.getElementById('home-feature-track');if(!track)return;
 const cards=[...track.querySelectorAll('[data-feature]')],status=document.getElementById('feature-position'),pause=document.getElementById('feature-pause');
 const media=matchMedia('(prefers-reduced-motion: reduce)');let index=0,timer,paused=media.matches,hovered=false;
 function describe(){status.textContent=cards[index].getAttribute('aria-label')+' · '+(index+1)+' / '+cards.length;pause.textContent=paused?'▶':'Ⅱ';pause.setAttribute('aria-label',paused?'Resume feature rotation':'Pause feature rotation');for(const [i,c]of cards.entries())c.inert=i!==index;}
 function schedule(){clearTimeout(timer);if(!paused&&!hovered&&!document.hidden)timer=setTimeout(()=>show((index+1)%cards.length),7000);}
 function show(next){index=(next+cards.length)%cards.length;track.scrollTo({left:index*track.clientWidth,behavior:media.matches?'auto':'smooth'});describe();schedule();}
 document.getElementById('feature-prev').onclick=()=>{paused=true;show(index-1);};document.getElementById('feature-next').onclick=()=>{paused=true;show(index+1);};
 pause.onclick=()=>{paused=!paused;describe();schedule();};
 track.addEventListener('scroll',()=>{const next=Math.round(track.scrollLeft/Math.max(1,track.clientWidth));if(next>=0&&next<cards.length&&next!==index){index=next;describe();}});
 track.addEventListener('pointerdown',()=>{paused=true;describe();schedule();});
 track.addEventListener('focusin',()=>{paused=true;describe();schedule();});
 track.addEventListener('mouseenter',()=>{hovered=true;schedule();});track.addEventListener('mouseleave',()=>{hovered=false;schedule();});
 document.addEventListener('visibilitychange',schedule);media.addEventListener?.('change',()=>{if(media.matches)paused=true;describe();schedule();});
 addEventListener('resize',()=>track.scrollTo({left:index*track.clientWidth,behavior:'auto'}));describe();schedule();
})();
