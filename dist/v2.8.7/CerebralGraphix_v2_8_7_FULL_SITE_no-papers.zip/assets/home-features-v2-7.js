(() => {
 'use strict';
 const track=document.getElementById('home-feature-track');if(!track)return;
 const carousel=track.closest('.home-feature-carousel'),cards=[...track.querySelectorAll('[data-feature]')];
 const media=matchMedia('(prefers-reduced-motion: reduce)');let index=0,timer,scrollTimer,hovered=false,touching=false,focused=false,programmatic=false,keyboardMode=false;
 function describe(){for(const [i,c]of cards.entries()){c.inert=i!==index;c.setAttribute('aria-hidden',String(i!==index));}}
 function schedule(){clearTimeout(timer);if(!media.matches&&!hovered&&!touching&&!focused&&!document.hidden)timer=setTimeout(()=>show(index+1),6000);}
 function show(next){programmatic=true;index=(next+cards.length)%cards.length;describe();track.scrollTo({left:index*track.clientWidth,behavior:media.matches?'auto':'smooth'});schedule();}
 document.getElementById('feature-prev').onclick=()=>show(index-1);document.getElementById('feature-next').onclick=()=>show(index+1);
 // Native scroll-snap supplies touch swiping; settled scroll becomes the new slide.
 track.addEventListener('scroll',()=>{clearTimeout(scrollTimer);scrollTimer=setTimeout(()=>{index=Math.max(0,Math.min(cards.length-1,Math.round(track.scrollLeft/Math.max(1,track.clientWidth))));describe();if(programmatic)programmatic=false;else schedule();},160);},{passive:true});
 carousel.addEventListener('pointerdown',()=>{keyboardMode=false;focused=false;touching=true;schedule();});
 addEventListener('pointerup',()=>{touching=false;schedule();});addEventListener('pointercancel',()=>{touching=false;schedule();});
 carousel.addEventListener('mouseenter',()=>{hovered=true;schedule();});carousel.addEventListener('mouseleave',()=>{hovered=false;schedule();});
 document.addEventListener('keydown',e=>{if(e.key==='Tab')keyboardMode=true;});
 carousel.addEventListener('focusin',()=>{focused=keyboardMode;schedule();});carousel.addEventListener('focusout',()=>{setTimeout(()=>{focused=keyboardMode&&carousel.contains(document.activeElement);schedule();},0);});
 carousel.addEventListener('keydown',e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){keyboardMode=true;focused=true;e.preventDefault();show(index+(e.key==='ArrowRight'?1:-1));}});
 document.addEventListener('visibilitychange',schedule);media.addEventListener('change',schedule);
 addEventListener('resize',()=>track.scrollTo({left:index*track.clientWidth,behavior:'instant'}));describe();schedule();
})();
