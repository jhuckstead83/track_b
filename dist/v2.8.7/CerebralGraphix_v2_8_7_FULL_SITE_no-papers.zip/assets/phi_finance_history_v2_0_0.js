(()=>{
  'use strict';
  const ROOT='https://live.cerebralgraphix.com/finance/latest/';
  const CODES=['UTILITIES','REAL_ESTATE','FOOD','HEALTHCARE','DEFENSE','BANKS','MACRO_ETF','TELECOM','ENERGY','MATERIALS','AI_BIG','MEDIA','AI_SEMIS','INDUSTRIALS','AUTOS_EV','RETAIL'];
  const LABELS=['Utilities','Real Estate','Food','Healthcare','Defense','Banks','Macro ETF','Telecom','Energy','Materials','AI Big','Media','AI Semis','Industrials','Autos / EV','Retail'];
  const COLORS=['#1b9e77','#7570b3','#66a61e','#e78ac3','#8c6d31','#1f78b4','#253494','#00a6d6','#e6ab02','#a6a622','#d95f02','#6a3d9a','#c51b7d','#008837','#d73027','#ffd92f'];
  const files={median:'sector_pressure_over_snapshots.png',average:'sector_pressure_average_over_snapshots.png'};
  const img=document.getElementById('chart'),button=document.getElementById('lens'),status=document.getElementById('stamp'),legacy=document.querySelector('.legacy-window');
  const plot=document.createElement('div');plot.className='weather-history';plot.hidden=true;legacy.after(plot);
  let lens='median',data=null,busy=false;
  const finite=v=>v!==null&&v!==undefined&&Number.isFinite(Number(v));
  const fmt=v=>Number(v).toFixed(1);
  const et=at=>new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',month:'short',day:'numeric',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(at))+' ET';
  const valid=d=>d?.schema==='phi.finance.weather.v2'&&Array.isArray(d.trace)&&Number.isFinite(Date.parse(d.published_at_utc))&&Date.parse(d.published_at_utc)<=Date.now()+120000;
  async function fetchJSON(name){
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000);
    try{const r=await fetch(ROOT+name+'?t='+Date.now(),{cache:'no-store',signal:controller.signal});if(!r.ok)throw Error(r.status);return await r.json()}finally{clearTimeout(timer)}
  }
  function render(){
    if(!data)return;legacy.hidden=true;plot.hidden=false;
    const points=data.trace.filter(p=>Number.isFinite(Date.parse(p.at))).slice(-360);
    const val=(p,c)=>p.sectors?.[c]?.[lens==='median'?'value':'average'];
    const values=points.flatMap(p=>CODES.map(c=>val(p,c))).filter(finite).map(Number);
    if(!points.length||!values.length){plot.textContent='The first recorded readings will appear here.';status.textContent='Finance Weather v2 is waiting for measured data.';return}
    const width=1000,height=430,pad={l:70,r:18,t:25,b:45};
    let low=Math.min(0,...values),high=Math.max(0,...values);const margin=Math.max(1,(high-low)*.1);low-=margin;high+=margin;
    const first=points[0],last=points.at(-1),start=Date.parse(first.at),end=Date.parse(last.at);
    const x=p=>pad.l+(end===start ? .5 : (Date.parse(p.at)-start)/(end-start))*(width-pad.l-pad.r);
    const y=v=>pad.t+(high-v)/(high-low)*(height-pad.t-pad.b);
    const paths=CODES.map((code,i)=>{
      let path='',previous=null;
      for(const p of points){
        const value=val(p,code),basis=p.sectors?.[code]?.basis;
        if(!finite(value)){previous=null;continue}
        const connected=previous&&Date.parse(p.at)-Date.parse(previous.at)<=900000&&basis===previous.basis&&p.session===previous.session;
        path+=`${connected?'L':'M'}${x(p).toFixed(1)},${y(value).toFixed(1)} `;previous={at:p.at,basis,session:p.session};
      }
      const v=val(last,code);
      return `<g style="color:${COLORS[i]}"><path d="${path.trim()}" fill="none" stroke="currentColor" stroke-width="2"><title>${LABELS[i]}</title></path>${finite(v)?`<circle cx="${x(last)}" cy="${y(v)}" r="3" fill="currentColor"><title>${LABELS[i]}: ${fmt(v)} bps</title></circle>`:''}</g>`;
    }).join('');
    const grid=[0,1,2,3,4].map(i=>{const v=low+(high-low)*i/4;return `<line x1="${pad.l}" x2="${width-pad.r}" y1="${y(v)}" y2="${y(v)}" class="history-grid-line"/><text x="${pad.l-8}" y="${y(v)+4}" text-anchor="end">${fmt(v)}</text>`}).join('');
    plot.innerHTML=`<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Sector ${lens} BPS across ${points.length} recorded snapshots"><text x="10" y="15">bps</text>${grid}<line x1="${pad.l}" x2="${width-pad.r}" y1="${y(0)}" y2="${y(0)}" class="history-zero"/>${paths}<text x="${pad.l}" y="${height-12}">${et(first.at)}</text><text x="${width-pad.r}" y="${height-12}" text-anchor="end">${et(last.at)}</text></svg><div class="weather-history-legend">${CODES.map((c,i)=>`<span><i style="background:${COLORS[i]}"></i>${LABELS[i]}<b>${finite(val(last,c))?fmt(val(last,c)):'—'}</b></span>`).join('')}</div>`;
    status.textContent=`${points.length} recorded snapshots · ${et(first.at)} to ${et(last.at)}. The most recent 360 snapshots travel with the live board. Gaps mark missing readings or a changed session/reference.`;
  }
  function oldChart(){
    plot.hidden=true;legacy.hidden=false;img.alt=`${lens} sector pressure across archived snapshots`;
    img.onerror=()=>{img.onerror=null;img.src='latest/'+files[lens]};img.src=ROOT+files[lens]+'?t='+Date.now();
    status.textContent='Archived chart. The v2 history will appear after the new publisher starts.';
  }
  async function refresh(){
    if(busy)return;busy=true;
    try{const next=await fetchJSON('weather_v2.json');if(!valid(next))throw Error('Invalid history');if(!data||Date.parse(next.published_at_utc)>=Date.parse(data.published_at_utc))data=next}
    catch{if(!data){try{const cached=JSON.parse(localStorage.getItem('cg_phi_weather_v2')||'null');if(valid(cached))data=cached}catch{}}}
    finally{busy=false}
    if(data)render();else oldChart();
  }
  button.onclick=()=>{lens=lens==='median'?'average':'median';button.textContent='Lens: '+lens;button.setAttribute('aria-pressed',String(lens==='average'));if(data)render();else oldChart()};
  document.getElementById('refresh').onclick=refresh;refresh();setInterval(refresh,60000);
})();
