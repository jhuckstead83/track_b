(()=>{
'use strict';

const LIVE='https://live.cerebralgraphix.com';
const STORE='cg_phi_grid_layout_v2';
const DATA_CACHE='cg_phi_last_known_good_v1';
const HOLD_MS=620;
const MOVE_PX=8;
const OVERNIGHT_MAX_AGE_MS=20*60*1000;
const OVERNIGHT_CLOCK_SKEW_MS=2*60*1000;
const AUTO_REFRESH_MS=30*1000;
const V2_CACHE="cg_phi_weather_v2";
const OVERNIGHT_TRACE_STORE='cg_phi_overnight_trace_v2';
const OVERNIGHT_SELECTION_STORE='cg_phi_overnight_selection_v1';
const OVERNIGHT_TRACE_MAX=360;
const OVERNIGHT_TRACE_GAP_MS=90*60*1000;

const META={
  UTILITIES:{slot:0,label:'Utilities',desc:'power & water',color:'#1b9e77'},
  REAL_ESTATE:{slot:1,label:'Real Estate',desc:'property & REITs',color:'#7570b3'},
  FOOD:{slot:2,label:'Food',desc:'grocers & QSR',color:'#66a61e'},
  HEALTHCARE:{slot:3,label:'Healthcare',desc:'care & pharma',color:'#e78ac3'},
  DEFENSE:{slot:4,label:'Defense',desc:'aero & defense',color:'#8c6d31'},
  BANKS:{slot:5,label:'Banks',desc:'banks & brokers',color:'#1f78b4'},
  MACRO_ETF:{slot:6,label:'Macro ETF',desc:'broad ETFs',color:'#253494'},
  TELECOM:{slot:7,label:'Telecom',desc:'carriers & data',color:'#00a6d6'},
  ENERGY:{slot:8,label:'Energy',desc:'oil & power',color:'#e6ab02'},
  MATERIALS:{slot:9,label:'Materials',desc:'metals & chemicals',color:'#a6a622'},
  AI_BIG:{slot:10,label:'AI Big',desc:'AI platforms',color:'#d95f02'},
  MEDIA:{slot:11,label:'Media',desc:'content & streaming',color:'#6a3d9a'},
  AI_SEMIS:{slot:12,label:'AI Semis',desc:'chips & fabs',color:'#c51b7d'},
  INDUSTRIALS:{slot:13,label:'Industrials',desc:'machinery & freight',color:'#008837'},
  AUTOS_EV:{slot:14,label:'Autos / EV',desc:'autos & EV',color:'#d73027'},
  RETAIL:{slot:15,label:'Retail',desc:'stores & e-commerce',color:'#ffd92f'}
};
const CODES=Object.keys(META);
const forbidden=new Set(['ticker','symbol','returned_symbol','leader_symbol','laggard_symbol','abs2_symbol','constituents','quote','bid','ask','last_price','account','order','position']);
const fidMeaning={
  stratified:'coherent: breadth agrees and mean is near median',
  diffuse:'scattered: the aggregate is a weaker summary',
  opaque:'hidden, incomplete, or too stale for a clean read'
};

let state={
  data:null,
  headline:'median',
  timer:null,
  arrange:false,
  expanded:null,
  slots:defaultSlots(),
  gesture:null,
  holdTimer:null,
  refreshTimer:null,
  overnightTrace:readOvernightTrace(),
  traceSelection:readTraceSelection()
};

const $=s=>document.querySelector(s);
const finite=v=>v!==null&&v!==undefined&&v!==''&&Number.isFinite(Number(v));
const num=v=>finite(v)?Number(v):null;
const fmt=(v,d=1)=>finite(v)?`${Number(v)>=0?'+':''}${Number(v).toFixed(d)}`:'—';
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));

function defaultSlots(){const out={};for(const [code,m] of Object.entries(META))out[code]=m.slot;return out}
function readTraceSelection(){
  try{
    const raw=JSON.parse(localStorage.getItem(OVERNIGHT_SELECTION_STORE)||'null');
    if(Array.isArray(raw))return Array.from({length:3},(_,i)=>CODES.includes(raw[i])&&raw.indexOf(raw[i])===i?raw[i]:'');
  }catch{}
  return ['AI_BIG','AI_SEMIS','MACRO_ETF'];
}
function readOvernightTrace(){
  try{
    const raw=JSON.parse(localStorage.getItem(OVERNIGHT_TRACE_STORE)||localStorage.getItem('cg_phi_overnight_trace_v1')||'[]');
    return Array.isArray(raw)?raw.filter(x=>x&&Number.isFinite(Date.parse(x.at))).slice(-OVERNIGHT_TRACE_MAX):[];
  }catch{return []}
}
function saveOvernightTrace(){try{localStorage.setItem(OVERNIGHT_TRACE_STORE,JSON.stringify(state.overnightTrace.slice(-OVERNIGHT_TRACE_MAX)))}catch{}}
function recordOvernightTrace(d){
  if(d?.v2){ingestV2Trace(d);return}
  if(!d?.overnightActive||!Number.isFinite(Date.parse(d.generated)))return;
  const nextAt=Date.parse(d.generated),prevAt=Date.parse(state.overnightTrace.at(-1)?.at||'');
  // A repeated or out-of-order response must not erase newer history.
  if(Number.isFinite(prevAt)&&nextAt<=prevAt)return;
  if(Number.isFinite(prevAt)&&nextAt-prevAt>OVERNIGHT_TRACE_GAP_MS)state.overnightTrace=[];
  const sectors={};
  for(const c of d.chambers||[])if(CODES.includes(c.code))sectors[c.code]={value:num(c.overnight),fresh:num(c.onN),expected:num(c.onD)};
  state.overnightTrace.push({at:d.generated,value:num(globalValue(d,'globalMedian')),fresh:num(d.globalFresh),expected:num(d.globalExpected),coverage:num(d.freshRatio),grade:String(d.coverage||''),sectors});
  state.overnightTrace=state.overnightTrace.slice(-OVERNIGHT_TRACE_MAX);saveOvernightTrace();
}
function renderTraceSelectors(){
  const host=$('#overnightTraceSelectors');if(!host)return;
  if(!host.children.length){
    for(let i=0;i<3;i++){
      const label=document.createElement('label');label.className='trace-selector';
      label.innerHTML=`<span>Line ${i+1}</span><select aria-label="Overnight sector line ${i+1}"><option value="">None</option>${CODES.map(code=>`<option value="${code}">${META[code].label}</option>`).join('')}</select>`;
      const select=label.querySelector('select');
      select.addEventListener('change',()=>{
        state.traceSelection[i]=select.value;
        try{localStorage.setItem(OVERNIGHT_SELECTION_STORE,JSON.stringify(state.traceSelection))}catch{}
        renderOvernightTrace();
      });
      host.appendChild(label);
    }
  }
  [...host.querySelectorAll('select')].forEach((select,i)=>{
    select.value=state.traceSelection[i];
    select.parentElement.style.setProperty('--trace-color',META[select.value]?.color||'var(--muted)');
    for(const option of select.options)option.disabled=!!option.value&&option.value!==select.value&&state.traceSelection.includes(option.value);
  });
}
function renderOvernightTrace(){
  const plot=$('#overnightTracePlot'),status=$('#overnightTraceState'),meta=$('#overnightTraceMeta'),legend=$('#overnightTraceLegend');if(!plot||!status||!meta)return;
  renderTraceSelectors();
  const pts=state.overnightTrace.filter(x=>Number.isFinite(Date.parse(x.at))).slice(-OVERNIGHT_TRACE_MAX);
  const series=[{code:'GLOBAL',label:'All sectors',color:'#63cdda',value:p=>num(p.value)},...state.traceSelection.filter(Boolean).map(code=>({code,label:META[code].label,color:META[code].color,value:p=>num(p.sectors?.[code]?.value)}))];
  const last=pts.at(-1);
  if(legend)legend.innerHTML=series.map(s=>{
    const value=last?s.value(last):null,c=last?.sectors?.[s.code];
    const cov=c&&finite(c.fresh)&&finite(c.expected)?` · ${c.fresh}/${c.expected} fresh`:'';
    return `<span class="trace-legend-item" style="--trace-color:${s.color}"><i aria-hidden="true"></i><span>${s.label}<b>${finite(value)?`${fmt(value)} bps`:'No fresh reading'}</b><small>${cov}</small></span></span>`;
  }).join('');
  const values=series.flatMap(s=>pts.map(s.value)).filter(finite);
  if(!pts.length||!values.length){plot.innerHTML='<div class="overnight-trace-empty">Waiting for fresh overnight readings. Choose up to three sectors above.</div>';status.textContent='WAITING FOR OVERNIGHT';meta.textContent='The board records all sectors as the overnight feed arrives. Your three line choices are saved.';return}
  const w=840,h=250,pad={l:63,r:18,t:22,b:34};
  let ymin=Math.min(0,...values),ymax=Math.max(0,...values);if(ymin===ymax){ymin-=1;ymax+=1}else{const p=(ymax-ymin)*.12;ymin-=p;ymax+=p}
  const start=Date.parse(pts[0].at),end=Date.parse(last.at);
  const x=p=>pad.l+(end===start?(w-pad.l-pad.r)/2:(Date.parse(p.at)-start)*(w-pad.l-pad.r)/(end-start));
  const y=v=>pad.t+(ymax-v)*(h-pad.t-pad.b)/(ymax-ymin);
  const paths=series.map(s=>{
    let path='',connected=false,previousAt=null,previousBasis=null;
    const dots=[];
    for(const p of pts){
      const v=s.value(p),at=Date.parse(p.at),basis=s.code==='GLOBAL'?p.basis:p.sectors?.[s.code]?.basis;
      if(!finite(v)){connected=false;previousAt=at;continue}
      if(previousAt!==null&&(at-previousAt>15*60*1000||basis!==previousBasis))connected=false;previousBasis=basis;
      path+=`${connected?'L':'M'}${x(p).toFixed(1)},${y(v).toFixed(1)} `;connected=true;previousAt=at;
      dots.push(`<circle cx="${x(p).toFixed(1)}" cy="${y(v).toFixed(1)}" r="${s.code==='GLOBAL'?2:3}"><title>${s.label} · ${formatEtTimestamp(p.at)} · ${fmt(v)} bps</title></circle>`);
    }
    return `<g data-trace-code="${s.code}" class="trace-series ${s.code==='GLOBAL'?'trace-global':''}" style="--trace-color:${s.color}"><path class="trace-line" d="${path.trim()}"/>${dots.join('')}</g>`;
  }).join('');
  plot.innerHTML=`<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="Overnight BPS: ${series.map(s=>s.label).join(', ')}. Missing readings leave gaps."><line class="trace-zero" x1="${pad.l}" x2="${w-pad.r}" y1="${y(0).toFixed(1)}" y2="${y(0).toFixed(1)}"/>${paths}<text class="trace-axis" x="${pad.l}" y="${h-8}">${formatEtTimestamp(pts[0].at)}</text><text class="trace-axis end" x="${w-pad.r}" y="${h-8}">${formatEtTimestamp(last.at)}</text><text class="trace-axis" x="4" y="${pad.t+4}">${fmt(ymax)} bps</text><text class="trace-axis" x="4" y="${h-pad.b}">${fmt(ymin)} bps</text></svg>`;
  status.textContent=`${overlayPlateActive()?'OVERNIGHT TRACE':'LAST OVERNIGHT TRACE'} · ${pts.length} SAMPLE${pts.length===1?'':'S'}`;
  meta.textContent=`Last ${formatEtTimestamp(last.at)}. Dashed teal: all-sector median. Colors match the tiles; gaps mean no fresh reading. The latest recorded history arrives with the board. Your line choices are saved in this browser.`;
}

function restoreSlots(){
  try{
    const raw=JSON.parse(localStorage.getItem(STORE)||'null');
    if(raw&&raw.slots&&CODES.every(c=>Number.isInteger(raw.slots[c])))state.slots=raw.slots;
  }catch(e){}
}
function persistSlots(){try{localStorage.setItem(STORE,JSON.stringify({v:2,slots:state.slots}))}catch(e){}}
function stripOverlay(d){
  const x=JSON.parse(JSON.stringify(d));
  for(const c of x.chambers||[]){c.overnight=null;c.onN=null;c.onD=null;c.grade=''}
  x.overnightActive=false;
  return x;
}
function markLastGood(d,source='persisted aggregate'){
  const x=stripOverlay(d);
  x.originalSession=x.session||'';
  x.session='LAST KNOWN GOOD';
  x.dataState='LAST_KNOWN_GOOD';
  x.fallbackSource=source;
  x.quoteState='HISTORICAL_AGGREGATE';
  x.coverage='LAST GOOD';
  return x;
}
function cacheLastGood(d){
  if(!usableBase(d))return;
  try{localStorage.setItem(DATA_CACHE,JSON.stringify(markLastGood(d,'browser cache')))}catch(e){}
}
function readCachedLastGood(){
  try{
    const x=JSON.parse(localStorage.getItem(DATA_CACHE)||'null');
    return x&&Array.isArray(x.chambers)?x:null;
  }catch(e){return null}
}
function deepKeys(o,a=[]){if(Array.isArray(o))o.forEach(x=>deepKeys(x,a));else if(o&&typeof o==='object')Object.entries(o).forEach(([k,v])=>{a.push(k.toLowerCase());deepKeys(v,a)});return a}
function membrane(o){const bad=[...new Set(deepKeys(o).filter(k=>forbidden.has(k)))];if(bad.length)throw Error('PUBLIC_MEMBRANE_REJECTED_KEYS: '+bad.join(','))}
async function j(url){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000);
  try{const r=await fetch(url+(url.includes('?')?'&':'?')+'t='+Date.now(),{cache:'no-store',signal:controller.signal});if(!r.ok)throw Error(`HTTP ${r.status}`);return await r.json()}finally{clearTimeout(timer)}
}
function overlayMap(data){const m=new Map();const list=data?.overnight?.chambers||data?.overlay?.chambers||data?.overnight_chambers||[];for(const c of list)m.set(String(c.sector_code||c.chamber_id||'').toUpperCase(),c);return m}

function baseCell(code,c={}){
  const m=META[code];
  return{
    code,
    label:m.label,
    desc:m.desc,
    base:num(c.headline_bps??c.median_bps),
    avg:num(c.avg_bps??c.average_bps),
    breadth:num(c.net_breadth),
    fresh:num(c.fresh_ratio),
    status:String(c.cell_status||c.fidelity||'').toLowerCase(),
    overnight:null,onN:null,onD:null,grade:''
  };
}


function normV2(d){
  membrane(d);
  if(d?.schema!=='phi.finance.weather.v2'||!Array.isArray(d.chambers)||d.chambers.length!==16)throw Error('Invalid v2 board');
  if(new Set(d.chambers.map(c=>c.sector_code)).size!==16||d.chambers.some(c=>!CODES.includes(c.sector_code)))throw Error('Invalid sector set');
  if(!Number.isFinite(Date.parse(d.published_at_utc))||Date.parse(d.published_at_utc)>Date.now()+120000)throw Error('Invalid timestamp');
  const overnight=d.session==='OVERNIGHT';
  const chambers=CODES.map(code=>{
    const raw=d.chambers.find(c=>c.sector_code===code),c=baseCell(code,raw);
    if(!Number.isInteger(raw.fresh_count)||!Number.isInteger(raw.expected_count)||raw.expected_count<=0||raw.fresh_count<0||raw.fresh_count>raw.expected_count)throw Error('Invalid coverage');
    return {...c,base:num(raw.display_bps??raw.headline_bps),overnight:overnight?num(raw.display_bps??raw.headline_bps):null,
      onN:raw.fresh_count,onD:raw.expected_count,grade:raw.coverage_grade||'',fresh:num(raw.coverage_ratio),
      readingState:raw.reading_state,readingSession:raw.session,observedAt:raw.observed_at_utc,newestObservation:raw.newest_observation_utc,
      validUntil:raw.valid_until_utc,referenceDate:raw.reference_date,basisId:raw.basis_id,movement:raw.movement||{},
      distribution:raw.distribution||{},sourceCounts:raw.source_counts||{},heldCount:raw.held_coverage_count,record51:raw.record51||''};
  });
  return {v2:true,sequence:d.sequence,epoch:d.writer_epoch,published:d.published_at_utc,
    generated:d.observed_at_utc||d.published_at_utc,validUntil:d.valid_until_utc,snapshotLabel:formatEtTimestamp(d.observed_at_utc),
    session:d.session,scheduledSession:d.scheduled_session,
    provider:[...new Set(d.chambers.flatMap(c=>Object.keys(c.source_counts||{})))].map(s=>({ETRADE:'E*TRADE',ALPACA_OVERNIGHT:'Alpaca overnight (indicative)',ALPACA_IEX:'Alpaca IEX'}[s]||s)).join(' · ')||'Waiting for providers',feed:'',quoteState:d.state,
    scope:'Measured sector aggregates',coverage:d.global_fresh_count===d.global_expected_count?'COMPLETE':'PARTIAL',
    freshRatio:num(d.coverage_ratio),globalFresh:num(d.global_fresh_count),globalExpected:num(d.global_expected_count),
    globalMedian:num(d.global_median_bps),snapCount:d.trace?.length||0,source:'Finance Weather v2',dataState:d.state,
    overnightActive:overnight,chambers,serverTrace:Array.isArray(d.trace)?d.trace:[]};
}
function currentCell(c,now=Date.now()){
  return c?.readingState==='CURRENT'&&finite(c.base)&&Number.isFinite(Date.parse(c.validUntil))&&Date.parse(c.validUntil)>=now;
}
function ingestV2Trace(d){
  const points=(d.serverTrace||[]).filter(p=>p.session==='OVERNIGHT'&&Number.isFinite(Date.parse(p.at)));
  if(!points.length)return;
  const sorted=points.sort((a,b)=>Date.parse(a.at)-Date.parse(b.at));let first=0;
  for(let i=1;i<sorted.length;i++)if(Date.parse(sorted[i].at)-Date.parse(sorted[i-1].at)>OVERNIGHT_TRACE_GAP_MS)first=i;
  state.overnightTrace=sorted.slice(first).slice(-OVERNIGHT_TRACE_MAX);saveOvernightTrace();
}
function renderHistoryPreview(d){
  const host=$('#v2HistoryPreview');if(!host||!d.v2)return;
  const points=(d.serverTrace||[]).filter(p=>Number.isFinite(Date.parse(p.at))).slice(-360);
  const values=points.flatMap(p=>CODES.map(c=>num(p.sectors?.[c]?.value))).filter(finite);
  if(!points.length||!values.length){host.textContent='Recorded history appears with the next measured readings.';return}
  const first=Date.parse(points[0].at),last=Date.parse(points.at(-1).at),width=600,height=180;
  let low=Math.min(0,...values),high=Math.max(0,...values);const padding=Math.max(1,(high-low)*.1);low-=padding;high+=padding;
  const x=p=>12+(last===first ? .5 : (Date.parse(p.at)-first)/(last-first))*576,y=v=>10+(high-v)/(high-low)*160;
  const paths=CODES.map(code=>{let path='',previous=null;for(const p of points){
    const cell=p.sectors?.[code],value=num(cell?.value);if(!finite(value)){previous=null;continue}
    const connected=previous&&cell.basis===previous.basis&&p.session===previous.session&&Date.parse(p.at)-previous.at<=900000;
    path+=`${connected?'L':'M'}${x(p).toFixed(1)},${y(value).toFixed(1)} `;previous={basis:cell.basis,session:p.session,at:Date.parse(p.at)};
  }const value=num(points.at(-1).sectors?.[code]?.value);return `<path d="${path}" fill="none" stroke="${META[code].color}" stroke-width="1.6"/>${finite(value)?`<circle cx="${x(points.at(-1))}" cy="${y(value)}" r="2" fill="${META[code].color}"/>`:''}`}).join('');
  host.innerHTML=`<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Preview of sixteen sector BPS histories"><line x1="12" x2="588" y1="${y(0)}" y2="${y(0)}" stroke="#ffffff44" stroke-dasharray="3 3"/>${paths}</svg><small>${points.length} recorded snapshots · ${formatEtTimestamp(points.at(-1).at)}</small>`;
}

function normFuture(d){
  membrane(d);
  const om=overlayMap(d), byCode=new Map((d.chambers||[]).map(c=>[String(c.sector_code||c.chamber_id||'').toUpperCase(),c]));
  const chambers=CODES.map(code=>{
    const c=byCode.get(code)||{};
    const o=om.get(code)||c.overnight||c.overlay||c.sessions?.overnight||{};
    const x=baseCell(code,c);
    x.overnight=num(c.overnight_bps??c.overlay_bps??o.overlay_median_bps??o.headline_bps??o.median_bps);
    x.onN=num(c.overnight_fresh_count??o.fresh_count);
    x.onD=num(c.overnight_expected_count??o.expected_count);
    x.grade=c.overnight_coverage_grade||o.coverage_grade||'';
    return x;
  });
  return{
    source:d.ledger||d.source||'chamber_grid_public.json',
    generated:d.generated_at_utc||d.latest_snapshot_utc||d.snapshot_utc||'',
    snapshotLabel:d.snapshot_et_label||d.latest_snapshot_et||d.snapshot_et||'',
    session:d.session||d.provider_session||d.overlay?.session||'',
    provider:d.selected_provider||d.provider||d.overlay?.provider||'',
    feed:d.feed||d.provider_feed||d.overlay?.feed||'',
    quoteState:d.quote_state||d.overlay?.quote_state||'',
    scope:d.scope||d.overlay?.scope||'NON_CONSOLIDATED',
    coverage:d.coverage_grade||d.provider_coverage_grade||d.overlay?.coverage_grade||'',
    freshRatio:num(d.fresh_ratio??d.global_fresh_ratio??d.provider_coverage_ratio),
    snapCount:num(d.snapshot_count??d.snap_count??d.history_count),
    globalMedian:num(d.global_median_bps??d.median_bps),
    spread:num(d.cross_sector_median_spread_bps??d.spread_bps),
    netBreadth:num(d.global_net_breadth??d.net_breadth),
    market_truth:d.market_truth||'NOT_PROVEN_BY_RECEIPT',
    trade_permission:d.trade_permission||'NO',
    dataState:d.data_state||(d.last_known_good?'LAST_KNOWN_GOOD':'CURRENT'),
    fallbackSource:d.fallback_source||'',
    chambers
  };
}

function normFlatPlate(d){
  membrane(d);
  const chambers=CODES.map(code=>{
    const key=code.toLowerCase();
    const x=baseCell(code,{
      median_bps:d[`${key}_median_bps`],
      avg_bps:d[`${key}_avg_bps`],
      net_breadth:d[`${key}_net_breadth`],
      fresh_ratio:d[`${key}_fresh_ratio`]
    });
    return x;
  });
  return{
    source:d.ledger||'latest_plate.json',generated:d.snapshot_utc||d.generated_at_utc||'',snapshotLabel:d.snapshot_et_label||d.snapshot_et||'',
    session:d.session||d.provider_session||'',provider:d.selected_provider||d.provider||'',feed:d.feed||'',quoteState:d.quote_state||'',scope:d.scope||'NON_CONSOLIDATED',coverage:d.coverage_grade||'',freshRatio:num(d.fresh_ratio),snapCount:num(d.snapshot_count),globalMedian:num(d.global_median_bps),spread:num(d.cross_sector_median_spread_bps),netBreadth:num(d.global_net_breadth),market_truth:d.market_truth||'NOT_PROVEN_BY_RECEIPT',trade_permission:d.trade_permission||'NO',dataState:d.data_state||(d.last_known_good?'LAST_KNOWN_GOOD':'CURRENT'),fallbackSource:d.fallback_source||'',chambers
  };
}

function freshOvernight(ov,nowMs=Date.now()){
  if(!ov||ov.active!==true||!Array.isArray(ov.chambers))return false;
  if(String(ov.session||'').trim().toUpperCase()!=='OVERNIGHT')return false;
  if(String(ov.status||'').trim().toUpperCase()!=='OK')return false;
  const created=Date.parse(ov.created_utc||'');
  if(!Number.isFinite(created))return false;
  const age=nowMs-created;
  if(age < -OVERNIGHT_CLOCK_SKEW_MS)return false;
  const grade=String(ov.global_coverage_grade||'').trim().toUpperCase();
  if(grade==='INACTIVE')return false;
  // Coverage quality and session identity are separate. A fresh overnight plate may
  // be visibly active even when the aggregate coverage grade is REJECT; missing
  // cells remain missing and the UI exposes the limited coverage explicitly.
  return ov.chambers.some(c=>finite(c.overlay_median_bps));
}
function formatEtTimestamp(value){
  const parsed=Date.parse(value||'');
  if(!Number.isFinite(parsed))return value||'';
  return new Intl.DateTimeFormat('en-US',{
    timeZone:'America/New_York',year:'numeric',month:'short',day:'numeric',
    hour:'numeric',minute:'2-digit',second:'2-digit',timeZoneName:'short'
  }).format(new Date(parsed));
}
function normOverlay(base,ov,nowMs=Date.now()){
  if(!ov||!Array.isArray(ov.chambers))return base;
  membrane(ov);
  const m=new Map(ov.chambers.map(c=>[String(c.sector_code||'').toUpperCase(),c]));
  base.chambers.forEach(c=>{
    const o=m.get(c.code);if(!o)return;
    c.overnight=num(o.overlay_median_bps);
    c.onN=num(o.fresh_count??o.fresh_symbol_count);
    c.onD=num(o.expected_count??o.expected_symbol_count);
    c.grade=o.coverage_grade||'';
  });
  base.overnightActive=freshOvernight(ov,nowMs);
  if(base.overnightActive){
    base.baseContext={
      source:base.source,generated:base.generated,snapshotLabel:base.snapshotLabel,
      session:base.session,provider:base.provider,feed:base.feed,quoteState:base.quoteState,
      scope:base.scope,coverage:base.coverage,freshRatio:base.freshRatio,
      globalMedian:base.globalMedian,spread:base.spread,netBreadth:base.netBreadth,
      dataState:base.dataState,fallbackSource:base.fallbackSource
    };
    const values=base.chambers.map(c=>c.overnight).filter(finite).map(Number);
    const globalFresh=num(ov.global_fresh_count),globalExpected=num(ov.global_expected_count);
    base.source=ov.ledger||'overnight_overlay.json';
    base.generated=ov.created_utc;
    base.snapshotLabel=formatEtTimestamp(ov.created_utc);
    base.session='OVERNIGHT';
    base.provider=ov.provider||'ALPACA';
    base.feed=ov.feed||'OVERNIGHT_DERIVED';
    base.quoteState=ov.quote_state||'REALTIME_INDICATIVE';
    base.scope=ov.coverage_scope||'NON_CONSOLIDATED';
    base.coverage=ov.global_coverage_grade||'';
    base.freshRatio=num(ov.global_coverage_ratio);
    base.globalFresh=globalFresh;
    base.globalExpected=globalExpected;
    base.globalMedian=num(ov.global_overlay_median_bps)??(values.length?median(values):null);
    base.spread=values.length?Math.max(...values)-Math.min(...values):null;
    base.netBreadth=null;
    base.dataState='OVERNIGHT';
  }
  return base;
}

function deactivateOvernight(d){
  if(!d?.overnightActive)return d;
  if(d.baseContext)Object.assign(d,d.baseContext);
  d.overnightActive=false;
  return d;
}

function normRows(rows){
  membrane(rows);
  const snaps=[...new Set(rows.map(x=>x.snapshot_utc).filter(Boolean))].sort();
  const latest=snaps.at(-1), latestRows=rows.filter(x=>x.snapshot_utc===latest), byCode=new Map(latestRows.map(x=>[String(x.sector_code).toUpperCase(),x]));
  const chambers=CODES.map(code=>baseCell(code,byCode.get(code)||{}));
  const med=chambers.map(c=>c.base).filter(finite), br=chambers.map(c=>c.breadth).filter(finite);
  return{
    source:'safe sector_plot_data adapter',generated:latest||'',snapshotLabel:latestRows[0]?.snapshot_et||latestRows[0]?.plot_time_label||'',session:'',provider:'',feed:'',quoteState:'',scope:'AGGREGATE_PUBLIC',coverage:'BASE ONLY',freshRatio:latestRows.length?latestRows.filter(x=>Number(x.fresh_ratio)>=.5).length/latestRows.length:null,snapCount:snaps.length,globalMedian:med.length?median(med):null,spread:med.length?Math.max(...med)-Math.min(...med):null,netBreadth:br.length?br.reduce((a,b)=>a+b,0):null,market_truth:'NOT_PROVEN_BY_RECEIPT',trade_permission:'NO',dataState:'CURRENT',fallbackSource:'',chambers
  };
}
function median(a){const s=[...a].sort((x,y)=>x-y),n=s.length;if(!n)return null;return n%2?s[(n-1)/2]:(s[n/2-1]+s[n/2])/2}

function usableBase(d){
  if(!d||!Array.isArray(d.chambers))return false;
  const vals=d.chambers.map(c=>c.base).filter(finite).map(Number);
  const nonzero=vals.filter(v=>Math.abs(v)>.05).length;
  return vals.length>=12&&nonzero>=4;
}
function emptyBaseFromOverlay(ov){
  const overlayFresh=finite(ov?.global_fresh_count)&&finite(ov?.global_expected_count)&&Number(ov.global_expected_count)>0
    ?Number(ov.global_fresh_count)/Number(ov.global_expected_count):null;
  return{
    source:'overnight_overlay.json',generated:ov?.base_snapshot_utc||'',snapshotLabel:ov?.base_snapshot_et_label||'',
    session:'',provider:'',feed:'',quoteState:'',scope:'NON_CONSOLIDATED',coverage:'',freshRatio:overlayFresh,snapCount:null,globalMedian:null,spread:null,netBreadth:null,market_truth:ov?.market_truth||'NOT_PROVEN_BY_RECEIPT',trade_permission:ov?.trade_permission||'NO',dataState:'CURRENT',fallbackSource:'',overnightActive:false,chambers:CODES.map(code=>baseCell(code,{}))
  };
}
async function loadCurrentBase(){
  try{
    const d=await j('/finance/live-data');
    return Array.isArray(d)?normRows(d):(Array.isArray(d?.chambers)?normFuture(d):normFlatPlate(d));
  }catch(e){
    try{return normFuture(await j(`${LIVE}/finance/latest/chamber_grid_public.json`))}
    catch(e2){
      try{const d=await j(`${LIVE}/finance/latest/latest_plate.json`);return Array.isArray(d?.chambers)?normFuture(d):normFlatPlate(d)}
      catch(e3){
        try{return normRows(await j(`${LIVE}/finance/latest/sector_plot_data.json`))}
        catch(e4){return null}
      }
    }
  }
}
async function loadLastGood(){
  try{
    const d=await j(`${LIVE}/finance/latest/last_known_good.json`);
    const x=Array.isArray(d?.chambers)?normFuture(d):normFlatPlate(d);
    if(usableBase(x))return markLastGood(x,'public last-known-good rail');
  }catch(e){}
  const cached=readCachedLastGood();
  if(cached&&usableBase(cached))return cached;
  try{
    const d=await j('static/last_known_good.json');
    const x=Array.isArray(d?.chambers)?normFuture(d):normFlatPlate(d);
    if(usableBase(x))return markLastGood(x,'bundled last-known-good plate');
  }catch(e){}
  try{return markLastGood(normRows(await j('static/sector_plot_data.json')),'bundled historical adapter')}catch(e){}
  return null;
}
async function load(){
  try{
    const raw=await j(`${LIVE}/finance/latest/weather_v2.json`),next=normV2(raw);
    if(state.data?.v2&&Date.parse(next.published)<Date.parse(state.data.published))return state.data;
    if(state.data?.v2&&next.epoch===state.data.epoch&&next.sequence<state.data.sequence)return state.data;
    try{localStorage.setItem(V2_CACHE,JSON.stringify(raw))}catch{}
    return next;
  }catch(e){
    if(state.data?.v2)return state.data;
    try{const cached=JSON.parse(localStorage.getItem(V2_CACHE)||'null');if(cached)return normV2(cached)}catch{}
  }
  let base=await loadCurrentBase();
  if(base&&usableBase(base))cacheLastGood(base);
  let ov=null;
  try{ov=await j(`${LIVE}/finance/latest/overnight_overlay.json`)}catch(e){}
  if(base&&ov)base=normOverlay(base,ov);
  if(base&&(usableBase(base)||base.overnightActive)){
    base.dataState=base.dataState||'CURRENT';
    return base;
  }
  if(ov){
    const overlayBase=normOverlay(emptyBaseFromOverlay(ov),ov);
    if(overlayBase.overnightActive){
      return overlayBase;
    }
  }
  const lastGood=await loadLastGood();
  if(lastGood)return lastGood;
  if(base){base.dataState='CURRENT_INCOMPLETE';return base}
  throw Error('No public or last-known-good finance plate is available.');
}

function fidelity(c){
  if(c.status&&['stratified','diffuse','opaque'].includes(c.status))return c.status;
  if(!finite(c.fresh)||c.fresh<.5||!finite(c.base)||!finite(c.avg))return'opaque';
  const skew=Math.abs(c.avg-c.base)/Math.max(Math.abs(c.base),5), breadth=Math.abs(c.breadth||0)/10;
  if(breadth>=.6&&skew<=.25)return'stratified';
  if(skew>=.75)return'opaque';
  return'diffuse';
}
function overlayPlateActive(){
  return Boolean(state.data?.overnightActive&&state.data.chambers.some(c=>finite(c.overnight)));
}
function cellValue(c){
  if(overlayPlateActive())return c.overnight;
  if(state.headline==='breadth')return c.breadth;
  return c.base;
}
function cellSubline(c){
  if(overlayPlateActive())return '';
  if(state.headline==='breadth')return finite(c.base)?`median ${fmt(c.base)} bps`:'median —';
  return '';
}
function explicitSession(d){return String(d.session||'').trim()||'BASE / UNKNOWN'}
function coverageText(c){return finite(c.onN)&&finite(c.onD)?`${c.onN}/${c.onD}${c.grade?' · '+String(c.grade).replaceAll('_',' '):''}`:(c.grade||'')}
function displayPressure(c,d=state.data){return d?.overnightActive?c.overnight:c.base}
function topBottom(d){
  const usable=d.chambers.filter(c=>finite(displayPressure(c,d))).sort((a,b)=>displayPressure(b,d)-displayPressure(a,d));
  return usable.length?`${usable[0].label} ${fmt(displayPressure(usable[0],d))} / ${usable.at(-1).label} ${fmt(displayPressure(usable.at(-1),d))}`:'—';
}
function globalValue(d,key){
  if(finite(d[key]))return d[key];
  const vals=d.chambers.map(c=>key==='globalMedian'?displayPressure(c,d):c.breadth).filter(finite);
  if(!vals.length)return null;
  if(key==='globalMedian')return median(vals);
  if(key==='netBreadth')return vals.reduce((a,b)=>a+b,0);
  return null;
}

function age(){
  if(!state.data)return;
  const parsed=Date.parse(state.data.generated), pill=$('#freshnessPill'), txt=$('#freshnessText'), last=state.data.dataState==='LAST_KNOWN_GOOD',overnight=state.data.overnightActive;
  if(!Number.isFinite(parsed)){txt.textContent=last?'LAST GOOD · AGE UNAVAILABLE':'AGE UNAVAILABLE';pill.className='status stale';return}
  const paused=state.data.v2?state.data.chambers.every(c=>!currentCell(c)):Date.now()-parsed>OVERNIGHT_MAX_AGE_MS;
  if(state.data.v2){
    for(const c of state.data.chambers){
      const tile=[...document.querySelectorAll('#phiGrid .cell')].find(t=>t.dataset.code===c.code);if(!tile)continue;
      const active=currentCell(c),mark=c.movement||{};
      tile.dataset.financeActive=active&&mark.eligible===true?'1':'0';
      tile.classList.toggle('reading-held',!active);
      const caption=tile.querySelector('[data-reading-state]');if(caption)caption.textContent=active?(state.data.overnightActive?'OVERNIGHT':'CURRENT'):'RESTING';
      const observed=Date.parse(c.newestObservation||c.observedAt||'');
      const confidence=Number.isFinite(observed)?Math.max(.15,Math.min(1,1-(Date.now()-observed)/(20*60*1000))):.15;
      tile.style.setProperty('--reading-confidence',String(confidence));
    }
    const ds=$('#dataState');if(ds)ds.textContent=state.data.overnightActive?(paused?'OVERNIGHT · RESTING':'OVERNIGHT'):(paused?'READINGS RESTING':state.data.session.replaceAll('_',' '));
  }
  if(paused){const note=$('#feedNotice');if(note){note.textContent='The market took a breath. The last readings stay on the board; your jbits float until fresh data returns.';note.hidden=false}}

  const s=Math.max(0,Math.floor((Date.now()-parsed)/1000));
  const ageText=s<60?`${s}s ago`:s<3600?`${Math.floor(s/60)}m ${s%60}s ago`:s<86400?`${Math.floor(s/3600)}h ${Math.floor((s%3600)/60)}m ago`:`${Math.floor(s/86400)}d ${Math.floor((s%86400)/3600)}h ago`;
  txt.textContent=last?`LAST GOOD · ${ageText}`:overnight?`OVERNIGHT${paused?' · RESTING':''} · ${ageText}`:ageText;
  pill.className='status '+(paused||last?'stale':overnight?'overnight':s<=300?'fresh':s<=1800?'aging':'stale');
}

function render(){
  const d=state.data;if(!d)return;
  const placeholder=$('#gridEmpty');if(placeholder)placeholder.hidden=true;
  const board=document.querySelector('.board-wrap');if(board)board.hidden=false;
  const overlayActive=overlayPlateActive();
  if(overlayActive)state.headline='median';
  const session=explicitSession(d);
  document.body.classList.toggle('overnight-mode',overlayActive);
  $('#session').textContent=session;
  const ds=$('#dataState'),isLast=d.dataState==='LAST_KNOWN_GOOD';
  const limitedOvernight=overlayActive&&(d.v2?d.freshRatio<.6:String(d.coverage||'').toUpperCase()==='REJECT');
  ds.textContent=overlayActive?(limitedOvernight?'OVERNIGHT · LIMITED':'OVERNIGHT'):isLast?'LAST KNOWN GOOD':d.dataState==='CURRENT_INCOMPLETE'?'CURRENT INCOMPLETE':'LATEST FEED';
  ds.classList.toggle('last-good',isLast);
  ds.classList.toggle('active',!overlayActive&&!isLast&&d.dataState!=='CURRENT_INCOMPLETE');
  ds.classList.toggle('overnight',overlayActive);
  $('#provider').textContent=[d.provider,d.feed].filter(Boolean).join(' · ')||'BASE PUBLIC RAIL';
  const coverageParts=[];
  if(overlayActive&&finite(d.globalFresh)&&finite(d.globalExpected))coverageParts.push(`${d.globalFresh}/${d.globalExpected}`);
  if(d.coverage)coverageParts.push(String(d.coverage).replaceAll('_',' '));
  $('#coverage').textContent=coverageParts.length?`COVERAGE ${coverageParts.join(' · ')}`:'BASE AGGREGATE';
  $('#session').hidden=overlayActive||isLast||session===ds.textContent;
  $('#coverage').hidden=isLast&&['LAST GOOD','LAST KNOWN GOOD'].includes(String(d.coverage||'').toUpperCase());
  $('#snapshotCount').textContent=`SNAPSHOTS ${finite(d.snapCount)?Math.round(d.snapCount):'—'}`;
  $('#stamp').textContent=d.snapshotLabel||d.generated||'—';
  $('#quoteState').textContent=d.quoteState||'SOURCE READING';
  $('#scopeState').textContent=d.scope||'AGGREGATE PUBLIC';
  $('#arrangeBanner').hidden=!state.arrange;
  $('#phiGrid').classList.toggle('unlocked',state.arrange);
  $('#headlineMedian').classList.toggle('active',state.headline==='median');
  $('#headlineBreadth').classList.toggle('active',state.headline==='breadth');
  $('#headlineMedian').setAttribute('aria-pressed',String(state.headline==='median'));
  $('#headlineBreadth').setAttribute('aria-pressed',String(state.headline==='breadth'));
  const headlineSwitch=document.querySelector('.headline-switch');
  if(headlineSwitch)headlineSwitch.hidden=overlayActive;
  const breadthOption=$('#rankBy').querySelector('option[value="breadth"]');
  const fidelityOption=$('#rankBy').querySelector('option[value="fidelity"]');
  const baseOption=$('#rankBy').querySelector('option[value="base"]');
  baseOption.textContent=overlayActive?'Overnight BPS':'Snapshot pressure';
  breadthOption.hidden=overlayActive;breadthOption.disabled=overlayActive;
  fidelityOption.hidden=overlayActive;fidelityOption.disabled=overlayActive;
  if(overlayActive&&!['base','coverage'].includes($('#rankBy').value))$('#rankBy').value='base';
  $('#rankHint').textContent=overlayActive
    ?'Overnight readings are ranked by size of movement, not direction.'
    :'Pressure and breadth are ranked by size of movement, not direction.';
  const legend=document.querySelector('.legend');if(legend)legend.hidden=overlayActive;
  const snapshotEyebrow=document.querySelector('.snapshot-time .eyebrow');if(snapshotEyebrow)snapshotEyebrow.textContent=overlayActive?'newest overnight reading':'last public snapshot';
  const globalKicker=document.querySelector('.global>.eyebrow');if(globalKicker)globalKicker.textContent=overlayActive?'overnight summary':'current snapshot summary';
  const globalBreadthLabel=$('#globalBreadth')?.previousElementSibling;if(globalBreadthLabel)globalBreadthLabel.textContent=overlayActive?'coverage':'net breadth';

  renderHistoryPreview(d);
  recordOvernightTrace(d);
  renderGrid();
  renderRank();
  renderOvernightTrace();
  const notice=$('#feedNotice');
  if(notice&&overlayActive&&limitedOvernight){
    const cov=finite(d.globalFresh)&&finite(d.globalExpected)?`${d.globalFresh}/${d.globalExpected}`:(finite(d.freshRatio)?`${Math.round(d.freshRatio*100)}%`:'limited');
    notice.textContent=`Overnight feed is live with limited coverage (${cov}). Resting tiles hold their last measured value. A dash means there is no saved reading yet.`;
    notice.hidden=false;
  }else if(notice&&notice.dataset.error!=='1'){notice.hidden=true;notice.textContent=''}
  $('#globalMedian').textContent=`${fmt(globalValue(d,'globalMedian'))} bps`;
  $('#globalSpread').textContent=`${fmt(finite(d.spread)?d.spread:(()=>{const v=d.chambers.map(c=>displayPressure(c,d)).filter(finite);return v.length?Math.max(...v)-Math.min(...v):null})())} bps`;
  $('#topBottom').textContent=topBottom(d);
  $('#globalBreadth').textContent=overlayActive
    ?(finite(d.globalFresh)&&finite(d.globalExpected)?`${d.globalFresh}/${d.globalExpected}${d.coverage?' · '+String(d.coverage).replaceAll('_',' '):''}`:(d.coverage||'—'))
    :fmt(globalValue(d,'netBreadth'),0);
  $('#sourceLine').textContent=overlayActive
    ?`Overnight reading · ${[d.provider,d.feed].filter(Boolean).join(' · ')||d.source} · ${String(d.coverage||'coverage unavailable').replaceAll('_',' ')}`
    :`Source: ${d.source} · state: ${d.dataState||'CURRENT'}${d.fallbackSource?' ('+d.fallbackSource+')':''} · session: ${session}`;
  age();clearInterval(state.timer);state.timer=setInterval(age,1000);
}

function renderGrid(){
  const grid=$('#phiGrid');grid.innerHTML='';
  const byCode=new Map(state.data.chambers.map(c=>[c.code,c]));
  for(const code of CODES){
    const c=byCode.get(code)||baseCell(code,{}), m=META[code], slot=state.slots[code], row=Math.floor(slot/4)+1,col=slot%4+1;
    const main=cellValue(c), fid=fidelity(c), cov=overlayPlateActive()?coverageText(c):'', expanded=state.expanded===code;
    const extendedHeadline=overlayPlateActive();
    const el=document.createElement('article');
    el.className=`cell${expanded?' expanded':''}`;
    el.dataset.code=code;
    el.dataset.gridCol=String(col);el.dataset.gridRow=String(row);
    el.dataset.financeBps=finite(displayPressure(c))?String(Number(displayPressure(c))):'';
    el.dataset.financeRail=extendedHeadline?'overnight':'base';
    el.dataset.financeGenerated=state.data.generated||'';
    el.dataset.financeLabel=m.label;
    if(state.data.v2){
      el.dataset.financeModel='v2';el.dataset.financeIndex=finite(c.movement?.index)?String(c.movement.index):'';
      el.dataset.financeEpoch=c.movement?.epoch||'';
      el.dataset.financeActive=currentCell(c)&&c.movement?.eligible===true?'1':'0';
      el.dataset.financeValidUntil=c.validUntil||'';
    }
    el.style.gridRow=String(row);el.style.gridColumn=String(col);el.style.setProperty('--accent',m.color);
    el.setAttribute('role','button');el.setAttribute('tabindex','0');el.setAttribute('aria-expanded',String(expanded));
    const sub=cellSubline(c);
    const subHtml=sub?`<div class="cell-sub comparison">${sub}</div>`:'';
    const overlayBlock=extendedHeadline&&finite(c.overnight)
      ?`<div class="reading overlay"><span>overnight</span><b>${fmt(c.overnight)} bps</b></div>`
      :`<div class="reading overlay"><span>overnight</span><b>—</b></div>`;
    const foot=state.data.v2
      ?`<span class="overnight-label" data-reading-state>${currentCell(c)?(extendedHeadline?'OVERNIGHT':'CURRENT'):'RESTING'}</span><span class="coverage">${c.onN}/${c.onD}</span>`
      :extendedHeadline
      ?`<span class="overnight-label">OVERNIGHT</span><span class="coverage">${finite(c.onN)&&finite(c.onD)?`${c.onN}/${c.onD}`:''}</span>`
      :`<span class="fidelity ${fid}">${fid}</span><span class="coverage">${state.data.dataState==='LAST_KNOWN_GOOD'?'last good':'base read'}</span>`;
    const extra=state.data.v2
      ?`<div class="reading"><span>measured median</span><b>${fmt(c.base)} bps</b></div><div class="reading"><span>contributors</span><b>${c.distribution.sample_size??c.onN}/${c.onD}</b></div><div class="reading"><span>reference close</span><b>${c.referenceDate||'—'}</b></div><div class="reading"><span>middle 80%</span><b>${fmt(c.distribution.p10_bps)} to ${fmt(c.distribution.p90_bps)}</b></div><p>${currentCell(c)?'Measured from the available contributors.':'Holding the last measured reading.'} ${c.movement?.eligible?'Jbits follow comparable readings.':'Jbits float while readings settle.'}</p>`
      :extendedHeadline
      ?`${overlayBlock}<div class="reading"><span>coverage</span><b>${cov||'—'}</b></div><p>Indicative overnight sector median.</p>`
      :`<div class="reading"><span>current snapshot</span><b>${fmt(c.base)} bps</b></div><div class="reading"><span>net breadth</span><b>${fmt(c.breadth,0)}</b></div><p>${fidMeaning[fid]}</p>`;
    el.innerHTML=`
      <div class="cell-top"><span class="cell-code">${code}</span><i class="cell-accent" aria-hidden="true"></i></div>
      <div class="cell-label">${m.label}</div>
      <div class="cell-desc">${m.desc}</div>
      <div class="cell-main${extendedHeadline?' overnight':''}">${fmt(main,state.headline==='breadth'?0:1)}${state.headline==='median'?' bps':''}</div>
      ${subHtml}
      <div class="cell-foot">${foot}</div>
      <div class="cell-extra">
        ${extra}
        <div class="finance-position-slot" data-finance-position-slot></div>
      </div>`;
    bindTile(el,code);
    grid.appendChild(el);
  }
}

function setArrange(on){
  state.arrange=!!on;
  clearTimeout(state.holdTimer);state.holdTimer=null;state.gesture=null;
  if(navigator.vibrate)try{navigator.vibrate(on?[24,35,24]:18)}catch(e){}
  render();
}
function bindTile(el,code){
  el.addEventListener('contextmenu',e=>e.preventDefault());
  el.addEventListener('keydown',e=>{
    if(e.key==='Enter'||e.key===' '){e.preventDefault();state.expanded=state.expanded===code?null:code;render()}
  });
  el.addEventListener('pointerdown',e=>tileDown(e,el,code));
  el.addEventListener('pointermove',e=>tileMove(e,el));
  el.addEventListener('pointerup',e=>tileUp(e,el));
  el.addEventListener('pointercancel',()=>clearGesture(el));
}
function tileDown(e,el,code){
  if(e.button!==0)return;
  el.setPointerCapture?.(e.pointerId);
  state.gesture={code,pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,lastX:e.clientX,lastY:e.clientY,originSlot:state.slots[code],moved:false,dragging:false,long:false,startedArrange:state.arrange};
  clearTimeout(state.holdTimer);
  state.holdTimer=setTimeout(()=>{
    if(!state.gesture||state.gesture.moved)return;
    state.gesture.long=true;
    if(state.arrange){setArrange(false)}else{setArrange(true)}
  },HOLD_MS);
}
function tileMove(e,el){
  const g=state.gesture;if(!g||g.pointerId!==e.pointerId)return;
  g.lastX=e.clientX;g.lastY=e.clientY;
  const dx=e.clientX-g.startX,dy=e.clientY-g.startY,dist=Math.hypot(dx,dy);
  if(dist>MOVE_PX){g.moved=true;clearTimeout(state.holdTimer)}
  if(state.arrange&&g.moved){
    g.dragging=true;el.classList.add('dragging');el.style.setProperty('--drag-x',`${dx}px`);el.style.setProperty('--drag-y',`${dy}px`);e.preventDefault();
  }
}
function tileUp(e,el){
  const g=state.gesture;if(!g||g.pointerId!==e.pointerId){clearGesture(el);return}
  clearTimeout(state.holdTimer);
  if(g.dragging&&state.arrange){
    const grid=$('#phiGrid'),r=grid.getBoundingClientRect(),col=clamp(Math.floor((e.clientX-r.left)/(r.width/4)),0,3),row=clamp(Math.floor((e.clientY-r.top)/(r.height/4)),0,3),target=row*4+col,origin=g.originSlot,or=Math.floor(origin/4),oc=origin%4;
    if(target!==origin&&Math.max(Math.abs(row-or),Math.abs(col-oc))<=1){
      const occupant=CODES.find(c=>c!==g.code&&state.slots[c]===target);
      if(occupant)state.slots[occupant]=origin;
      state.slots[g.code]=target;persistSlots();
    }
    clearGesture(el);render();return;
  }
  if(!g.long&&!g.moved){state.expanded=state.expanded===g.code?null:g.code}
  clearGesture(el);render();
}
function clearGesture(el){clearTimeout(state.holdTimer);state.holdTimer=null;state.gesture=null;if(el){el.classList.remove('dragging');el.style.removeProperty('--drag-x');el.style.removeProperty('--drag-y')}}

function renderRank(){
  const key=$('#rankBy').value;
  const overnight=overlayPlateActive();
  const rankF={stratified:3,diffuse:2,opaque:1};
  const vals=state.data.chambers.map(c=>({...c,fid:fidelity(c)})).sort((a,b)=>{
    if(key==='coverage')return overnight
      ?((b.onN||0)/(b.onD||1))-((a.onN||0)/(a.onD||1))
      :(num(b.fresh)??-1)-(num(a.fresh)??-1);
    if(key==='fidelity')return rankF[b.fid]-rankF[a.fid]||META[a.code].slot-META[b.code].slot;
    const av=key==='base'?(overnight?a.overnight:a.base):a.breadth,bv=key==='base'?(overnight?b.overnight:b.base):b.breadth;
    if(!finite(av)&&!finite(bv))return META[a.code].slot-META[b.code].slot;if(!finite(av))return 1;if(!finite(bv))return-1;return Math.abs(bv)-Math.abs(av);
  });
  $('#rankList').innerHTML=vals.map(c=>{
    let value;
    if(key==='coverage')value=overnight
      ?(finite(c.onN)&&finite(c.onD)?`${c.onN}/${c.onD}`:'—')
      :(finite(c.fresh)?`${Math.round(c.fresh*100)}%`:'—');
    else if(key==='fidelity')value=c.fid;
    else{const v=key==='base'?(overnight?c.overnight:c.base):c.breadth;value=`${key==='base'?(overnight?'overnight ':'snapshot '):''}${fmt(v,key==='breadth'?0:1)}${key==='breadth'?'':' bps'}`}
    return`<div class="rank-chip" style="--accent:${META[c.code].color}"><strong>${META[c.code].label}</strong><span>${value}</span></div>`;
  }).join('');
}

async function refresh(){
  const b=$('#refresh'),pill=$('#freshnessPill'),notice=$('#feedNotice');
  if(b.disabled)return;
  b.disabled=true;pill.disabled=true;b.textContent='Refreshing…';
  try{
    state.data=await load();render();
    if(notice){notice.dataset.error='0';age()}
  }catch(e){
    console.error(e);
    if(notice){
      notice.textContent=state.data?'Data could not be refreshed. The previous snapshot is still shown.':'Market data is unavailable right now. Try Refresh again.';
      notice.dataset.error='1';notice.hidden=false;
    }
    if(!state.data){
      $('#freshnessText').textContent='UNAVAILABLE';pill.className='status stale';
      $('#dataState').textContent='UNAVAILABLE';$('#stamp').textContent='No snapshot available';
      $('#session').textContent='SESSION —';$('#coverage').textContent='COVERAGE —';
      const placeholder=$('#gridEmpty');if(placeholder)placeholder.hidden=true;
      const board=document.querySelector('.board-wrap');if(board)board.hidden=true;
      $('#provider').textContent='Unavailable';$('#quoteState').textContent='UNAVAILABLE';
      $('#sourceLine').textContent='No public aggregate or last-known-good snapshot is available.';
    }
  }finally{b.disabled=false;pill.disabled=false;b.textContent='Refresh'}
}
function init(){
  restoreSlots();
  renderOvernightTrace();
  const guideLink=document.querySelector('a[href="#board-guide"]');
  if(guideLink)guideLink.addEventListener('click',()=>{const guide=$('#board-guide');if(guide)guide.open=true});
  $('#rankBy').onchange=()=>{if(state.data)renderRank()};
  $('#refresh').onclick=refresh;$('#freshnessPill').onclick=refresh;
  $('#headlineMedian').onclick=()=>{state.headline='median';render()};
  $('#headlineBreadth').onclick=()=>{state.headline='breadth';render()};
  $('#resetLayout').onclick=()=>{state.slots=defaultSlots();state.expanded=null;persistSlots();render()};
  $('#lockGrid').onclick=()=>setArrange(false);
  clearInterval(state.refreshTimer);
  state.refreshTimer=setInterval(()=>{
    if(document.visibilityState!=='hidden')refresh();
  },AUTO_REFRESH_MS);
  refresh();
}

window.PhiFinanceV2={init,refresh};
if(window.__CG_FINANCE_TEST__)window.PhiFinanceV2._test={
  recordOvernightTrace,renderOvernightTrace,readTraceSelection,getTrace:()=>state.overnightTrace,
  normV2,currentCell,normFuture,normOverlay,freshOvernight,deactivateOvernight,overlayPlateActive,cellValue,cellSubline,displayPressure,
  setData:d=>{state.data=d},setNow:()=>Date.now()
};
})();
