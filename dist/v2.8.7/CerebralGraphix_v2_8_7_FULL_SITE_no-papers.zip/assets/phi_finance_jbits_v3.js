import {ready,refreshCredits,subscribeCredits,formatCredits,recoveryCountdown,spend,award} from '/area-51/assets/credits-v2-0b3.js';

// Keep the existing storage key and aggregate fields: every Area 51 game uses
// lastValueCents to count finance holdings toward reserve recovery.
const STORE='cerebralgraphix.finance.positions.v1';
const STEP_CENTS=200;
const MAX_LIVE_POSITION_MS=12*60*60*1000;
let positions=load(),wallet=null,busy=false,markPending=false,queue=Promise.resolve();
const $=s=>document.querySelector(s);
const finite=v=>v!==''&&v!==null&&v!==undefined&&Number.isFinite(Number(v));
const uuid=()=>globalThis.crypto?.randomUUID?.()||('fin-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2));
const valueJbits=cents=>(Number(cents)/100).toFixed(4);
const copy=x=>JSON.parse(JSON.stringify(x));
const templates=new WeakMap();

function load(){try{const x=JSON.parse(localStorage.getItem(STORE)||'{}');return x&&typeof x==='object'&&!Array.isArray(x)?x:{}}catch{return {}}}
function save(next=positions){localStorage.setItem(STORE,JSON.stringify(next));positions=next;}
function lock(work){
  if(globalThis.navigator?.locks?.request)return navigator.locks.request(STORE,work);
  const run=queue.then(work,work);queue=run.catch(()=>{});return run;
}
function lotsOf(pos){
  if(Array.isArray(pos.lots)&&pos.lots.length)return pos.lots;
  const {lots,settlement,...legacy}=pos;return [legacy];
}
function selectedStakeCents(){
  const value=Number($('#financeStakeAmount')?.value||2);
  return Number.isFinite(value)?Math.min(1e11,Math.max(STEP_CENTS,Math.round(value/2)*STEP_CENTS)):STEP_CENTS;
}
function markLot(lot,tile,now=Date.now()){
  const raw=tile?.dataset.financeBps,rail=tile?.dataset.financeRail||'';
  const live=!!tile&&finite(raw)&&rail===lot.rail&&now-Number(lot.openedAt||0)<=MAX_LIVE_POSITION_MS;
  const deltaBps=live?Number(raw)-Number(lot.entryBps):Number(lot.lastDeltaBps||0);
  const valueCents=live?Math.max(0,Number(lot.stakeCents)*(1+deltaBps/10000)):Number(lot.lastValueCents??lot.stakeCents);
  return {...lot,lastBps:live?Number(raw):lot.lastBps,lastDeltaBps:deltaBps,lastValueCents:valueCents,live};
}
function currentMark(pos,tile){
  const lots=lotsOf(pos).map(lot=>markLot(lot,pos.settlement?null:tile));
  const stakeCents=lots.reduce((n,lot)=>n+Number(lot.stakeCents),0);
  const valueCents=lots.reduce((n,lot)=>n+Number(lot.lastValueCents),0);
  return {lots,stakeCents,valueCents,deltaBps:stakeCents?(valueCents/stakeCents-1)*10000:0,live:!pos.settlement&&lots.every(lot=>lot.live)};
}
function checkpoint(pos,mark){
  return {...pos,lots:mark.lots.map(({live,...lot})=>lot),stakeCents:mark.stakeCents,lastValueCents:mark.valueCents,lastDeltaBps:mark.deltaBps};
}
function setMessage(text,bad=false){const el=$('#financeJbitMessage');if(el){el.textContent=text||'';el.classList.toggle('bad',bad)}}
function renderBank(s=wallet){
  if(!s)return;wallet=s;
  if($('#financeJbitBalance'))$('#financeJbitBalance').textContent=s.ready?formatCredits(s.balanceCents):'—';
  if($('#financeJbitClock'))$('#financeJbitClock').textContent=s.ready?recoveryCountdown(s):'Opening bank…';
  renderPositions();scheduleMarks();
}
function bindButton(btn,handler){
  if(!btn||btn.dataset.bound)return;btn.dataset.bound='1';
  for(const name of ['pointerdown','pointerup','click','keydown','keyup'])btn.addEventListener(name,e=>e.stopPropagation());
  btn.addEventListener('click',e=>{e.preventDefault();handler().catch(err=>setMessage(err?.message||String(err),true))});
}
function renderPositions(){
  if(!busy)positions=load();
  const stakeCents=selectedStakeCents(),stakeLabel=formatCredits(stakeCents);
  for(const tile of document.querySelectorAll('#phiGrid .cell')){
    const code=tile.dataset.code,slot=tile.querySelector('[data-finance-position-slot]');if(!code||!slot)continue;
    const pos=positions[code],mark=pos?currentMark(pos,tile):null;
    const canStake=finite(tile.dataset.financeBps)&&!busy&&wallet?.ready&&Number(wallet.balanceCents)>=stakeCents&&(!pos||mark.live);
    const addButton=`<button class="finance-stake" type="button" ${canStake?'':'disabled'}>${pos?'Add':'Back'} ${stakeLabel} jb</button>`;
    let badge=tile.querySelector('.finance-position-badge'),html;
    if(!pos){
      badge?.remove();tile.classList.remove('has-finance-position');delete tile.dataset.financePosition;
      html=addButton+`<span class="finance-position-note">${!finite(tile.dataset.financeBps)?'Waiting for a reading':wallet?.ready&&Number(wallet.balanceCents)<stakeCents?'Need more jbits':'Repeat to add more'}</span>`;
    }else{
      tile.classList.add('has-finance-position');tile.dataset.financePosition=`${valueJbits(mark.valueCents)} jb`;
      if(!badge){badge=document.createElement('span');badge.className='finance-position-badge';tile.querySelector('.cell-top')?.appendChild(badge)}
      badge.textContent=tile.dataset.financePosition;
      html=`<span class="finance-mark"><b>${valueJbits(mark.valueCents)} jb</b><small>${formatCredits(mark.stakeCents)} backed · ${mark.lots.length} ${mark.lots.length===1?'entry':'entries'} · ${mark.live?'each from its entry BPS':pos.settlement?'exit pending':'last mark · exit to restart'}</small></span>${addButton}<button class="finance-exit" type="button" ${busy?'disabled':''}>${pos.settlement?'Finish exit':'Exit all'}</button>`;
    }
    // Keep focused controls in the DOM on unchanged one-second bank refreshes.
    if(templates.get(slot)!==html){
      slot.innerHTML=html;templates.set(slot,html);
      bindButton(slot.querySelector('.finance-stake'),()=>openPosition(code));
      bindButton(slot.querySelector('.finance-exit'),()=>exitPosition(code));
    }
  }
}
function tileFor(code){return [...document.querySelectorAll('#phiGrid .cell')].find(t=>t.dataset.code===code)}
function scheduleMarks(){
  if(busy||markPending)return;markPending=true;
  queueMicrotask(()=>lock(async()=>{
    if(busy)return;
    const next=load();let changed=false;
    for(const [code,pos] of Object.entries(next)){
      const mark=currentMark(pos,tileFor(code));
      const updated=checkpoint(pos,mark);
      if(JSON.stringify(updated)!==JSON.stringify(pos)){next[code]=updated;changed=true}
    }
    if(changed)save(next);
  }).catch(()=>setMessage('This browser could not save the latest position marks.',true)).finally(()=>{markPending=false}));
}
async function operation(work){
  if(busy)return;busy=true;renderPositions();
  try{await lock(async()=>{positions=load();await work()})}
  finally{busy=false;positions=load();renderBank();}
}
async function openPosition(code){
  return operation(async()=>{
    const tile=tileFor(code),raw=tile?.dataset.financeBps;
    if(!tile||!finite(raw))throw Error('This tile has no current BPS reading to enter.');
    const bps=Number(raw),rail=tile.dataset.financeRail||'base',stakeCents=selectedStakeCents();
    const previous=positions[code],mark=previous?currentMark(previous,tile):null;
    if(previous&&!mark.live)throw Error('Exit the saved position before backing this new reading.');
    const before=copy(positions),id=uuid(),at=Date.now();
    const lot={id,sectorCode:code,stakeCents,entryBps:bps,rail,openedAt:at,sourceAt:tile.dataset.financeGenerated||'',lastBps:bps,lastDeltaBps:0,lastValueCents:stakeCents};
    // Check storage before debit; unchanged write has no economic effect.
    save(before);
    const tx=await spend({id:`finance:stake:${id}`,source:'finance-weather',kind:previous?'tile-add':'tile-stake',amountCents:stakeCents,evidence:{sectorCode:code,entryBps:bps,rail,sourceAt:lot.sourceAt}});
    const next=previous?checkpoint(previous,mark):{id,sectorCode:code,label:tile.dataset.financeLabel||code,rail,openedAt:at,lots:[]};
    next.lots.push(lot);next.stakeCents=(mark?.stakeCents||0)+stakeCents;next.lastValueCents=(mark?.valueCents||0)+stakeCents;
    next.lastDeltaBps=(next.lastValueCents/next.stakeCents-1)*10000;
    try{save({...before,[code]:next})}
    catch{
      positions=before;
      const refund=await award({id:`finance:stake-refund:${id}`,source:'finance-weather',kind:'tile-stake-refund',amountCents:stakeCents,evidence:{sectorCode:code,reason:'position-storage-failed'}});
      wallet=refund.snapshot;throw Error('The addition could not be saved. Its jbits were returned.');
    }
    wallet=tx.snapshot;
    setMessage(`${tile.dataset.financeLabel||code}: ${formatCredits(stakeCents)} jbits ${previous?'added':'backed'} at ${bps>=0?'+':''}${bps.toFixed(1)} bps. ${formatCredits(next.stakeCents)} jbits backed across ${next.lots.length} ${next.lots.length===1?'entry':'entries'}.`);
  });
}
async function exitPosition(code){
  return operation(async()=>{
    let pos=positions[code];if(!pos)return;
    if(!pos.settlement){
      const mark=currentMark(pos,tileFor(code));pos=checkpoint(pos,mark);
      pos.settlement={payout:Math.max(0,Math.round(mark.valueCents)),evidence:{sectorCode:code,stakeCents:mark.stakeCents,markedValueCents:mark.valueCents,lots:pos.lots}};
      save({...positions,[code]:pos});
    }
    const tx=await award({id:`finance:exit:${pos.id}`,source:'finance-weather',kind:'tile-exit',amountCents:pos.settlement.payout,evidence:pos.settlement.evidence});
    wallet=tx.snapshot;
    const next={...positions};delete next[code];
    // A failed clear leaves a frozen settlement. Retry uses the same receipt,
    // preventing both a second payout and additions to an already paid position.
    try{save(next)}catch{throw Error('The exit was paid. Choose Finish exit to clear the saved tile.');}
    setMessage(`${pos.label||code}: ${valueJbits(pos.settlement.payout)} jbits returned; all entries cleared.`);
  });
}

subscribeCredits(renderBank);
ready.then(renderBank).catch(e=>setMessage(e.message||String(e),true));
setInterval(()=>refreshCredits().catch(()=>{}),1000);
const stakeInput=$('#financeStakeAmount');
if(stakeInput){stakeInput.addEventListener('change',()=>{stakeInput.value=String(selectedStakeCents()/100);renderPositions()});stakeInput.addEventListener('input',renderPositions)}
const grid=$('#phiGrid');
if(grid)new MutationObserver(()=>{renderPositions();scheduleMarks()}).observe(grid,{childList:true});
addEventListener('storage',e=>{if(e.key===STORE){renderPositions();scheduleMarks()}});
renderPositions();
if(window.__CG_FINANCE_TEST__)window.PhiFinanceJbitsTest={currentMark,selectedStakeCents,openPosition,exitPosition,renderPositions};
