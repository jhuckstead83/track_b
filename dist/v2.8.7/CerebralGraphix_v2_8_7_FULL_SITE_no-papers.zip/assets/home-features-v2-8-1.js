(() => {
 'use strict';
 const track=document.getElementById('home-feature-track');if(!track)return;
 const carousel=track.closest('.home-feature-carousel'),cards=[...track.querySelectorAll('[data-feature]')];
 const toggle=document.getElementById('feature-pause'),media=matchMedia('(prefers-reduced-motion: reduce)');
 let index=0,timer,scrollTimer,paused=media.matches,engaged=false,touching=false,programmatic=false;
 function describe(){
   for(const [i,c]of cards.entries()){c.inert=i!==index;c.setAttribute('aria-hidden',String(i!==index));}
   toggle.hidden=!engaged;
   toggle.setAttribute('aria-label',paused?'Play hero carousel':'Pause hero carousel');
   toggle.title=paused?'Play':'Pause';
   toggle.querySelector('[data-play-icon]').hidden=!paused;
   toggle.querySelector('[data-pause-icon]').hidden=paused;
   track.setAttribute('aria-live',paused?'polite':'off');
 }
 function schedule(){clearTimeout(timer);if(!paused&&!touching&&!document.hidden&&cards.length>1)timer=setTimeout(()=>show(index+1),6000);}
 function engage(){engaged=true;paused=true;describe();schedule();}
 function show(next){programmatic=true;index=(next+cards.length)%cards.length;describe();track.scrollTo({left:index*track.clientWidth,behavior:media.matches?'auto':'smooth'});schedule();}
 document.getElementById('feature-prev').onclick=()=>{engage();show(index-1);};
 document.getElementById('feature-next').onclick=()=>{engage();show(index+1);};
 toggle.onclick=()=>{engaged=true;paused=!paused;describe();schedule();};
 // Engagement pauses once; explicit Play resumes even while the pointer remains
 // over the control. Leaving the carousel never silently undoes a manual pause.
 carousel.addEventListener('mouseenter',engage);
 carousel.addEventListener('focusin',e=>{if(e.target!==toggle||!carousel.contains(e.relatedTarget))engage();});
 carousel.addEventListener('pointerdown',e=>{touching=true;if(!toggle.contains(e.target))engage();schedule();});
 function release(){if(!touching)return;touching=false;schedule();}
 addEventListener('pointerup',release);addEventListener('pointercancel',release);
 // Native scroll-snap retains swipe behavior. A manual swipe also pauses.
 track.addEventListener('scroll',()=>{clearTimeout(scrollTimer);scrollTimer=setTimeout(()=>{
   index=Math.max(0,Math.min(cards.length-1,Math.round(track.scrollLeft/Math.max(1,track.clientWidth))));
   if(programmatic)programmatic=false;else engage();describe();
 },160);},{passive:true});
 carousel.addEventListener('keydown',e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();engage();show(index+(e.key==='ArrowRight'?1:-1));}});
 document.addEventListener('visibilitychange',schedule);
 media.addEventListener('change',()=>{if(media.matches)paused=true;describe();schedule();});
 addEventListener('resize',()=>{programmatic=true;track.scrollTo({left:index*track.clientWidth,behavior:'instant'});});
 describe();schedule();
})();
