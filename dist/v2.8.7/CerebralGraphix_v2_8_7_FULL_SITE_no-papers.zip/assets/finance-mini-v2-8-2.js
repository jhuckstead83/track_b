/* One feed per page; read-only tiles and an optional movable monitor. */
(() => {
 'use strict';
 const model=window.FinanceMiniModel;if(!model)return;
 const CACHE='cg_phi_weather_v2',PREF='cg_finance_monitor_v1';
 const FEED='https://live.cerebralgraphix.com/finance/latest/weather_v2.json';
 const REFERENCE='https://docs.google.com/spreadsheets/d/1d34G7-JIusLnSB6_Ujt4xieVnJDFxyRcfgZZfF3sC5Y/gviz/tq?tqx=out:csv&sheet=Summary&range=A1:C23';
 const REF_CACHE='cg_phi_reference_v1';let reference=null,referenceLoading=false,referenceTimer;
 let raw=null,connected=false,loading=false,expanded=false,manual=false,dock,restore,dialog,pref={hidden:false,pinned:false,x:1,y:1};
 let lastProjection,fetchTimer;
 const hosts=[...document.querySelectorAll('[data-finance-mini]')];
 const hasDock=document.body.hasAttribute('data-finance-dock');
 function readCache(){try{const d=JSON.parse(localStorage.getItem(CACHE)||'null');return d?model.validate(d):null;}catch{return null;}}
 function readPref(){try{const value=document.cookie.split('; ').find(s=>s.startsWith(PREF+'='));if(value){const p=JSON.parse(decodeURIComponent(value.slice(PREF.length+1)));pref={hidden:p.hidden===true,pinned:p.pinned===true,x:Number.isFinite(p.x)?Math.max(0,Math.min(1,p.x)):1,y:Number.isFinite(p.y)?Math.max(0,Math.min(1,p.y)):1};}}catch{}}
 function savePref(){try{document.cookie=PREF+'='+encodeURIComponent(JSON.stringify(pref))+'; Path=/; Max-Age=31536000; SameSite=Lax'+(location.protocol==='https:'?'; Secure':'');}catch{}}
 function prepare(host){
   host.innerHTML='<div class="finance-mini-grid" aria-label="Sector readings in basis points">'+model.CODES.map(code=>{
     const m=model.META[code];return '<div class="finance-mini-cell" data-sector="'+code+'" style="--sector:'+m.color+'"><span class="finance-mini-sector">'+m.label+'</span><span class="finance-mini-value">—</span><span class="finance-mini-unit">bps</span></div>';
   }).join('')+'</div><div class="finance-mini-caption"><span data-mini-state>Waiting for readings</span><time data-mini-time></time></div>';
 }
 function timeLabel(value){const t=Date.parse(value);return Number.isFinite(t)?new Intl.DateTimeFormat(undefined,{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit',timeZoneName:'short'}).format(t):'';}
 function position(){
   if(!dock||dock.hidden)return;
   const rect=dock.getBoundingClientRect(),maxX=Math.max(8,innerWidth-rect.width-8),maxY=Math.max(8,innerHeight-rect.height-8);
   dock.style.left=(8+pref.x*Math.max(0,maxX-8))+'px';dock.style.top=(8+pref.y*Math.max(0,maxY-8))+'px';
 }
 function moveTo(x,y){
   const r=dock.getBoundingClientRect(),maxX=Math.max(8,innerWidth-r.width-8),maxY=Math.max(8,innerHeight-r.height-8);
   const left=Math.max(8,Math.min(maxX,x)),top=Math.max(8,Math.min(maxY,y));
   pref.x=(left-8)/Math.max(1,maxX-8);pref.y=(top-8)/Math.max(1,maxY-8);
   dock.style.left=left+'px';dock.style.top=top+'px';
 }
 function showPanel(value,{retainTab=true}={}){
   const before=dock.hidden?null:dock.getBoundingClientRect();
   if(retainTab){manual=true;pref.pinned=true;}
   expanded=value;dock.classList.toggle('expanded',value);
   dock.querySelector('.finance-dock-toggle').setAttribute('aria-expanded',String(value));
   dock.querySelector('.finance-dock-toggle').setAttribute('aria-label',value?'Collapse Finance grid':'Show Finance grid');
   dock.querySelector('.finance-dock-fold').inert=!value;
   render();
   if(before&&!dock.hidden)moveTo(before.right-dock.getBoundingClientRect().width,before.top);else position();
   if(retainTab)savePref();
 }
 function render(){
   const p=lastProjection=model.project(document.body.hasAttribute('data-finance-reference-only')?null:raw,window.PhiWeatherEngine,Date.now(),connected,reference);
   const labels={live:p.weather?'Live weather':'Current median',fading:p.referenceDate?'Fading to Google · '+p.referenceDate:'Fading · last observations',rest:'At rest',recorded:'Recorded reading · offline',reference:'Recorded median · Google',waiting:'Waiting for readings'};
   for(const host of hosts){
     host.dataset.feedState=p.kind;
     for(const c of p.cells){const cell=host.querySelector('[data-sector="'+c.code+'"]');cell.querySelector('.finance-mini-value').textContent=model.format(c.value);cell.setAttribute('aria-label',c.label+': '+model.format(c.value)+' basis points');}
     host.querySelector('[data-mini-state]').textContent=labels[p.kind];
     const time=host.querySelector('[data-mini-time]');time.textContent=p.kind==='reference'?new Intl.DateTimeFormat(undefined,{month:'short',day:'numeric',year:'numeric',timeZone:'UTC'}).format(new Date(p.observed)):timeLabel(p.observed);if(p.observed)time.dateTime=p.observed;else time.removeAttribute('datetime');
   }
   if(dock){
     const wasHidden=dock.hidden;dock.hidden=pref.hidden||(!p.active&&!expanded&&!manual&&!pref.pinned);
     dock.classList.toggle('is-active',p.active);dock.dataset.feedState=p.kind;
     dock.querySelector('.finance-dock-label').textContent=p.active?'Finance · active':p.kind==='rest'?'Finance · at rest':'Finance · '+(p.kind==='reference'?'reference':p.kind==='recorded'?'recorded':p.kind==='fading'?'fading':'waiting');
     if(wasHidden&&!dock.hidden)position();
     restore.textContent=pref.hidden?'Restore Finance monitor':'Finance monitor';
   }
 }
 async function refresh(){
   clearTimeout(fetchTimer);if(loading)return;
   if(document.hidden){fetchTimer=setTimeout(refresh,30000);return;}
   loading=true;const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),8000);
   try{
     const response=await fetch(FEED+'?t='+Date.now(),{cache:'no-store',signal:controller.signal});
     if(!response.ok)throw Error('Finance feed unavailable');
     const next=model.validate(await response.json());if(!model.newer(next,raw))throw Error('Older response');
     raw=next;connected=true;try{localStorage.setItem(CACHE,JSON.stringify(raw));}catch{}
   }catch{connected=false;}
   finally{clearTimeout(timeout);loading=false;render();fetchTimer=setTimeout(refresh,30000);}
 }
 async function refreshReference(){
   clearTimeout(referenceTimer);if(referenceLoading)return;
   if(document.hidden){referenceTimer=setTimeout(refreshReference,300000);return;}
   referenceLoading=true;const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),10000);
   try{
     const response=await fetch(REFERENCE,{cache:'no-store',credentials:'omit',signal:controller.signal});
     if(!response.ok)throw Error('Reference unavailable');
     const next=model.parseReferenceCSV(await response.text());
     if(!reference||next.quote_date>=reference.quote_date){reference=next;try{localStorage.setItem(REF_CACHE,JSON.stringify(next));}catch{}document.dispatchEvent(new CustomEvent('finance-reference-update'));}
   }catch{/* Retain the labelled, dated reference. Never report this as live. */}
   finally{clearTimeout(timeout);referenceLoading=false;render();referenceTimer=setTimeout(refreshReference,300000);}
 }
 function setupDock(){
   readPref();dock=document.createElement('aside');dock.className='finance-dock';dock.hidden=true;dock.setAttribute('aria-label','Finance activity monitor');
   dock.innerHTML='<div class="finance-dock-bar"><button type="button" class="finance-dock-handle" aria-label="Move Finance monitor. Drag this tab or use arrow keys." title="Drag Finance tab to move"><i aria-hidden="true"></i><span class="finance-dock-label">Finance</span></button><button type="button" class="finance-dock-toggle" aria-label="Show Finance grid" aria-expanded="false" aria-controls="finance-dock-panel"><svg class="finance-dock-chevron" viewBox="0 0 24 24" aria-hidden="true"><path d="m5 8 7 8 7-8"/></svg></button><button type="button" class="finance-dock-hide" aria-label="Hide Finance monitor" title="Hide monitor"><span aria-hidden="true">×</span></button></div><div class="finance-dock-fold" inert><div class="finance-dock-clip"><div id="finance-dock-panel" class="finance-dock-panel"><div data-finance-mini></div><a class="finance-dock-open" href="/finance/live.html">Open Finance ↗</a></div></div></div>';
   document.body.appendChild(dock);const host=dock.querySelector('[data-finance-mini]');hosts.push(host);
   restore=document.createElement('button');restore.type='button';restore.className='finance-monitor-settings';restore.textContent='Finance monitor';
   (document.querySelector('footer')||document.body).appendChild(restore);
   dialog=document.createElement('dialog');dialog.className='finance-hide-dialog';dialog.setAttribute('aria-labelledby','finance-hide-title');
   dialog.innerHTML='<h2 id="finance-hide-title">Hide the Finance monitor?</h2><p>Remember this choice on this browser. You can restore it using “Finance monitor” at the bottom of the page.</p><div><button type="button" data-hide-cancel>Keep it</button><button type="button" data-hide-confirm>Yes, hide</button></div>';
   document.body.appendChild(dialog);
   dock.querySelector('.finance-dock-toggle').onclick=()=>showPanel(!expanded);
   dock.querySelector('.finance-dock-hide').onclick=()=>dialog.showModal();
   dialog.querySelector('[data-hide-cancel]').onclick=()=>dialog.close();
   dialog.querySelector('[data-hide-confirm]').onclick=()=>{pref.hidden=true;pref.pinned=false;savePref();dialog.close();manual=false;showPanel(false,{retainTab:false});restore.focus({preventScroll:true});};
   restore.onclick=()=>{pref.hidden=false;manual=true;savePref();showPanel(true);dock.querySelector('.finance-dock-toggle').focus({preventScroll:true});};
   let gesture=null;
   const handle=dock.querySelector('.finance-dock-handle');
   // The label alone moves the tab. Chevron and X have separate click targets.
   handle.addEventListener('pointerdown',e=>{
     if(e.button!==0||e.isPrimary===false||gesture)return;
     e.stopPropagation();
     const r=dock.getBoundingClientRect();gesture={id:e.pointerId,x:e.clientX,y:e.clientY,left:r.left,top:r.top,drag:false};
     handle.setPointerCapture(e.pointerId);
   });
   handle.addEventListener('pointermove',e=>{
     if(!gesture||e.pointerId!==gesture.id)return;
     const dx=e.clientX-gesture.x,dy=e.clientY-gesture.y;
     if(!gesture.drag&&Math.hypot(dx,dy)<4)return;
     gesture.drag=true;dock.classList.add('dragging');e.preventDefault();e.stopPropagation();
     moveTo(gesture.left+dx,gesture.top+dy);
   });
   function endDrag(){
     const g=gesture;gesture=null;
     if(g?.drag){manual=true;pref.pinned=true;savePref();}
     if(g&&handle.hasPointerCapture(g.id))handle.releasePointerCapture(g.id);
     dock.classList.remove('dragging');
   }
   handle.addEventListener('pointerup',endDrag);handle.addEventListener('pointercancel',endDrag);handle.addEventListener('lostpointercapture',endDrag);
   handle.addEventListener('click',e=>e.stopPropagation());
   handle.addEventListener('keydown',e=>{
     const d={ArrowLeft:[-16,0],ArrowRight:[16,0],ArrowUp:[0,-16],ArrowDown:[0,16]}[e.key];if(!d)return;
     e.preventDefault();e.stopPropagation();const r=dock.getBoundingClientRect();moveTo(r.left+d[0],r.top+d[1]);manual=true;pref.pinned=true;savePref();
   });
   dock.querySelector('.finance-dock-fold').addEventListener('transitionend',position);
   new ResizeObserver(position).observe(dock);addEventListener('resize',position);
 }
 if(hasDock)setupDock();if(!hosts.length)return;
 hosts.forEach(prepare);raw=readCache();
 try{reference=model.validateReference(window.FinanceReferenceSeed);}catch{}
 try{const saved=model.validateReference(JSON.parse(localStorage.getItem(REF_CACHE)||'null'));if(!reference||saved.quote_date>=reference.quote_date)reference=saved;}catch{}
 window.FinanceReference=Object.freeze({get:()=>reference,refresh:refreshReference});
 render();if(!document.body.hasAttribute('data-finance-reference-only'))refresh();refreshReference();
 setInterval(()=>{if(!document.hidden)render();},1000);
 addEventListener('storage',e=>{if(e.key!==CACHE)return;const next=readCache();if(next&&model.newer(next,raw)){raw=next;render();}});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden){render();if(!document.body.hasAttribute('data-finance-reference-only'))refresh();refreshReference();}});
})();
