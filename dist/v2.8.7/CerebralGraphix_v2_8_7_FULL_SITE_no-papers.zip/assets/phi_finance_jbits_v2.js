import {ready,refreshCredits,subscribeCredits,formatCredits,recoveryCountdown,spend,award} from '/area-51/assets/credits-v2-0b3.js';

const STORE='cerebralgraphix.finance.positions.v1';
const MIN_STAKE_CENTS=200;
const MAX_LIVE_POSITION_MS=12*60*60*1000;
let positions=load();
let wallet=null;
let busy=false;
const $=s=>document.querySelector(s);
const finite=v=>v!==''&&v!==null&&v!==undefined&&Number.isFinite(Number(v));
const uuid=()=>globalThis.crypto?.randomUUID?.()||('fin-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2));

function load(){try{const x=JSON.parse(localStorage.getItem(STORE)||'{}');return x&&typeof x==='object'&&!Array.isArray(x)?x:{}}catch{return {}}}
function save(){try{localStorage.setItem(STORE,JSON.stringify(positions));return true}catch{return false}}
function valueJbits(cents){return (Number(cents)/100).toFixed(4)}
function selectedStakeCents(){const input=$('#financeStakeAmount');const n=Number(input?.value||2);if(!Number.isFinite(n))return MIN_STAKE_CENTS;return Math.max(MIN_STAKE_CENTS,Math.round(n*100))}
function currentMark(pos,tile){
  if(!tile)return {valueCents:Number(pos.lastValueCents??pos.stakeCents),deltaBps:Number(pos.lastDeltaBps||0),live:false};
  const bps=Number(tile.dataset.financeBps),rail=tile.dataset.financeRail||'';
  if(Date.now()-Number(pos.openedAt||0)>MAX_LIVE_POSITION_MS||!Number.isFinite(bps)||rail!==pos.rail)return {valueCents:Number(pos.lastValueCents??pos.stakeCents),deltaBps:Number(pos.lastDeltaBps||0),live:false};
  const delta=bps-Number(pos.entryBps),value=Math.max(0,Number(pos.stakeCents)*(1+delta/10000));
  pos.lastBps=bps;pos.lastDeltaBps=delta;pos.lastValueCents=value;pos.lastMarkedAt=Date.now();
  return {valueCents:value,deltaBps:delta,live:true};
}
function setMessage(text,bad=false){const el=$('#financeJbitMessage');if(!el)return;el.textContent=text||'';el.classList.toggle('bad',!!bad)}
function renderBank(s=wallet){if(!s)return;wallet=s;const bal=$('#financeJbitBalance'),clock=$('#financeJbitClock');if(bal)bal.textContent=s.ready?formatCredits(s.balanceCents):'—';if(clock)clock.textContent=s.ready?recoveryCountdown(s):'Opening bank…';renderPositions()}
function bindButton(btn,handler){if(btn.dataset.bound)return;btn.dataset.bound='1';for(const name of ['pointerdown','pointerup','click'])btn.addEventListener(name,e=>e.stopPropagation());btn.addEventListener('click',e=>{e.preventDefault();handler().catch(err=>setMessage(err?.message||String(err),true))})}
function renderPositions(){
  let changed=false;
  for(const tile of document.querySelectorAll('#phiGrid .cell')){
    const code=tile.dataset.code,slot=tile.querySelector('[data-finance-position-slot]');if(!code||!slot)continue;
    const bps=Number(tile.dataset.financeBps),rail=tile.dataset.financeRail||'base',pos=positions[code];
    let badge=tile.querySelector('.finance-position-badge');
    if(!pos){if(badge)badge.remove();tile.classList.remove('has-finance-position');delete tile.dataset.financePosition;

      const stakeCents=selectedStakeCents(),canStake=finite(bps)&&!busy&&wallet?.ready&&Number(wallet.balanceCents)>=stakeCents;
      slot.innerHTML=`<button class="finance-stake" type="button" ${canStake?'':'disabled'}>Back tile</button><span class="finance-position-note">${valueJbits(stakeCents)} jb selected${wallet?.ready&&Number(wallet.balanceCents)<stakeCents?' · need more jbits':''}</span>`;
      const btn=slot.querySelector('.finance-stake');bindButton(btn,()=>openPosition(tile));continue;
    }
    const mark=currentMark(pos,tile);changed=changed||mark.live;
    tile.classList.add('has-finance-position');tile.dataset.financePosition=`${valueJbits(mark.valueCents)} jb`;
    if(!badge){badge=document.createElement('span');badge.className='finance-position-badge';tile.querySelector('.cell-top')?.appendChild(badge)}if(badge)badge.textContent=tile.dataset.financePosition;
    const sign=mark.deltaBps>=0?'+':'';
    slot.innerHTML=`<span class="finance-mark"><b>${valueJbits(mark.valueCents)} jb</b><small>${mark.live?`${sign}${mark.deltaBps.toFixed(1)} bps since entry`:'rail changed · last mark'}</small></span><button class="finance-exit" type="button" ${busy?'disabled':''}>Exit & clear</button>`;
    bindButton(slot.querySelector('.finance-exit'),()=>exitPosition(code,tile));
  }
  if(changed)save();
}
async function openPosition(tile){
  if(busy)return;const code=tile.dataset.code,bps=Number(tile.dataset.financeBps),rail=tile.dataset.financeRail||'base',stakeCents=selectedStakeCents();
  if(!code||!Number.isFinite(bps))throw Error('This tile has no current BPS reading to enter.');
  if(stakeCents<MIN_STAKE_CENTS)throw Error('Finance positions require at least 2 jbits.');
  if(positions[code])return;busy=true;renderPositions();
  const id=uuid();
  try{
    const tx=await spend({id:`finance:stake:${id}`,source:'finance-weather',kind:'tile-stake',amountCents:stakeCents,evidence:{sectorCode:code,label:tile.dataset.financeLabel||code,entryBps:bps,rail,sourceAt:tile.dataset.financeGenerated||''}});
    positions[code]={id,sectorCode:code,label:tile.dataset.financeLabel||code,stakeCents,entryBps:bps,rail,openedAt:Date.now(),sourceAt:tile.dataset.financeGenerated||'',lastBps:bps,lastDeltaBps:0,lastValueCents:stakeCents,lastMarkedAt:Date.now()};
    if(!save()){
      delete positions[code];
      await award({id:`finance:stake-refund:${id}`,source:'finance-weather',kind:'tile-stake-refund',amountCents:stakeCents,evidence:{sectorCode:code,reason:'position-storage-failed'}});
      throw Error(`The browser could not save the finance position. ${valueJbits(stakeCents)} jbits were returned.`);
    }
    wallet=tx.snapshot;renderBank();setMessage(`${tile.dataset.financeLabel||code}: ${valueJbits(stakeCents)} jbits entered at ${bps>=0?'+':''}${bps.toFixed(1)} bps.`);
  }finally{busy=false;renderPositions()}
}
async function exitPosition(code,tile){
  if(busy)return;const pos=positions[code];if(!pos)return;busy=true;renderPositions();
  try{
    const mark=currentMark(pos,tile),payout=Math.max(0,Math.round(mark.valueCents));
    const tx=await award({id:`finance:exit:${pos.id}`,source:'finance-weather',kind:'tile-exit',amountCents:payout,evidence:{sectorCode:code,stakeCents:pos.stakeCents,entryBps:pos.entryBps,exitBps:mark.live?Number(tile.dataset.financeBps):pos.lastBps,deltaBps:mark.deltaBps,rail:pos.rail,markedValueCents:mark.valueCents,settledCents:payout}});
    delete positions[code];save();wallet=tx.snapshot;renderBank();setMessage(`${pos.label||code}: exited at ${valueJbits(payout)} jbits; tile BPS position cleared.`);
  }finally{busy=false;renderPositions()}
}

subscribeCredits(renderBank);
ready.then(renderBank).catch(e=>setMessage(e.message||String(e),true));
setInterval(()=>refreshCredits().catch(()=>{}),1000);
const stakeInput=$('#financeStakeAmount');if(stakeInput){stakeInput.addEventListener('change',()=>{const cents=selectedStakeCents();stakeInput.value=(cents/100).toFixed(cents%100?2:0);renderPositions()});stakeInput.addEventListener('input',renderPositions);}
const grid=$('#phiGrid');if(grid){new MutationObserver(renderPositions).observe(grid,{childList:true});}
renderPositions();
