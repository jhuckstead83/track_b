/* Finance Weather v2.1: game-credit payout, independent of browser weather. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.PhiJbitTower=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const CURVE='sqrt2-tower-v1',STEP_BPS=1,levels=[1];
  const finite=x=>x!==null&&x!==''&&x!==undefined&&Number.isFinite(Number(x));
  // Beyond 128 iterations the difference from 2 is below double precision.
  function tower(height){
    if(!Number.isFinite(height))return height===Infinity?2:1;
    const h=Math.max(0,height);if(h>=128)return 2;
    const n=Math.floor(h),fraction=h-n;
    while(levels.length<=n+1)levels.push(Math.min(2,Math.pow(Math.SQRT2,levels.at(-1))));
    return levels[n]+fraction*(levels[n+1]-levels[n]);
  }
  function multiplier(signalBps,anchor=1){
    const a=Math.max(0,Number(anchor)),progress=tower(Math.abs(signalBps)/STEP_BPS)-1;
    // Old marks above 2x are grandfathered with no additional upside.
    return signalBps>=0?a+Math.max(0,2-a)*progress:a*(1-progress);
  }
  function mark(lot,reading){
    const stake=Number(lot.stakeCents),old=Number(lot.lastValueCents??stake);
    const live=!!reading?.live&&finite(reading.index)&&Number(reading.index)>0;
    if(!(stake>0)||!Number.isFinite(old))return {...lot,live:false};
    if(lot.payoutCurve!==CURVE){
      // Adopt the current stream as a fresh origin. Never reprice old movement.
      return {...lot,model:'v2',payoutCurve:CURVE,payoutAnchor:Math.max(0,old/stake),
        payoutReturnFactor:1,signalBps:0,lastValueCents:old,
        lastDeltaBps:(old/stake-1)*10000,
        streamIndex:live?Number(reading.index):null,streamEpoch:live?reading.epoch:null,live};
    }
    let factor=finite(lot.payoutReturnFactor)?Math.max(0,Number(lot.payoutReturnFactor)):1;
    if(live&&lot.streamEpoch===reading.epoch&&finite(lot.streamIndex)&&Number(lot.streamIndex)>0){
      factor*=Number(reading.index)/Number(lot.streamIndex);
    }
    const signalBps=(factor-1)*10000;
    const value=stake*multiplier(signalBps,finite(lot.payoutAnchor)?Number(lot.payoutAnchor):1);
    return {...lot,model:'v2',payoutReturnFactor:factor,signalBps,
      lastValueCents:value,lastDeltaBps:(value/stake-1)*10000,
      streamIndex:live?Number(reading.index):lot.streamIndex,
      streamEpoch:live?reading.epoch:lot.streamEpoch,live};
  }
  function entry(){return {payoutCurve:CURVE,payoutAnchor:1,payoutReturnFactor:1,signalBps:0}}
  return Object.freeze({CURVE,STEP_BPS,tower,multiplier,mark,entry});
});
