/* Finance Weather 2.1: pure UTC-age display engine. No network or wallet writes. */
(function(root){
  'use strict';
  const finite=v=>typeof v==='number'&&Number.isFinite(v);
  function weight(age,p){
    if(!finite(age)||age < -2||!p||![p.grace_seconds,p.half_life_seconds,p.horizon_seconds].every(finite)||p.half_life_seconds<=0||p.grace_seconds<0||p.horizon_seconds<=p.grace_seconds)return 0;
    const elapsed=Math.max(0,age-p.grace_seconds), horizon=p.horizon_seconds-p.grace_seconds;
    if(elapsed>=horizon)return 0;
    const floor=2**(-horizon/p.half_life_seconds);
    return Math.max(0,Math.min(1,(2**(-elapsed/p.half_life_seconds)-floor)/(1-floor)));
  }
  function evaluate(cohorts,expected,now=Date.now()){
    let total=0,effective=0,known=0,latest=null;const sources={};
    if(!Array.isArray(cohorts)||!Number.isInteger(expected)||expected<=0||!finite(now))return {bps:null,effective:0,known:0,weightedMean:null,sources:{}};
    for(const c of cohorts){
      const at=Date.parse(c.at),quality=c.quality_weight;
      if(!finite(at)||!finite(c.sum_bps)||!Number.isInteger(c.count)||c.count<=0||known+c.count>expected||!finite(quality)||quality<0||quality>1)continue;
      const w=weight((now-at)/1000,c.decay)*quality;
      known+=c.count;effective+=w*c.count;total+=w*c.sum_bps;
      latest=latest===null?at:Math.max(latest,at);
      if(w>0)sources[c.source]=(sources[c.source]||0)+w*c.count;
    }
    return {bps:known?total/expected:null,effective,known,weightedMean:effective?total/effective:null,sources,latest};
  }
  const api=Object.freeze({version:'2.1.0',weight,evaluate});
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  else root.PhiWeatherEngine=api;
})(typeof window!=='undefined'?window:this);
