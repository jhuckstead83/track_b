# The Grain — threshed kernel of the cardinal-cube seed
**No claims. Ethos scrubbed, no mythos imported. This is the part that survived the threshing — store the grain, not the harvest.**
Cerebral Graphix (Jeffery Huckstead). The figures (six-cone build, deltas) are harvests; this is the seed grain they grow from. Toil it freely.

---

## What this is, exactly
A small set of **mutually-implied** exact relations on one cube, with **no floor** (no relation comes first; each implies the others through the kiss). It does not assert a mechanism. It **rations**: it portions every length it can into clean fractions, and leaves the three irrationals standing only at the joints where a rational ration cannot close. It is **closed and keeps closing** — turn any door, the others fall out, and they fold back into the same closed set. That is why it reads as a seed/grain, not an atlas (an atlas needs a floor) and not salt (salt is finished and inert). Grain can be toiled: planted, threshed, milled, replanted.

## The kernel (the part that paid — survived every threshing)
On a cube of half-side `a`, the three natural spheres are
```
insphere  (touches 6 faces)        radius a        face-inscribed
midsphere (through 12 edge-mids)   radius a√2      edge-inscribed   ← the "cornerless middle" inscription
circumsphere (through 8 corners)   radius a√3      corner-inscribed
```
**Squared-radius law:  1 : 2 : 3.**  (true of every cube; owes nothing to the construction)
- √2 lives at the **edge** (midsphere). √3 lives at the **corner** (circumsphere). The **face** is the rational 1.
- The midsphere through the edge-midpoints is the **cuboctahedron** (12 vertices `(±a,±a,0)` & perms).

## The cardinal seating (six radii from three halved diameters)
- Six radii on the cardinal axes ±x,±y,±z are **three diameters bisected at one center**. The center is the **seventh point** — implied, load-bearing, the midpoint the diameter needs to yield two radii.
- The cones supply the one undeformed constant: each **cone base is pure π** in radius (R = H = π normalization). So: **π at the base, √2 at the edge, √3 at the corner** — three constants, three sources, one object.

## The kiss (why there is no floor)
The 45° cone is set **from the square** (R = H ⇒ 45°), and √2 is that square's **diagonal**, which is also the cone's **tangency length**, which is also the midsphere's **diameter-ratio**. The sphere kisses the wall at the length the square already fixed — so the kiss **re-expresses one fact through another door**, it does not add one. Square ⇄ diagonal ⇄ cone ⇄ kiss ⇄ square: a loop, no first tooth, no floor. Chicken-and-egg is a **property**, not a gap.

## The two operators (distinct — do NOT fuse; verified)
One shared seed ball, one center, two engines contracting by different ratios in different directions:
- **Outward (√2 / Pell):** wall-tangent cone-tip cascade, ratio `λ = 3 − 2√2 = (1+√2)^-2`.
- **Inward (√3):** sphere→cube→sphere recursion, ratio `1/√3` (cube side = 2R/√3).
- **Verified distinct:** at R₀ = π/√2, cone-figure cube half-side = π/2 ≈ 1.5708; √3 cube half-side = R₀/√3 ≈ 1.2825. **Different cubes.** Shared center is a construction device, not a shared mechanism.

## What it is honestly (no claim past this)
A **rationing seed**: maximum portioning to rationals, the three irrationals pinned at the three joints (edge, corner, base) where the ration won't close, all folded into one floorless mutually-implied kernel that **radiates** the figures by manipulation. Its real power is **portability and transport straight to the visual cortex** — high-bandwidth delivery of an exact structure, a *different stimulus* than statistical work. It is an **apophenia machine with its firewall attached**: rich enough to make a unity *feel* inevitable, fenced so it never claims one. The single durable fact is **1:2:3** (a cube theorem). Everything else is harvest — replantable, but chaff once you hold the grain.

## The discipline that threshed it (keep this with the grain)
- It is a **tool/seed**, not a finding. No "we found." No mechanism claimed. √2 and √3 are **constructed lengths**, not asserted.
- **Localized, not contained:** the irrationals are given an *address*, not tamed or made finite. An address is not the thing.
- The free instrument (the mind: fluid, scale-variable, imprecise, generative) **proposes**; the fixed instrument (the numbers: rigid, exact, no imagination) **disposes**. Modulation finds; precision refuses. Neither alone.
- A pile of true relations is not a result; the feeling that they fuse is the siren. Carry forward only what **pays**: 1:2:3 pays. The rest waits for a ratio-sweep to rule an interlock in or out.

*Stored as grain, not harvest: the kernel that survived the beating, to be toiled — planted, threshed, milled, replanted — by whoever holds it.*
