Assets directory.

Expected optional files:
- fable_v09_ladder_infographic.png

If this image is not uploaded, the ASCII Bridge will still work, but the packet figure may show a missing image placeholder.
