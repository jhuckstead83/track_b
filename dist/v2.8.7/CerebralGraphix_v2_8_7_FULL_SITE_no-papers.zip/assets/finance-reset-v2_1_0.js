(()=>{'use strict';
const ack=document.querySelector('#ack'),button=document.querySelector('#reset'),status=document.querySelector('#result');
ack.addEventListener('change',()=>{button.disabled=!ack.checked});
function clearBank(){return new Promise((resolve,reject)=>{
  if(typeof indexedDB==='undefined'){resolve();return}
  const request=indexedDB.deleteDatabase('cerebralgraphix-area51-v2');
  request.onsuccess=()=>resolve();request.onerror=()=>reject(Error('The saved bank could not be cleared. Use your browser site-data settings.'));
  request.onblocked=()=>{status.textContent='Close all other Cerebral Graphix tabs. The reset is waiting for their bank connections to close.'};
});}
button.addEventListener('click',async()=>{
  if(!ack.checked||!confirm('Erase this browser’s saved Cerebral Graphix jbits, holdings and game progress? This cannot be undone.'))return;
  button.disabled=true;ack.disabled=true;status.textContent='Clearing this site’s saved state…';
  try{
    await clearBank();
    localStorage.clear();sessionStorage.clear();
    if(typeof caches!=='undefined'){for(const name of await caches.keys())await caches.delete(name)}
    // Only script-accessible cookies at known site paths; browser security cookies are outside this tool.
    for(const part of document.cookie.split(';')){
      const name=part.split('=')[0].trim();if(!name)continue;
      for(const path of ['/','/finance','/area-51'])document.cookie=name+'=; Max-Age=0; path='+path+'; SameSite=Lax';
    }
    status.textContent='Reset complete. Return to Finance Weather to start fresh.';
    button.textContent='Saved state cleared';
  }catch(error){status.textContent=error.message||'Reset incomplete. Use your browser site-data settings.';button.disabled=false;ack.disabled=false}
});
})();
