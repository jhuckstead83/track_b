/* Progressive enhancement. All reading content and links are already in HTML.
   No trackers, cookies, remote libraries or external font requests are added. */
'use strict';
(() => {
 const fold = s => s.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
 const query = document.querySelector('#record-search');
 if (query) {
  const category = document.querySelector('#record-category');
  const sort = document.querySelector('#record-sort');
  const cards = [...document.querySelectorAll('.record-card')];
  const list = document.querySelector('#record-list');
  function apply() {
   const terms = fold(query.value.trim()).split(/\s+/).filter(Boolean);
   let shown = 0;
   cards.forEach(card => {
    const match = terms.every(t => fold(card.dataset.search).includes(t)) && (!category.value || card.dataset.band === category.value);
    card.hidden = !match; shown += Number(match);
   });
   const ordered = [...cards].sort((a,b) => sort.value === 'title' ? a.dataset.title.localeCompare(b.dataset.title) : (sort.value === 'oldest' ? a.dataset.date.localeCompare(b.dataset.date) : b.dataset.date.localeCompare(a.dataset.date)));
   ordered.forEach(card => list.append(card));
   document.querySelector('#record-count').textContent = `${shown} of ${cards.length} indexed records`;
   document.querySelector('#record-empty').hidden = shown !== 0;
   try { const u = new URL(location.href); u.searchParams.delete('q'); u.searchParams.delete('topic'); u.searchParams.delete('since'); if(query.value)u.searchParams.set('q',query.value);if(category.value)u.searchParams.set('topic',category.value);history.replaceState(null,'',u); } catch(_) {}
  }
  const params = new URLSearchParams(location.search);
  query.value = params.get('q') || '';
  if([...category.options].some(o=>o.value===params.get('topic')))category.value=params.get('topic');
  query.addEventListener('input',apply);category.addEventListener('change',apply);sort.addEventListener('change',apply);
  document.querySelector('#record-reset').addEventListener('click',()=>{query.value='';category.value='';sort.value='newest';apply();query.focus();});
  apply();
 }
 const atlasData = document.querySelector('#atlas-data');
 if (atlasData) {
  let data;
  try { data=JSON.parse(atlasData.textContent); } catch(_) { return; }
  const search=document.querySelector('#atlas-search'), topic=document.querySelector('#atlas-topic');
  const entries=[...document.querySelectorAll('.atlas-entry')], links=[...document.querySelectorAll('.atlas-node-link')];
  const library=document.querySelector('#atlas-library');
  const mobile=window.matchMedia('(max-width:860px)');
  const known=new Set(data.nodes.map(n=>n.id));
  const initial=location.hash.slice(1);
  let selected=known.has(initial)?initial:'postmaster';
  function choose(id,moveFocus=false) {
   if(!known.has(id))return;
   selected=id;
   entries.forEach(e=>e.hidden=e.id!==id);
   links.forEach(a=>a.setAttribute('aria-current',String(a.dataset.node===id)));
   const entry=document.getElementById(id);
   document.querySelector('#selected-name').textContent=data.nodes.find(n=>n.id===id).label;
   if(moveFocus && location.hash.slice(1)!==id){
    try { const u=new URL(location.href);u.hash=id;history.pushState(null,'',u); }catch(_){}
   }
   if(moveFocus){
    if(mobile.matches)library.open=false;
    entry.focus({preventScroll:true}); entry.scrollIntoView({block:'start',behavior:'auto'});
   }
  }
  function applyFilter() {
   const terms=fold(search.value.trim()).split(/\s+/).filter(Boolean);
   let shown=0;
   links.forEach(a=>{const show=terms.every(t=>fold(a.dataset.search).includes(t))&&(!topic.value||a.dataset.topic===topic.value);a.hidden=!show;shown+=Number(show);});
   document.querySelector('#atlas-count').textContent=`${shown} of ${links.length} map entries`;
   document.querySelector('#atlas-empty').hidden=shown!==0;
   if(search.value||topic.value)library.open=true;
  }
  document.querySelectorAll('[data-node]').forEach(a=>a.addEventListener('click',e=>{const id=a.dataset.node;if(known.has(id)){e.preventDefault();choose(id,true);}}));
  search.addEventListener('input',applyFilter);topic.addEventListener('change',applyFilter);
  document.querySelector('#atlas-reset').addEventListener('click',()=>{search.value='';topic.value='';applyFilter();search.focus();});
  document.querySelector('#browse-map-entries').addEventListener('click',e=>{e.preventDefault();library.open=true;library.scrollIntoView({block:'start'});library.querySelector('summary').focus();});
  library.open=!mobile.matches;
  mobile.addEventListener('change',()=>library.open=!mobile.matches);
  window.addEventListener('hashchange',()=>{const id=location.hash.slice(1);if(known.has(id))choose(id,true);});
  choose(selected);applyFilter();
  const holder=document.querySelector('#map-canvas');
  const disclosure=document.querySelector('#relationship-map');
  const NS='http://www.w3.org/2000/svg';
  const make=(tag,attrs={})=>{const el=document.createElementNS(NS,tag);Object.entries(attrs).forEach(([k,v])=>el.setAttribute(k,v));return el;};
  function drawMap(){
   if(!disclosure.open)return;
   const width=Math.max(250,Math.floor(holder.clientWidth));
   const columns=width>=760?3:width>=510?2:1;
   const gap=24,pad=16,box=(width-2*pad-gap*(columns-1))/columns;
   const mapNodes=data.map_nodes.map(id=>data.nodes.find(n=>n.id===id));
   const rowH=116,height=Math.ceil(mapNodes.length/columns)*rowH+pad;
   const svg=make('svg',{viewBox:`0 0 ${width} ${height}`,role:'group','aria-label':'Selected research relationships. Choose a node to read its sources and limits.'});
   const positions={};mapNodes.forEach((n,i)=>positions[n.id]={x:pad+(i%columns)*(box+gap),y:pad+Math.floor(i/columns)*rowH});
   // Only documented relationships between the displayed nodes are drawn.
   data.edges.forEach(e=>{if(!positions[e.a]||!positions[e.b])return;const a=positions[e.a],b=positions[e.b];const path=make('path',{d:`M ${a.x+box/2} ${a.y+40} L ${b.x+box/2} ${b.y+40}`,class:`map-edge ${e.type}`,'aria-hidden':'true'});svg.append(path);});
   mapNodes.forEach(n=>{
    const pos=positions[n.id],g=make('g',{class:'map-node',transform:`translate(${pos.x} ${pos.y})`,role:'button',tabindex:'0','aria-label':`Read ${n.label}`});
    g.append(make('rect',{width:box,height:84,rx:9}));
    const words=(n.short||n.label).split(' ');let line='',lines=[];const max=Math.floor((box-24)/7.2);
    words.forEach(w=>{if((line+' '+w).trim().length>max&&line){lines.push(line);line=w;}else line=(line+' '+w).trim();});if(line)lines.push(line);
    lines.slice(0,2).forEach((s,i)=>{const t=make('text',{x:13,y:24+i*18});t.textContent=s;g.append(t);});
    const sub=make('text',{x:13,y:68,class:'map-sub'});sub.textContent=n.kind==='tool'?'Interactive tool':(n.record_id?'Record '+n.record_id:'Reading entry');g.append(sub);
    const pick=()=>choose(n.id,true);g.addEventListener('click',pick);g.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();pick();}});svg.append(g);
   });
   holder.replaceChildren(svg);
  }
  disclosure.addEventListener('toggle',drawMap);
  if('ResizeObserver' in window)new ResizeObserver(drawMap).observe(holder);
 }
 const copy=document.querySelector('#copy-citation');
 if(copy)copy.addEventListener('click',async()=>{
  try{await navigator.clipboard.writeText(document.querySelector('#citation-text').textContent);document.querySelector('#copy-status').textContent='Citation copied.';}
  catch(_){document.querySelector('#copy-status').textContent='Select and copy the citation text below.';}
 });
})();
