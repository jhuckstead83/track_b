
(function(){
  'use strict';
  const LIVE_ORIGIN='https://live.cerebralgraphix.com';
  const MAX_AGE_SECONDS=300;
  const PLACEMENT={
    UTILITIES:[1,1,'real'],REAL_ESTATE:[1,2,'real'],FOOD:[1,3,'deduced'],HEALTHCARE:[1,4,'real'],
    DEFENSE:[2,1,'real'],BANKS:[2,2,'real'],MACRO_ETF:[2,3,'real'],TELECOM:[2,4,'deduced'],
    ENERGY:[3,1,'real'],MATERIALS:[3,2,'deduced'],AI_BIG:[3,3,'real'],MEDIA:[3,4,'deduced'],
    AI_SEMIS:[4,1,'real'],INDUSTRIALS:[4,2,'deduced'],AUTOS_EV:[4,3,'real'],RETAIL:[4,4,'real']
  };
  const COLORS={MACRO_ETF:'#4C78A8',AI_BIG:'#F58518',AI_SEMIS:'#E45756',AUTOS_EV:'#72B7B2',BANKS:'#54A24B',ENERGY:'#B279A2',DEFENSE:'#9D755D',RETAIL:'#EECA3B',HEALTHCARE:'#FF9DA6',UTILITIES:'#8CD17D',REAL_ESTATE:'#BAB0AC',FOOD:'#8CD17D',MATERIALS:'#B07AA1',INDUSTRIALS:'#59A14F',MEDIA:'#F28E2B',TELECOM:'#4E79A7'};
  const FORBIDDEN_PUBLIC_KEYS=new Set(['ticker','symbol','returned_symbol','leader_symbol','laggard_symbol','abs2_symbol','constituents','quote','bid','ask','last_price','account','order','position']);
  const CHAMBER_TOTALS=Object.freeze({
    UTILITIES:10,REAL_ESTATE:10,FOOD:10,HEALTHCARE:10,
    DEFENSE:10,BANKS:10,MACRO_ETF:13,TELECOM:10,
    ENERGY:10,MATERIALS:10,AI_BIG:10,MEDIA:10,
    AI_SEMIS:10,INDUSTRIALS:10,AUTOS_EV:10,RETAIL:10
  });
  const CELL_STATUS_CONFIG=Object.freeze({
    FRESH_MIN:0.50,
    BREADTH_HI:0.60,
    RELATIVE_SKEW_LO:0.25,
    RELATIVE_SKEW_HI:0.75,
    SKEW_FLOOR_BPS:5
  });
  const $=s=>document.querySelector(s);
  let lastRenderedData=null;
  let ageClockTimer=null;
  let freshnessFlashTimer=null;
  let freshnessDisclosureShown=false;
  let freshnessRefreshInFlight=false;
  function prefersDark(){return window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches;}
  function currentTheme(){return document.documentElement.dataset.theme||'light';}
  function applyTheme(theme){
    const next=theme==='dark'?'dark':'light';
    document.documentElement.dataset.theme=next;
    document.documentElement.style.colorScheme=next;
    document.querySelectorAll('[data-theme-label]').forEach(el=>el.textContent=next==='dark'?'Light':'Dark');
    document.querySelectorAll('[data-theme-icon]').forEach(el=>el.textContent=next==='dark'?'☀':'☾');
    if(lastRenderedData) render(lastRenderedData);
    return next;
  }
  function initTheme(){
    const preset=document.documentElement.dataset.theme;
    return applyTheme(preset|| (prefersDark()?'dark':'light'));
  }
  function toggleTheme(){return applyTheme(currentTheme()==='dark'?'light':'dark');}

  const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
  const fmt=v=>Number.isFinite(Number(v))?`${Number(v)>=0?'+':''}${Number(v).toFixed(1)}`:'—';
  const pct=v=>Number.isFinite(Number(v))?`${Math.round(Number(v)*100)}%`:'—';
  const ageSec=iso=>iso?Math.max(0,Math.floor((Date.now()-new Date(iso).getTime())/1000)):null;
  const finiteNumber=v=>Number.isFinite(Number(v))?Number(v):NaN;
  function normalizeCellStatus(value){
    const s=String(value||'').trim().toLowerCase();
    return ['stratified','diffuse','opaque'].includes(s)?s:null;
  }
  function chamberTotal(c){
    const up=finiteNumber(c?.up_count),down=finiteNumber(c?.down_count),flat=finiteNumber(c?.flat_count);
    if(Number.isFinite(up)&&Number.isFinite(down)&&Number.isFinite(flat)){
      const total=up+down+flat;
      if(total>0)return total;
    }
    const rowCount=finiteNumber(c?.row_count);
    if(Number.isFinite(rowCount)&&rowCount>0)return rowCount;
    const mapped=finiteNumber(CHAMBER_TOTALS[String(c?.sector_code||'').toUpperCase()]);
    return Number.isFinite(mapped)&&mapped>0?mapped:NaN;
  }
  function cellStatus(chamber){
    const fresh=finiteNumber(chamber?.fresh_ratio);
    const median=finiteNumber(chamber?.median_bps ?? chamber?.headline_bps);
    const avg=finiteNumber(chamber?.avg_bps);
    if(!Number.isFinite(fresh)||fresh<CELL_STATUS_CONFIG.FRESH_MIN)return 'opaque';
    if(!Number.isFinite(median)||!Number.isFinite(avg))return 'opaque';

    const relativeSkew=Math.abs(avg-median)/Math.max(Math.abs(median),CELL_STATUS_CONFIG.SKEW_FLOOR_BPS);
    const total=chamberTotal(chamber);
    const net=finiteNumber(chamber?.net_breadth);
    const breadthFrac=(Number.isFinite(total)&&total>0&&Number.isFinite(net))
      ?Math.abs(net)/total
      :NaN;

    if(Number.isFinite(breadthFrac)
       && breadthFrac>=CELL_STATUS_CONFIG.BREADTH_HI
       && relativeSkew<=CELL_STATUS_CONFIG.RELATIVE_SKEW_LO){
      return 'stratified';
    }
    if(relativeSkew>=CELL_STATUS_CONFIG.RELATIVE_SKEW_HI)return 'opaque';
    return 'diffuse';
  }
  function resolvedCellStatus(chamber){
    return normalizeCellStatus(chamber?.cell_status)||cellStatus(chamber);
  }
  function hexToRgb(h){h=h.replace('#','');return [0,2,4].map(i=>parseInt(h.slice(i,i+2),16));}
  function rgbToHex(a){return '#'+a.map(v=>Math.round(clamp(v,0,255)).toString(16).padStart(2,'0')).join('');}
  function blend(a,b,t){const A=hexToRgb(a),B=hexToRgb(b);return rgbToHex(A.map((v,i)=>(1-t)*v+t*B[i]));}
  function pressureFill(value,maxAbs){
    const dark=currentTheme()==='dark';
    const base=dark?'#171d28':'#F7F7F7';
    const empty=dark?'#111722':'#F3F3F3';
    const pos=dark?'#2F8F58':'#2E7D32';
    const neg=dark?'#B94D46':'#C62828';
    const v=Number(value);
    if(!Number.isFinite(v)||!maxAbs)return empty;
    const n=clamp(v/maxAbs,-1,1);
    if(n>0)return blend(base,pos,.24+.62*Math.abs(n));
    if(n<0)return blend(base,neg,.24+.62*Math.abs(n));
    return base;
  }
  function deepKeys(obj,out=[]){if(Array.isArray(obj))obj.forEach(v=>deepKeys(v,out));else if(obj&&typeof obj==='object')Object.entries(obj).forEach(([k,v])=>{out.push(String(k).toLowerCase());deepKeys(v,out)});return out;}
  function assertPublicMembrane(obj){const hits=[...new Set(deepKeys(obj).filter(k=>FORBIDDEN_PUBLIC_KEYS.has(k)))];if(hits.length)throw new Error('PUBLIC_MEMBRANE_REJECTED_KEYS: '+hits.join(','));}
  function normalizeFuturePublic(data){assertPublicMembrane(data);const chambers=(data.chambers||[]).map((c,i)=>({
    sector_code:String(c.sector_code||c.chamber_id||`C${String(i+1).padStart(2,'0')}`).toUpperCase(),sector_label:c.sector_label||'',row:Number(c.row),col:Number(c.col),kind:c.kind||'real',headline_bps:Number(c.headline_bps??c.median_bps??NaN),median_bps:Number(c.median_bps??c.headline_bps??NaN),avg_bps:Number(c.avg_bps??NaN),weighted_avg_bps:Number(c.weighted_avg_bps??NaN),net_breadth:Number(c.net_breadth??NaN),up_count:Number(c.up_count??NaN),down_count:Number(c.down_count??NaN),flat_count:Number(c.flat_count??NaN),fresh_ratio:Number(c.fresh_ratio??NaN),row_count:Number(c.row_count??NaN),weather:c.weather||null,cell_status:normalizeCellStatus(c.cell_status)
  }));
    return {mode:'public',source:'chamber_grid_public.json',generated_at_utc:data.generated_at_utc||data.latest_snapshot_utc||'',freshness:data.freshness||{},market_truth:data.market_truth||'NOT_PROVEN_BY_RECEIPT',trade_permission:data.trade_permission||'NO',chambers,global:data.global||null};
  }
  function normalizeSafePlotData(rows){assertPublicMembrane(rows);if(!Array.isArray(rows)||!rows.length)throw new Error('SAFE_AGGREGATE_EMPTY');const snaps=[...new Set(rows.map(r=>r.snapshot_utc).filter(Boolean))].sort();const latest=snaps.at(-1);const latestRows=rows.filter(r=>r.snapshot_utc===latest&&r.sector_code!=='GLOBAL_STACK');const chambers=Object.entries(PLACEMENT).map(([code,p])=>{const r=latestRows.find(x=>String(x.sector_code).toUpperCase()===code)||{};return {sector_code:code,sector_label:r.sector_label||code,row:p[0],col:p[1],kind:p[2],headline_bps:Number(r.median_bps??NaN),median_bps:Number(r.median_bps??NaN),avg_bps:Number(r.avg_bps??NaN),weighted_avg_bps:Number(r.weighted_avg_bps??NaN),net_breadth:Number(r.net_breadth??NaN),up_count:NaN,down_count:NaN,flat_count:NaN,fresh_ratio:Number(r.fresh_ratio??NaN),row_count:Number(CHAMBER_TOTALS[code]??NaN),weather:null,cell_status:null};});
    const globalRow=rows.filter(r=>r.snapshot_utc===latest&&r.sector_code==='GLOBAL_STACK')[0]||null;
    return {mode:'public',source:'safe sector_plot_data adapter',generated_at_utc:latest,market_truth:'NOT_PROVEN_BY_RECEIPT',trade_permission:'NO',freshness:{max_age_seconds:MAX_AGE_SECONDS,receipt_status:'SAFE_AGGREGATE_ADAPTER_NO_NIST_RECEIPT_FIELD',proof_status:'NOT_PROVEN_BY_RECEIPT'},chambers,global:globalRow};
  }
  async function fetchJson(url){const r=await fetch(url+(url.includes('?')?'&':'?')+'t='+Date.now(),{cache:'no-store',mode:url.startsWith('http')?'cors':'same-origin'});if(!r.ok)throw new Error(`HTTP ${r.status} ${url}`);return r.json();}
  async function loadPublic(){
    // 1) Same-origin Pages Function when deployed through Git/Wrangler.
    try{
      const live=await fetchJson('/finance/live-data');
      return Array.isArray(live)?normalizeSafePlotData(live):normalizeFuturePublic(live);
    }catch(_e){}

    // 2) Direct R2 live aggregate for dashboard Direct Upload deployments.
    // Requires R2 CORS to allow https://cerebralgraphix.com.
    try{
      return normalizeSafePlotData(
        await fetchJson(`${LIVE_ORIGIN}/finance/latest/sector_plot_data.json`)
      );
    }catch(_e){}

    // 3) Last-resort bundled static snapshot.
    return normalizeSafePlotData(await fetchJson('static/sector_plot_data.json'));
  }
  function normalizePrivate(data){const chambers=(data.chambers||[]).map(c=>({...c,sector_code:String(c.sector_code||'').toUpperCase()}));return {mode:'private',source:data.source||'private_chamber_grid.json',generated_at_utc:data.generated_at_utc||'',market_truth:data.market_truth||'NOT_PROVEN_BY_RECEIPT',trade_permission:data.trade_permission||'NO',freshness:data.freshness||{max_age_seconds:MAX_AGE_SECONDS,proof_status:'NOT_PROVEN_BY_RECEIPT'},chambers,global:data.global||null};}
  async function loadPrivate(url){return normalizePrivate(await fetchJson(url));}
  function formatAgeSeconds(value){
    const n=Number(value);
    if(!Number.isFinite(n)||n<0)return 'AGE UNAVAILABLE';
    const s=Math.floor(n);
    if(s<3600)return `${s}s`;
    const days=Math.floor(s/86400);
    const hours=Math.floor((s%86400)/3600);
    const minutes=Math.floor((s%3600)/60);
    const seconds=s%60;
    if(days>0)return `${days}d ${hours}h ${minutes}m ${seconds}s`;
    return `${hours}h ${String(minutes).padStart(2,'0')}m ${String(seconds).padStart(2,'0')}s`;
  }
  function updateAgeDisplay(data=lastRenderedData){
    if(!data)return;
    const age=ageSec(data.generated_at_utc);
    const max=Number(data.freshness?.max_age_seconds||MAX_AGE_SECONDS);
    const stale=age===null||age>max;
    const el=$('#freshnessPill');
    if(el&&!el.classList.contains('refreshing')&&!el.classList.contains('flash')){
      el.classList.toggle('stale',stale);
      const text=el.querySelector('.freshness-text');
      if(text)text.textContent=age===null?'AGE UNAVAILABLE':`${stale?'STALE':'FRESH'} · ${formatAgeSeconds(age)}`;
    }
    const ageDetail=$('#ageDetail');
    if(ageDetail)ageDetail.textContent=`snapshot: ${data.generated_at_utc||'—'}\nage_seconds: ${age??'—'}\nmax_age_seconds: ${max}\nreceipt_status: ${data.freshness?.receipt_status||'—'}\nproof_status: ${data.freshness?.proof_status||'NOT_PROVEN_BY_RECEIPT'}\nsource: ${data.source}`;
  }
  function startAgeClock(data=lastRenderedData){
    if(ageClockTimer){clearInterval(ageClockTimer);ageClockTimer=null;}
    updateAgeDisplay(data);
    ageClockTimer=setInterval(()=>updateAgeDisplay(lastRenderedData),1000);
  }
  function setStatus(data){startAgeClock(data);}
  function flashFreshness(message='REFRESHED'){
    const el=$('#freshnessPill');
    if(!el)return;
    if(freshnessFlashTimer){clearTimeout(freshnessFlashTimer);freshnessFlashTimer=null;}
    el.classList.remove('refreshing');
    el.classList.add('flash');
    const text=el.querySelector('.freshness-text');
    if(text)text.textContent=message;
    freshnessFlashTimer=setTimeout(()=>{
      el.classList.remove('flash');
      updateAgeDisplay(lastRenderedData);
    },900);
  }
  async function refreshFreshness(){
    if(freshnessRefreshInFlight)return false;
    freshnessRefreshInFlight=true;
    const el=$('#freshnessPill');
    if(el){
      el.classList.remove('flash');
      el.classList.add('refreshing');
      const text=el.querySelector('.freshness-text');
      if(text)text.textContent='REFRESHING…';
    }
    try{
      const data=await loadPublic();
      render(data);
      flashFreshness('REFRESHED');
      if(!freshnessDisclosureShown){
        freshnessDisclosureShown=true;
        openDialog('#ageDialog');
      }
      return true;
    }catch(err){
      flashFreshness('REFRESH FAILED');
      const src=$('#sourceLine');
      if(src)src.textContent=`LIVE REFRESH FAILED · ${err.message} · showing last rendered data`;
      return false;
    }finally{
      freshnessRefreshInFlight=false;
    }
  }
  function render(data){lastRenderedData=data;const grid=$('#phiGrid');if(!grid)return;grid.innerHTML='';const all=Object.entries(PLACEMENT).map(([code,p])=>data.chambers.find(c=>c.sector_code===code)||{sector_code:code,row:p[0],col:p[1],kind:p[2]});const maxAbs=Math.max(1,...all.map(c=>Math.abs(Number(c.headline_bps))).filter(Number.isFinite));all.sort((a,b)=>a.row-b.row||a.col-b.col).forEach(c=>{const live=Number.isFinite(Number(c.headline_bps));const cell=document.createElement('article');cell.className='cell'+(live?'':' empty');cell.style.setProperty('--fill',pressureFill(live?c.headline_bps:NaN,maxAbs));cell.style.setProperty('--accent',COLORS[c.sector_code]||'#777777');const counts=Number.isFinite(Number(c.up_count))?`↑${c.up_count} ↓${c.down_count} · net ${fmt(c.net_breadth)}`:`net ${fmt(c.net_breadth)}`;const fresh=`fresh ${pct(c.fresh_ratio)}`;let symbols='';if(data.mode==='private'){const lines=[];if(c.leader_symbol)lines.push(`HI ${c.leader_symbol} ${fmt(c.leader_bps)}`);if(c.laggard_symbol)lines.push(`LO ${c.laggard_symbol} ${fmt(c.laggard_bps)}`);if(c.abs2_symbol)lines.push(`ABS ${c.abs2_symbol} ${fmt(c.abs2_bps)}`);symbols=`<div class="symbols">${lines.map(x=>`<div>${x}</div>`).join('')}</div>`;}
      const status=live?resolvedCellStatus(c):null;
      const statusHtml=status?`<div class="cell-status cell-status-${status}"><span class="cell-status-mark" aria-hidden="true"></span>${status}</div>`:'';
      cell.innerHTML=`<div class="code">${c.sector_code}</div><div class="bps">${live?fmt(c.headline_bps)+' bps':'—'}</div><div class="metrics">${counts}<br>${fresh}</div>${statusHtml}${symbols}`;grid.appendChild(cell);});
    const g=$('#globalLine');if(g){const x=data.global||{};const median=x.median_bps??x.global_median_bps;const weighted=x.weighted_avg_bps??x.global_weighted_avg_bps;const net=x.net_breadth??x.global_net_breadth;g.textContent=`GLOBAL_STACK outside grid · median ${fmt(median)} bps · weighted ${fmt(weighted)} bps · net breadth ${fmt(net)}`;}
    const src=$('#sourceLine');if(src)src.textContent=`source: ${data.source} · market_truth: ${data.market_truth} · trade_permission: ${data.trade_permission}`;setStatus(data);
  }
  function openDialog(id){document.querySelector(id)?.classList.add('open')};function closeDialog(id){document.querySelector(id)?.classList.remove('open')}
  window.PhiFinanceGrid={loadPublic,loadPrivate,render,setStatus,refreshFreshness,updateAgeDisplay,startAgeClock,openDialog,closeDialog,initTheme,toggleTheme,applyTheme,cellStatus,resolvedCellStatus,CELL_STATUS_CONFIG};
})();
