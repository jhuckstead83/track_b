/* Shared, read-only finance projection. Same default sector order and weather engine as Finance. */
(function(root){
'use strict';
const META={
  UTILITIES:{slot:0,label:'Utilities',desc:'power & water',color:'#1b9e77'},
  REAL_ESTATE:{slot:1,label:'Real Estate',desc:'property & REITs',color:'#7570b3'},
  FOOD:{slot:2,label:'Food',desc:'grocers & QSR',color:'#66a61e'},
  HEALTHCARE:{slot:3,label:'Healthcare',desc:'care & pharma',color:'#e78ac3'},
  DEFENSE:{slot:4,label:'Defense',desc:'aero & defense',color:'#8c6d31'},
  BANKS:{slot:5,label:'Banks',desc:'banks & brokers',color:'#1f78b4'},
  MACRO_ETF:{slot:6,label:'Macro ETF',desc:'broad ETFs',color:'#253494'},
  TELECOM:{slot:7,label:'Telecom',desc:'carriers & data',color:'#00a6d6'},
  ENERGY:{slot:8,label:'Energy',desc:'oil & power',color:'#e6ab02'},
  MATERIALS:{slot:9,label:'Materials',desc:'metals & chemicals',color:'#a6a622'},
  AI_BIG:{slot:10,label:'AI Big',desc:'AI platforms',color:'#d95f02'},
  MEDIA:{slot:11,label:'Media',desc:'content & streaming',color:'#6a3d9a'},
  AI_SEMIS:{slot:12,label:'AI Semis',desc:'chips & fabs',color:'#c51b7d'},
  INDUSTRIALS:{slot:13,label:'Industrials',desc:'machinery & freight',color:'#008837'},
  AUTOS_EV:{slot:14,label:'Autos / EV',desc:'autos & EV',color:'#d73027'},
  RETAIL:{slot:15,label:'Retail',desc:'stores & e-commerce',color:'#ffd92f'}
};
const CODES=Object.keys(META), finite=v=>v!==null&&v!==undefined&&v!==''&&Number.isFinite(Number(v)), num=v=>finite(v)?Number(v):null;
const forbidden=new Set(['ticker','symbol','returned_symbol','leader_symbol','laggard_symbol','abs2_symbol','constituents','quote','bid','ask','last_price','account','order','position']);
function checkKeys(obj,depth=0){
 if(depth>20)throw Error('Payload too deep');
 if(obj&&typeof obj==='object')for(const [k,v]of Object.entries(obj)){if(forbidden.has(k.toLowerCase()))throw Error('Non-aggregate field');checkKeys(v,depth+1);}
}
function validate(d,now=Date.now()){
 checkKeys(d);
 if(d?.schema!=='phi.finance.weather.v2'||!Array.isArray(d.chambers)||d.chambers.length!==16)throw Error('Invalid finance board');
 if(new Set(d.chambers.map(c=>c.sector_code)).size!==16||d.chambers.some(c=>!CODES.includes(c.sector_code)))throw Error('Invalid sector set');
 if(!Number.isFinite(Date.parse(d.published_at_utc))||Date.parse(d.published_at_utc)>now+120000)throw Error('Invalid publication time');
 for(const c of d.chambers)if(!Number.isInteger(c.fresh_count)||!Number.isInteger(c.expected_count)||c.expected_count<=0||c.fresh_count<0||c.fresh_count>c.expected_count)throw Error('Invalid coverage');
 return d;
}
function newer(next,prior){
 if(!prior)return true;
 if(Date.parse(next.published_at_utc)<Date.parse(prior.published_at_utc))return false;
 return !(next.writer_epoch===prior.writer_epoch&&Number.isFinite(next.sequence)&&Number.isFinite(prior.sequence)&&next.sequence<prior.sequence);
}
function project(raw,engine,now=Date.now(),connected=false){
 if(!raw)return {kind:'waiting',active:false,observed:null,cells:CODES.map(code=>({code,...META[code],value:null,current:false}))};
 const weather=raw.browser_engine?.version==='2.1.0'&&typeof engine?.evaluate==='function';
 const cells=CODES.map(code=>{
   const c=raw.chambers.find(c=>c.sector_code===code),median=num(c.display_bps??c.headline_bps);
   const read=weather?engine.evaluate(c.weather_cohorts||[],c.expected_count,now):{bps:median,effective:c.fresh_count};
   const current=c.reading_state==='CURRENT'&&finite(median)&&Number.isFinite(Date.parse(c.valid_until_utc))&&Date.parse(c.valid_until_utc)>=now;
   // Cached data is explicitly a recorded median, never a live activity signal.
   const value=connected?read.bps:median;
   return {code,...META[code],value,median,current,effective:read.effective};
 });
 const flowing=connected&&cells.some(c=>c.current&&c.effective>0&&finite(c.value)&&Math.abs(c.value)>=.05);
 const fading=connected&&weather&&cells.some(c=>c.effective>0&&finite(c.value)&&Math.abs(c.value)>=.05);
 const any=cells.some(c=>finite(c.value));
 return {cells,kind:!connected?(any?'recorded':'waiting'):flowing?'live':fading?'fading':any?'rest':'waiting',active:flowing,
   observed:raw.observed_at_utc||raw.published_at_utc,weather:weather&&connected};
}
function validateReference(d,now=Date.now()){
 checkKeys(d);
 if(d?.schema!=='phi.finance.reference.v1'||d.source!=='GOOGLE_FINANCE'||!Array.isArray(d.cells)||d.cells.length!==16)throw Error('Invalid reference');
 if(!/^\d{4}-\d{2}-\d{2}$/.test(d.quote_date)||!Number.isFinite(Date.parse(d.quote_date))||Date.parse(d.quote_date)>now+86400000)throw Error('Invalid reference date');
 if(new Set(d.cells.map(c=>c.sector_code)).size!==16||d.cells.some(c=>!CODES.includes(c.sector_code)||!(c.median_bps===null||typeof c.median_bps==='number'&&Number.isFinite(c.median_bps))||!Number.isInteger(c.used_count)||!Number.isInteger(c.expected_count)||c.expected_count<=0||c.used_count<0||c.used_count>c.expected_count))throw Error('Invalid reference sectors');
 return d;
}
function parseReferenceCSV(text,now=Date.now()){
 if(typeof text!=='string'||text.length>16000)throw Error('Invalid reference CSV');
 const rows=[];let row=[],field='',quoted=false;
 for(let i=0;i<text.length;i++){
  const ch=text[i];
  if(ch==='"'){if(quoted&&text[i+1]==='"'){field+='"';i++;}else quoted=!quoted;}
  else if(ch===','&&!quoted){row.push(field);field='';}
  else if(ch==='\n'&&!quoted){row.push(field.replace(/\r$/,''));rows.push(row);row=[];field='';}
  else field+=ch;
 }
 if(quoted)throw Error('Unclosed CSV quote');if(field||row.length){row.push(field.replace(/\r$/,''));rows.push(row);}
 const dateText=rows.find(r=>r[0]==='Quote date used')?.[1]||'';
 const m=/^([A-Za-z]{3}) (\d{1,2}), (\d{4})$/.exec(dateText),months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
 if(!m||!months.includes(m[1]))throw Error('Missing reference quote date');
 const quoteDate=m[3]+'-'+String(months.indexOf(m[1])+1).padStart(2,'0')+'-'+m[2].padStart(2,'0');
 const cells=CODES.map(code=>{
  const matches=rows.filter(r=>r[0]===META[code].label);if(matches.length!==1)throw Error('Missing or duplicate sector');
  const r=matches[0],count=/^(\d+)\s*\/\s*(\d+)$/.exec(r[2]||'');if(!count)throw Error('Missing reference coverage');
  const value=r[1]?.trim(),bps=/^[+-]?\d+(?:\.\d+)?$/.test(value)?Number(value):null;
  if(bps===null&&!['n/a','n.a.','—',''].includes(value))throw Error('Invalid reference median');
  return {sector_code:code,median_bps:bps,used_count:Number(count[1]),expected_count:Number(count[2])};
 });
 return validateReference({schema:'phi.finance.reference.v1',source:'GOOGLE_FINANCE',quote_date:quoteDate,read_at_utc:new Date(now).toISOString(),cells},now);
}
function chooseReference(p,reference){
 if(!reference||['live','fading'].includes(p.kind)||!reference.cells.some(c=>finite(c.median_bps)))return p;
 return {kind:'reference',active:false,observed:reference.quote_date,weather:false,cells:CODES.map(code=>{
  const c=reference.cells.find(c=>c.sector_code===code);return {code,...META[code],value:c.median_bps,current:false};
 })};
}
const api=Object.freeze({META,CODES,validate,newer,project,validateReference,parseReferenceCSV,chooseReference,format:v=>finite(v)?(Number(v)>=0?'+':'')+Number(v).toFixed(1):'—'});
if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.FinanceMiniModel=api;
})(typeof window!=='undefined'?window:this);
