# Integration checks v1.12

- [x] active research count — 51
- [x] C-Geometry live HTML 
- [x] C-Geometry PDF 
- [x] Atlas support runtime 
- [x] Finance fixed placement 
- [x] Overnight overlay endpoint 
- [x] Legacy crop CSS 
- [x] Old TFG DOI absent homepage 
- [x] Old Flux DOI absent homepage 
- [x] Sitemap new atlas 
- [x] Overnight notebook coordination patch included — docs/finance
