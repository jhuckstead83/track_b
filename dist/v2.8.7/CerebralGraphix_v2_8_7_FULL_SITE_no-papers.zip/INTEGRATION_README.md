# Site Integration Patch: Centered Rational Chamber

This package integrates the new Centered Rational Chamber tool into the uploaded homepage.

## What this patch changes

1. Adds a new tool card in the homepage `#tools` grid:
   - **Centered Rational Chamber**
   - `Open` → `tools/centered_rational_chamber/`
   - `Method` → `tools/centered_rational_chamber/method.html`

2. Adds the full standalone tool folder:
   - `tools/centered_rational_chamber/index.html`
   - `tools/centered_rational_chamber/src/app.js`
   - `tools/centered_rational_chamber/src/style.css`
   - `tools/centered_rational_chamber/method.html`
   - supporting docs and tests

3. Keeps the Six Cardinal Picone tool separate.

## What this patch does not change

- It does not edit your top navigation by default.
- It does not touch the existing Six Cardinal Picone links.
- It does not alter Finance Weather, Papers, Receipts, Maker's Mark, or footer content.
- It does not add physics or interpretation language.

## Files to copy into your site repo

Copy these from the patch root:

```text
index.html
tools/centered_rational_chamber/
```

Then inspect:

```text
index_integration.diff
```

## Optional topbar link

If you want a direct topbar link, use:

```text
snippets/optional_top_nav_link.html
```

I did not apply it automatically because your current nav is already dense.

## Recommended launch check

After copying into your repo, verify:

```text
/
```

shows the new homepage card, and:

```text
/tools/centered_rational_chamber/
```

opens the lab.

Then open:

```text
/tools/centered_rational_chamber/method.html
```

to confirm the Method & Limitations page is one click away.
