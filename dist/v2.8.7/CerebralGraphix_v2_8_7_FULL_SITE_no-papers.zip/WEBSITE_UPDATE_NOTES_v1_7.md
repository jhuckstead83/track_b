# Cerebral Graphix Website v1.7 — Visual Front Door Release

**Built:** 2026-07-09

## What changed

1. Repositioned the homepage from decoder-ledger-first to visual-first.
2. Added a top-level `plots/` landing page and promoted Polar → live finance → 3D geometry.
3. Replaced `tools/polar_shell_renderer.html` with the reviewed canonical equal-area reduced-fraction renderer (DOI `10.5281/zenodo.21280464`).
4. Preserved the former prime-numerator renderer as `tools/polar_shell_prime_numerator_legacy.html` so the two objects are not conflated.
5. Added local paper assets:
   - `papers/polar_shell_renderer.pdf`
   - `papers/polar_shell_renderer.tex`
   - `papers/annular_shell_isolation.pdf`
6. Added explicit Paper ↔ Plot links and the canonical DOI chain:
   - Polar: `10.5281/zenodo.21280464`
   - Arithmetic parent: `10.5281/zenodo.21187177`
   - Annular diagnostic: `10.5281/zenodo.20564213`
7. Added the Polar-vs-Annular fence to the homepage, plots page, papers shelf, and chamber-series index.
8. Rebuilt the tools directory into four groups: plots/maps, live data, 3D geometry, utilities/origins.
9. Added page title, meta description, and non-JavaScript fallback text to both Six Cardinal Picone builds.
10. Regenerated `site-index.html`, updated `site-index.json`, rebuilt `sitemap.xml`, and refreshed the webmanifest description.

## Judgment calls made

- I **did not delete** the decoder tools. They remain public under **Utilities & origins**.
- I **did not merge** the former prime-numerator renderer into the new Polar Shell base object. It is preserved as a separate legacy research view because the predicates differ.
- I **did not hardcode current finance numbers** into the homepage. The homepage reads `finance/latest/public_manifest.json` at runtime so the live card can move with the public rail.
- I **did not promote the Annular Shell paper as the same shell mechanism** as Polar. It is shown as a radial/analytic sibling with a different radius law.
- I created a **new versioned release** instead of overwriting v1.6, preserving provenance.

## Known corpus note

The Chamber-Lift reader guide in the supplied Drive folder still contains an older parent DOI (`20533247`) in its final line. This site release uses the confirmed canonical arithmetic parent `21187177`. I did not overwrite the chamber-source guide because the website request did not require mutating that separate source folder.
