# Area 51 public Alpha — live test card

Use a private browser profile for a clean 8-credit bank. Use a normal profile to
verify that credits and unfinished Blackjack hands survive reloads.

## Route and return checks

1. Open `/` and confirm Area 51 is the right-side lead hero card.
2. Open the two promoted core links, Invariant and Blackjack 51; then open the
   Memory 51 and Telescope 51 supporting links from the lab.
3. From every game, return to `/area-51/`.
4. Open the DOI from the footer and confirm it resolves to the frozen v7.2 record.
5. In Invariant, confirm `Play Telescope 51 β` remains in the Cards/Symbols row.

## Memory 51

1. Reveal and self-grade a Study card; confirm this does not count as an
   objective recall check.
2. Complete Recall checks in card→theory, theory→card, and mixed directions.
3. Edit one symbol and meaning; confirm the card version and review schedule reset.
4. Export mappings, restore the default, then import the exported mapping.
5. Export a research receipt and confirm that mapping version, direction,
   correctness, response time, self-grade, active seconds, and credit awards are
   separate fields.
6. Leave the tab idle and confirm idle time does not increase Memory learning time.

## Blackjack 51

1. Deal under contextual aces; exercise Hit, Stand, Double, and one legal split.
2. Reload during an unfinished hand and confirm the hand and bank return.
3. Change the ace rule between rounds and confirm the bank does not reset.
4. Use `Observe next · 2`, then end the hand before consuming that card; export a
   receipt and confirm the observation remains recorded as unconsumed.
5. Buy `Reveal visible odds · 1`; confirm the exact safe/bust fractions appear,
   the next card stays hidden, and the bank falls by exactly 1 credit.
6. Use one next-card contract and confirm it draws immediately and records the
   pre-draw quote, stake, event, and return separately.
7. Hit into a new decision state; confirm its odds are hidden again and can be
   purchased independently.
8. Open `Two 17s`, append the same 10, and confirm soft 17 remains 17 while hard
   17 becomes 27.
9. Open `The swap` and run the 51-position certificate: physical differences at
   positions 50 and 51; no blackjack-value differences.

## Telescope 51 and Invariant

1. Play both Telescope branches and export a local receipt.
2. Confirm the unread resolution tail remains hidden until the declared play reveals it.
3. Confirm the paper and archive-addressing statement links open.
4. In Invariant, test the swap, the observer, the game comparison, v7.2 return,
   downloads, and recurrence-certificate export.
5. Step the published Invariant fixture and confirm the running ledger displays
   `y_n`, both live card-count vectors, and `ledger ✓`. Open the CSV download and
   confirm 1,566 rows plus its header. A new random exploration must state that
   the archived card-count columns belong to the published fixture.

## Boundaries

- `3♥` may display as the author's lucky sentinel; it must not alter scheduling,
  rules, odds, reward, or inference.
- No page view, click, idle interval, credit balance, or local receipt is evidence
  of a human research participant.
- No Area 51 session is transmitted automatically in public Alpha 0.1.
