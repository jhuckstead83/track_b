# Cerebral Graphix v1.13.10 — Area 51 core pair

Date: 20 September 2026  
Baseline: v1.13.9

## Outcome

This patch repairs the broken homepage Area 51 hero and concentrates the first
lab entrance on the core pair:

- **Invariant** is the fixed 51-card object, decoder, evidence boundary and
  maintained v7.2 foundation.
- **Blackjack 51** is the featured playable rule applied to that object.
- Memory 51 and Telescope 51 remain available as supporting experiments at
  their stable current URLs.

The homepage now requests `/assets/site-v1-13-10.css`. v1.13.9 had appended the
Area 51 hero rules to the older `site-v1-13-6.css` filename, allowing a browser
or edge cache to reuse a pre-Area-51 copy. The new fingerprint removes that
cache ambiguity.

## Shared cards and economy

Invariant and Blackjack 51 now load one scoped core stylesheet for card faces,
backs, red suits, the 3♥ lucky sentinel and the Area 51 bank. Invariant displays
the same persistent balance without spending it. Blackjack remains the core
page that stakes, purchases information and returns game credits.

The 3♥ treatment is visual only. It changes no rule, odds, reward or result.

## The restored y_n/card relation

The archived v7.2 `height_ledger.csv` is now published directly as:

`/area-51/assets/invariant-y-n-ledger-v7-2.csv`

It contains 1,566 rows. For each published turn `n`, it joins the supplied
stored label `y_n` to the original and one-swap hand-count vectors. The live
Invariant page displays both current card states, the shared `y_n` label and a
ledger check.

The boundary is explicit: the card transition determines the state and turn
index; the turn index selects a supplied label. The cards do not generate
`y_n`, predict `y_(n+1)`, calculate an unobserved zero or place `y_n` inside the
card transition.

## Blackjack 51 Alpha 0.2

Blackjack 51 now separates three prices:

- 1 credit reveals the exact safe/bust odds for the current decision state
  under the declared uniform unseen-card model;
- 1 credit enters a safe/bust forecast contract and draws immediately; and
- 2 credits briefly reveal the unchanged next card.

Buying odds does not reveal the card. A hit, split or other state change creates
a new decision state and hides its odds again. Purchases use stable transaction
identifiers, so the same decision-state view cannot be charged twice. Paid
views, forecast stakes, observations, outcomes and credits remain separate in
the local receipt.

## Compatibility

All five stable Area 51 routes are unchanged. The original
`/research/line-game/` pages remain byte-identical to v1.13.9, including the
approved `Play Telescope 51 β` button position. The archived v7.2 capsule and
DOI `10.5281/zenodo.22851517` remain the frozen foundation and license record.

No session data is transmitted automatically. Credits are designed game
currency—not bits, entropy, cognition, proof, cash or research evidence.

## Validation

- 15,424 implementation assertions passed.
- 3,072 complete Blackjack simulations and 3,072 deterministic replays passed.
- Paid odds were checked for complementarity, state stability, declared cost
  and duplicate-view rejection.
- The y_n ledger schema, first label and all 1,566 rows were checked.
- Five Area 51 pages passed duplicate-ID, local-reference, script-ID, JSON,
  citation and cache-fingerprint checks.
- Full-site link, package-size and manifest totals are recorded in
  `release-v1.13.10.json`.
- Browser/device rendering remains a live post-deployment check because this
  build environment has no browser executable.

