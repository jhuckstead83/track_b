# Cerebral Graphix v1.13.9 — Area 51 public Alpha

Date: 20 September 2026  
Baseline: v1.13.8

## Outcome

Area 51 is now the homepage lead interactive object and a first-class research
area. The current-publication strip remains Triangular-n Postmaster v5.1.

Permanent current URLs intended for Zenodo and other archived references:

- `https://cerebralgraphix.com/area-51/`
- `https://cerebralgraphix.com/area-51/invariant/`
- `https://cerebralgraphix.com/area-51/telescope-51/`
- `https://cerebralgraphix.com/area-51/memory-51/`
- `https://cerebralgraphix.com/area-51/blackjack-51/`

Every Game 51 page links back to Area 51 and to the archived v7.2 foundation,
DOI `10.5281/zenodo.22851517`. The DOI record remains the authority for the
deposited foundation and license; the stable web routes remain current.

## Public Alpha functions

- **Memory 51:** customizable ordinary-card ↔ symbol/declared-meaning mappings,
  study and objective recall modes, both directions, local mapping import/export,
  versioned receipts, and active-learning credit progress.
- **Blackjack 51:** 51-card play with `2♣` outside as `Ⅰ`, contextual or fixed
  aces, hit/stand/double/one value-matched split, paid observation, exact
  next-card forecast quotes, persistent unfinished hands, and local receipts.
- **Telescope 51:** stable current route for the public-beta finite-observation
  laboratory and its existing paper/machine-statement links.
- **Invariant:** stable current Area 51 route for the maintained v7.2 interactive;
  the archived v7.2 capsule remains directly available.

The shared Alpha economy starts with 8 credits. Passive recovery and completed
Memory 51 active-recall work each use a 5:10 threshold. One release switch in
`area-51/assets/economy-config.js` can later disable passive recovery while
preserving balances and ledgers.

## Research fence

The Area 51 landing page and machine index separately identify:

1. the fixed data and exact card order;
2. declared representations such as identity, `V`, `R`, `C`, `S`, blackjack
   value, or a versioned Memory mapping;
3. the exact finite value of a proof or certificate; and
4. interpretations and claims that do not follow.

The decoder transports the supplied integer. It does not calculate a zero,
certify a new ordinate, extend an archive, or prove RH. Credits are designed
game rewards, not bits, entropy, intelligence, cash, scarcity, or proof of
learning. Traffic and client-local receipts are not human-study evidence.

## Compatibility and deployment

The original `/research/line-game/` entry pages are byte-identical to v1.13.8,
including the approved `Play Telescope 51 β` button location and style. Existing
links continue to work.

Deploy either the full-site package at the web root or apply the delta package
over an exact v1.13.8 deployment. Do not nest the package directory itself.
Rollback is the unchanged v1.13.8 full-site package.

No Area 51 page transmits a session automatically. Live testing therefore checks
browser behavior and local persistence; it does not create a research dataset.

## Validation

- 3,072 complete Blackjack simulations and 3,072 deterministic replays passed.
- 15,415 implementation assertions passed.
- Five Area 51 HTML pages passed duplicate-ID, local-link, script-reference, JSON,
  canonical/citation and indexing checks.
- Every deployable file remains below Cloudflare's 25,000,000-byte per-file limit.
- Browser/device visual QA remains a live post-deployment check because this
  build environment has no browser executable.
