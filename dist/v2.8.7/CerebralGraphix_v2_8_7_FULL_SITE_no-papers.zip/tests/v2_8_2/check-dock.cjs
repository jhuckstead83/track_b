/* In-memory DOM and simulated time; no rendered-browser claim. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {parseHTML}=require('linkedom');
const ROOT=path.resolve(__dirname,'../..'),checks=[];
const csv=fs.readFileSync(path.resolve(__dirname,'google-summary.csv'),'utf8');
const model=require(ROOT+'/assets/finance-mini-model-v2-8-1.js'),engine=require(ROOT+'/assets/finance-browser-engine-v2_1_0.js');
const reference=model.parseReferenceCSV(csv),now=Date.parse('2026-09-27T21:00:00Z'),iso=t=>new Date(t).toISOString();
function pass(s){checks.push(s);console.log('PASS',s);}
function feed(){return {schema:'phi.finance.weather.v2',browser_engine:{version:'2.1.0'},published_at_utc:iso(now),observed_at_utc:iso(now),writer_epoch:'test',sequence:10,scheduled_session:'REGULAR',state:'CURRENT',global_fresh_count:320,global_expected_count:320,chambers:model.CODES.map((code,i)=>({sector_code:code,display_bps:i+2,headline_bps:i+2,fresh_count:20,expected_count:20,reading_state:'CURRENT',valid_until_utc:iso(now+60000),movement:{index:100+i,epoch:'test',eligible:true},weather_cohorts:[{at:iso(now-30000),sum_bps:20*(i+2),count:20,quality_weight:1,source:'TEST_FIXTURE',decay:{grace_seconds:60,half_life_seconds:60,horizon_seconds:300}}]}))};}
async function mount(html,files,{reduced=true,cache=new Map(),cookies={value:''},liveFeed=null}={}){
 const {window,document}=parseHTML(html),timers=new Map();let time=now,id=0,hidden=false;const writes=[],requests=[];
 const media={matches:reduced,addEventListener(type,cb){this.change=cb;}};
 class ClockDate extends Date{constructor(...args){super(...(args.length?args:[time]));}static now(){return time;}}
 const sandbox={document,console,Date:ClockDate,Intl,JSON,Math,URL,AbortController,Blob,Response,performance:{now:()=>time-now},innerWidth:390,innerHeight:844,
   navigator:{},__CG_FINANCE_TEST__:true,location:{protocol:'https:',pathname:'/'},matchMedia:()=>media,
   localStorage:{getItem:k=>cache.get(k)||null,setItem:(k,v)=>{writes.push(k);cache.set(k,v);}},
   setTimeout:(f,t=0)=>{timers.set(++id,{f,at:time+t});return id;},clearTimeout:i=>timers.delete(i),
   setInterval:(f,t)=>{const key=++id;timers.set(key,{f,at:time+t,repeat:t});return key;},clearInterval:i=>timers.delete(i),
   ResizeObserver:class{observe(){}},fetch:async url=>{requests.push(String(url));if(String(url).includes('docs.google.com'))return {ok:true,text:async()=>csv};if(!liveFeed)throw Error('Offline test');return {ok:true,json:async()=>liveFeed};}
 };
 Object.defineProperty(document,'hidden',{get:()=>hidden});Object.defineProperty(document,'activeElement',{get:()=>document._active||document.body});
 Object.defineProperty(document,'cookie',{get:()=>cookies.value,set:v=>{cookies.value=v.split(';')[0];}});
 for(const k of ['addEventListener','removeEventListener','dispatchEvent'])sandbox[k]=window[k].bind(window);
 sandbox.window=sandbox;sandbox.self=sandbox;sandbox.Event=window.Event;sandbox.CustomEvent=window.CustomEvent;
 window.HTMLElement.prototype.focus=function(){document._active=this;};
 window.HTMLElement.prototype.scrollTo=function({left=0}){this.scrollLeft=left;};
 window.HTMLElement.prototype.getBoundingClientRect=function(){const w=this.classList.contains('finance-dock')?(this.classList.contains('expanded')?324:225):340,h=this.classList.contains('finance-dock')?(this.classList.contains('expanded')?410:44):60;const left=parseFloat(this.style.left)||0,top=parseFloat(this.style.top)||0;return {left,top,width:w,height:h,right:left+w,bottom:top+h};};
 window.HTMLElement.prototype.showModal=function(){this.open=true;};window.HTMLElement.prototype.close=function(){this.open=false;};
 window.HTMLElement.prototype.setPointerCapture=function(i){this._capture=i;};window.HTMLElement.prototype.hasPointerCapture=function(i){return this._capture===i;};window.HTMLElement.prototype.releasePointerCapture=function(){this._capture=null;};
 Object.defineProperty(window.HTMLSelectElement.prototype,'value',{get(){return this.querySelector('option[selected]')?.getAttribute('value')||this.querySelector('option')?.getAttribute('value')||'';},set(v){for(const o of this.querySelectorAll('option'))o.toggleAttribute('selected',o.getAttribute('value')===String(v));},configurable:true});
 const ctx=vm.createContext(sandbox);for(const f of files)vm.runInContext(fs.readFileSync(path.join(ROOT,f),'utf8'),ctx,{filename:f});
 const flush=async()=>{for(let i=0;i<12;i++)await Promise.resolve();};await flush();
 async function advance(ms){const target=time+ms;while(true){const entry=[...timers].filter(([,t])=>t.at<=target).sort((a,b)=>a[1].at-b[1].at)[0];if(!entry)break;const [key,t]=entry;time=t.at;timers.delete(key);if(t.repeat)timers.set(key,{...t,at:time+t.repeat});t.f();await flush();}time=target;await flush();}
 async function click(sel){const e=document.querySelector(sel);assert(e,'Missing '+sel);assert(!e.disabled,'Disabled '+sel);e.click();await flush();}
 return {document,sandbox,ctx,cache,cookies,writes,requests,timers,media,advance,flush,click,$:s=>document.querySelector(s),setHidden:v=>hidden=v,setFeed:v=>liveFeed=v};
}
(async()=>{
 const scripts=['finance-browser-engine-v2_1_0.js','finance-mini-model-v2-8-1.js','finance-reference-seed-v2-7.js','finance-mini-v2-8-2.js'].map(f=>'assets/'+f);
 const html='<html><body data-finance-dock><footer></footer></body></html>',cookies={value:''},cache=new Map();
 const h=await mount(html,scripts,{cookies,cache});
 const event=(target,type,props={})=>{const e=new h.sandbox.Event(type,{bubbles:true,cancelable:true});Object.assign(e,{button:0,pointerId:1,isPrimary:true,clientX:300,clientY:300},props);h.$(target).dispatchEvent(e);};
 assert.equal(h.$('.finance-dock').hidden,true);await h.click('.finance-monitor-settings');
 assert(!h.$('.finance-dock-grip'));assert(h.$('.finance-dock-handle'));assert(h.$('.finance-dock-toggle svg'));
 assert.equal(h.$('.finance-dock-toggle').getAttribute('aria-expanded'),'true');
 await h.click('.finance-dock-toggle');await h.advance(2000);
 assert.equal(h.$('.finance-dock').hidden,false);assert.equal(h.$('.finance-dock-toggle').getAttribute('aria-expanded'),'false');assert.equal(h.$('.finance-dock-fold').inert,true);assert(!h.$('dialog').open);
 assert.equal(JSON.parse(decodeURIComponent(cookies.value.split('=').slice(1).join('='))).hidden,false);
 pass('Separate label handle and larger SVG chevron; collapsing the reference grid keeps the tab visible without a hide dialog');
 await h.click('.finance-dock-handle');assert.equal(h.$('.finance-dock-toggle').getAttribute('aria-expanded'),'false');
 const before=h.$('.finance-dock').getBoundingClientRect();
 event('.finance-dock-handle','pointerdown');event('.finance-dock-handle','pointermove',{clientX:240,clientY:260,pointerType:'touch'});event('.finance-dock-handle','pointerup');
 const after=h.$('.finance-dock').getBoundingClientRect();assert(after.left<before.left);assert(after.top<before.top);assert(after.left>=8&&after.right<=382);
 assert.equal(h.$('.finance-dock-toggle').getAttribute('aria-expanded'),'false');assert(!h.$('dialog').open);
 event('.finance-dock-handle','keydown',{key:'ArrowLeft'});assert(h.$('.finance-dock').getBoundingClientRect().left<after.left);
 pass('Mouse/touch pointer drag and keyboard movement use the Finance label, save position, stay in bounds, and never toggle or dismiss');
 const reload=await mount(html,scripts,{cookies,cache});assert.equal(reload.$('.finance-dock').hidden,false);assert.equal(reload.$('.finance-dock-toggle').getAttribute('aria-expanded'),'false');
 await h.click('.finance-dock-toggle');assert.equal(h.$('.finance-dock-toggle').getAttribute('aria-expanded'),'true');assert.equal(h.$('.finance-dock-fold').inert,false);
 await h.click('.finance-dock-toggle');assert(!h.$('.finance-dock').hidden);
 pass('Pinned collapsed tab survives reload during downtime and the chevron reopens the grid');
 await h.click('.finance-dock-hide');assert(h.$('dialog').open);await h.click('[data-hide-cancel]');assert(!h.$('.finance-dock').hidden);
 await h.click('.finance-dock-hide');await h.click('[data-hide-confirm]');assert(h.$('.finance-dock').hidden);
 const hidden=await mount(html,scripts,{cookies,cache});assert(hidden.$('.finance-dock').hidden);await hidden.click('.finance-monitor-settings');assert(!hidden.$('.finance-dock').hidden);
 pass('X still requires confirmation, Cancel retains the tab, confirmed hiding persists, and footer restore works');
 fs.writeFileSync(__dirname+'/DOCK_QA_v2_8_2.json',JSON.stringify({status:'PASS',checks,scope:'In-memory DOM, pointer events, timers and cookie persistence; no rendered-browser or physical-device check'},null,2)+'\n');
})().catch(e=>{console.error(e);process.exitCode=1;});
