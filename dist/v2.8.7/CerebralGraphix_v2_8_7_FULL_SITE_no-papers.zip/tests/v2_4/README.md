# v2.4 verification

From this directory, run `npm ci`, then `npm test` (Node 22+).

`check.mjs` adapts the inherited regression suite to the maintained entrypoints and the new policy of retaining malformed banks instead of silently resetting them.

The other runners cover Prospect's account adapter, all 32 hold masks, exact jackpot reservation, reload and retry behavior, cross-game wallet continuity, fallback storage failure, cross-tab transaction serialization, and card-action handlers. `decision_checks.mjs` checks paid odds displayed beside a card, reuse without duplicate charges, hidden-card privacy, free hold-odds computation, and stale-odds invalidation.

`mobile_flow_checks.mjs` checks the shared stamp collection and daily cap, assisted recall and retries, Telescope return continuity, direct Prospect holds and reel travel, starting Blackjack instructions, and homepage routing.

DOM checks use linkedom; IndexedDB transaction checks use fake-indexeddb. They do not verify CSS layout, native browser storage, actual animation frames, Safari, or physical phones. Those remain release checks.

The supplied Project 51 source archive includes the original pure-engine, independent census, and paper-verification runners. The result copies here were replayed during this release.

`release_checks.mjs` covers versioned startup with an obsolete cached app present, presentation-load failure without bank loss, restoring a saved hand, the reel-local action overlay, controlled-frame travel and staggered stops, reduced motion, and Blackjack Double.
