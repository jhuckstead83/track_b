import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {mount,wait} from './dom_harness.mjs';
const a=await mount('area-51/prospect-51');
// Exercise the shipped frame-driven reel controller. This does not render CSS.
a.window.matchMedia=()=>({matches:false});
// The game captured its motion object during initialization: harness exposes the object below.
a.window.testMotion.matches=false;

const checks=[];
await a.click('#deal');assert.equal(a.$('rotors').getAttribute('aria-busy'),'true');const committed=await a.wallet();assert.equal(committed.balanceCents,700);assert.equal(committed.apps.prospect51.state.phase,'hold');checks.push('Entry and hand commit before scrolling starts');
assert(a.$('draw').disabled);assert(a.document.querySelector('[data-example]').disabled);assert(a.$('export-record').disabled);checks.push('Draw, examples and receipt controls are locked during travel');
await a.click('#skip-reels');assert.equal(a.$('rotors').getAttribute('aria-busy'),'false');assert.deepEqual(await a.wallet(),committed);checks.push('Reveal now ends presentation without redraw or charge');
await a.click('#rotor-1 .reel-face');await a.click(a.menu('Hold this card'));const held=a.$('token-1').getAttribute('card');await a.click('#draw');assert.equal(a.document.querySelectorAll('.is-spinning').length,4);assert.equal(a.$('token-1').getAttribute('card'),held);const settled=await a.wallet();checks.push('Only the four unheld reels travel after settlement is committed');
a.window.dispatchEvent(new a.window.Event('resize'));await wait(15);assert.equal(a.document.querySelectorAll('.is-spinning').length,0);assert.deepEqual(await a.wallet(),settled);checks.push('Resize reveals existing settlement without repeating payout');
writeFileSync('tests/v2_4/results/MOTION_COORDINATION_CHECKS.json',JSON.stringify({passed:checks.length,scope:'In-memory DOM and frame-driven animation coordination, not rendered motion verification.',checks},null,2));console.log(checks.length+' motion coordination checks passed.');a.close();process.exit();
