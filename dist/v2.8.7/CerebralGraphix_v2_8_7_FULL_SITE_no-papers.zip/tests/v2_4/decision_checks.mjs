import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {mount,wait} from './dom_harness.mjs';
const checks=[];
let app=await mount('area-51/blackjack-51');
try{
 const {$,document}=app;
 // A deterministic live hand with a real safe/bust decision, independent of host randomness.
 let seed;
 for(let i=0;i<100;i++){
  const candidate='decision-menu-'+i,e=new app.window.BJ51.Engine({seed:candidate});e.start(1);
  if(e.active()){const v=e.total(e.current().cards);if(!v.soft&&v.total>=12&&v.total<20){seed=candidate;break;}}
 }
 assert(seed);$('setting-seed').value=seed;await app.click('#new-session');await app.click('[data-bet="1"]');await app.click('#deal');assert(!$('hit').hidden);
 const before=await app.wallet();await app.click('#player-hands .active .card');
 assert(app.menu('Show safe / bust odds · 1 jbit'));assert(!app.menu('Hit · take a card'));assert(!app.menu('Stand · keep this hand'));
 assert.equal((await app.wallet()).balanceCents,before.balanceCents);assert(document.querySelector('.card-quote').textContent.includes('Odds hidden'));
 checks.push('Opening a card menu neither buys odds nor takes a game action');
 await app.click(app.menu('Show safe / bust odds · 1 jbit'));
 const paid=await app.wallet();assert.equal(paid.balanceCents,before.balanceCents-100);
 assert.equal($('card-actions').hidden,false);assert(!$('card-actions').textContent.includes('Odds hidden'));
 for(const choice of ['safe','bust'])assert($('card-actions').textContent.includes($(choice+'-quote').textContent));
 assert(!app.menu('Show safe / bust odds · 1 jbit'));
 checks.push('Paid odds cost exactly one jbit and appear beside the same card');
 $('show-market-odds').click();await wait(30);assert.equal((await app.wallet()).balanceCents,paid.balanceCents);
 await app.click('#dealer-cards .card.back');assert(!$('card-actions').querySelector('p51-token'));
 assert.equal(document.querySelector('#dealer-cards .card.back').dataset.card,undefined);
 assert($('card-actions').textContent.includes($('safe-quote').textContent));assert(!app.menu('Inspect paper symbol'));
 checks.push('Purchased odds are reused from a face-down card without exposing its identity or charging twice');
 await app.click(app.menu('Decision market details'));assert($('decision-tools').open);
 assert.equal(document.querySelector('#play details').id,'decision-tools');assert(!$('ace-readout'));
 assert.equal($('double').hidden,false);assert.equal($('double').disabled,!app.window.BJ51.Engine.replay((await app.wallet()).apps.blackjack.state.engine).canDouble());
 checks.push('Market details are the first play disclosure; legal primary moves remain on the table');
}finally{app.close();}
app=await mount('area-51/prospect-51');
try{
 const {$}=app;await app.click('#deal');await wait(20);
 for(let i=0;i<4;i++){await app.click('#rotor-'+i+' .reel-face');await app.click(app.menu('Hold this card'));}
 const before=await app.wallet();await app.click('#rotor-4 .reel-face');assert(app.menu('Count hold odds'));assert(!app.menu('Draw unheld · free'));assert(!app.menu('Bank this hand'));
 await app.click(app.menu('Count hold odds'));await wait(60);
 assert($('card-hold-odds').textContent.startsWith('46 equally likely completions.'));
 assert.equal($('card-hold-odds').textContent,$('odds-result').textContent);assert.deepEqual(await app.wallet(),before);
 checks.push('Prospect card odds enumerate the selected hold without drawing, settling, or spending');
 await app.click('#rotor-0 .reel-face');await app.click(app.menu('Release this card'));
 assert($('odds-result').textContent.startsWith('Choose a hold'));
 await app.click('#rotor-0 .reel-face');assert(!$('card-hold-odds').textContent.includes('46 equally likely'));
 await app.click(app.menu('Read these odds'));assert($('odds-panel').open);
 checks.push('Changing a hold clears old odds; the shortcut opens the original decision explanation');
}finally{app.close();}
writeFileSync('tests/v2_4/results/DECISION_SHORTCUT_CHECKS.json',JSON.stringify({passed:checks.length,scope:'In-memory DOM interaction checks; no rendered-browser or CSS layout claim.',checks},null,2));
console.log(checks.length+' decision shortcut checks passed.');process.exit();
