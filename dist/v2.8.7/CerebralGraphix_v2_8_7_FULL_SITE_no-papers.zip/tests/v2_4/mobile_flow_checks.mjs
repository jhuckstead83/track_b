import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import path from 'node:path';
import {mount,wait,storage} from './dom_harness.mjs';
const checks=[],shared=storage(),session=storage();
let app=await mount('area-51/memory-51',{shared,session,search:'?card=AS'});
try{
 const {$,document}=app;
 const api=(await app.evaluateFile(path.resolve('area-51/assets/stamps-v2-3.js'))).namespace;
 const target=api.STAMPS.find(s=>s.card==='AS');
 $('direction').value='card-symbol';$('direction').onchange();
 // Practice selects a fresh requested prompt; opening the inspector on that prompt marks it assisted.
 $('stamp-select').value='AS';$('stamp-select').onchange();await app.click('#stamp-practice');
 assert([...document.querySelectorAll('#answers p51-token')].every(t=>t.shadowRoot.querySelector('svg path')));
 await app.click('[data-answer="'+target.id+'"]');
 let wallet=await app.wallet();assert.equal(wallet.balanceCents,1000);assert.equal($('stamp-count').textContent,'1 / 51');assert(wallet.apps.cardStamps.marks.AS);
 checks.push('Memory renders exact vector stamps and saves a correct recall with its +2-jbit award');
 const receipt=wallet.entries.find(e=>e.kind==='four-way-recall');
 const tx={id:receipt.id.slice(7),correct:true,assisted:false,options:4,evidence:{card:'AS',symbolId:target.id}};
 const retry=await api.recordStampedRecall(tx);assert(retry.duplicate);assert(!retry.newStamp);assert.equal((await app.wallet()).balanceCents,1000);assert.equal(Object.keys(retry.marks).length,1);
 const others=api.STAMPS.filter(s=>s.card!=='AS');
 for(const [i,s]of others.slice(0,5).entries())await api.recordStampedRecall({id:'cap-'+i,correct:true,assisted:false,options:4,evidence:{card:s.card,symbolId:s.id}});
 wallet=await app.wallet();assert.equal(wallet.recallPaid,800);assert.equal(wallet.balanceCents,1600);assert.equal(Object.keys(wallet.apps.cardStamps.marks).length,6);
 checks.push('Retry cannot duplicate a stamp or award; six unique stamps can be earned while jbits stop at the daily cap of eight');
 for(const [i,result]of [{correct:false,assisted:false},{correct:true,assisted:true}].entries()){
  const s=others[5+i];await api.recordStampedRecall({id:'no-award-'+i,...result,options:4,evidence:{card:s.card,symbolId:s.id}});
 }
 await assert.rejects(api.recordStampedRecall({...tx,id:'invalid-pair',evidence:{card:'AS',symbolId:others[0].id}}),/published alphabet/);
 const altered=await api.recordStampedRecall({...tx,evidence:{card:others[8].card,symbolId:others[8].id}});
 assert(!altered.marks[others[8].card]);assert.equal(Object.keys((await app.wallet()).apps.cardStamps.marks).length,6);
 checks.push('Wrong, assisted, mismatched, and altered retry evidence cannot add stamps');
 const practice=others[9];$('stamp-select').value=practice.card;$('stamp-select').onchange();await app.click('#stamp-practice');
 $('stamp-select').value=practice.card;$('stamp-select').onchange();await app.click('[data-answer="'+practice.id+'"]');
 assert($('message-sub').textContent.includes('Study round'));assert(!(await app.wallet()).apps.cardStamps.marks[practice.card]);
 checks.push('Inspecting the current answer in the stamp explorer converts that recall to assisted practice');
}finally{app.close();}
app=await mount('area-51/telescope-51',{shared,session});
try{
 const {$,document}=app;
 assert.equal($('stamp-count').textContent,'6 / 51');
 assert.equal(document.querySelectorAll('#playerTable p51-token').length,0);
 for(const back of document.querySelectorAll('#playerTable .house-card')){assert.equal(back.getAttribute('aria-label'),'Unmarked house card back');assert(!back.hasAttribute('data-card'));}
 const before=(await app.wallet()).balanceCents;await app.click('.player .card');await app.click(app.menu('Reveal & stamp · 6 jbits'));
 assert.equal((await app.wallet()).balanceCents,before-600);assert.equal(document.querySelector('#playerTable p51-token').getAttribute('card'),'AS');await wait(1700);
 assert(document.querySelector('#playerTable .house-stamp'));await app.click('.player .card');await app.click(app.menu('Turn to card face'));
 assert(document.querySelector('#playerTable .house-front'));await app.click('.player .card');await app.click(app.menu('Turn to stamped back'));
 assert.equal((await app.wallet()).balanceCents,before-600);
 checks.push('Telescope starts with anonymous backs; one six-jbit reveal stays stamped and subsequent flips are free');
 await app.click('.depth-button');await app.click('.player:nth-child(2) .choose-player');
 $('stamp-select').value='AS';$('stamp-select').onchange();await app.click('#stamp-practice');
 const checkpoint=JSON.parse(session.getItem('telescope51.learning-return'));assert.equal(checkpoint.selectedPlayer,1);assert(checkpoint.peeked[0]);assert(app.window.location.href.includes('return=telescope51'));
}finally{app.close();}
app=await mount('area-51/memory-51',{shared,session,search:'?card=AS&return=telescope51'});
try{assert.equal(app.$('return-blackjack').getAttribute('href'),'../telescope-51/');assert.equal(app.$('stamp-count').textContent,'6 / 51');}finally{app.close();}
app=await mount('area-51/telescope-51',{shared,session});
try{
 assert(app.document.querySelector('.player:nth-child(2).selected'));assert.equal(app.document.querySelector('#playerTable p51-token').getAttribute('card'),'AS');assert.equal(app.$('stamp-count').textContent,'6 / 51');assert.equal(session.getItem('telescope51.learning-return'),null);
 checks.push('The shared stamp collection survives a Memory trip, and returning restores the chosen Telescope rule, player, and revealed back');
 const before=(await app.wallet()).balanceCents;app.$('lab-depth').value='4';app.$('lab-depth').oninput();assert(app.$('lab-rule-result').textContent.includes('P3 remains'));assert.equal((await app.wallet()).balanceCents,before);
 checks.push('The Telescope rule lab resolves the selected three-card example without spending');
}finally{app.close();}
app=await mount('area-51/prospect-51');
try{
 const {$,document}=app;assert($('motion-readout').textContent.includes('Reduced motion'));
 await app.click('#deal');const before=await app.wallet(),initial=before.apps.prospect51.state.round.hand.slice();
 for(let i=0;i<5;i++){await app.click('#hold-'+i);assert.equal($('hold-'+i).getAttribute('aria-pressed'),'true');}
 assert.equal($('draw').textContent,'Keep five · collect');assert(!$('bank-hand'));await app.click('#draw');
 const settled=await app.wallet();assert.equal(settled.apps.prospect51.state.phase,'settled');assert.deepEqual(settled.apps.prospect51.state.round.hand,initial);assert(settled.balanceCents>=before.balanceCents);
 checks.push('Five direct Hold buttons retain the initial hand and settle through the single master control');
 await app.click('#deal');const fresh=(await app.wallet()).apps.prospect51.state.round.hand.slice();assert.equal($('draw').textContent,'Draw 5 · free');await app.click('#draw');const drawn=(await app.wallet()).apps.prospect51.state.round.hand;
 assert(drawn.every(c=>!fresh.includes(c)));
 checks.push('With no holds selected, the master button performs the approved free five-card draw');
 // Exercise frame-driven travel without a Web Animations implementation.
 delete app.window.Element.prototype.animate;$('reel-motion').value='reels';$('reel-motion').onchange();assert.equal($('motion-readout').textContent,'Scrolling reels');
 await app.click('#deal');assert.equal($('rotors').getAttribute('aria-busy'),'true');assert($('reel-motion').disabled);
 const strip=document.querySelector('.is-spinning .reel-strip'),first=strip.style.transform,committed=await app.wallet();await wait(25);assert(strip.style.transform&&strip.style.transform!==first);await app.click('#skip-reels');
 assert.equal($('rotors').getAttribute('aria-busy'),'false');assert.deepEqual(await app.wallet(),committed);
 checks.push('Explicit scrolling overrides system reduction; frame callbacks move card strips and interruption cannot redraw or pay twice');
}finally{app.close();}
app=await mount('area-51/blackjack-51');
try{
 const before=(await app.wallet()).balanceCents;await app.click('#player-hands .card');await app.click(app.menu('How the decision market works'));await wait(10);
 assert(app.$('decision-tools').open);assert(!app.$('market-start-guide').hidden);assert.equal(app.document.activeElement,app.$('decision-tools').querySelector('summary'));
 await app.click('a[href="#rule-card"]');assert(app.$('rule-card').open);assert(!app.$('play').hidden);assert.equal((await app.wallet()).balanceCents,before);
 checks.push('The starting Blackjack card opens useful market instructions; research expands while the game stays available');
}finally{app.close();}
app=await mount('');
try{
 const {document,$}=app,cards=[...document.querySelectorAll('[data-feature]')];assert.equal(cards.length,6);assert.equal(cards[0].dataset.feature,'finance');
 for(const c of cards.slice(1)){assert.equal(c.querySelector('.feature-overview').getAttribute('href'),'/area-51/');assert.equal(c.querySelector('.feature-play').getAttribute('href'),'/area-51/'+c.dataset.feature+'/');}
 await app.click('#feature-next');assert.equal($('feature-position').textContent,'Invariant · 2 / 6');assert(!cards[1].inert);await app.click('#feature-prev');assert.equal($('feature-position').textContent,'Finance Weather · 1 / 6');
 checks.push('Finance leads the homepage rotation; game-card bodies open Area 51 and explicit Play links open the matching game');
}finally{app.close();}
writeFileSync('tests/v2_4/results/MOBILE_FLOW_CHECKS.json',JSON.stringify({passed:checks.length,scope:'In-memory DOM, wallet transactions, and animation callbacks; no CSS or physical-device verification.',checks},null,2));
console.log(checks.length+' mobile interaction checks passed.');process.exit();
