import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {mount,wait} from './dom_harness.mjs';
const reports=[];
for(const game of ['invariant','blackjack-51','telescope-51','memory-51','prospect-51']){
 let app;
 try{
  app=await mount('area-51/'+game);const {$,document}=app;const checks=[];
  if(game==='invariant'){
   assert.equal(document.querySelectorAll('.next-card.card-target').length,3);checks.push('three face-down cards expose moves');
   await app.click('.next-card');assert(!app.menu('Play turn · free'));assert(app.menu('Prediction details'));await app.click('#step');assert.equal($('turn').textContent,'1');checks.push('main move advances persisted hand while cards expose decision tools');
   await app.click('.next-card');await app.click(app.menu('Reveal this top card · 6 jbits'));assert.equal((await app.wallet()).balanceCents,200);checks.push('paid reveal debits six once');
  }
  if(game==='blackjack-51'){
   assert.equal($('balance').textContent,'8');await app.click('#player-hands .card');assert(!app.menu('Deal · 2 jbits'));await app.click('#deal');checks.push('main deal uses shared bank');
   if(!$('hit').hidden){await app.click('#player-hands .active .card');assert(!app.menu('Hit · take a card'));assert(app.menu('Show safe / bust odds · 1 jbit'));await app.click('#stand');checks.push('cards expose odds; main Stand resolves round');}
   assert((await app.wallet()).apps.blackjack);assert.equal($('deal').hidden,false);
  }
  if(game==='telescope-51'){
   assert.equal(document.querySelectorAll('.card.card-target').length,3);
   await app.click('.depth-button');await app.click('.player .card');await app.click(app.menu('Choose Player 1'));assert(document.querySelector('.player.selected .action-slot button'));checks.push('tap card selects winner beside rule-depth choice');
   await app.click('.player.selected .card');assert.equal(document.querySelectorAll('.card-odds-table tbody tr').length,4);await app.click('.player.selected .action-slot button');await wait(100);checks.push('card shows reference odds; visible ticket control persists ticket');
  }
  if(game==='memory-51'){
   assert.equal(document.querySelectorAll('#answers button').length,4);
   await app.click('#prompt-object');assert(app.menu('Study / reveal pair · practice'));await app.click(app.menu('Study / reveal pair · practice'));assert($('message-title').textContent.includes('Study'));checks.push('prompt-card study marks assisted');
   await app.click('#answers button');assert.equal((await app.wallet()).balanceCents,800);checks.push('assisted answer never awards jbits');
  }
  if(game==='prospect-51'){
   assert.equal($('bank').textContent,'8.00');assert(!$('reset'));
   await app.click('#rotor-0 .reel-face');assert(!app.menu('Spin five · 1 jbit'));await app.click('#primary-move');await wait(30);
   assert.equal($('bank').textContent,'7.00');assert.equal((await app.wallet()).apps.prospect51.state.phase,'hold');checks.push('main spin deals from shared bank');
   await app.click('#rotor-0 .reel-face');await app.click(app.menu('Hold this card'));assert.equal($('hold-0').textContent,'HELD ✓');checks.push('card menu persists hold');
   const w0=await app.wallet();await app.click('#rotor-0 .reel-face');await app.click(app.menu('Turn to paper mark'));assert.equal($('token-0').getAttribute('face'),'symbol');assert.deepEqual(await app.wallet(),w0);checks.push('paper-symbol view leaves wallet and hand unchanged');
   await app.click('#primary-move');await wait(30);assert.equal((await app.wallet()).apps.prospect51.state.phase,'settled');checks.push('one redraw settles');
   const w1=await app.wallet();await app.click('[data-example="royal"]');assert.equal($('result-title').textContent,'A royal, read two ways.');assert.deepEqual(await app.wallet(),w1);checks.push('royal illustration cannot pay');
  }
  reports.push({game,passed:checks.length,checks});console.log(game,'PASS',checks.length);
 }catch(e){console.error(game,'FAIL',e.stack);reports.push({game,error:e.message});process.exitCode=1;}
 finally{app?.close();}
}
writeFileSync('tests/v2_5/results/DOM_CHECKS.json',JSON.stringify({scope:'In-memory DOM simulation, not a rendered-browser or CSS layout test.',reports},null,2));
process.exit(process.exitCode||0);
