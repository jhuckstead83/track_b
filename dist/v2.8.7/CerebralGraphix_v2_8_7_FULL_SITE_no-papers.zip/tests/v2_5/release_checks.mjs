import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {mount,storage,wait} from './dom_harness.mjs';
const checks=[],shared=storage();
let app=await mount('area-51/prospect-51',{shared,moduleOverrides:{'area-51/prospect-51/app-v2-3.js':'throw Error("Stale cached application");'}});
try{
 assert(app.loadedModules.includes('area-51/prospect-51/boot-v2-5.js'));assert(!app.loadedModules.includes('area-51/prospect-51/app-v2-3.js'));
 assert.equal(app.$('bank').textContent,'8.00');assert(!app.$('primary-move').disabled);assert(!app.$('bank-hand'));
 await app.click('#primary-move');await app.click('#hold-2');
 checks.push('The v2.5 boot path never loads the old cached app and opens the shared bank without the removed Bank button');
}finally{app.close();}
const original=JSON.parse(shared.getItem('cerebralgraphix.area51.wallet.v2.fallback'));
app=await mount('area-51/prospect-51',{shared,moduleOverrides:{'area-51/prospect-51/app-v2-5.js':'throw Error("Test presentation load failure");'}});
try{
 assert.equal(Number(app.$('bank').textContent),original.balanceCents/100);assert(!app.$('error').hidden);assert(app.$('error').textContent.includes('retained'));assert(!app.$('retry-start').hidden);assert(app.$('primary-move').disabled);
 assert.deepEqual(await app.wallet(),original);
 checks.push('A presentation-load failure leaves the existing bank visible, retains the exact hand, and gives a reload action');
}finally{app.close();}
app=await mount('area-51/prospect-51',{shared});
try{
 const current=await app.wallet();assert.deepEqual(current.apps.prospect51.state,original.apps.prospect51.state);assert.equal(current.balanceCents,original.balanceCents);assert.equal(app.$('hold-2').getAttribute('aria-pressed'),'true');
 await app.click('#rotor-2 .reel-face');assert.equal(app.$('card-actions').parentElement.id,'reel-stage');assert(app.$('card-actions').classList.contains('reel-card-actions'));
 const saved=await app.wallet(),identity=app.$('token-2').getAttribute('card');await app.click(app.menu('Turn to paper mark'));assert.equal(app.$('token-2').getAttribute('face'),'symbol');assert.equal(app.$('token-2').getAttribute('card'),identity);assert.deepEqual(await app.wallet(),saved);
 await app.click('#rotor-2 .reel-face');app.$('card-actions').dispatchEvent(Object.assign(new app.window.Event('keydown',{bubbles:true}),{key:'Escape'}));assert(app.$('card-actions').hidden);assert.equal(app.document.activeElement,app.document.querySelector('#rotor-2 .reel-face'));
 checks.push('Reload retains holds; the reel-local overlay flips the same identity without spending and returns keyboard focus to its card');
}finally{app.close();}
function clock(){let id=0;const pending=new Map();return {request(cb){pending.set(++id,cb);return id;},cancel(key){pending.delete(key);},step(now){const batch=[...pending.values()];pending.clear();for(const cb of batch)cb(now);}};}
const frames=clock();app=await mount('area-51/prospect-51',{frames});
try{
 app.$('reel-motion').value='reels';app.$('reel-motion').onchange();await app.click('#primary-move');
 const committed=await app.wallet(),strips=[...app.document.querySelectorAll('.reel-strip')],start=strips.map(s=>s.style.transform);assert.equal(app.document.querySelectorAll('.is-spinning').length,5);
 frames.step(0);frames.step(300);assert(strips.every((s,i)=>s.style.transform!==start[i]));assert.deepEqual(await app.wallet(),committed);
 frames.step(1260);assert.equal(app.document.querySelectorAll('.is-spinning').length,4);assert.equal(app.$('token-0').getAttribute('card'),committed.apps.prospect51.state.round.hand[0]);
 frames.step(2100);assert.equal(app.document.querySelectorAll('.is-spinning').length,0);assert.equal(app.$('rotors').getAttribute('aria-busy'),'false');assert(!app.$('primary-move').disabled);assert.deepEqual(await app.wallet(),committed);
 checks.push('Every symbol band travels, reels stop in sequence, and natural animation completion reveals the committed hand without another transaction');
 await app.click('#hold-1');const held=app.$('token-1').getAttribute('card');await app.click('#primary-move');const settled=await app.wallet();assert.equal(app.document.querySelectorAll('.is-spinning').length,4);assert.equal(app.$('token-1').getAttribute('card'),held);
 frames.step(3000);frames.step(3200);app.window.dispatchEvent(new app.window.Event('resize'));await wait(10);assert.equal(app.$('rotors').getAttribute('aria-busy'),'false');assert.deepEqual(await app.wallet(),settled);
 checks.push('Held reels stay fixed; resizing during the redraw cannot change the settled hand or pay twice');
 app.$('reel-motion').value='reduced';app.$('reel-motion').onchange();await app.click('#primary-move');assert.equal(app.document.querySelectorAll('.is-spinning').length,0);assert.equal(app.$('rotors').getAttribute('aria-busy'),'false');
 checks.push('Reduced motion skips travel while preserving the same deal and hold controls');
}finally{app.close();}
app=await mount('area-51/blackjack-51');
try{
 async function eligibleSeed(){
  const saved=(await app.wallet()).apps.blackjack.state.engine;
  for(let i=0;i<200;i++){const candidate='double-layout-'+i,e=app.window.BJ51.Engine.replay(saved);e.configure({...e.options,seed:candidate});e.start(1);if(e.canDouble()&&e.total(e.current().cards).total>=9&&e.total(e.current().cards).total<=11){e.act('hit');if(e.active())return candidate;}}
  throw Error('No eligible two-card fixture found');
 }
 let seed=await eligibleSeed();app.$('setting-seed').value=seed;await app.click('#new-session');await app.click('[data-bet="1"]');await app.click('#deal');
 for(const id of ['hit','stand','double'])assert(!app.$(id).hidden);assert(!app.$('double').disabled);
 await app.click('#double');const w=await app.wallet(),e=app.window.BJ51.Engine.replay(w.apps.blackjack.state.engine);assert(!e.active());assert.equal(e.round.hands[0].cards.length,3);assert.equal(e.round.hands[0].stake,2);
 checks.push('The visible Double button doubles the stake, takes exactly one card, and finishes the hand under the existing rules');
 seed=await eligibleSeed();app.$('setting-seed').value=seed;await app.click('#new-session');await app.click('[data-bet="1"]');await app.click('#deal');await app.click('#hit');
 assert(!app.$('hit').hidden);assert(!app.$('double').hidden);assert(app.$('double').disabled);
 checks.push('Double keeps its place beside Hit and Stand and disables after an ineligible hit');
}finally{app.close();}
writeFileSync('tests/v2_5/results/V25_RELEASE_CHECKS.json',JSON.stringify({passed:checks.length,scope:'In-memory DOM, sequential module loading, wallet transactions, and controlled animation frames. No CSS or device-rendering claim.',checks},null,2));
console.log(checks.length+' v2.5 release checks passed.');process.exit();
