// Runs shipped scripts against an in-memory DOM. It does NOT render CSS or emulate a browser.
import {parseHTML} from 'linkedom';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
import path from 'node:path';
import {setTimeout as timeout,setInterval as interval,clearTimeout as stopTimeout,clearInterval as stopInterval} from 'node:timers';
import {webcrypto} from 'node:crypto';
export const ROOT=path.resolve('.');
export const wait=ms=>new Promise(r=>setTimeout(r,ms));
export function storage(initial={}){const m=new Map(Object.entries(initial));return {getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),map:m};}
export async function mount(route,{shared=storage(),session=storage(),search='',crypto=webcrypto}={}){
 const filename=path.join(ROOT,route,'index.html'),{window,document}=parseHTML(readFileSync(filename,'utf8'));
 const sandbox={document},modules=new Map(),intervals=new Set(),errors=[];
 const testMotion={matches:true,addEventListener(){},removeEventListener(){}};
 const props={testMotion,console,crypto,localStorage:shared,sessionStorage:session,Date,performance,URL,Blob,Uint32Array,TextEncoder,TextDecoder,Response,URLSearchParams,queueMicrotask,
  innerWidth:390,innerHeight:844,requestAnimationFrame:cb=>setTimeout(()=>cb(performance.now()),0),cancelAnimationFrame:clearTimeout,
  setTimeout:timeout,clearTimeout:stopTimeout,setInterval:(f,t)=>{const id=interval(f,t);intervals.add(id);return id;},clearInterval:stopInterval,
  location:{href:'http://fixture.test/'+route+'/'+search,pathname:'/'+route+'/',hash:'',search},
  matchMedia:()=>testMotion,
  getComputedStyle:()=>({getPropertyValue:()=>'',display:'block'}),
  navigator:{locks:{request:async(name,work)=>work()}},
  BroadcastChannel:class{postMessage(){}addEventListener(){}},
  indexedDB:undefined,confirm:()=>false,open:()=>null,
  fetch:async url=>{let rel=String(url);if(rel.startsWith('http'))rel=new URL(rel).pathname;
   const dest=rel.startsWith('/')?path.join(ROOT,rel):path.resolve(path.dirname(filename),rel);
   const text=readFileSync(dest,'utf8');return {ok:true,status:200,json:async()=>JSON.parse(text),text:async()=>text};}
 };
 Object.assign(sandbox,props);
 for(const k of ['HTMLElement','HTMLSelectElement','Element','Node','Document','CustomEvent','Event','MutationObserver','customElements'])sandbox[k]=window[k];
 for(const k of ['addEventListener','removeEventListener','dispatchEvent'])sandbox[k]=window[k].bind(window);
 sandbox.window=sandbox;sandbox.self=sandbox;const context=vm.createContext(sandbox);
 window.HTMLElement.prototype.getBoundingClientRect=function(){return {x:40,y:200,left:40,top:200,bottom:290,right:110,width:70,height:90};};
 window.HTMLElement.prototype.focus=function(){document._testActive=this;};
 Object.defineProperty(document,'activeElement',{get:()=>document._testActive||document.body,configurable:true});
 window.HTMLElement.prototype.scrollIntoView=function(){};
 window.HTMLElement.prototype.scrollTo=function({left=0}){this.scrollLeft=left;};
 // linkedom exposes select.value as getter-only; model native select assignment for application code.
 Object.defineProperty(window.HTMLSelectElement.prototype,'value',{get(){const s=[...this.querySelectorAll('option')].find(o=>o.hasAttribute('selected'));return s?.getAttribute('value')??this.querySelector('option')?.getAttribute('value')??'';},set(v){for(const o of this.querySelectorAll('option'))o.toggleAttribute('selected',o.getAttribute('value')===String(v));},configurable:true});
 async function getModule(f){
  f=path.resolve(f);if(modules.has(f))return modules.get(f);
  const m=new vm.SourceTextModule(readFileSync(f,'utf8'),{context,identifier:f,
    importModuleDynamically:async(spec,ref)=>{const mod=await getModule(path.resolve(path.dirname(ref.identifier),spec));if(mod.status==='unlinked')await link(mod);if(mod.status!=='evaluated')await mod.evaluate();return mod;}});
  modules.set(f,m);return m;
 }
 async function link(m){await m.link((spec,ref)=>getModule(path.resolve(path.dirname(ref.identifier),spec)));}
 async function evaluateFile(f){const m=await getModule(f);if(m.status==='unlinked')await link(m);if(m.status!=='evaluated')await m.evaluate();return m;}
 const scripts=[...document.querySelectorAll('script')],deferred=[];
 for(const script of scripts){
  if(['application/json','application/ld+json'].includes(script.type))continue;
  if(script.type==='module'||script.hasAttribute('defer')){deferred.push(script);continue;}
  const src=script.getAttribute('src'),f=src?(src.startsWith('/')?path.join(ROOT,src):path.resolve(path.dirname(filename),src)):filename;
  vm.runInContext(src?readFileSync(f,'utf8'):script.textContent,context,{filename:f,importModuleDynamically:spec=>evaluateFile(path.resolve(path.dirname(f),spec))});
 }
 for(const script of deferred){
  const src=script.getAttribute('src'),f=src?(src.startsWith('/')?path.join(ROOT,src):path.resolve(path.dirname(filename),src)):filename;
  if(script.type==='module')await evaluateFile(f);else vm.runInContext(readFileSync(f,'utf8'),context,{filename:f,importModuleDynamically:spec=>evaluateFile(path.resolve(path.dirname(f),spec))});
 }
 document.dispatchEvent(new window.Event('DOMContentLoaded'));await wait(70);
 const $=id=>document.getElementById(id);
 return {window:sandbox,document,$,context,shared,async click(sel){const e=typeof sel==='string'?document.querySelector(sel):sel;if(!e)throw Error('Missing target '+sel);if(e.disabled)throw Error('Disabled target '+sel);e.click();await wait(35);},menu(label){return [...document.querySelectorAll('#card-actions button')].find(b=>b.textContent===label);},async wallet(){return JSON.parse(shared.getItem('cerebralgraphix.area51.wallet.v2.fallback'));},close(){for(const i of intervals)clearInterval(i);},evaluateFile};
}
