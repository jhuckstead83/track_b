import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../..',import.meta.url));process.chdir(root);
const env={...process.env,CG_QA_PACKAGE:fileURLToPath(new URL('./package.json',import.meta.url)),CG_CHECK_REPORT:fileURLToPath(new URL('./results/REGRESSION_CHECKS.json',import.meta.url))};
for(const name of ['check.mjs','wallet_checks.mjs','storage_checks.mjs','idb_checks.mjs','dom_checks.mjs','dom_recovery_checks.mjs','motion_checks.mjs','decision_checks.mjs','mobile_flow_checks.mjs']){
 const args=(name.startsWith('dom_')||['motion_checks.mjs','decision_checks.mjs','mobile_flow_checks.mjs'].includes(name))?['--experimental-vm-modules']:[];
 const r=spawnSync(process.execPath,[...args,fileURLToPath(new URL(name,import.meta.url))],{env,stdio:'inherit'});if(r.status!==0)process.exit(r.status||1);
}
