import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {mount,storage,wait} from './dom_harness.mjs';
const checks=[],shared=storage();let a=await mount('area-51/prospect-51',{shared});
await a.click('#deal');await wait(20);await a.click('#rotor-3 .reel-face');await a.click(a.menu('Hold · keep this card'));
const saved=(await a.wallet()).apps.prospect51.state;a.close();
a=await mount('area-51/prospect-51',{shared});assert.equal(a.$('hold-3').textContent,'HELD ✓');assert.equal(a.$('token-3').getAttribute('card'),saved.round.hand[3]);assert.equal(a.$('bank').textContent,'7.00');checks.push('Reload restores committed hand, hold and shared balance');
for(let i=0;i<5;i++)if(a.$('hold-'+i).getAttribute('aria-pressed')!=='true')await a.click('#hold-'+i);await a.click('#draw');const after=await a.wallet();a.close();a=await mount('area-51/prospect-51',{shared});assert.equal((await a.wallet()).balanceCents,after.balanceCents);assert.equal(a.$('draw').hidden,true);assert(!a.$('bank-hand'));checks.push('Reload after settlement cannot pay again');a.close();
// Cross-game handoff uses the same persisted wallet.
let b=await mount('area-51/blackjack-51',{shared});assert.equal(Number(b.$('balance').textContent),after.balanceCents/100);checks.push('Blackjack opens the balance left by Prospect');
await b.click('#deal');const bj=await b.wallet();assert(bj.apps.blackjack);b.close();
a=await mount('area-51/prospect-51',{shared});assert.equal(Number(a.$('bank').textContent),bj.balanceCents/100);checks.push('Prospect reopens the balance left by Blackjack');a.close();
// Fresh hidden shuffle: no identity in the card label before paid reveal.
a=await mount('area-51/invariant');a.$('start').value='random';await a.click('#reset');const label=a.document.querySelector('.next-card').getAttribute('aria-label');assert(label.includes('face-down'));
await a.click('.next-card');const call=a.menu('Call P1 & play · 1 jbit');assert(call&&!call.disabled);await a.click(call);assert.equal(a.$('turn').textContent,'1');assert.equal((await a.wallet()).apps.invariant.state.predictions.length,1);checks.push('Hidden-card prediction uses chosen player and persists the call');a.close();
a=await mount('area-51/blackjack-51');await a.click('#deal');const visible=a.document.querySelector('#player-hands .card[data-card]');const card=visible.dataset.card,prior=await a.wallet();await a.click(visible);await a.click(a.menu('Inspect paper symbol'));assert.equal(a.document.querySelector('p51-token[face="symbol"]').getAttribute('card'),card);assert.deepEqual(await a.wallet(),prior);checks.push('Blackjack paper-symbol inspection preserves hand and bank');a.close();
writeFileSync('tests/v2_3/results/DOM_RECOVERY_CHECKS.json',JSON.stringify({passed:checks.length,scope:'In-memory DOM simulation; no CSS or rendered-browser claim.',checks},null,2));console.log(checks.length+' UI recovery/continuity checks passed.');process.exit();
