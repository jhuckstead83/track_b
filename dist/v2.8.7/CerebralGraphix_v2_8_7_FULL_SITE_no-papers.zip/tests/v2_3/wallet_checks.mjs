import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import vm from 'node:vm';
import {webcrypto} from 'node:crypto';
import {fresh,post} from '../../area-51/assets/wallet-core-v2-0b3.js';
import {account,updateAccount} from '../../area-51/prospect-51/account-v2-3.js';
const scope={crypto:webcrypto};scope.globalThis=scope;vm.createContext(scope);
for(const f of ['data.js','engine.js'])vm.runInContext(readFileSync(new URL('../../area-51/prospect-51/'+f,import.meta.url),'utf8'),scope);
const E=scope.P51Engine,copy=x=>JSON.parse(JSON.stringify(x));
const checks=[];function check(name,fn){fn();checks.push(name);}
const at=1700000000000,settings={wire:'geared',knob:7};
let w=fresh(at),r=account(w,E),op=0;
function action(kind,extra={}){return updateAccount(w,{kind,...extra,operationId:'op-'+(++op),expectedRevision:r.revision},E,at);}
check('New Prospect account adopts shared balance; never grants demo 100',()=>assert.equal(r.state.balanceCents,800));
check('One deal atomically debits 1 jbit and increments meter by 0.01',()=>{r=action('deal',{settings});assert.equal(w.balanceCents,700);assert.equal(r.state.meterCents,5101);assert.equal(w.receipts['prospect51:1:entry'].deltaCents,-100);});
check('Same operation ID retries without redraw, debit or meter increment',()=>{const before=copy(w);const again=updateAccount(w,{kind:'deal',settings,operationId:'op-'+op,expectedRevision:1},E,at);assert.deepEqual(copy(w),before);assert.deepEqual(again,r);});
check('Operation ID cannot change its terms',()=>assert.throws(()=>updateAccount(w,{kind:'bank',operationId:'op-'+op,expectedRevision:1},E,at),/different terms/));
check('Another tab cannot replace a live hand from a stale revision',()=>{const before=copy(w);assert.throws(()=>updateAccount(w,{kind:'deal',settings,operationId:'stale',expectedRevision:1},E,at),/another tab/);assert.deepEqual(copy(w),before);});
check('Hold changes neither balance, meter nor identity',()=>{const before=copy(r.state);r=action('hold',{slot:2});assert.equal(w.balanceCents,700);assert.equal(r.state.meterCents,before.meterCents);assert.deepEqual(r.state.round.hand,before.round.hand);assert(r.state.round.holds[2]);});
check('JSON reload preserves exact hand and hold',()=>{w=copy(w);r=account(w,E);assert(r.state.round.holds[2]);assert.equal(r.state.phase,'hold');});
check('Award from another game is retained at Prospect settlement',()=>{post(w,{id:'test-memory',source:'memory51',kind:'four-way-recall',deltaCents:200},at);r=action('bank');assert.equal(w.balanceCents,900+r.state.round.result.totalCents);});
check('Settlement retry returns checkpoint and cannot pay twice',()=>{const before=copy(w);const retry=updateAccount(w,{kind:'bank',operationId:'op-'+op,expectedRevision:r.revision-1},E,at);assert.deepEqual(copy(w),before);assert.equal(retry.state.phase,'settled');assert.throws(()=>action('bank'),/settled/);});
check('Insufficient funds do not commit a hand, meter or receipt',()=>{const poor=fresh(at);poor.balanceCents=99;const a=account(poor,E),before=copy(poor);assert.throws(()=>updateAccount(poor,{kind:'deal',settings,operationId:'poor',expectedRevision:a.revision},E,at));assert.deepEqual(copy(poor),before);});
check('Malformed account fails closed',()=>{const bad=copy(w);bad.apps.prospect51.state.round.remaining=['2C'];assert.throws(()=>account(bad,E));});
for(let mask=0;mask<32;mask++){
 const a=fresh(at);a.balanceCents=50000;let rec=account(a,E),n=0;
 const run=(kind,extra={})=>{rec=updateAccount(a,{kind,...extra,expectedRevision:rec.revision,operationId:'mask'+mask+':'+(++n)},E,at);};
 run('deal',{settings});const initial=copy(rec.state.round.initial);
 for(let i=0;i<5;i++)if(mask&(1<<i))run('hold',{slot:i});
 const before=a.balanceCents;run('draw');
 for(let i=0;i<5;i++)if(mask&(1<<i))assert.equal(rec.state.round.hand[i],initial[i]);else assert(!initial.includes(rec.state.round.hand[i]));
 assert.equal(a.balanceCents,before+rec.state.round.result.totalCents);assert.equal(new Set(rec.state.round.hand).size,5);
}
checks.push('All 32 shared-wallet hold masks preserve kept cards, exclude discards and settle exactly once');
function forceInitial(key){
 return {...E,deal(s,sets){const nextNo=s.roundNo+1;let pool=E.CARDS.slice(),i=0,carry=nextNo;
 return E.deal(s,sets,m=>{const j=i+1,a=E.gear(m,j,sets.wire),b=(sets.knob+j*(j+1)/2+carry)%m,e=pool.indexOf(key[i]);let d=0;while((a*d+b)%m!==e)d++;pool.splice(e,1);carry+=e+1;i++;return d;});}};
}
check('Exact initial archive hit reserves 51.01 jbits and adds poker award once',()=>{
 const a=fresh(at);const x=account(a,E);const F=forceInitial(E.ARCHIVE_KEY);
 const d=updateAccount(a,{kind:'deal',settings,expectedRevision:x.revision,operationId:'jack-deal'},F,at);
 assert.equal(d.state.round.pendingBonusCents,5101);assert.equal(d.state.meterCents,5100);assert.equal(a.balanceCents,700);
 const s=updateAccount(a,{kind:'bank',expectedRevision:d.revision,operationId:'jack-bank'},E,at);
 assert.equal(a.balanceCents,6001);assert.equal(s.state.round.result.grossCents,200);assert.equal(s.state.round.result.bonusCents,5101);
});
check('Archive reservation survives replacing the initial five cards',()=>{
 const a=fresh(at),x=account(a,E),F=forceInitial(E.ARCHIVE_KEY);
 const d=updateAccount(a,{kind:'deal',settings,expectedRevision:x.revision,operationId:'jd'},F,at);
 const s=updateAccount(a,{kind:'draw',expectedRevision:d.revision,operationId:'jf'},E,at);
 assert(!E.isKey(s.state.round.hand));assert.equal(s.state.round.result.bonusCents,5101);
});
check('One swap loses archive eligibility while preserving two-pair score',()=>{
 const a=fresh(at),x=account(a,E),key=[...E.ARCHIVE_KEY];[key[0],key[1]]=[key[1],key[0]];
 const d=updateAccount(a,{kind:'deal',settings,expectedRevision:x.revision,operationId:'sd'},forceInitial(key),at);
 assert.equal(d.state.round.pendingBonusCents,0);assert.equal(E.score(d.state.round.hand).category,2);
});
writeFileSync(new URL('./results/WALLET_CHECKS.json',import.meta.url),JSON.stringify({passed:checks.length,checks},null,2));console.log(checks.length+' shared-account checks passed, including 32 hold masks.');
