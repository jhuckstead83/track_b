// Focused review-checkpoint checks. This is not a browser/device or strategy study.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
const here=path.dirname(fileURLToPath(import.meta.url)),root=path.resolve(here,'../..');
const require=createRequire(process.env.CG_QA_PACKAGE||import.meta.url);
const {parse}=require('acorn'),{parseHTML}=require('linkedom'),{indexedDB}=require('fake-indexeddb');
const read=p=>fs.readFileSync(path.join(root,p),'utf8'),plain=x=>JSON.parse(JSON.stringify(x));
let checks=0;const results={};
function check(value,label){assert.ok(value,label);checks++;}
function eq(a,b,label){assert.deepEqual(plain(a),plain(b),label);checks++;}
function throws(f,re,label){assert.throws(f,re,label);checks++;}
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)]);}
const area=path.join(root,'area-51'),pages=[path.join(root,'index.html'),...walk(area).filter(f=>f.endsWith('.html'))];
let parsedScripts=0,localLinks=0;
for(const page of pages){
  const {document}=parseHTML(fs.readFileSync(page,'utf8')),ids=[...document.querySelectorAll('[id]')].map(x=>x.id);
  eq(new Set(ids).size,ids.length,path.relative(root,page)+': unique IDs');
  for(const script of document.querySelectorAll('script:not([src])')){
    if(script.type&&script.type!=='module'&&script.type!=='text/javascript'){if(script.type.includes('json'))JSON.parse(script.textContent);continue;}
    parse(script.textContent,{ecmaVersion:'latest',sourceType:script.type==='module'?'module':'script'});parsedScripts++;
  }
  for(const el of document.querySelectorAll('a[href],link[href],script[src],img[src]')){
    const ref=el.getAttribute('href')||el.getAttribute('src');if(!ref||/^[a-z]+:|^\/\//i.test(ref))continue;
    const [target,hash]=ref.split('#'),clean=decodeURIComponent(target.split('?')[0]);
    let resolved=clean?(clean.startsWith('/')?path.join(root,clean):path.resolve(path.dirname(page),clean)):page;
    if(fs.existsSync(resolved)&&fs.statSync(resolved).isDirectory())resolved=path.join(resolved,'index.html');
    check(fs.existsSync(resolved),path.relative(root,page)+' -> '+ref);localLinks++;
    if(hash&&resolved===page)check(ids.includes(decodeURIComponent(hash)),'Missing local anchor '+ref+' on '+page);
  }
  // Catch missing controls without claiming a rendered-browser pass.
  const own=path.join(path.dirname(page),'app.js');
  if(fs.existsSync(own)&&page.endsWith('index.html'))for(const m of fs.readFileSync(own,'utf8').matchAll(/\$\('([^']+)'\)/g))check(ids.includes(m[1]),'Missing app control '+m[1]+' on '+page);
}
for(const f of walk(area).filter(f=>f.endsWith('.js'))){parse(fs.readFileSync(f,'utf8'),{ecmaVersion:'latest',sourceType:'module'});parsedScripts++;}
results.static={pages:pages.length,parsedScripts,localLinks};

const core=await import('../../area-51/assets/wallet-core-v2-0b.js'),{fresh,post,accrue,recall,migrate,POLICY}=core;
const at=Date.UTC(2026,8,21),s=fresh(at);
post(s,{id:'spend',source:'test',kind:'stake',deltaCents:-150},at);
eq(s.balanceCents,650,'Stake debited');
post(s,{id:'spend',source:'test',kind:'stake',deltaCents:-150},at);
eq(s.balanceCents,650,'Duplicate stake not debited');
throws(()=>post(s,{id:'spend',source:'test',kind:'stake',deltaCents:-100},at),/different terms/);
throws(()=>post(s,{id:'overdraw',source:'test',kind:'stake',deltaCents:-900},at),/Not enough/);
eq(accrue(s,at-100),0,'Backward clock does not mint');
eq(accrue(s,at+POLICY.interval),100,'Timed unit');
eq(accrue(s,at+POLICY.interval*2),50,'Fractional cap');
eq(s.balanceCents,800,'Recovery capped at 8');
post(s,{id:'win',source:'test',kind:'win',deltaCents:1234},at+POLICY.interval*2);
eq(accrue(s,at+POLICY.interval*20),0,'Winnings are retained, not refilled');
eq(s.balanceCents,2034);
const legacy=migrate({schema:'cerebralgraphix.area51.credit-ledger.v1',balanceCents:266,entries:[],recoveryCursorAt:at},at);
eq(legacy.balanceCents,266,'Migration preserves balance');
const legacyCredits=migrate({schema:'cerebralgraphix.area51.credits.v1',balance:3.25,recoveryCursorAt:at},at);
eq(legacyCredits.balanceCents,325,'Deployed credits.v1 balance migrates');
throws(()=>migrate({schema:'broken'},at),/cannot be verified/);
const memory=fresh(at);
eq(recall(memory,{id:'study',correct:true,assisted:true},at).entry.deltaCents,0,'Study earns zero');
eq(recall(memory,{id:'wrong',correct:false,assisted:false},at).entry.deltaCents,0,'Incorrect earns zero');
for(let i=0;i<5;i++)recall(memory,{id:'answer'+i,correct:true,assisted:false},at);
eq(memory.recallPaid,800,'Recall daily cap');
eq(memory.balanceCents,1600);
recall(memory,{id:'answer0',correct:true,assisted:false},at);
eq(memory.balanceCents,1600,'Recall retry earns zero');
results.walletCore='passed';

const frozen=read('research/line-game/Invariant_v7_2.html'),published=frozen.match(/<script id="game-engine">([\s\S]*?)<\/script>/)[1];
eq(read('area-51/invariant/engine.js').trim(),published.trim(),'Published Invariant transition unchanged');
const ic=vm.createContext({});vm.runInContext(published,ic);const {CardGame,rankDeck,decimalRank}=ic.InvariantEngine;
const experiment=JSON.parse(read('area-51/invariant/experiment.json'));
eq(String(rankDeck(experiment.deck)),'14134725141735');
const swapped=experiment.deck.slice();[swapped[49],swapped[50]]=[swapped[50],swapped[49]];
eq(decimalRank(rankDeck(swapped)),'14.134725141734');
const before=new CardGame(experiment.before),after=new CardGame(experiment.after);
for(const g of [before,after])while(g.status==='playing'&&g.turn<2000)g.step();
eq([before.status,before.turn],['finished',144],'Published finish');
eq([after.status,after.cycle],['cycle',{entry:1015,repeat:1535,period:520}],'Published cycle');
after.forgive();eq(after.hands.flat().length+after.bank.length,51,'Forgiveness conservation');
results.invariant={finish:before.turn,cycle:{entry:1015,repeat:1535,period:520}};

const bjhtml=read('area-51/blackjack-51/index.html'),bjscript=bjhtml.match(/<script id="blackjack-engine">([\s\S]*?)<\/script>/)[1];
const bc=vm.createContext({});vm.runInContext(bjscript,bc);const {Engine,handValue,marketQuote,SOURCE_A,SOURCE_B,value}=bc.BJ51;
eq(SOURCE_A.map(value),SOURCE_B.map(value),'A/B blackjack value profile');
eq(SOURCE_A,experiment.deck.slice(0,51),'Blackjack uses the published active order');
eq(handValue(['AS','6H','10D']).total,17,'Flexible ace');
const settle=e=>{while(e.active())e.act('stand');return e;};
const e=new Engine({seed:'v2-checkpoint'},{balance:100});e.start(2);settle(e);const cursor=e.shoe.cursor;e.start(2);check(e.shoe.cursor>cursor&&e.shoe.number===1,'Second hand consumes same shoe');settle(e);
e.reconcile(2.66,'fractional-test');eq(Engine.replay(e.snapshot()).snapshot(),e.snapshot(),'Fractional balance replay');
const quoteInput={choice:'safe',hand:['10S','6H'],pool:['AS','KD','2D','4H','9C'],dealerUp:'AH',ace:'flex'};
const q=marketQuote(quoteInput);let total=0,favorable=0;
for(const hole of quoteInput.pool){if(value(hole)===10)continue;for(const next of quoteInput.pool){if(next===hole)continue;total++;if(!handValue([...quoteInput.hand,next]).bust)favorable++;}}
eq([q.total,q.favorable],[total,favorable],'Quote conditions on failed dealer blackjack check');
const fixture=new Engine({},{balance:8});fixture.shoe.deck=['AS','9H','KS','7C',...fixture.shoe.deck.filter(c=>!['AS','9H','KS','7C'].includes(c))];fixture.start(2);
eq([fixture.bank,fixture.round.hands[0].result],[11,'blackjack'],'Natural pays 3:2');
results.blackjack='persistent-shoe, fractional replay, natural settlement, and conditional quote passed';

// One fake IndexedDB exercises the actual wallet transaction and game adapter.
// It does not replace the outstanding real-browser/multiple-window gate.
const localRecords=new Map([['cerebralgraphix.area51.credits.v1','{malformed legacy bank']]);
globalThis.indexedDB=indexedDB;globalThis.localStorage={getItem:key=>localRecords.has(key)?localRecords.get(key):null,setItem:(key,value)=>localRecords.set(key,value),removeItem:key=>localRecords.delete(key)};
globalThis.BroadcastChannel=class{addEventListener(){}postMessage(){}};
const bank=await import('../../area-51/assets/credits-v2-0b2.js');await bank.ready;
await assert.rejects(bank.atomic(w=>{post(w,{id:'abort',source:'test',kind:'stake',deltaCents:-100},Date.now());w.apps.test={state:'should not commit'};throw Error('forced abort');}),/forced abort/);checks++;
let w=await bank.readWallet();eq([w.balanceCents,w.apps.test],[800,undefined],'Wallet and checkpoint roll back together');
const pair=await Promise.all([bank.transact({id:'duplicate',source:'test',kind:'stake',deltaCents:-100}),bank.transact({id:'duplicate',source:'test',kind:'stake',deltaCents:-100})]);
eq(pair.filter(r=>r.applied).length,1,'Concurrent duplicate applied once');
const adapter=vm.createContext({BJ51:bc.BJ51,__walletAPI:bank,Date});
vm.runInContext(read('area-51/blackjack-51/wallet-adapter-v2-0b2.js').replace("import('../assets/credits-v2-0b2.js')",'Promise.resolve(globalThis.__walletAPI)'),adapter);
const store=adapter.CGBlackjack51Store,initial=await store.read();
let game=new Engine({seed:'adapter-check'},{balance:initial.initialBalance});
const envelope=engine=>({schema:'cg-blackjack51-bank-v1',engine:engine.snapshot(),lastAccrualAt:Date.now()});
let record=await store.compareAndSwap({expectedRevision:0,operationId:'init',state:envelope(game)});
game=Engine.replay(record.state.engine);game.start(2);
record=await store.compareAndSwap({expectedRevision:record.revision,operationId:'deal',state:envelope(game)});
w=await bank.readWallet();eq(w.balanceCents,Math.round(record.state.engine.bank*100),'Stake and hand commit together');
const retry=await store.compareAndSwap({expectedRevision:record.revision-1,operationId:'deal',state:envelope(game)});
eq(retry.revision,record.revision,'Same operation retry is idempotent');
await assert.rejects(store.compareAndSwap({expectedRevision:0,operationId:'stale',state:envelope(game)}),/Another tab/);checks++;
game=Engine.replay(record.state.engine);settle(game);record=await store.compareAndSwap({expectedRevision:record.revision,operationId:'stand',state:envelope(game)});
w=await bank.readWallet();eq(w.balanceCents,Math.round(record.state.engine.bank*100),'Settlement and hand commit together');
await bank.transact({id:'recall-fixture',source:'test',kind:'earn',deltaCents:200});record=await store.read();
eq(record.state.engine.bank,(await bank.readWallet()).balanceCents/100,'Outside earnings reconcile into table');
const telescope=await import('../../area-51/telescope-51/wallet-v2-0b2.js');
const ticket=await telescope.settleTicket({branch:'A',round:0,correct:true,reward:4,evidence:{test:true}});
eq(ticket.value.payout,4);const balance=(await bank.readWallet()).balanceCents;
const repeated=await telescope.settleTicket({branch:'A',round:0,correct:true,reward:4,evidence:{test:true}});
eq(repeated.value.funded,false);eq((await bank.readWallet()).balanceCents,balance,'Known Telescope repeat cannot mint');
await telescope.recordTwinExposure('B',0);eq((await telescope.settleTicket({branch:'B',round:0,correct:true,reward:51,evidence:{test:true}})).value.funded,false,'Exposed twin is study');
results.transactionIntegration='rollback, duplicate receipt, blackjack CAS/settlement, cross-game balance, and Telescope repeat passed';

// Reproduce the reported failure: IndexedDB opens but never fires an event.
// The new entry point must time out into the same-origin fallback and stay usable.
localRecords.clear();globalThis.indexedDB={open(){return {};}};
const fallbackStarted=Date.now(),fallbackBank=await import('../../area-51/assets/credits-v2-0b2.js?hung-indexeddb');
await fallbackBank.ready;check(Date.now()-fallbackStarted<1600,'Hung IndexedDB falls back promptly');
eq(fallbackBank.getCreditSnapshot().balanceCents,800,'Fallback bank opens at 8 jbits');
await fallbackBank.transact({id:'fallback-spend',source:'test',kind:'stake',deltaCents:-100});
eq(fallbackBank.getCreditSnapshot().balanceCents,700,'Fallback bank can fund a game action');
const reloadedFallback=await import('../../area-51/assets/credits-v2-0b2.js?reload-fallback');await reloadedFallback.ready;
eq(reloadedFallback.getCreditSnapshot().balanceCents,700,'Fallback bank survives a module reload');
results.storageFallback='hung IndexedDB timeout, playable local fallback, and reload persistence passed';
const maintained={
  home:read('index.html'),hub:read('area-51/index.html'),invariant:read('area-51/invariant/index.html'),
  blackjack:read('area-51/blackjack-51/index.html'),telescope:read('area-51/telescope-51/index.html'),memory:read('area-51/memory-51/index.html')
};
check(maintained.home.includes('/assets/site-v2-0b.css'),'Homepage uses fingerprinted hero CSS');
check(read('assets/site-v2-0b.css').includes('.v2-area-hero'),'Fingerprinted CSS contains hero rules');
check(maintained.hub.includes('bank-display-v2-0b2.js'),'Hub uses second fingerprinted shared bank');
check(maintained.invariant.includes('app-v2-0b2.js')&&maintained.invariant.includes('bank-display-v2-0b2.js'),'Invariant uses second fingerprinted table and bank');
check(maintained.blackjack.includes('wallet-adapter-v2-0b2.js'),'Blackjack uses second fingerprinted wallet adapter');
check(maintained.telescope.includes('app-v2-0b2.js')&&maintained.telescope.includes('bank-display-v2-0b2.js'),'Telescope uses second fingerprinted table and bank');
check(maintained.telescope.includes('.game.shell{margin-inline:auto}'),'Telescope table shell restores centered inline margins');
check(maintained.memory.includes('./app-v2-0b2.js')&&maintained.memory.includes('id="bank">—</div>'),'Memory waits for the shared bank instead of showing a hard-coded balance');
results.hotfix='fingerprinted bank recovery on all entry points and Telescope table centering passed';
const report={status:'PASS_SCOPED_CHECKPOINT_CHECKS',checks,...results,notRun:['Browser rendering and real multi-window persistence','Device/accessibility review','Full website discovery/feed/Atlas validation','Finance live data or prediction bank']};
if(process.env.CG_CHECK_REPORT)fs.writeFileSync(process.env.CG_CHECK_REPORT,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
