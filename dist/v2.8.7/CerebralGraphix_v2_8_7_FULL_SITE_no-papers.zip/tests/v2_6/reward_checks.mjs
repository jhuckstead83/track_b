import assert from 'node:assert/strict';
import path from 'node:path';
import {webcrypto} from 'node:crypto';
import {writeFileSync} from 'node:fs';
import {mount,storage,wait} from './dom_harness.mjs';

const checks=[],audio={contexts:[],starts:[],stops:[]};
class Param{setValueAtTime(){}linearRampToValueAtTime(){}exponentialRampToValueAtTime(){}}
class FakeAudio{
 constructor(){this.state='suspended';this.currentTime=0;this.destination={};audio.contexts.push(this);}
 async resume(){this.state='running';}
 createGain(){return {gain:new Param(),connect(){},disconnect(){}};}
 createOscillator(){return {frequency:new Param(),connect(){},disconnect(){},start(at){audio.starts.push(at);},stop(at){audio.stops.push(at);if(at===undefined)this.onended?.();}};}
}
const globals={AudioContext:FakeAudio};
let app=await mount('area-51/prospect-51',{globals});
let E;
try{
 E=app.window.P51Engine;
 const {scoringSlots}= (await app.evaluateFile(path.resolve('area-51/prospect-51/rewards-v2-6.js'))).namespace;
 const cases=[
  [['AS','8H','7D','3C','JS'],0,[]],
  [['5S','5H','8C','QD','AS'],0,[]],
  [['JS','JD','4C','7H','9S'],1,[0,1]],
  [['5S','5H','QC','QD','KS'],2,[0,1,2,3]],
  [['5H','KS','KD','4S','KC'],3,[1,2,4]],
  [['AS','2H','3D','4S','5C'],4,[0,1,2,3,4]],
  [['AH','3H','7H','9H','QH'],5,[0,1,2,3,4]],
  [['KS','KD','KH','4S','4C'],6,[0,1,2,3,4]],
  [['KS','KH','KD','KC','7D'],7,[0,1,2,3]],
  [['4S','5S','6S','7S','8S'],8,[0,1,2,3,4]],
  [['10H','JH','QH','KH','AH'],9,[0,1,2,3,4]]
 ];
 for(const [hand,category,slots]of cases){assert.equal(E.score(hand).category,category);assert.deepEqual(Array.from(scoringSlots(hand,category)),slots);}
 checks.push('All ten scoring categories and a nonpaying low pair highlight exactly the contributing identities; the screenshot hand marks only slots 2, 3, and 5');
 app.window.testMotion.matches=false;
 const wallet=await app.wallet();assert.equal(audio.contexts.length,0);
 await app.click('[data-example="kings"]');
 assert.equal(app.$('prospect-machine').dataset.reward,'example');
 assert.deepEqual([...app.document.querySelectorAll('.scoring-rotor')].map(n=>n.id),['rotor-1','rotor-2','rotor-4']);
 assert.equal(app.document.querySelectorAll('.jbit-coin').length,12);assert(!app.$('bank').classList.contains('jbit-arrival'));
 assert(!app.$('example-banner').hidden);assert(app.$('result-note').textContent.includes('no jbits awarded'));
 assert.deepEqual(await app.wallet(),wallet);assert.equal(audio.contexts.length,0);
 await app.click('#exit-example');assert.equal(app.document.querySelectorAll('.jbit-coin').length,0);
 checks.push('The Three kings preview shows the same contributing cards and decorative coins without changing the wallet, pulsing the bank, or creating audio while muted');
 await app.click('#sound-toggle');assert.equal(audio.contexts.length,1);assert(audio.starts.length>0);
 await app.click('#sound-toggle');assert.equal(app.$('sound-toggle').getAttribute('aria-pressed'),'false');
 const silentCount=audio.starts.length;await app.click('[data-example="royal"]');assert.equal(audio.starts.length,silentCount);assert.deepEqual(await app.wallet(),wallet);
 app.window.dispatchEvent(new app.window.Event('pagehide'));assert.equal(app.document.querySelectorAll('.jbit-coin').length,0);
 checks.push('Sound is created only after an explicit gesture; mute and page exit stop scheduled tones and effects');
 const {ProspectSounds}=(await app.evaluateFile(path.resolve('area-51/prospect-51/sounds-v2-6.js'))).namespace;
 let resumeAudio;
 app.window.AudioContext=class extends FakeAudio{resume(){return new Promise(resolve=>{resumeAudio=()=>{this.state='running';resolve();};});}};
 const sounds=new ProspectSounds(app.document.createElement('button'));sounds.enabled=true;
 let starting=sounds.unlock(),before=audio.starts.length;sounds.award({netCents:200,category:3});assert.equal(audio.starts.length,before);resumeAudio();await starting;await wait(0);assert(audio.starts.length>before);
 sounds.silence();sounds.context.state='suspended';starting=sounds.unlock();before=audio.starts.length;sounds.award({netCents:200,category:3});sounds.silence();resumeAudio();await starting;await wait(0);assert.equal(audio.starts.length,before);
 checks.push('A win cue waits for delayed audio activation, and muting or cancelling before activation prevents that queued cue');
}finally{app.close();}

function cryptoFor(hand,redraw=[]){
 const pool=Array.from(E.CARDS),digits=[];let carry=1;
 for(const [slot,card]of hand.entries()){
  const m=pool.length,e=pool.indexOf(card),j=slot+1,b=E.mod(j*(j+1)/2+carry,m);
  digits.push(E.mod(e-b,m));pool.splice(e,1);carry+=e+1;
 }
 carry=52;
 for(const [slot,card]of redraw){const m=pool.length,e=pool.indexOf(card),j=slot+1,b=E.mod(j*(j+1)/2+carry,m);digits.push(E.mod(e-b,m));pool.splice(e,1);carry+=e+1;}
 return {randomUUID:()=>webcrypto.randomUUID(),getRandomValues(word){assert(digits.length,'Fixture requested unexpected game randomness');word[0]=digits.shift();return word;}};
}
async function settledFixture(hand,{reduced=false}={}){
 const shared=storage(),app=await mount('area-51/prospect-51',{shared,crypto:cryptoFor(hand),globals});
 app.window.testMotion.matches=false;
 app.$('wiring').value='straight';app.$('reel-motion').value='reduced';app.$('reel-motion').onchange();
 await app.click('#primary-move');assert.deepEqual((await app.wallet()).apps.prospect51.state.round.hand,hand);
 assert.equal(app.document.querySelectorAll('.scoring-card').length,0);
 for(let i=0;i<5;i++)await app.click('#hold-'+i);
 if(!reduced){app.$('reel-motion').value='reels';app.$('reel-motion').onchange();}
 await app.click('#primary-move');return {app,shared};
}
let shared;
({app,shared}=await settledFixture(['5H','KS','KD','4S','KC']));
try{
 const settled=await app.wallet();assert.equal(settled.balanceCents,1000);assert.equal(settled.apps.prospect51.state.round.result.netCents,200);
 assert.equal(app.document.querySelectorAll('.scoring-card').length,3);assert.equal(app.document.querySelectorAll('.jbit-coin').length,12);
 assert(app.$('prospect-machine').classList.contains('celebrating'));
 const count=app.document.querySelector('.award-count');assert(Number(count.textContent)>=0&&Number(count.textContent)<=3);
 await app.click('#rotor-1 .reel-face');await app.click(app.menu('Turn to paper mark'));
 assert.equal(app.document.querySelectorAll('.scoring-card').length,3);assert.equal(app.$('token-1').getAttribute('face'),'symbol');assert.deepEqual(await app.wallet(),settled);
 app.window.dispatchEvent(new app.window.Event('resize'));assert.equal(app.document.querySelectorAll('.jbit-coin').length,0);assert.equal(app.document.querySelector('.award-count').textContent,'3.00');
 assert.deepEqual(await app.wallet(),settled);
 checks.push('A real three-kings settlement credits exactly 3.00 gross, highlights all three kings, counts to the recorded award, and survives card inspection and resize without another transaction');
}finally{app.close();}
app=await mount('area-51/prospect-51',{shared,globals});
try{
 assert.equal((await app.wallet()).balanceCents,1000);assert.equal(app.document.querySelectorAll('.scoring-card').length,3);assert.equal(app.document.querySelectorAll('.jbit-coin').length,0);assert(!app.$('prospect-machine').classList.contains('celebrating'));
 checks.push('Reload restores settled highlights and the exact bank but never replays the reward animation');
}finally{app.close();}

for(const [hand,label,slots]of [
 [['JS','JD','4C','7H','9S'],'return',2],
 [['AS','8H','7D','3C','JS'],'none',0]
]){
 ({app}=await settledFixture(hand));
 try{
  assert.equal(app.$('prospect-machine').dataset.reward,label);assert.equal(app.document.querySelectorAll('.scoring-card').length,slots);assert.equal(app.document.querySelectorAll('.jbit-coin').length,0);assert(!app.$('prospect-machine').classList.contains('celebrating'));
 }finally{app.close();}
}
checks.push('An entry-returning pair gets quiet static feedback; a no-award hand has no winning lights or coins');

function clock(){let id=0;const pending=new Map();return {request(cb){pending.set(++id,cb);return id;},cancel(key){pending.delete(key);},step(now){const callbacks=[...pending.values()];pending.clear();for(const cb of callbacks)cb(now);}};}
const frames=clock();
app=await mount('area-51/prospect-51',{frames,crypto:cryptoFor(['5H','KS','KD','4S','7C'],[[0,'9D'],[3,'2S'],[4,'KC']]),globals});
try{
 app.window.testMotion.matches=false;app.$('wiring').value='straight';app.$('reel-motion').value='reduced';app.$('reel-motion').onchange();
 await app.click('#primary-move');await app.click('#hold-1');await app.click('#hold-2');
 app.$('reel-motion').value='reels';app.$('reel-motion').onchange();await app.click('#primary-move');
 const committed=await app.wallet();assert.equal(committed.balanceCents,1000);assert.equal(app.$('rotors').getAttribute('aria-busy'),'true');assert.equal(app.document.querySelectorAll('.scoring-card,.jbit-coin').length,0);
 frames.step(0);frames.step(2100);assert.equal(app.$('rotors').getAttribute('aria-busy'),'false');assert.equal(app.document.querySelectorAll('.scoring-card').length,3);assert.equal(app.document.querySelectorAll('.jbit-coin').length,12);assert.deepEqual(await app.wallet(),committed);
 Object.defineProperty(app.document,'hidden',{value:true,configurable:true});app.document.dispatchEvent(new app.window.Event('visibilitychange'));
 assert.equal(app.document.querySelectorAll('.jbit-coin').length,0);assert.equal(app.document.querySelector('.award-count').textContent,'3.00');assert.deepEqual(await app.wallet(),committed);
 checks.push('A winning redraw commits once, waits for all moving reels before highlighting or celebrating, and stops its effects immediately when the page is hidden');
}finally{app.close();}

({app}=await settledFixture(['5H','KS','KD','4S','KC'],{reduced:true}));
try{
 assert.equal(app.document.querySelectorAll('.scoring-card').length,3);assert.equal(app.document.querySelectorAll('.jbit-coin').length,0);assert.equal(app.document.querySelector('.award-count').textContent,'3.00');assert.equal((await app.wallet()).balanceCents,1000);
 checks.push('Reduced motion presents the exact final award and winning cards immediately, without a coin flight or count-up');
}finally{app.close();}

app=await mount('area-51/prospect-51');
try{
 await app.click('#sound-toggle');assert(app.$('sound-toggle').disabled);assert.equal(app.$('sound-toggle').textContent,'♪ Sound unavailable');
 await app.click('#primary-move');assert.equal((await app.wallet()).apps.prospect51.state.phase,'hold');assert(app.$('error').hidden);
 checks.push('A browser without Web Audio can still open the shared bank and play normally');
}finally{app.close();}
writeFileSync('tests/v2_6/results/V26_REWARD_CHECKS.json',JSON.stringify({passed:checks.length,scope:'Approved scorer fixtures, in-memory game/wallet interaction, mock Web Audio scheduling, and effect lifecycle; no native rendering or listening claim.',checks},null,2));
console.log(checks.length+' v2.6 reward checks passed.');process.exit();
