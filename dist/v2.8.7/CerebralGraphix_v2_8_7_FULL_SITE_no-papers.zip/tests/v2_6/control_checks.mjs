import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import path from 'node:path';
import {parse as parseCSS} from 'cssom';
import {parse as parseSelector,stringify} from 'css-what';
import {mount} from './dom_harness.mjs';

// Resolve authored declarations for these controls only. This does not lay out,
// paint, hit-test, or replace a real browser/device review.
function specificity(tokens){return tokens.reduce((n,t)=>n+(t.type==='attribute'?(t.name==='id'&&t.ignoreCase==='quirks'?1e6:1e3):t.type==='tag'||t.type==='pseudo-element'?1:t.type==='pseudo'?(t.name==='where'?0:Array.isArray(t.data)?Math.max(...t.data.map(specificity)):1e3):0),0);}
function rulesFor(app,route){
 return [...app.document.querySelectorAll('style,link[rel=stylesheet]')].flatMap(el=>{
  const href=el.getAttribute('href');
  return [...parseCSS(href?readFileSync(href.startsWith('/')?path.join('.',href):path.join(route,href),'utf8'):el.textContent).cssRules];
 });
}
function authored(rules,el,property,width=390){
 let value='',priority=-1;
 function visit(list){for(const rule of list){
  if(rule.media){
   const media=rule.media.mediaText;
   const min=media.match(/min-width:\s*(\d+)px/),max=media.match(/max-width:\s*(\d+)px/);
   if(/prefers-reduced-motion/.test(media)||(min&&width<+min[1])||(max&&width>+max[1]))continue;
   visit(rule.cssRules);continue;
  }
  if(!rule.selectorText||!rule.style.getPropertyValue(property))continue;
  for(const tokens of parseSelector(rule.selectorText)){
   if(tokens.some(t=>t.type==='pseudo-element'))continue;
   const selector=stringify([tokens]);
   if(!el.matches(selector))continue;
   const score=specificity(tokens)+(rule.style.getPropertyPriority(property)==='important'?1e9:0);
   if(score>=priority){priority=score;value=rule.style.getPropertyValue(property);}
  }
 }}visit(rules);return value;
}

const checks=[];
let app=await mount('area-51/prospect-51');
try{
 const primary=app.$('primary-move'),rules=rulesFor(app,'area-51/prospect-51');
 const legacy=[...parseCSS('body[data-game=prospect] .hold{pointer-events:none}body[data-game=prospect] .action-row{grid-template-columns:1fr 1fr}').cssRules];
 assert.equal(authored(legacy,app.$('hold-0'),'pointer-events'),'none');
 for(const width of [320,390,500,1060]){
  assert.equal(authored([...legacy,...rules],app.$('hold-0'),'pointer-events',width),'auto');
  assert.equal(authored([...legacy,...rules],primary.parentElement,'grid-template-columns',width),'minmax(0,1fr)');
  assert.equal(authored(rules,primary,'width',width),'100%');
  assert.equal(authored(rules,primary,'height',width),'48px');
 }
 checks.push('The current stylesheet overrides the reported click-blocking Hold rule and two-column primary row at all four reviewed CSS breakpoints');
 assert.equal(primary.dataset.action,'spin');await app.click(primary);
 const before=await app.wallet(),hand=before.apps.prospect51.state.round.hand.slice();
 await app.click('#hold-0');assert.equal(app.$('hold-0').getAttribute('aria-pressed'),'true');assert(app.$('rotor-0').classList.contains('held'));
 await app.click('#hold-0');assert.equal(app.$('hold-0').getAttribute('aria-pressed'),'false');assert(!app.$('rotor-0').classList.contains('held'));
 await app.click('#hold-0');await app.click('#hold-4');
 assert.equal((await app.wallet()).balanceCents,before.balanceCents);assert.equal(primary.textContent,'Draw 3 · free');
 assert.equal(app.$('primary-move'),primary);assert(!primary.classList.contains('primary'));
 await app.click(primary);const after=await app.wallet();
 assert.equal(after.apps.prospect51.state.round.hand[0],hand[0]);assert.equal(after.apps.prospect51.state.round.hand[4],hand[4]);
 assert.equal(after.apps.prospect51.state.phase,'settled');assert.equal(primary.dataset.action,'spin');assert(primary.classList.contains('primary'));assert.equal(app.$('primary-move'),primary);
 checks.push('Direct Hold and Release update the saved hand without charge; the same primary button draws three cards while preserving both held identities');
}finally{app.close();}

app=await mount('area-51/blackjack-51');
try{
 const saved=(await app.wallet()).apps.blackjack.state.engine;
 let seed;
 for(let i=0;i<100;i++){const candidate='empty-bank-double-'+i,e=app.window.BJ51.Engine.replay(saved);e.configure({...e.options,seed:candidate});e.start(8);if(e.active()){seed=candidate;break;}}
 assert(seed);app.$('setting-seed').value=seed;await app.click('#new-session');await app.click('[data-bet="8"]');await app.click('#deal');
 assert.equal((await app.wallet()).balanceCents,0);assert(!app.$('double').hidden);assert(app.$('double').disabled);
 const legacy=[...parseCSS('body[data-game=blackjack] #double,body[data-game=blackjack] #split{display:none}').cssRules];
 const rules=[...legacy,...rulesFor(app,'area-51/blackjack-51')];
 assert.equal(authored(legacy,app.$('double'),'display'),'none');
 for(const id of ['hit','stand','double'])assert.equal(authored(rules,app.$(id),'display'),'block');
 await app.click('#stand');assert(app.$('double').hidden);assert.equal(authored(rules,app.$('double'),'display'),'none');
 checks.push('Double remains in the active three-button row at zero balance, overrides the old hiding rule, and still honors hidden state after settlement');
}finally{app.close();}

app=await mount('area-51/telescope-51');
try{
 const names=[...app.document.querySelectorAll('.depth-button .rule-name')];
 assert.deepEqual(names.map(n=>n.textContent),['Value','Rank','Color','Suit']);
 for(const n of names)assert.equal(n.querySelector('strong').textContent,n.textContent[0]);
 const rules=rulesFor(app,'area-51/telescope-51');
 for(const n of names){assert.equal(authored(rules,n,'white-space',320),'nowrap');assert.equal(authored(rules,n.querySelector('strong'),'display',320),'inline');}
 checks.push('Rule names contain one emphasized initial and one unbroken word, with gross awards on their separate line');
}finally{app.close();}

for(const route of ['invariant','blackjack-51','telescope-51','memory-51','prospect-51']){
 app=await mount('area-51/'+route);
 try{
  assert.equal(app.document.body.dataset.uiVersion,['telescope-51','prospect-51'].includes(route)?'2.6.0':'2.5.0');
  const hrefs=[...app.document.querySelectorAll('link[rel=stylesheet]')].map(n=>n.getAttribute('href'));
  assert(hrefs.includes('/area-51/assets/card-ui-v2-5.css'));assert(!hrefs.includes('/area-51/assets/card-ui-v2-3.css'));
  if(['invariant','telescope-51','memory-51'].includes(route))assert(app.loadedModules.includes('area-51/'+route+'/app-v2-5.js'));
 }finally{app.close();}
}
checks.push('All five pages request the new shared CSS and the changed applications use v2.5 URLs');
writeFileSync('tests/v2_6/results/V26_CONTROL_CHECKS.json',JSON.stringify({passed:checks.length,scope:'In-memory interaction and authored CSS cascade checks. No native hit testing, visual rendering, or device claim.',checks},null,2));
console.log(checks.length+' v2.6 control regression checks passed.');process.exit();
