// v1.13 entry point retained; the v2 checkpoint suite is authoritative.
await import('../v2/check.mjs');
