#!/usr/bin/env python3
"""Compatibility entry point for the scoped v2 review checks; npm ci in tests/v2 first."""
from pathlib import Path
import subprocess
raise SystemExit(subprocess.call(["node", str(Path(__file__).resolve().parents[1] / "v2" / "check.mjs")]))
