// v2.8.0 link check: every local href/src in the given HTML/MD files must resolve to a file in the site tree.
// Usage (from the site root): node tests/v2_8/link_check.cjs file1.html file2.md ...
'use strict';
const fs = require('fs'), path = require('path');
const root = process.cwd(), bad = [], seen = [];
for (const rel of process.argv.slice(2)) {
  const file = path.join(root, rel), text = fs.readFileSync(file, 'utf8');
  const refs = [...text.matchAll(/\b(?:href|src)="([^"]+)"/g)].map(m => m[1])
    .concat(rel.endsWith('.md') ? [...text.matchAll(/\]\(([^)\s]+)\)/g)].map(m => m[1]) : []);
  for (let ref of refs) {
    if (/^(https?:|mailto:|data:|#|javascript:)/.test(ref)) continue;
    ref = ref.replace(/[?#].*$/, ''); if (!ref) continue;
    let target = ref.startsWith('/') ? path.join(root, ref) : path.resolve(path.dirname(file), ref);
    if (ref.endsWith('/') || (fs.existsSync(target) && fs.statSync(target).isDirectory())) target = path.join(target, 'index.html');
    seen.push(rel + ' → ' + ref);
    if (!fs.existsSync(target)) bad.push(rel + ' → ' + ref);
  }
}
console.log(JSON.stringify({ filesChecked: process.argv.length - 2, localRefs: seen.length, broken: bad }, null, 1));
process.exit(bad.length ? 1 : 0);
