const fs = require('fs');
const vm = require('vm');

const sourcePath = process.argv[2];
if (!sourcePath) throw new Error('usage: node test_overnight_collapsed_renderer.js JS');

const source = fs.readFileSync(sourcePath, 'utf8');
const sandbox = {
  window: { __CG_FINANCE_TEST__: true },
  document: { querySelector: () => null },
  localStorage: { getItem: () => null, setItem: () => {} },
  navigator: {},
  console,
  setTimeout,
  clearTimeout,
  setInterval,
  clearInterval,
  fetch: async () => { throw new Error('network disabled in renderer unit test'); }
};
vm.createContext(sandbox);
vm.runInContext(source, sandbox, { filename: sourcePath });

const api = sandbox.window.PhiFinanceV2._test;
const codes = [
  'UTILITIES','REAL_ESTATE','FOOD','HEALTHCARE','DEFENSE','BANKS','MACRO_ETF','TELECOM',
  'ENERGY','MATERIALS','AI_BIG','MEDIA','AI_SEMIS','INDUSTRIALS','AUTOS_EV','RETAIL'
];
const now = Date.now();

function assert(condition, message) {
  if (!condition) throw new Error(message);
}
function base() {
  return api.normFuture({
    generated_at_utc: new Date(now - 5 * 60 * 1000).toISOString(),
    session: 'REGULAR',
    data_state: 'CURRENT',
    chambers: codes.map((sector_code, index) => ({
      sector_code,
      median_bps: index + 1,
      avg_bps: index + 1.2,
      net_breadth: index % 3 - 1,
      fresh_ratio: 1
    }))
  });
}
function overlay(ageMs = 60 * 1000, patch = {}) {
  return {
    ledger: 'TEST_OVERNIGHT',
    created_utc: new Date(now - ageMs).toISOString(),
    session: 'OVERNIGHT',
    active: true,
    status: 'OK',
    provider: 'ALPACA',
    feed: 'OVERNIGHT_DERIVED',
    quote_state: 'REALTIME_INDICATIVE',
    coverage_scope: 'NON_CONSOLIDATED',
    global_fresh_count: 120,
    global_expected_count: 144,
    global_coverage_ratio: 120 / 144,
    global_coverage_grade: 'USABLE_PARTIAL',
    chambers: codes.map((sector_code, index) => ({
      sector_code,
      overlay_median_bps: (index + 1) * -2.5,
      fresh_count: 7,
      expected_count: 8,
      coverage_grade: 'USABLE_PARTIAL'
    })),
    ...patch
  };
}

const fresh = overlay();
assert(api.freshOvernight(fresh, now), 'fresh OK overnight output should activate');
const overnight = api.normOverlay(base(), fresh, now);
api.setData(overnight);
assert(api.overlayPlateActive(), 'page should enter automatic overnight mode');
assert(overnight.session === 'OVERNIGHT', 'overnight mode should own the public session label');
assert(overnight.dataState === 'OVERNIGHT', 'overnight mode should own the data state');
assert(overnight.generated === fresh.created_utc, 'freshness should follow the overnight output timestamp');
assert(overnight.provider === 'ALPACA', 'overnight provider should be shown');
for (const c of overnight.chambers) {
  assert(api.cellValue(c) === c.overnight, `${c.code}: tile should show overnight BPS`);
  assert(api.cellSubline(c) === '', `${c.code}: overnight tile should not mention the close`);
}

const stale = api.normOverlay(base(), overlay(20 * 60 * 1000 + 1), now);
api.setData(stale);
assert(!api.overlayPlateActive(), 'overlay older than 20 minutes must not remain active');
assert(stale.session === 'REGULAR', 'stale overlay must not replace the base session');
assert(stale.chambers.every(c => api.cellValue(c) === c.base), 'stale overlay must not replace base values');

for (const [name, candidate] of [
  ['inactive', overlay(1000, { active: false })],
  ['wrong session', overlay(1000, { session: 'REGULAR' })],
  ['error status', overlay(1000, { status: 'OVERLAY_ERROR_BASE_PRESERVED' })],
  ['missing timestamp', overlay(1000, { created_utc: '' })],
  ['no readings', overlay(1000, { chambers: codes.map(sector_code => ({ sector_code, overlay_median_bps: null })) })]
]) {
  assert(!api.freshOvernight(candidate, now), `${name} output must fail closed`);
}


const limited = overlay(1000, { global_fresh_count: 81, global_expected_count: 156, global_coverage_ratio: 81/156, global_coverage_grade: 'REJECT' });
assert(api.freshOvernight(limited, now), 'fresh overnight values should activate teal mode even when global coverage is limited');
const limitedPlate = api.normOverlay(base(), limited, now);api.setData(limitedPlate);
assert(api.overlayPlateActive(), 'limited-coverage overnight plate should remain visibly overnight');

const expired = api.normOverlay(base(), fresh, now);
api.deactivateOvernight(expired);
assert(!expired.overnightActive, 'expired overnight mode should deactivate immediately');
assert(expired.session === 'REGULAR', 'deactivation should restore the regular session context');
assert(expired.dataState === 'CURRENT', 'deactivation should restore the regular data state');

assert(!/official close/i.test(source), 'official-close copy should not return');
assert(!/Δ vs base/.test(source), 'overnight renderer should not compare against the close');
assert(source.includes('overnight-label'), 'tiles need the teal overnight label');

console.log(JSON.stringify({
  pass: true,
  active_mode: 'OVERNIGHT',
  chambers: overnight.chambers.length,
  freshness_limit_minutes: 20,
  stale_and_error_cases_fail_closed: true,
  limited_coverage_stays_visible: true,
  close_comparison_removed: true
}, null, 2));
