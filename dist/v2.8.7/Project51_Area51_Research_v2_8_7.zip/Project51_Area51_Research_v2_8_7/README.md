# Project 51: Reading the Record Across Rules -- Area 51 research files (site v2.8.7)

Jeffery Lyn Huckstead, Cerebral Graphix, 2026. DOI 10.5281/zenodo.23004789. CC BY 4.0. RH STATUS: OPEN.

Paths mirror the site, so every verifier runs in place from this folder:

- area-51/sedaps-51/        51 SEDAPS v0.4.1: research update, certificates, verifiers, receipts
- area-51/sedaps-51/independent/   independent replays, censuses, the three-live loop programs
- area-51/twins-51/         51 Twins v1: exhibit page, data, builder, verifier, calibration, evidence
- area-51/prospect-51/data.js, engine.js   the Prospect 51 engine the Twins verifier reads
- research/project-51/formula51/   Formula 51 band and deduction, with its independent check

Quick checks (Node 18+, Python 3):
    node area-51/twins-51/verify-twins-v1.cjs
    node area-51/twins-51/build-twins-page-v1.cjs
    node area-51/sedaps-51/independent/live3_construct_check.cjs
    python3 area-51/sedaps-51/independent/live3_rigid_period.py
    python3 research/project-51/formula51/f51_independent.py research/project-51/formula51/f51_band.json   (about 2 minutes)
Longer runs are listed in area-51/sedaps-51/independent/README.md.
